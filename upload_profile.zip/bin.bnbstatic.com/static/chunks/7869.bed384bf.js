"use strict";
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "54823dff-72a6-55da-97dc-2fbd7f08341f")
    } catch (e) {}
}();
(self.webpackChunkc2c_user_ui = self.webpackChunkc2c_user_ui || []).push([
    [7869], {
        seJA: (e, s, t) => {
            t.d(s, {
                A: () => r
            });
            var a = t("BK7R"),
                n = t("TrCV"),
                l = t("C6y2"),
                c = t("cKr8");

            function r(e) {
                var s = e.sx,
                    t = void 0 === s ? {} : s,
                    r = e.iconSize,
                    i = void 0 === r ? 48 : r;
                return (0, n.jsx)(l.A, {
                    sx: (0, a.A)({
                        width: "100%",
                        pt: "80px",
                        pb: "80px"
                    }, t),
                    children: (0, n.jsx)(c.A, {
                        size: i,
                        m: "auto"
                    })
                })
            }
        },
        kjWw: (e, s, t) => {
            t.r(s), t.d(s, {
                default: () => ve
            });
            var a = t("TrCV"),
                n = t("Lp65"),
                l = t("5njO"),
                c = t("8v/2"),
                r = t("fU5Q"),
                i = t("DTvD"),
                o = t.n(i),
                p = t("f2u4"),
                d = t("eeEA"),
                u = t("wIZF"),
                x = t("Y4uf");
            const m = function(e) {
                return o().createElement(x.A, (0, u.__assign)({
                    viewBox: "0 0 96 96",
                    fill: "none"
                }, e), o().createElement("path", {
                    opacity: .5,
                    d: "M58 12.002l16 16H58v-16z",
                    fill: "#929AA5"
                }), o().createElement("path", {
                    opacity: .15,
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M22 12.002h36v16h16v56H22v-72zm6 19.997h40v4H28v-4zm0 8h12.248a16.074 16.074 0 00-4.74 4H28v-4zm32.49 4a16.076 16.076 0 00-4.739-4H68v4H60.49zm-32.49 4h5.163a15.891 15.891 0 00-1.04 4H28v-4zm34.837 0c.51 1.261.864 2.603 1.039 4h4.123v-4h-5.162zm-34.838 8h4.124a15.891 15.891 0 001.04 4H28v-4zm35.877 0a15.891 15.891 0 01-1.04 4H68v-4h-4.123zm-35.876 8h7.509a16.074 16.074 0 004.739 4H28v-4zm32.49 0a16.074 16.074 0 01-4.739 4H68v-4H60.49zm7.51 8v4H28v-4h40z",
                    fill: "#929AA5"
                }), o().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M48 65.999c6.627 0 12-5.373 12-12s-5.373-12-12-12c-6.628 0-12 5.373-12 12s5.372 12 12 12zm0-16.8l-4.8 4.8 4.8 4.8 4.8-4.8-4.8-4.8z",
                    fill: "#F0B90B"
                }))
            };
            const f = function(e) {
                return o().createElement(x.A, (0, u.__assign)({
                    viewBox: "0 0 96 96",
                    fill: "none"
                }, e), o().createElement("path", {
                    opacity: .15,
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M35.545 88c-4.668-.013-10.028-1.867-15.545-7.384V52.001h23.7l14.49 14.49a9.261 9.261 0 01-13.097 0l-6.194-6.194-2.019 2.018 9.606 9.71h29.515c0 8.816-7.148 15.964-15.965 15.964l-24.261.012h-.23z",
                    fill: "#929AA5"
                }), o().createElement("path", {
                    opacity: .5,
                    d: "M8 52h12v36H8V52z",
                    fill: "#929AA5"
                }), o().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M68 12c11.045 0 20 8.954 20 20s-8.955 20-20 20c-11.046 0-20-8.954-20-20s8.954-20 20-20zm0 28l-8-8 8-8 8 8-8 8z",
                    fill: "#F0B90B"
                }))
            };
            const h = function(e) {
                return o().createElement(x.A, (0, u.__assign)({
                    viewBox: "0 0 96 96",
                    fill: "none"
                }, e), o().createElement("path", {
                    opacity: .15,
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M84 44H12v40h72V44zM48 61.998l-8-8 8-8 8 8-8 8z",
                    fill: "#929AA5"
                }), o().createElement("path", {
                    opacity: .5,
                    d: "M30 8h36L48 26 30 8z",
                    fill: "#929AA5"
                }), o().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M48 33.999c11.045 0 20 8.954 20 20s-8.955 20-20 20c-11.046 0-20-8.954-20-20s8.954-20 20-20zm0 28l-8-8 8-8 8 8-8 8z",
                    fill: "#F0B90B"
                }))
            };
            var b = t("SK1U");
            const v = function(e) {
                return o().createElement(x.A, (0, u.__assign)({
                    viewBox: "0 0 96 96",
                    fill: "none"
                }, e), o().createElement("path", {
                    opacity: .15,
                    d: "M12 40h72v44H12V40z",
                    fill: "#929AA5"
                }), o().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M48 16c7.731 0 14 6.268 14 14S55.73 44 48 44c-7.733 0-14-6.268-14-14s6.267-14 14-14zm0 20l-6-6 6-6 6 6-6 6zM69.999 52c5.522 0 10 4.477 10 10s-4.478 10-10 10c-5.523 0-10-4.477-10-10s4.477-10 10-10zm0 14.286L65.713 62l4.286-4.286L74.284 62 70 66.286zM27.998 64c6.628 0 12 5.373 12 12 0 6.628-5.372 12-12 12-6.627 0-12-5.372-12-12 0-6.627 5.373-12 12-12zm0 17.144L22.857 76l5.143-5.143L33.14 76 28 81.144z",
                    fill: "#F0B90B"
                }))
            };
            var y, w = t("HcTV"),
                g = p.A.TabPane,
                A = function(e) {
                    var s = e.image,
                        t = e.title,
                        n = e.description;
                    return (0, a.jsxs)(d.Ay, {
                        className: "border border-line rounded-[24px] px-xl py-5xl",
                        children: [(0, a.jsx)(d.Ay, {
                            className: "mb-xl",
                            children: s
                        }), (0, a.jsx)(d.Ay, {
                            className: "headline5 mb-m",
                            children: t
                        }), (0, a.jsx)(d.Ay, {
                            className: "body3 text-secondaryText",
                            children: n
                        })]
                    })
                };

            function j() {
                var e = (0, w.Ay)().t,
                    s = (0, i.useState)(0),
                    t = s[0],
                    l = s[1];
                return (0, a.jsxs)(d.Ay, {
                    className: "container",
                    children: [(0, a.jsxs)(n.A, {
                        className: "mobile:flex-col noMob:flex-row mobile:mb-xl tablet:mb-3xl pc:mb-3xl justify-between",
                        children: [(0, a.jsx)(d.Ay, {
                            className: "mobile:headline3 tablet:headline2 pc:headline1",
                            children: e("c2c-user-seo-how-p2p-work-title")
                        }), (0, a.jsxs)(p.A, {
                            variant: "primary-gray",
                            className: "[&_.bn-tab]:rounded-m w-fit mobile:mt-3xl",
                            selectedIndex: t,
                            onChange: function(e) {
                                l(e)
                            },
                            children: [(0, a.jsx)(g, {
                                tabNode: (0, a.jsx)(d.Ay, {
                                    className: "subtitle2",
                                    children: e("c2c-user-seo-how-p2p-work-tab-buy")
                                })
                            }), (0, a.jsx)(g, {
                                tabNode: (0, a.jsx)(d.Ay, {
                                    className: "subtitle2",
                                    children: e("c2c-user-seo-how-p2p-work-tab-sell")
                                })
                            })]
                        })]
                    }), (0, a.jsx)(d.Ay, {
                        className: "grid mobile:grid-cols-1 mobile:gap-l tablet:grid-cols-2 tablet:gap-xl pc:grid-cols-3 pc:gap-m",
                        children: 0 === t ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)(A, {
                                image: (0, a.jsx)(m, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: e("c2c-user-express-seo-how-p2p-work-buy-title-step1"),
                                description: e("c2c-user-seo-how-p2p-work-buy-desc-step1")
                            }), (0, a.jsx)(A, {
                                image: (0, a.jsx)(f, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: e("c2c-user-express-seo-how-p2p-work-buy-title-step2"),
                                description: e("c2c-user-seo-how-p2p-work-buy-desc-step2")
                            }), (0, a.jsx)(A, {
                                image: (0, a.jsx)(h, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: e("c2c-user-express-seo-how-p2p-work-buy-title-step3"),
                                description: e("c2c-user-seo-how-p2p-work-buy-desc-step3")
                            })]
                        }) : (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)(A, {
                                image: (0, a.jsx)(m, {
                                    className: "w-[96px] h-[96px]",
                                    name: "Document"
                                }),
                                title: e("c2c-user-express-seo-how-p2p-work-sell-title-step1"),
                                description: e("c2c-user-seo-how-p2p-work-sell-desc-step1")
                            }), (0, a.jsx)(A, {
                                image: (0, a.jsx)(b.A, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: e("c2c-user-express-seo-how-p2p-work-sell-title-step2"),
                                description: e("c2c-user-seo-how-p2p-work-sell-desc-step2")
                            }), (0, a.jsx)(A, {
                                image: (0, a.jsx)(v, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: e("c2c-user-express-seo-how-p2p-work-sell-title-step3"),
                                description: e("c2c-user-seo-how-p2p-work-sell-desc-step3")
                            })]
                        })
                    })]
                })
            }! function(e) {
                e[e.Buy = 0] = "Buy", e[e.Sell = 1] = "Sell"
            }(y || (y = {}));
            var N = t("zUKr"),
                k = function(e) {
                    var s = e.icon,
                        t = e.title,
                        n = e.description,
                        l = (0, c.r)().blockHeader;
                    return (0, a.jsxs)(d.Ay, {
                        children: [(0, a.jsx)(d.Ay, {
                            as: "img",
                            src: "".concat(N.K5, "/static/images/c2c/user/").concat(s, ".svg"),
                            alt: s,
                            className: "mb-m w-[32px] h-[32px]"
                        }), (0, a.jsx)(d.Ay, {
                            className: "subtitle1 mb-2xs",
                            children: t
                        }), !l && (0, a.jsx)(d.Ay, {
                            className: "body2 text-secondaryText",
                            children: n
                        })]
                    })
                };
            const q = function() {
                var e = (0, w.Ay)().t,
                    s = (0, c.r)().blockHeader;
                return (0, a.jsxs)(d.Ay, {
                    className: "container",
                    children: [(0, a.jsx)(d.Ay, {
                        className: "mobile:headline3 tablet:headline2 pc:headline1",
                        children: e(s ? "c2c-user-seo-title" : "c2c-user-seo-advantages-title")
                    }), (0, a.jsxs)(d.Ay, {
                        className: "mt-3xl block pc:grid grid-cols-[1fr,max-content] gap-[80px]",
                        children: [(0, a.jsxs)(n.A, {
                            className: "flex-col gap-3xl",
                            children: [(0, a.jsx)(k, {
                                icon: "online-banking-2c-wht",
                                title: e("c2c-user-seo-advantages-market-place-title"),
                                description: e("c2c-user-seo-advantages-market-place-description")
                            }), (0, a.jsx)(k, {
                                icon: "convert-coins-2c-wht",
                                title: e("c2c-user-seo-advantages-subtitle2"),
                                description: e("c2c-user-seo-advantages-flexible-payment-description")
                            }), (0, a.jsx)(k, {
                                icon: "spend-to-earn-2c-blk",
                                title: e("c2c-user-seo-advantages-subtitle3"),
                                description: e("c2c-user-seo-advantages-preferred-price-description")
                            })]
                        }), (0, a.jsx)(n.A, {
                            className: "justify-center w-[530px] noPc:hidden",
                            children: (0, a.jsx)(d.Ay, {
                                as: "img",
                                src: "".concat(N.K5, "/static/images/c2c/p2p-landing-page-advantage.svg"),
                                className: "w-[530px] h-[540px]",
                                loading: "lazy",
                                alt: "binance p2p advantage"
                            })
                        })]
                    })]
                })
            };
            var z = t("sViW"),
                B = t("0GOp"),
                M = t.n(B),
                T = t("Q755"),
                L = t("wgY5"),
                S = t.n(L),
                E = t("YWmI"),
                _ = t("Mtrz"),
                D = t("nocm"),
                R = t("yct4"),
                C = t("DkGs"),
                H = t("seJA"),
                P = t("V3BA"),
                F = t("+bTb"),
                I = "".concat(N.K5, "/static/images/blog/default-banner.png"),
                K = function(e) {
                    var s = e.data,
                        t = (0, w.Ay)().t,
                        n = (0, R.Xo)(),
                        l = s.title,
                        c = s.banner,
                        r = s.brief,
                        o = s.postTime,
                        p = s.masterCategory,
                        u = s.idStr,
                        x = (0, i.useMemo)((function() {
                            var e;
                            return e = (null === p || void 0 === p ? void 0 : p.name) ? /\d{18}/.test(p.name) ? "cat-".concat(p.name) : p.name : t ? "All" : "all", "".concat(D.A.MAIN_HOST, "/").concat(n, "/blog/").concat((0, C.gL)(e), "/").concat((0, C.gL)(l), "-").concat(u)
                        }), [n, t, u, p, l]),
                        m = (0, i.useMemo)((function() {
                            if (!c) return I;
                            try {
                                var e = JSON.parse(c);
                                return null === e || void 0 === e ? void 0 : e.bannerUrl
                            } catch (s) {
                                return console.warn("Banner JSON('".concat(c, "') parse error:"), s.message), I
                            }
                        }), [c]);
                    return (0, a.jsxs)(d.Ay, {
                        as: "a",
                        href: x,
                        target: "_blank",
                        className: "no-underline",
                        children: [(0, a.jsx)(d.Ay, {
                            className: "w-full rounded-m overflow-hidden mb-xl mobile:h-[193px] tablet:h-[198px] pc:h-[207px]",
                            children: (0, a.jsx)(d.Ay, {
                                as: "img",
                                src: m,
                                className: "w-full h-full object-cover rounded-[24px]",
                                alt: l
                            })
                        }), (0, a.jsx)(d.Ay, {
                            className: "subtitle4 text-primaryText mb-m",
                            children: l
                        }), (0, a.jsx)(d.Ay, {
                            className: "body3 text-secondaryText mb-m",
                            children: r
                        }), (0, a.jsx)(d.Ay, {
                            className: "subtitle2 text-secondaryText",
                            children: S()(o, "x").format("YYYY-MM-DD")
                        })]
                    })
                },
                O = function(e) {
                    var s = e.data;
                    return e.isLoading ? (0, a.jsx)(H.A, {}) : (0, a.jsx)(d.Ay, {
                        className: "grid gap-xl mobile:grid-cols-1 tablet:grid-cols-2 pc:grid-cols-3 ",
                        children: s.map((function(e) {
                            return (0, a.jsx)(K, {
                                data: e
                            }, e.id)
                        }))
                    })
                };
            const V = function() {
                var e = (0, w.Ay)().t,
                    s = function() {
                        var e = (0, i.useState)(!1),
                            s = e[0],
                            t = e[1],
                            a = (0, i.useState)([]),
                            n = a[0],
                            l = a[1],
                            c = (0, R.Xo)(),
                            r = function() {
                                var e = (0, z.A)(M().mark((function e() {
                                    var s, a, n, r;
                                    return M().wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return t(!0), e.next = 3, (0, F.Rk)(P.A.GET_BLOGS, {
                                                    category: 4,
                                                    page: 1,
                                                    size: 3,
                                                    lang: c
                                                });
                                            case 3:
                                                s = e.sent, a = s.success, n = s.data, a && n && l(null !== (r = null === n || void 0 === n ? void 0 : n.blogList) && void 0 !== r ? r : []), t(!1);
                                            case 8:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e)
                                })));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }();
                        return {
                            isLoading: s,
                            blogList: n,
                            fetchLastestP2PBlogs: r
                        }
                    }(),
                    t = s.blogList,
                    l = s.isLoading,
                    c = s.fetchLastestP2PBlogs;
                return (0, T.A)((function() {
                    c()
                })), (0, a.jsxs)(d.Ay, {
                    className: "container",
                    children: [(0, a.jsxs)(n.A, {
                        className: "justify-between mb-3xl",
                        children: [(0, a.jsx)(d.Ay, {
                            className: "mobile:headline3 tablet:headline2 pc:headline1",
                            children: e("c2c-ui-blog-label")
                        }), (0, a.jsxs)(E.A, {
                            path: "/blog/p2p",
                            target: "_blank",
                            subDomain: "www",
                            className: "subtitle1 text-primaryText no-underline flex self-center items-center",
                            children: [e("c2c-fee-sys-view-more"), (0, a.jsx)(_.A, {
                                className: "mt-px w-[24px] h-[24px]"
                            })]
                        })]
                    }), (0, a.jsx)(O, {
                        data: t,
                        isLoading: l
                    })]
                })
            };
            var W = t("BK7R"),
                G = t("QUKP"),
                Y = t("gZfF"),
                U = t("JgEn"),
                J = t("3fwp"),
                Q = function(e) {
                    var s = e.color,
                        t = e.name,
                        l = (0, Y.A)(e, ["color", "name"]);
                    return (0, a.jsx)(U.A, {
                        tooltips: t,
                        arrow: !0,
                        className: "[&_.bn-tooltips-ele]:w-full w-full",
                        children: (0, a.jsxs)(n.A, (0, G.A)((0, W.A)({
                            className: "py-m tablet:py-xl px-4xl w-full h-max items-center overflow-hidden text-ellipsis border border-line rounded-[12px] cursor-pointer no-underline text-primaryText hover:bg-BasicBg"
                        }, l), {
                            children: [(0, a.jsx)(d.Ay, {
                                className: "w-[4px] h-[14px] rounded-default mr-s flex-none",
                                style: {
                                    background: s
                                }
                            }), (0, a.jsx)(d.Ay, {
                                className: "subtitle1 whitespace-nowrap overflow-hidden overflow-ellipsis",
                                "aria-labelledby": t,
                                children: t
                            })]
                        }))
                    })
                };
            const Z = function(e) {
                var s, t, n = e.asset,
                    l = e.fiat,
                    c = e.tradeArea,
                    r = (0, w.Ay)().t,
                    o = (0, R.Xo)(),
                    p = (0, J.Nz)({
                        fiat: l,
                        tradeArea: c
                    }),
                    u = (0, i.useMemo)((function() {
                        var e, s, t, a;
                        return null === (t = null !== (a = null === p || void 0 === p || null === (e = p.data) || void 0 === e || null === (s = e.data) || void 0 === s ? void 0 : s.tradeMethods) && void 0 !== a ? a : []) || void 0 === t ? void 0 : t.slice(0, 9).map((function(e) {
                            var s, t, a = "/trade/".concat(e.identifier);
                            return n && (a += "/".concat(n)), l && (a += "?fiat=".concat(l)), (0, G.A)((0, W.A)({}, e), {
                                tradeMethodBgColor: null === (s = e) || void 0 === s ? void 0 : s.tradeMethodBgColor,
                                tradeMethodName: null === (t = e) || void 0 === t ? void 0 : t.tradeMethodName,
                                tradeLink: a
                            })
                        }))
                    }), [null === p || void 0 === p || null === (s = p.data) || void 0 === s ? void 0 : s.data, o, n, l]);
                return (0, a.jsxs)(d.Ay, {
                    className: "container",
                    children: [(0, a.jsx)(d.Ay, {
                        className: "mobile:headline3 tablet:headline2 pc:headline1",
                        children: r("c2c-user-seo-top-payment-title")
                    }), (0, a.jsx)(d.Ay, {
                        className: "mt-3xl grid mobile:gap-y-l noMob:gap-y-3xl gap-x-xl mobile:grid-cols-1 tablet:grid-cols-2 pc:grid-cols-4",
                        children: u.map((function(e) {
                            return (0, a.jsx)(E.A, {
                                path: e.tradeLink,
                                target: "_blank",
                                children: (0, a.jsx)(Q, {
                                    identifier: e.identifier,
                                    color: e.tradeMethodBgColor,
                                    name: null !== (t = e.tradeMethodName) && void 0 !== t ? t : e.identifier
                                })
                            }, e.identifier)
                        }))
                    })]
                })
            };
            var X = t("ezuS");
            const $ = function(e) {
                return o().createElement(x.A, (0, u.__assign)({
                    viewBox: "0 0 24 24",
                    fill: "none"
                }, e), o().createElement("path", {
                    d: "M6.379 8.5l-1.94 1.94a6.45 6.45 0 109.122 9.12l1.939-1.939-2.121-2.121-1.94 1.94a3.45 3.45 0 01-4.878-4.88L8.5 10.622 6.379 8.5zM12.56 6.56a3.45 3.45 0 014.88 4.88l-1.94 1.939 2.121 2.121 1.94-1.94a6.45 6.45 0 10-9.122-9.12L8.5 6.378 10.621 8.5l1.94-1.94z",
                    fill: "currentColor"
                }), o().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M9.81 16.31l-2.12-2.12 6.5-6.5 2.12 2.12-6.5 6.5z",
                    fill: "currentColor"
                }))
            };
            var ee = t("ZSsA"),
                se = t("DzvH"),
                te = t("LcZo"),
                ae = t("jibv"),
                ne = t("7+bj"),
                le = t("YiNW"),
                ce = function(e) {
                    var s = e.children,
                        t = e.title,
                        n = e.defaultOpen,
                        l = void 0 !== n && n,
                        c = e.iconType,
                        r = void 0 === c ? "plus" : c,
                        o = e.opened,
                        p = e.onClick,
                        u = e.fullWidth,
                        x = void 0 === u || u,
                        m = e.sz,
                        f = void 0 === m ? "medium" : m,
                        h = e.openedClassName,
                        b = e.className,
                        v = (0, i.useState)(l),
                        y = v[0],
                        w = v[1];
                    (0, i.useEffect)((function() {
                        w(o)
                    }), [o]);
                    var g = "plus" === r ? se.A : te.A,
                        A = "plus" === r ? ae.A : ne.A;
                    return (0, a.jsxs)(d.Ay, {
                        className: (0, le.cn)("w-full", b),
                        children: [t && (0, a.jsxs)(d.Ay, {
                            className: (0, le.cn)("items-center cursor-pointer gap-4xs", (0, X.A)({
                                "grid grid-cols-[1fr,20px]": x,
                                "flex w-max": !x
                            }, h, y)),
                            onClick: function() {
                                p ? p() : w((function(e) {
                                    return !e
                                }))
                            },
                            children: [(0, a.jsx)(d.Ay, {
                                className: (0, le.cn)({
                                    "body2 tablet:subtitle1 pc:headline5": "large" === f,
                                    body2: "medium" === f
                                }),
                                children: t
                            }), y ? (0, a.jsx)(g, {
                                className: "w-[20px] h-[20px] transition-transform duration-300 ease-in-out text-primaryText"
                            }) : (0, a.jsx)(A, {
                                className: "w-[20px] h-[20px] transition-transform duration-300 ease-in-out text-primaryText"
                            })]
                        }), (0, a.jsx)(d.Ay, {
                            className: (0, le.cn)("body2", y && ("large" === f ? "mt-xl" : "mt-m"), {
                                "opacity-100 max-h-[100rem] transition-all ease-in-out duration-150": y,
                                "opacity-0 max-h-0 overflow-hidden transition-all ease-in-out duration-150 pb-0": !y
                            }),
                            children: s
                        })]
                    })
                };
            ce.displayName = "Accordion", ce.Group = function(e) {
                var s = e.children,
                    t = e.activeIndex,
                    n = e.iconType,
                    l = e.onChange,
                    c = e.fullWidth,
                    r = e.sz,
                    p = e.openedClassName,
                    u = e.className,
                    x = (0, Y.A)(e, ["children", "activeIndex", "iconType", "onChange", "fullWidth", "sz", "openedClassName", "className"]),
                    m = (0, i.useState)(t),
                    f = m[0],
                    h = m[1];
                (0, i.useEffect)((function() {
                    h(t)
                }), [t]);
                var b = o().Children.map(s, (function(e, s) {
                    return (0, i.cloneElement)(e, {
                        opened: s === f,
                        onClick: function() {
                            return function(e) {
                                h(e === f ? null : e), l(e)
                            }(s)
                        },
                        iconType: n,
                        fullWidth: c,
                        sz: r,
                        openedClassName: p
                    })
                }));
                return (0, a.jsx)(d.Ay, (0, G.A)((0, W.A)({
                    className: (0, le.cn)("flex gap-m flex-col", u)
                }, x), {
                    children: b
                }))
            };
            const re = ce;
            var ie, oe = p.A.TabPane;
            ! function(e) {
                e[e.Beginner = 0] = "Beginner", e[e.Advance = 1] = "Advance", e[e.Advertisers = 2] = "Advertisers"
            }(ie || (ie = {}));
            var pe = function(e) {
                    return "\u3010".concat(e, "\u3011")
                },
                de = function(e, s) {
                    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : ["\u3010", "\u3011"],
                        n = e.indexOf(t[0]),
                        l = e.indexOf(t[1]),
                        c = e.slice(0, n),
                        r = e.slice(l + 1, e.length),
                        i = e.slice(n + 1, l);
                    return n > -1 && l > -1 && "undefined" !== typeof s[0] ? (0, a.jsxs)(a.Fragment, {
                        children: [c, (0, a.jsx)(E.A, {
                            className: "text-textLink",
                            subDomain: "www",
                            path: s[0],
                            target: "_blank",
                            children: i
                        }), de(r, s.slice(1))]
                    }) : (0, a.jsx)(a.Fragment, {
                        children: e
                    })
                },
                ue = function(e) {
                    var s = e.title,
                        t = e.content,
                        n = e.link,
                        l = e.domain,
                        c = void 0 === l ? "www" : l;
                    return "undefined" !== typeof n ? (0, a.jsxs)(E.A, {
                        path: n,
                        target: "_blank",
                        className: "flex w-full justify-between items-center no-underline hover:text-textLink hover:underline hover:cursor-pointer",
                        subDomain: c,
                        children: [(0, a.jsx)(d.Ay, {
                            className: "mobile:body2 tablet:subtitle1 pc:headline5",
                            children: s
                        }), (0, a.jsx)($, {
                            className: "w-[16px] h-[16px] flex-shrink-0",
                            color: "primary"
                        })]
                    }) : (0, a.jsx)(re, {
                        sz: "large",
                        title: s,
                        children: t
                    })
                },
                xe = function(e) {
                    var s = e.faqList;
                    return (0, a.jsx)(n.A, {
                        className: "gap-xl px-m flex-col",
                        children: s.map((function(e, s) {
                            return (0, a.jsxs)(n.A, {
                                className: "hover:bg-SecondaryBg py-m",
                                children: [(0, a.jsx)(n.A, {
                                    className: "w-[24px] h-[24px] p-4xs border border-Line rounded-m justify-center items-center mt-4xs mr-m",
                                    children: s + 1
                                }), (0, a.jsx)(ue, (0, W.A)({}, e))]
                            }, e.title)
                        }))
                    })
                };
            const me = function(e) {
                var s, t = e.tradeMode,
                    n = (0, w.Ay)().t,
                    l = (0, i.useState)(0),
                    c = l[0],
                    r = l[1],
                    o = (0, i.useMemo)((function() {
                        return function(e, s) {
                            var t;
                            return t = {}, (0, X.A)(t, ie.Beginner, [{
                                title: e("c2c-user-seo-faqs-beginner-what-is-p2p-question"),
                                content: (0, a.jsx)(ee.x6, {
                                    t: e,
                                    i18nKey: "c2c-user-seo-faqs-beginner-what-is-p2p-answer-ver2",
                                    components: {
                                        l: (0, a.jsx)(E.A, {
                                            className: "text-textLink",
                                            target: "_blank",
                                            subDomain: "www",
                                            path: "/blog/p2p/intro-to-peertopeer-trading-what-is-p2p-trading-and-how-does-a-local-bitcoin-exchange-work-421499824684901839"
                                        })
                                    }
                                })
                            }, {
                                title: e("c2c-user-seo-faqs-beginner-question2"),
                                content: (0, a.jsx)(ee.x6, {
                                    t: e,
                                    i18nKey: "c2c-user-seo-faqs-beginner-solution2-v4",
                                    components: {
                                        l1: (0, a.jsx)(E.A, {
                                            className: "text-textLink",
                                            target: "_blank",
                                            subDomain: "www",
                                            path: "/support/faq/how-to-sell-cryptocurrency-on-binance-p2p-website-360041106311"
                                        }),
                                        l2: (0, a.jsx)(E.A, {
                                            className: "text-textLink",
                                            target: "_blank",
                                            subDomain: "www",
                                            path: "/support/faq/how-to-sell-cryptocurrency-via-p2p-cash-trade-zone-on-binance-app-281b12d4a7c34598b3403eb7299663bc"
                                        })
                                    }
                                })
                            }, {
                                title: e("express" === s ? "c2c-user-seo-faqs-beginner-support-currency-in-express-zone-question" : "c2c-user-seo-faqs-beginner-support-currency-in-trade-zone-question"),
                                content: de(e("express" === s ? "c2c-user-seo-faqs-beginner-support-currency-in-express-zone-answer" : "c2c-user-seo-faqs-beginner-support-currency-in-trade-zone-answer", {
                                    "bitcoin-link": pe(e("c2c-user-seo-faqs-btc-link")),
                                    "ethereum-link": pe(e("c2c-user-seo-faqs-eth-link"))
                                }), ["/price/bitcoin", "/price/ethereum"])
                            }, {
                                title: e("c2c-user-seo-faqs-beginner-question5"),
                                link: "/support/faq/360041632232"
                            }, {
                                title: e("c2c-user-seo-faqs-beginner-question7"),
                                link: "/support/faq/2f1d9f5f360a45c38b81413f722afa22"
                            }, {
                                title: e("c2c-user-seo-faqs-beginner-question1"),
                                content: de(e("c2c-user-seo-faqs-beginner-solution1-v2", {
                                    "buy-crypto-on-Binance-P2P-platform-link": pe(e("c2c-user-seo-faqs-buy-crypto-on-Binance-P2P-platform-link"))
                                }), ["/support/faq/360043832851"])
                            }, {
                                title: e("c2c-user-seo-faqs-beginner-why-binance-p2p-better-question"),
                                content: de(e("c2c-user-seo-faqs-beginner-why-binance-p2p-better-answer", {
                                    "why-Binance-P2P-is-the-best-peer-to-peer-marketplace": pe(e("c2c-user-seo-faqs-why-Binance-P2P-is-the-best-peer-to-peer-marketplace"))
                                }), ["https://www.binance.com/blog/p2p/10-reasons-why-p2p-is-the-best-way-to-buy-local-bitcoin-in-your-currency-421499824684903068"])
                            }, {
                                title: e("c2c-user-seo-faqs-beginner-question4"),
                                content: de(e("c2c-user-seo-faqs-beginner-solution4"), ["/support/faq/0acb8aea955f4970a70bef25ee05f2e2"])
                            }, {
                                title: e("c2c-user-seo-faqs-beginner-question6"),
                                link: "/support/faq/360038038972"
                            }, {
                                title: e("c2c-user-seo-faqs-beginner-question8"),
                                link: "/support/faq/360041066751"
                            }]), (0, X.A)(t, ie.Advance, [{
                                title: e("c2c-user-seo-faqs-advanced-question1"),
                                link: "/support/faq/360037261532"
                            }, {
                                title: e("c2c-user-seo-faqs-advanced-question3"),
                                link: "/support/faq/9bd969ce7fcd4592acfdddd2bf9ef15f"
                            }, {
                                title: e("c2c-user-seo-faqs-advanced-question6"),
                                link: "/support/faq/360037619471"
                            }, {
                                title: e("c2c-user-seo-faqs-advanced-question2"),
                                link: "/support/faq/2ef479e9469643189738167e2006cf81"
                            }, {
                                title: e("c2c-user-seo-faqs-advanced-question4"),
                                link: "/support/faq/3d9759e1e058496a9593874791c54dfe"
                            }, {
                                title: e("c2c-user-seo-faqs-advanced-how-to-sell-btc-for-cash"),
                                link: "/event/bitcoin-to-cash "
                            }]), (0, X.A)(t, ie.Advertisers, [{
                                title: e("c2c-user-seo-faqs-advertisers-question1"),
                                link: "/support/faq/360042084072"
                            }, {
                                title: e("c2c-user-seo-faqs-advertisers-question3"),
                                link: "/support/faq/360041839052"
                            }, {
                                title: e("c2c-user-seo-faqs-advertisers-question5"),
                                link: "/support/faq/360043895111"
                            }, {
                                title: e("c2c-user-seo-faqs-advertisers-question7"),
                                link: "/support/faq/5be45ba170494ddbb7cac8d943fabf9e"
                            }, {
                                title: e("c2c-user-seo-faqs-advertisers-question2"),
                                link: "/support/faq/78e991b3ec1a4aac9e08e0a6b669e8d1"
                            }, {
                                title: e("c2c-user-seo-faqs-advertisers-question4"),
                                link: "/support/faq/66607f4c63e748568f503fcbd8f08965"
                            }, {
                                title: e("c2c-user-seo-faqs-advertisers-question6"),
                                link: "/support/faq/0bec3bb9292241e99c20136a4d3dbfe6"
                            }, {
                                title: e("c2c-user-seo-faqs-advertisers-how-to-post-cash-adv-question"),
                                content: (0, a.jsx)(ee.x6, {
                                    t: e,
                                    i18nKey: "c2c-user-seo-faqs-advertisers-how-to-post-cash-adv-answer",
                                    components: {
                                        l1: (0, a.jsx)(E.A, {
                                            className: "text-textLink",
                                            target: "_blank",
                                            path: "/support/faq/how-to-post-cash-advertisements-on-binance-p2p-merchant-portal-6e8021658666490e95e68d09f872df17",
                                            subDomain: "www"
                                        }),
                                        l2: (0, a.jsx)(E.A, {
                                            className: "text-textLink",
                                            target: "_blank",
                                            path: "/support/faq/how-to-post-cash-trade-advertisements-on-binance-p2p-app-fca8a35804f24cc5a15054e6c4265c4f",
                                            subDomain: "www"
                                        })
                                    }
                                })
                            }]), t
                        }(n, t)
                    }), [n, t]);
                return (0, a.jsxs)(d.Ay, {
                    className: "container",
                    children: [(0, a.jsxs)(d.Ay, {
                        className: "justify-between mb-3xl mobile:block noMob:flex",
                        children: [(0, a.jsx)(d.Ay, {
                            className: "mobile:headline3 tablet:headline2 pc:headline1",
                            children: n("c2c-user-seo-faqs-title")
                        }), (0, a.jsxs)(p.A, {
                            variant: "primary-gray",
                            className: "[&_.bn-tab]:rounded-m w-fit mobile:mt-3xl",
                            selectedIndex: c,
                            onChange: function(e) {
                                r(e)
                            },
                            children: [(0, a.jsx)(oe, {
                                tabNode: (0, a.jsx)(d.Ay, {
                                    className: "subtitle2",
                                    children: n("c2c-user-seo-faqs-tab-beginner")
                                })
                            }), (0, a.jsx)(oe, {
                                tabNode: (0, a.jsx)(d.Ay, {
                                    className: "subtitle2",
                                    children: n("c2c-user-seo-faqs-tab-advanced")
                                })
                            }), (0, a.jsx)(oe, {
                                tabNode: (0, a.jsx)(d.Ay, {
                                    className: "subtitle2",
                                    children: n("c2c-user-seo-faqs-tab-advertisers")
                                })
                            })]
                        })]
                    }), (0, a.jsx)(d.Ay, {
                        children: (0, a.jsx)(xe, {
                            faqList: null !== (s = o[c]) && void 0 !== s ? s : []
                        })
                    })]
                })
            };
            var fe = t("cNVJ"),
                he = p.A.TabPane;

            function be() {
                var e = (0, w.Ay)().t,
                    s = (0, i.useState)(y.Buy),
                    t = s[0],
                    l = s[1],
                    c = t === y.Buy,
                    r = (0, fe.d4)((function(e) {
                        return e.quickTrade
                    })),
                    o = r.asset,
                    u = r.fiat,
                    x = Object.freeze({
                        title: e(c ? "c2c-user-how-express-works-buy-title" : "c2c-user-how-express-works-sell-title", {
                            crypto: o
                        }),
                        buyTab: e("c2c-user-how-express-works-buy-tab", {
                            crypto: o
                        }),
                        sellTab: e("c2c-user-how-express-works-sell-tab", {
                            crypto: o
                        }),
                        step1TitleBuy: e("c2c-user-how-express-works-buy-title-step1"),
                        step1DescriptionBuy: e("c2c-user-how-express-works-buy-desc-step1", {
                            fiat: u,
                            crypto: o
                        }),
                        step2TitleBuy: e("c2c-user-how-express-works-buy-title-step2", {
                            fiat: u
                        }),
                        step2DescriptionBuy: e("c2c-user-how-express-works-buy-desc-step2"),
                        step3TitleBuy: e("c2c-user-how-express-works-buy-title-step3", {
                            crypto: o
                        }),
                        step3DescriptionBuy: e("c2c-user-how-express-works-buy-desc-step3", {
                            crypto: o
                        }),
                        step1TitleSell: e("c2c-user-how-express-works-sell-title-step1"),
                        step1DescriptionSell: e("c2c-user-how-express-works-sell-desc-step1", {
                            fiat: u,
                            crypto: o
                        }),
                        step2TitleSell: e("c2c-user-how-express-works-sell-title-step2", {
                            fiat: u
                        }),
                        step2DescriptionSell: e("c2c-user-how-express-works-sell-desc-step2", {
                            fiat: u
                        }),
                        step3TitleSell: e("c2c-user-how-express-works-sell-title-step3", {
                            crypto: o
                        }),
                        step3DescriptionSell: e("c2c-user-how-express-works-sell-desc-step3", {
                            fiat: u,
                            crypto: o
                        })
                    });
                return (0, a.jsxs)(d.Ay, {
                    className: "container",
                    children: [(0, a.jsxs)(n.A, {
                        className: "mobile:flex-col noMob:flex-row mobile:mb-xl tablet:mb-3xl pc:mb-3xl justify-between",
                        children: [(0, a.jsx)(d.Ay, {
                            className: "mobile:headline3 tablet:headline2 pc:headline1",
                            children: x.title
                        }), (0, a.jsxs)(p.A, {
                            variant: "primary-gray",
                            className: "[&_.bn-tab]:rounded-m w-fit mobile:mt-3xl",
                            selectedIndex: t,
                            onChange: function(e) {
                                l(e)
                            },
                            children: [(0, a.jsx)(he, {
                                tabNode: (0, a.jsx)(d.Ay, {
                                    className: "subtitle2",
                                    children: x.buyTab
                                })
                            }), (0, a.jsx)(he, {
                                tabNode: (0, a.jsx)(d.Ay, {
                                    className: "subtitle2",
                                    children: x.sellTab
                                })
                            })]
                        })]
                    }), (0, a.jsx)(d.Ay, {
                        className: "grid mobile:grid-cols-1 mobile:gap-l tablet:grid-cols-2 tablet:gap-xl pc:grid-cols-3 pc:gap-m",
                        children: c ? (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)(A, {
                                image: (0, a.jsx)(m, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: x.step1TitleBuy,
                                description: x.step1DescriptionBuy
                            }), (0, a.jsx)(A, {
                                image: (0, a.jsx)(f, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: x.step2TitleBuy,
                                description: x.step2DescriptionBuy
                            }), (0, a.jsx)(A, {
                                image: (0, a.jsx)(h, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: x.step3TitleBuy,
                                description: x.step3DescriptionBuy
                            })]
                        }) : (0, a.jsxs)(a.Fragment, {
                            children: [(0, a.jsx)(A, {
                                image: (0, a.jsx)(m, {
                                    className: "w-[96px] h-[96px]",
                                    name: "Document"
                                }),
                                title: x.step1TitleSell,
                                description: x.step1DescriptionSell
                            }), (0, a.jsx)(A, {
                                image: (0, a.jsx)(b.A, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: x.step2TitleSell,
                                description: x.step2DescriptionSell
                            }), (0, a.jsx)(A, {
                                image: (0, a.jsx)(v, {
                                    className: "w-[96px] h-[96px]"
                                }),
                                title: x.step3TitleSell,
                                description: x.step3DescriptionSell
                            })]
                        })
                    })]
                })
            }
            const ve = function(e) {
                var s = e.asset,
                    t = e.fiat,
                    i = e.contentType,
                    o = void 0 === i ? "trade" : i,
                    p = (0, c.r)(),
                    d = p.blockGuide,
                    u = p.blockEvent;
                return "express_step_2" === o ? (0, a.jsx)(n.A, {
                    className: "flex-col gap-[60px] pb-[60px] tablet:gap-[96px] tablet:pb-[96px] pc:gap-[128px] pc:pb-[128px]",
                    children: (0, a.jsx)(l.A, {
                        children: (0, a.jsx)(be, {})
                    })
                }) : (0, a.jsxs)(n.A, {
                    className: "flex-col gap-[60px] pb-[60px] tablet:gap-[96px] tablet:pb-[96px] pc:gap-[128px] pc:pb-[128px]",
                    children: [(0, a.jsx)(l.A, {
                        children: "express" === o ? (0, a.jsx)(be, {}) : (0, a.jsx)(j, {})
                    }), !u && (0, a.jsx)(l.A, {
                        children: (0, a.jsx)(q, {})
                    }), !u && (0, a.jsx)(l.A, {
                        children: (0, a.jsx)(V, {})
                    }), (0, a.jsx)(l.A, {
                        children: (0, a.jsx)(Z, {
                            asset: s,
                            fiat: t,
                            tradeArea: "express" === o ? r.G.Express : r.G.P2P
                        })
                    }), !d && (0, a.jsx)(l.A, {
                        children: (0, a.jsx)(me, {
                            tradeMode: o
                        })
                    })]
                })
            }
        },
        DkGs: (e, s, t) => {
            t.d(s, {
                C5: () => o,
                In: () => r,
                Qn: () => i,
                gL: () => c
            });
            var a = t("jPI1"),
                n = t.n(a),
                l = t("QhW/"),
                c = n()((function(e) {
                    return e && e.replace(/<!--[\s\S]*?-->/gm, "").replace(/(&nbsp;|\n)/gim, "").replace(/<\/?.+?>/gm, "")
                }), (function(e) {
                    return e && "string" === typeof e ? encodeURI(e.replace(l.A.punctuation, "").toLowerCase().replace(/ /g, "-")) : ""
                })),
                r = function(e) {
                    return new Promise((function(s, t) {
                        var a = new window.FileReader;
                        a.readAsDataURL(e), a.onload = function() {
                            return s(a.result)
                        }, a.onerror = function(e) {
                            return t(e)
                        }
                    }))
                },
                i = function() {
                    var e = document.getElementById("pre-chat-container");
                    e || (e = document.querySelector('#chatWidget div[data-cy="chat-entry"]')), e && e.click()
                },
                o = function(e, s, t) {
                    return s ? "loading" : t ? "success" : e ? "error" : void 0
                }
        },
        SK1U: (e, s, t) => {
            t.d(s, {
                A: () => r
            });
            var a = t("wIZF"),
                n = t("DTvD"),
                l = t.n(n),
                c = t("Y4uf");
            const r = function(e) {
                return l().createElement(c.A, (0, a.__assign)({
                    viewBox: "0 0 96 96",
                    fill: "none"
                }, e), l().createElement("path", {
                    opacity: .15,
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M66.001 10c9.942 0 18 8.059 18 18s-8.058 18-18 18c-9.94 0-18-8.059-18-18s8.06-18 18-18zm0 26l-8-8 8-8 8 8-8 8z",
                    fill: "#929AA5"
                }), l().createElement("path", {
                    d: "M28.002 12A8 8 0 1128 28a8 8 0 010-16z",
                    fill: "#F0B90B"
                }), l().createElement("path", {
                    opacity: .5,
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M20.002 32a8 8 0 00-8 8v4h32v-4a8 8 0 00-8-8h-2l-6 6-6-6h-2z",
                    fill: "#929AA5"
                }), l().createElement("path", {
                    opacity: .15,
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M30.002 50c-9.942 0-18 8.059-18 18s8.058 18 18 18c9.94 0 18-8.059 18-18s-8.06-18-18-18zm0 26l8-8-8-8-8 8 8 8z",
                    fill: "#929AA5"
                }), l().createElement("path", {
                    d: "M68.001 52a8 8 0 100 16 8 8 0 000-16z",
                    fill: "#F0B90B"
                }), l().createElement("path", {
                    opacity: .5,
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M76.001 72a8 8 0 018 8v4h-32v-4a8 8 0 018-8h2l6 6 6-6h2z",
                    fill: "#929AA5"
                }))
            }
        }
    }
]);
//# debugId=54823dff-72a6-55da-97dc-2fbd7f08341f