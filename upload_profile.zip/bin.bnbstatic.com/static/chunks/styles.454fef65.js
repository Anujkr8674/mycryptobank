"use strict";
(self.webpackChunklanding_strategy_ui = self.webpackChunklanding_strategy_ui || []).push([
    [1869], {
        WEEv: () => {},
        "NcR+": () => {},
        "wM+X": () => {},
        Dvxa: () => {},
        "m+5l": () => {},
        pC2Q: () => {},
        kUzC: () => {},
        zoqr: () => {}
    }
]);