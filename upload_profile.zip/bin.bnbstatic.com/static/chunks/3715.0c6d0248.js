"use strict";
(self.webpackChunkspot_trade_ui = self.webpackChunkspot_trade_ui || []).push([
    [3715], {
        "3zF4": (t, e, s) => {
            s.r(e), s.d(e, {
                default: () => l
            });
            var n = s("mXdx"),
                u = s("DTvD"),
                r = s.n(u),
                o = s("Qhol"),
                a = s("2m9I"),
                c = function() {
                    return (0, a.Z)(), (0, n.jsx)(n.Fragment, {})
                };
            const m = r().memo(c);
            var i = function() {
                return (0, o.QsY)().isDesktop ? (0, n.jsx)(m, {}) : null
            };
            const l = r().memo(i)
        }
    }
]);