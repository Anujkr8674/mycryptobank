"use strict";
(self.webpackChunkspot_trade_ui = self.webpackChunkspot_trade_ui || []).push([
    [5699], {
        "O/r9": (e, r, t) => {
            t.r(r), t.d(r, {
                default: () => v
            });
            var n = t("S+0I"),
                s = t("jbFV"),
                a = t.n(s),
                u = t("mXdx"),
                c = t("2IQ4"),
                l = t("DTvD"),
                o = t("MD8j"),
                i = t("BiCW"),
                d = t("bQ69"),
                x = t("ekAd"),
                f = t("tB80"),
                j = t("5rT1"),
                p = t("lW1t"),
                h = t("0yrM"),
                k = t("0ac5"),
                m = (0, i.A)((0, n._)(a().mark((function e() {
                    var r;
                    return a().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, Promise.all([t.e(6934), t.e(9461), t.e(5900), t.e(7422)]).then(t.bind(t, "cNo3"));
                            case 2:
                                return r = e.sent, e.abrupt("return", r.default);
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                }))), {
                    webpack: function() {
                        return ["cNo3"]
                    },
                    ssr: !1
                }),
                b = function() {
                    var e = (0, o.d4)(p.makeFullscreen);
                    return (0, u.jsx)(u.Fragment, {
                        children: (0, u.jsx)(c.A, {
                            sx: (0, j.vE)({
                                isChartFullscreen: e
                            }),
                            children: (0, u.jsxs)(k.A, {
                                children: [(0, u.jsx)(x.A, {}), (0, u.jsx)(h._D, {}), (0, u.jsx)(h.Uo, {}), (0, u.jsx)(m, {}), (0, u.jsx)(h.IY, {
                                    platform: d.ND
                                }), e ? null : (0, u.jsx)(f.default, {
                                    layout: ""
                                })]
                            })
                        })
                    })
                };
            const v = (0, l.memo)(b)
        }
    }
]);