(self.webpackChunkspot_trade_ui = self.webpackChunkspot_trade_ui || []).push([
    [4560], {
        jTOc: (t, e, r) => {
            "use strict";
            r.d(e, {
                A: () => o
            });
            var n = r("d12p"),
                i = {
                    0: "CONNECTING",
                    1: "OPEN",
                    2: "CLOSING",
                    3: "CLOSED"
                };
            const o = function(t) {
                var e, r, o, s, u, f = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3e3,
                    h = !1,
                    a = function() {
                        h || (h = !0, (e = new WebSocket(t)).onerror = function(t) {
                            console.error("socket error", t)
                        }, e.onclose = function(t) {
                            h = !1, 1e3 !== t.code && c()
                        }, e.onopen = o, e.onmessage = s)
                    },
                    l = function() {
                        for (var t = arguments.length, i = new Array(t), o = 0; o < t; o++) i[o] = arguments[o];
                        var s;
                        clearTimeout(r), e && (s = e).close.apply(s, (0, n._)(i))
                    },
                    c = function() {
                        l(), r = setTimeout((function() {
                            a()
                        }), f)
                    };
                return {
                    open: a,
                    close: l,
                    send: function(t) {
                        e && e.send(t)
                    },
                    onopen: function(t) {
                        o = t, e && (e.onopen = o)
                    },
                    onmessage: function(t) {
                        s = t, e && (e.onmessage = s)
                    },
                    onclose: function(t) {
                        u = t, e && (e.onclose = u)
                    },
                    readyState: function() {
                        return e ? i[e.readyState] : "UNKNOWN"
                    }
                }
            }
        },
        a1X9: t => {
            "use strict";
            t.exports = function(t, e) {
                var r = new Array(arguments.length - 1),
                    n = 0,
                    i = 2,
                    o = !0;
                for (; i < arguments.length;) r[n++] = arguments[i++];
                return new Promise((function(i, s) {
                    r[n] = function(t) {
                        if (o)
                            if (o = !1, t) s(t);
                            else {
                                for (var e = new Array(arguments.length - 1), r = 0; r < e.length;) e[r++] = arguments[r];
                                i.apply(null, e)
                            }
                    };
                    try {
                        t.apply(e || null, r)
                    } catch (u) {
                        o && (o = !1, s(u))
                    }
                }))
            }
        },
        kkqJ: (t, e) => {
            "use strict";
            var r = e;
            r.length = function(t) {
                var e = t.length;
                if (!e) return 0;
                for (var r = 0; --e % 4 > 1 && "=" === t.charAt(e);) ++r;
                return Math.ceil(3 * t.length) / 4 - r
            };
            for (var n = new Array(64), i = new Array(123), o = 0; o < 64;) i[n[o] = o < 26 ? o + 65 : o < 52 ? o + 71 : o < 62 ? o - 4 : o - 59 | 43] = o++;
            r.encode = function(t, e, r) {
                for (var i, o = null, s = [], u = 0, f = 0; e < r;) {
                    var h = t[e++];
                    switch (f) {
                        case 0:
                            s[u++] = n[h >> 2], i = (3 & h) << 4, f = 1;
                            break;
                        case 1:
                            s[u++] = n[i | h >> 4], i = (15 & h) << 2, f = 2;
                            break;
                        case 2:
                            s[u++] = n[i | h >> 6], s[u++] = n[63 & h], f = 0
                    }
                    u > 8191 && ((o || (o = [])).push(String.fromCharCode.apply(String, s)), u = 0)
                }
                return f && (s[u++] = n[i], s[u++] = 61, 1 === f && (s[u++] = 61)), o ? (u && o.push(String.fromCharCode.apply(String, s.slice(0, u))), o.join("")) : String.fromCharCode.apply(String, s.slice(0, u))
            };
            var s = "invalid encoding";
            r.decode = function(t, e, r) {
                for (var n, o = r, u = 0, f = 0; f < t.length;) {
                    var h = t.charCodeAt(f++);
                    if (61 === h && u > 1) break;
                    if (void 0 === (h = i[h])) throw Error(s);
                    switch (u) {
                        case 0:
                            n = h, u = 1;
                            break;
                        case 1:
                            e[r++] = n << 2 | (48 & h) >> 4, n = h, u = 2;
                            break;
                        case 2:
                            e[r++] = (15 & n) << 4 | (60 & h) >> 2, n = h, u = 3;
                            break;
                        case 3:
                            e[r++] = (3 & n) << 6 | h, u = 0
                    }
                }
                if (1 === u) throw Error(s);
                return r - o
            }, r.test = function(t) {
                return /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(t)
            }
        },
        CAcF: t => {
            "use strict";

            function e() {
                this._listeners = {}
            }
            t.exports = e, e.prototype.on = function(t, e, r) {
                return (this._listeners[t] || (this._listeners[t] = [])).push({
                    fn: e,
                    ctx: r || this
                }), this
            }, e.prototype.off = function(t, e) {
                if (void 0 === t) this._listeners = {};
                else if (void 0 === e) this._listeners[t] = [];
                else
                    for (var r = this._listeners[t], n = 0; n < r.length;) r[n].fn === e ? r.splice(n, 1) : ++n;
                return this
            }, e.prototype.emit = function(t) {
                var e = this._listeners[t];
                if (e) {
                    for (var r = [], n = 1; n < arguments.length;) r.push(arguments[n++]);
                    for (n = 0; n < e.length;) e[n].fn.apply(e[n++].ctx, r)
                }
                return this
            }
        },
        I8D1: t => {
            "use strict";

            function e(t) {
                return "undefined" !== typeof Float32Array ? function() {
                    var e = new Float32Array([-0]),
                        r = new Uint8Array(e.buffer),
                        n = 128 === r[3];

                    function i(t, n, i) {
                        e[0] = t, n[i] = r[0], n[i + 1] = r[1], n[i + 2] = r[2], n[i + 3] = r[3]
                    }

                    function o(t, n, i) {
                        e[0] = t, n[i] = r[3], n[i + 1] = r[2], n[i + 2] = r[1], n[i + 3] = r[0]
                    }

                    function s(t, n) {
                        return r[0] = t[n], r[1] = t[n + 1], r[2] = t[n + 2], r[3] = t[n + 3], e[0]
                    }

                    function u(t, n) {
                        return r[3] = t[n], r[2] = t[n + 1], r[1] = t[n + 2], r[0] = t[n + 3], e[0]
                    }
                    t.writeFloatLE = n ? i : o, t.writeFloatBE = n ? o : i, t.readFloatLE = n ? s : u, t.readFloatBE = n ? u : s
                }() : function() {
                    function e(t, e, r, n) {
                        var i = e < 0 ? 1 : 0;
                        if (i && (e = -e), 0 === e) t(1 / e > 0 ? 0 : 2147483648, r, n);
                        else if (isNaN(e)) t(2143289344, r, n);
                        else if (e > 34028234663852886e22) t((i << 31 | 2139095040) >>> 0, r, n);
                        else if (e < 11754943508222875e-54) t((i << 31 | Math.round(e / 1401298464324817e-60)) >>> 0, r, n);
                        else {
                            var o = Math.floor(Math.log(e) / Math.LN2);
                            t((i << 31 | o + 127 << 23 | 8388607 & Math.round(e * Math.pow(2, -o) * 8388608)) >>> 0, r, n)
                        }
                    }

                    function s(t, e, r) {
                        var n = t(e, r),
                            i = 2 * (n >> 31) + 1,
                            o = n >>> 23 & 255,
                            s = 8388607 & n;
                        return 255 === o ? s ? NaN : i * (1 / 0) : 0 === o ? 1401298464324817e-60 * i * s : i * Math.pow(2, o - 150) * (s + 8388608)
                    }
                    t.writeFloatLE = e.bind(null, r), t.writeFloatBE = e.bind(null, n), t.readFloatLE = s.bind(null, i), t.readFloatBE = s.bind(null, o)
                }(), "undefined" !== typeof Float64Array ? function() {
                    var e = new Float64Array([-0]),
                        r = new Uint8Array(e.buffer),
                        n = 128 === r[7];

                    function i(t, n, i) {
                        e[0] = t, n[i] = r[0], n[i + 1] = r[1], n[i + 2] = r[2], n[i + 3] = r[3], n[i + 4] = r[4], n[i + 5] = r[5], n[i + 6] = r[6], n[i + 7] = r[7]
                    }

                    function o(t, n, i) {
                        e[0] = t, n[i] = r[7], n[i + 1] = r[6], n[i + 2] = r[5], n[i + 3] = r[4], n[i + 4] = r[3], n[i + 5] = r[2], n[i + 6] = r[1], n[i + 7] = r[0]
                    }

                    function s(t, n) {
                        return r[0] = t[n], r[1] = t[n + 1], r[2] = t[n + 2], r[3] = t[n + 3], r[4] = t[n + 4], r[5] = t[n + 5], r[6] = t[n + 6], r[7] = t[n + 7], e[0]
                    }

                    function u(t, n) {
                        return r[7] = t[n], r[6] = t[n + 1], r[5] = t[n + 2], r[4] = t[n + 3], r[3] = t[n + 4], r[2] = t[n + 5], r[1] = t[n + 6], r[0] = t[n + 7], e[0]
                    }
                    t.writeDoubleLE = n ? i : o, t.writeDoubleBE = n ? o : i, t.readDoubleLE = n ? s : u, t.readDoubleBE = n ? u : s
                }() : function() {
                    function e(t, e, r, n, i, o) {
                        var s = n < 0 ? 1 : 0;
                        if (s && (n = -n), 0 === n) t(0, i, o + e), t(1 / n > 0 ? 0 : 2147483648, i, o + r);
                        else if (isNaN(n)) t(0, i, o + e), t(2146959360, i, o + r);
                        else if (n > 17976931348623157e292) t(0, i, o + e), t((s << 31 | 2146435072) >>> 0, i, o + r);
                        else {
                            var u;
                            if (n < 22250738585072014e-324) t((u = n / 5e-324) >>> 0, i, o + e), t((s << 31 | u / 4294967296) >>> 0, i, o + r);
                            else {
                                var f = Math.floor(Math.log(n) / Math.LN2);
                                1024 === f && (f = 1023), t(4503599627370496 * (u = n * Math.pow(2, -f)) >>> 0, i, o + e), t((s << 31 | f + 1023 << 20 | 1048576 * u & 1048575) >>> 0, i, o + r)
                            }
                        }
                    }

                    function s(t, e, r, n, i) {
                        var o = t(n, i + e),
                            s = t(n, i + r),
                            u = 2 * (s >> 31) + 1,
                            f = s >>> 20 & 2047,
                            h = 4294967296 * (1048575 & s) + o;
                        return 2047 === f ? h ? NaN : u * (1 / 0) : 0 === f ? 5e-324 * u * h : u * Math.pow(2, f - 1075) * (h + 4503599627370496)
                    }
                    t.writeDoubleLE = e.bind(null, r, 0, 4), t.writeDoubleBE = e.bind(null, n, 4, 0), t.readDoubleLE = s.bind(null, i, 0, 4), t.readDoubleBE = s.bind(null, o, 4, 0)
                }(), t
            }

            function r(t, e, r) {
                e[r] = 255 & t, e[r + 1] = t >>> 8 & 255, e[r + 2] = t >>> 16 & 255, e[r + 3] = t >>> 24
            }

            function n(t, e, r) {
                e[r] = t >>> 24, e[r + 1] = t >>> 16 & 255, e[r + 2] = t >>> 8 & 255, e[r + 3] = 255 & t
            }

            function i(t, e) {
                return (t[e] | t[e + 1] << 8 | t[e + 2] << 16 | t[e + 3] << 24) >>> 0
            }

            function o(t, e) {
                return (t[e] << 24 | t[e + 1] << 16 | t[e + 2] << 8 | t[e + 3]) >>> 0
            }
            t.exports = e(e)
        },
        mpzN: module => {
            "use strict";

            function inquire(moduleName) {
                try {
                    var mod = eval("quire".replace(/^/, "re"))(moduleName);
                    if (mod && (mod.length || Object.keys(mod).length)) return mod
                } catch (e) {}
                return null
            }
            module.exports = inquire
        },
        FmKl: t => {
            "use strict";
            t.exports = function(t, e, r) {
                var n = r || 8192,
                    i = n >>> 1,
                    o = null,
                    s = n;
                return function(r) {
                    if (r < 1 || r > i) return t(r);
                    s + r > n && (o = t(n), s = 0);
                    var u = e.call(o, s, s += r);
                    return 7 & s && (s = 1 + (7 | s)), u
                }
            }
        },
        gA9B: (t, e) => {
            "use strict";
            var r = e;
            r.length = function(t) {
                for (var e = 0, r = 0, n = 0; n < t.length; ++n)(r = t.charCodeAt(n)) < 128 ? e += 1 : r < 2048 ? e += 2 : 55296 === (64512 & r) && 56320 === (64512 & t.charCodeAt(n + 1)) ? (++n, e += 4) : e += 3;
                return e
            }, r.read = function(t, e, r) {
                if (r - e < 1) return "";
                for (var n, i = null, o = [], s = 0; e < r;)(n = t[e++]) < 128 ? o[s++] = n : n > 191 && n < 224 ? o[s++] = (31 & n) << 6 | 63 & t[e++] : n > 239 && n < 365 ? (n = ((7 & n) << 18 | (63 & t[e++]) << 12 | (63 & t[e++]) << 6 | 63 & t[e++]) - 65536, o[s++] = 55296 + (n >> 10), o[s++] = 56320 + (1023 & n)) : o[s++] = (15 & n) << 12 | (63 & t[e++]) << 6 | 63 & t[e++], s > 8191 && ((i || (i = [])).push(String.fromCharCode.apply(String, o)), s = 0);
                return i ? (s && i.push(String.fromCharCode.apply(String, o.slice(0, s))), i.join("")) : String.fromCharCode.apply(String, o.slice(0, s))
            }, r.write = function(t, e, r) {
                for (var n, i, o = r, s = 0; s < t.length; ++s)(n = t.charCodeAt(s)) < 128 ? e[r++] = n : n < 2048 ? (e[r++] = n >> 6 | 192, e[r++] = 63 & n | 128) : 55296 === (64512 & n) && 56320 === (64512 & (i = t.charCodeAt(s + 1))) ? (n = 65536 + ((1023 & n) << 10) + (1023 & i), ++s, e[r++] = n >> 18 | 240, e[r++] = n >> 12 & 63 | 128, e[r++] = n >> 6 & 63 | 128, e[r++] = 63 & n | 128) : (e[r++] = n >> 12 | 224, e[r++] = n >> 6 & 63 | 128, e[r++] = 63 & n | 128);
                return r - o
            }
        },
        jbP7: (t, e, r) => {
            var n = r("6DXg"),
                i = r("HEV4");
            t.exports = function(t, e, r, o) {
                return null == t ? [] : (i(e) || (e = null == e ? [] : [e]), i(r = o ? void 0 : r) || (r = null == r ? [] : [r]), n(t, e, r))
            }
        },
        gHJi: (t, e, r) => {
            "use strict";
            t.exports = r("wRAs")
        },
        wRAs: (t, e, r) => {
            "use strict";
            var n = e;

            function i() {
                n.util._configure(), n.Writer._configure(n.BufferWriter), n.Reader._configure(n.BufferReader)
            }
            n.build = "minimal", n.Writer = r("R/rw"), n.BufferWriter = r("f0T6"), n.Reader = r("iUYL"), n.BufferReader = r("Fa0v"), n.util = r("a8eG"), n.rpc = r("IZNV"), n.roots = r("gESf"), n.configure = i, i()
        },
        iUYL: (t, e, r) => {
            "use strict";
            t.exports = f;
            var n, i = r("a8eG"),
                o = i.LongBits,
                s = i.utf8;

            function u(t, e) {
                return RangeError("index out of range: " + t.pos + " + " + (e || 1) + " > " + t.len)
            }

            function f(t) {
                this.buf = t, this.pos = 0, this.len = t.length
            }
            var h = "undefined" !== typeof Uint8Array ? function(t) {
                    if (t instanceof Uint8Array || Array.isArray(t)) return new f(t);
                    throw Error("illegal buffer")
                } : function(t) {
                    if (Array.isArray(t)) return new f(t);
                    throw Error("illegal buffer")
                },
                a = function() {
                    return i.Buffer ? function(t) {
                        return (f.create = function(t) {
                            return i.Buffer.isBuffer(t) ? new n(t) : h(t)
                        })(t)
                    } : h
                };

            function l() {
                var t = new o(0, 0),
                    e = 0;
                if (!(this.len - this.pos > 4)) {
                    for (; e < 3; ++e) {
                        if (this.pos >= this.len) throw u(this);
                        if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 7 * e) >>> 0, this.buf[this.pos++] < 128) return t
                    }
                    return t.lo = (t.lo | (127 & this.buf[this.pos++]) << 7 * e) >>> 0, t
                }
                for (; e < 4; ++e)
                    if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 7 * e) >>> 0, this.buf[this.pos++] < 128) return t;
                if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 28) >>> 0, t.hi = (t.hi | (127 & this.buf[this.pos]) >> 4) >>> 0, this.buf[this.pos++] < 128) return t;
                if (e = 0, this.len - this.pos > 4) {
                    for (; e < 5; ++e)
                        if (t.hi = (t.hi | (127 & this.buf[this.pos]) << 7 * e + 3) >>> 0, this.buf[this.pos++] < 128) return t
                } else
                    for (; e < 5; ++e) {
                        if (this.pos >= this.len) throw u(this);
                        if (t.hi = (t.hi | (127 & this.buf[this.pos]) << 7 * e + 3) >>> 0, this.buf[this.pos++] < 128) return t
                    }
                throw Error("invalid varint encoding")
            }

            function c(t, e) {
                return (t[e - 4] | t[e - 3] << 8 | t[e - 2] << 16 | t[e - 1] << 24) >>> 0
            }

            function p() {
                if (this.pos + 8 > this.len) throw u(this, 8);
                return new o(c(this.buf, this.pos += 4), c(this.buf, this.pos += 4))
            }
            f.create = a(), f.prototype._slice = i.Array.prototype.subarray || i.Array.prototype.slice, f.prototype.uint32 = function() {
                var t = 4294967295;
                return function() {
                    if (t = (127 & this.buf[this.pos]) >>> 0, this.buf[this.pos++] < 128) return t;
                    if (t = (t | (127 & this.buf[this.pos]) << 7) >>> 0, this.buf[this.pos++] < 128) return t;
                    if (t = (t | (127 & this.buf[this.pos]) << 14) >>> 0, this.buf[this.pos++] < 128) return t;
                    if (t = (t | (127 & this.buf[this.pos]) << 21) >>> 0, this.buf[this.pos++] < 128) return t;
                    if (t = (t | (15 & this.buf[this.pos]) << 28) >>> 0, this.buf[this.pos++] < 128) return t;
                    if ((this.pos += 5) > this.len) throw this.pos = this.len, u(this, 10);
                    return t
                }
            }(), f.prototype.int32 = function() {
                return 0 | this.uint32()
            }, f.prototype.sint32 = function() {
                var t = this.uint32();
                return t >>> 1 ^ -(1 & t)
            }, f.prototype.bool = function() {
                return 0 !== this.uint32()
            }, f.prototype.fixed32 = function() {
                if (this.pos + 4 > this.len) throw u(this, 4);
                return c(this.buf, this.pos += 4)
            }, f.prototype.sfixed32 = function() {
                if (this.pos + 4 > this.len) throw u(this, 4);
                return 0 | c(this.buf, this.pos += 4)
            }, f.prototype.float = function() {
                if (this.pos + 4 > this.len) throw u(this, 4);
                var t = i.float.readFloatLE(this.buf, this.pos);
                return this.pos += 4, t
            }, f.prototype.double = function() {
                if (this.pos + 8 > this.len) throw u(this, 4);
                var t = i.float.readDoubleLE(this.buf, this.pos);
                return this.pos += 8, t
            }, f.prototype.bytes = function() {
                var t = this.uint32(),
                    e = this.pos,
                    r = this.pos + t;
                if (r > this.len) throw u(this, t);
                return this.pos += t, Array.isArray(this.buf) ? this.buf.slice(e, r) : e === r ? new this.buf.constructor(0) : this._slice.call(this.buf, e, r)
            }, f.prototype.string = function() {
                var t = this.bytes();
                return s.read(t, 0, t.length)
            }, f.prototype.skip = function(t) {
                if ("number" === typeof t) {
                    if (this.pos + t > this.len) throw u(this, t);
                    this.pos += t
                } else
                    do {
                        if (this.pos >= this.len) throw u(this)
                    } while (128 & this.buf[this.pos++]);
                return this
            }, f.prototype.skipType = function(t) {
                switch (t) {
                    case 0:
                        this.skip();
                        break;
                    case 1:
                        this.skip(8);
                        break;
                    case 2:
                        this.skip(this.uint32());
                        break;
                    case 3:
                        for (; 4 !== (t = 7 & this.uint32());) this.skipType(t);
                        break;
                    case 5:
                        this.skip(4);
                        break;
                    default:
                        throw Error("invalid wire type " + t + " at offset " + this.pos)
                }
                return this
            }, f._configure = function(t) {
                n = t, f.create = a(), n._configure();
                var e = i.Long ? "toLong" : "toNumber";
                i.merge(f.prototype, {
                    int64: function() {
                        return l.call(this)[e](!1)
                    },
                    uint64: function() {
                        return l.call(this)[e](!0)
                    },
                    sint64: function() {
                        return l.call(this).zzDecode()[e](!1)
                    },
                    fixed64: function() {
                        return p.call(this)[e](!0)
                    },
                    sfixed64: function() {
                        return p.call(this)[e](!1)
                    }
                })
            }
        },
        Fa0v: (t, e, r) => {
            "use strict";
            t.exports = o;
            var n = r("iUYL");
            (o.prototype = Object.create(n.prototype)).constructor = o;
            var i = r("a8eG");

            function o(t) {
                n.call(this, t)
            }
            o._configure = function() {
                i.Buffer && (o.prototype._slice = i.Buffer.prototype.slice)
            }, o.prototype.string = function() {
                var t = this.uint32();
                return this.buf.utf8Slice ? this.buf.utf8Slice(this.pos, this.pos = Math.min(this.pos + t, this.len)) : this.buf.toString("utf-8", this.pos, this.pos = Math.min(this.pos + t, this.len))
            }, o._configure()
        },
        gESf: t => {
            "use strict";
            t.exports = {}
        },
        IZNV: (t, e, r) => {
            "use strict";
            e.Service = r("4UAz")
        },
        "4UAz": (t, e, r) => {
            "use strict";
            t.exports = i;
            var n = r("a8eG");

            function i(t, e, r) {
                if ("function" !== typeof t) throw TypeError("rpcImpl must be a function");
                n.EventEmitter.call(this), this.rpcImpl = t, this.requestDelimited = Boolean(e), this.responseDelimited = Boolean(r)
            }(i.prototype = Object.create(n.EventEmitter.prototype)).constructor = i, i.prototype.rpcCall = function t(e, r, i, o, s) {
                if (!o) throw TypeError("request must be specified");
                var u = this;
                if (!s) return n.asPromise(t, u, e, r, i, o);
                if (u.rpcImpl) try {
                    return u.rpcImpl(e, r[u.requestDelimited ? "encodeDelimited" : "encode"](o).finish(), (function(t, r) {
                        if (t) return u.emit("error", t, e), s(t);
                        if (null !== r) {
                            if (!(r instanceof i)) try {
                                r = i[u.responseDelimited ? "decodeDelimited" : "decode"](r)
                            } catch (t) {
                                return u.emit("error", t, e), s(t)
                            }
                            return u.emit("data", r, e), s(null, r)
                        }
                        u.end(!0)
                    }))
                } catch (f) {
                    return u.emit("error", f, e), void setTimeout((function() {
                        s(f)
                    }), 0)
                } else setTimeout((function() {
                    s(Error("already ended"))
                }), 0)
            }, i.prototype.end = function(t) {
                return this.rpcImpl && (t || this.rpcImpl(null, null, null), this.rpcImpl = null, this.emit("end").off()), this
            }
        },
        dsAi: (t, e, r) => {
            "use strict";
            t.exports = i;
            var n = r("a8eG");

            function i(t, e) {
                this.lo = t >>> 0, this.hi = e >>> 0
            }
            var o = i.zero = new i(0, 0);
            o.toNumber = function() {
                return 0
            }, o.zzEncode = o.zzDecode = function() {
                return this
            }, o.length = function() {
                return 1
            };
            var s = i.zeroHash = "\0\0\0\0\0\0\0\0";
            i.fromNumber = function(t) {
                if (0 === t) return o;
                var e = t < 0;
                e && (t = -t);
                var r = t >>> 0,
                    n = (t - r) / 4294967296 >>> 0;
                return e && (n = ~n >>> 0, r = ~r >>> 0, ++r > 4294967295 && (r = 0, ++n > 4294967295 && (n = 0))), new i(r, n)
            }, i.from = function(t) {
                if ("number" === typeof t) return i.fromNumber(t);
                if (n.isString(t)) {
                    if (!n.Long) return i.fromNumber(parseInt(t, 10));
                    t = n.Long.fromString(t)
                }
                return t.low || t.high ? new i(t.low >>> 0, t.high >>> 0) : o
            }, i.prototype.toNumber = function(t) {
                if (!t && this.hi >>> 31) {
                    var e = 1 + ~this.lo >>> 0,
                        r = ~this.hi >>> 0;
                    return e || (r = r + 1 >>> 0), -(e + 4294967296 * r)
                }
                return this.lo + 4294967296 * this.hi
            }, i.prototype.toLong = function(t) {
                return n.Long ? new n.Long(0 | this.lo, 0 | this.hi, Boolean(t)) : {
                    low: 0 | this.lo,
                    high: 0 | this.hi,
                    unsigned: Boolean(t)
                }
            };
            var u = String.prototype.charCodeAt;
            i.fromHash = function(t) {
                return t === s ? o : new i((u.call(t, 0) | u.call(t, 1) << 8 | u.call(t, 2) << 16 | u.call(t, 3) << 24) >>> 0, (u.call(t, 4) | u.call(t, 5) << 8 | u.call(t, 6) << 16 | u.call(t, 7) << 24) >>> 0)
            }, i.prototype.toHash = function() {
                return String.fromCharCode(255 & this.lo, this.lo >>> 8 & 255, this.lo >>> 16 & 255, this.lo >>> 24, 255 & this.hi, this.hi >>> 8 & 255, this.hi >>> 16 & 255, this.hi >>> 24)
            }, i.prototype.zzEncode = function() {
                var t = this.hi >> 31;
                return this.hi = ((this.hi << 1 | this.lo >>> 31) ^ t) >>> 0, this.lo = (this.lo << 1 ^ t) >>> 0, this
            }, i.prototype.zzDecode = function() {
                var t = -(1 & this.lo);
                return this.lo = ((this.lo >>> 1 | this.hi << 31) ^ t) >>> 0, this.hi = (this.hi >>> 1 ^ t) >>> 0, this
            }, i.prototype.length = function() {
                var t = this.lo,
                    e = (this.lo >>> 28 | this.hi << 4) >>> 0,
                    r = this.hi >>> 24;
                return 0 === r ? 0 === e ? t < 16384 ? t < 128 ? 1 : 2 : t < 2097152 ? 3 : 4 : e < 16384 ? e < 128 ? 5 : 6 : e < 2097152 ? 7 : 8 : r < 128 ? 9 : 10
            }
        },
        a8eG: function(t, e, r) {
            "use strict";
            var n = e;

            function i(t, e, r) {
                for (var n = Object.keys(e), i = 0; i < n.length; ++i) void 0 !== t[n[i]] && r || (t[n[i]] = e[n[i]]);
                return t
            }

            function o(t) {
                function e(t, r) {
                    if (!(this instanceof e)) return new e(t, r);
                    Object.defineProperty(this, "message", {
                        get: function() {
                            return t
                        }
                    }), Error.captureStackTrace ? Error.captureStackTrace(this, e) : Object.defineProperty(this, "stack", {
                        value: (new Error).stack || ""
                    }), r && i(this, r)
                }
                return (e.prototype = Object.create(Error.prototype)).constructor = e, Object.defineProperty(e.prototype, "name", {
                    get: function() {
                        return t
                    }
                }), e.prototype.toString = function() {
                    return this.name + ": " + this.message
                }, e
            }
            n.asPromise = r("a1X9"), n.base64 = r("kkqJ"), n.EventEmitter = r("CAcF"), n.float = r("I8D1"), n.inquire = r("mpzN"), n.utf8 = r("gA9B"), n.pool = r("FmKl"), n.LongBits = r("dsAi"), n.isNode = Boolean("undefined" !== typeof r.g && r.g && r.g.process && r.g.process.versions && r.g.process.versions.node), n.global = n.isNode && r.g || "undefined" !== typeof window && window || "undefined" !== typeof self && self || this, n.emptyArray = Object.freeze ? Object.freeze([]) : [], n.emptyObject = Object.freeze ? Object.freeze({}) : {}, n.isInteger = Number.isInteger || function(t) {
                return "number" === typeof t && isFinite(t) && Math.floor(t) === t
            }, n.isString = function(t) {
                return "string" === typeof t || t instanceof String
            }, n.isObject = function(t) {
                return t && "object" === typeof t
            }, n.isset = n.isSet = function(t, e) {
                var r = t[e];
                return !(null == r || !t.hasOwnProperty(e)) && ("object" !== typeof r || (Array.isArray(r) ? r.length : Object.keys(r).length) > 0)
            }, n.Buffer = function() {
                try {
                    var t = n.inquire("buffer").Buffer;
                    return t.prototype.utf8Write ? t : null
                } catch (e) {
                    return null
                }
            }(), n._Buffer_from = null, n._Buffer_allocUnsafe = null, n.newBuffer = function(t) {
                return "number" === typeof t ? n.Buffer ? n._Buffer_allocUnsafe(t) : new n.Array(t) : n.Buffer ? n._Buffer_from(t) : "undefined" === typeof Uint8Array ? t : new Uint8Array(t)
            }, n.Array = "undefined" !== typeof Uint8Array ? Uint8Array : Array, n.Long = n.global.dcodeIO && n.global.dcodeIO.Long || n.global.Long || n.inquire("long"), n.key2Re = /^true|false|0|1$/, n.key32Re = /^-?(?:0|[1-9][0-9]*)$/, n.key64Re = /^(?:[\\x00-\\xff]{8}|-?(?:0|[1-9][0-9]*))$/, n.longToHash = function(t) {
                return t ? n.LongBits.from(t).toHash() : n.LongBits.zeroHash
            }, n.longFromHash = function(t, e) {
                var r = n.LongBits.fromHash(t);
                return n.Long ? n.Long.fromBits(r.lo, r.hi, e) : r.toNumber(Boolean(e))
            }, n.merge = i, n.lcFirst = function(t) {
                return t.charAt(0).toLowerCase() + t.substring(1)
            }, n.newError = o, n.ProtocolError = o("ProtocolError"), n.oneOfGetter = function(t) {
                for (var e = {}, r = 0; r < t.length; ++r) e[t[r]] = 1;
                return function() {
                    for (var t = Object.keys(this), r = t.length - 1; r > -1; --r)
                        if (1 === e[t[r]] && void 0 !== this[t[r]] && null !== this[t[r]]) return t[r]
                }
            }, n.oneOfSetter = function(t) {
                return function(e) {
                    for (var r = 0; r < t.length; ++r) t[r] !== e && delete this[t[r]]
                }
            }, n.toJSONOptions = {
                longs: String,
                enums: String,
                bytes: String,
                json: !0
            }, n._configure = function() {
                var t = n.Buffer;
                t ? (n._Buffer_from = t.from !== Uint8Array.from && t.from || function(e, r) {
                    return new t(e, r)
                }, n._Buffer_allocUnsafe = t.allocUnsafe || function(e) {
                    return new t(e)
                }) : n._Buffer_from = n._Buffer_allocUnsafe = null
            }
        },
        "R/rw": (t, e, r) => {
            "use strict";
            t.exports = l;
            var n, i = r("a8eG"),
                o = i.LongBits,
                s = i.base64,
                u = i.utf8;

            function f(t, e, r) {
                this.fn = t, this.len = e, this.next = void 0, this.val = r
            }

            function h() {}

            function a(t) {
                this.head = t.head, this.tail = t.tail, this.len = t.len, this.next = t.states
            }

            function l() {
                this.len = 0, this.head = new f(h, 0, 0), this.tail = this.head, this.states = null
            }
            var c = function() {
                return i.Buffer ? function() {
                    return (l.create = function() {
                        return new n
                    })()
                } : function() {
                    return new l
                }
            };

            function p(t, e, r) {
                e[r] = 255 & t
            }

            function y(t, e) {
                this.len = t, this.next = void 0, this.val = e
            }

            function d(t, e, r) {
                for (; t.hi;) e[r++] = 127 & t.lo | 128, t.lo = (t.lo >>> 7 | t.hi << 25) >>> 0, t.hi >>>= 7;
                for (; t.lo > 127;) e[r++] = 127 & t.lo | 128, t.lo = t.lo >>> 7;
                e[r++] = t.lo
            }

            function g(t, e, r) {
                e[r] = 255 & t, e[r + 1] = t >>> 8 & 255, e[r + 2] = t >>> 16 & 255, e[r + 3] = t >>> 24
            }
            l.create = c(), l.alloc = function(t) {
                return new i.Array(t)
            }, i.Array !== Array && (l.alloc = i.pool(l.alloc, i.Array.prototype.subarray)), l.prototype._push = function(t, e, r) {
                return this.tail = this.tail.next = new f(t, e, r), this.len += e, this
            }, y.prototype = Object.create(f.prototype), y.prototype.fn = function(t, e, r) {
                for (; t > 127;) e[r++] = 127 & t | 128, t >>>= 7;
                e[r] = t
            }, l.prototype.uint32 = function(t) {
                return this.len += (this.tail = this.tail.next = new y((t >>>= 0) < 128 ? 1 : t < 16384 ? 2 : t < 2097152 ? 3 : t < 268435456 ? 4 : 5, t)).len, this
            }, l.prototype.int32 = function(t) {
                return t < 0 ? this._push(d, 10, o.fromNumber(t)) : this.uint32(t)
            }, l.prototype.sint32 = function(t) {
                return this.uint32((t << 1 ^ t >> 31) >>> 0)
            }, l.prototype.uint64 = function(t) {
                var e = o.from(t);
                return this._push(d, e.length(), e)
            }, l.prototype.int64 = l.prototype.uint64, l.prototype.sint64 = function(t) {
                var e = o.from(t).zzEncode();
                return this._push(d, e.length(), e)
            }, l.prototype.bool = function(t) {
                return this._push(p, 1, t ? 1 : 0)
            }, l.prototype.fixed32 = function(t) {
                return this._push(g, 4, t >>> 0)
            }, l.prototype.sfixed32 = l.prototype.fixed32, l.prototype.fixed64 = function(t) {
                var e = o.from(t);
                return this._push(g, 4, e.lo)._push(g, 4, e.hi)
            }, l.prototype.sfixed64 = l.prototype.fixed64, l.prototype.float = function(t) {
                return this._push(i.float.writeFloatLE, 4, t)
            }, l.prototype.double = function(t) {
                return this._push(i.float.writeDoubleLE, 8, t)
            };
            var b = i.Array.prototype.set ? function(t, e, r) {
                e.set(t, r)
            } : function(t, e, r) {
                for (var n = 0; n < t.length; ++n) e[r + n] = t[n]
            };
            l.prototype.bytes = function(t) {
                var e = t.length >>> 0;
                if (!e) return this._push(p, 1, 0);
                if (i.isString(t)) {
                    var r = l.alloc(e = s.length(t));
                    s.decode(t, r, 0), t = r
                }
                return this.uint32(e)._push(b, e, t)
            }, l.prototype.string = function(t) {
                var e = u.length(t);
                return e ? this.uint32(e)._push(u.write, e, t) : this._push(p, 1, 0)
            }, l.prototype.fork = function() {
                return this.states = new a(this), this.head = this.tail = new f(h, 0, 0), this.len = 0, this
            }, l.prototype.reset = function() {
                return this.states ? (this.head = this.states.head, this.tail = this.states.tail, this.len = this.states.len, this.states = this.states.next) : (this.head = this.tail = new f(h, 0, 0), this.len = 0), this
            }, l.prototype.ldelim = function() {
                var t = this.head,
                    e = this.tail,
                    r = this.len;
                return this.reset().uint32(r), r && (this.tail.next = t.next, this.tail = e, this.len += r), this
            }, l.prototype.finish = function() {
                for (var t = this.head.next, e = this.constructor.alloc(this.len), r = 0; t;) t.fn(t.val, e, r), r += t.len, t = t.next;
                return e
            }, l._configure = function(t) {
                n = t, l.create = c(), n._configure()
            }
        },
        f0T6: (t, e, r) => {
            "use strict";
            t.exports = o;
            var n = r("R/rw");
            (o.prototype = Object.create(n.prototype)).constructor = o;
            var i = r("a8eG");

            function o() {
                n.call(this)
            }

            function s(t, e, r) {
                t.length < 40 ? i.utf8.write(t, e, r) : e.utf8Write ? e.utf8Write(t, r) : e.write(t, r)
            }
            o._configure = function() {
                o.alloc = i._Buffer_allocUnsafe, o.writeBytesBuffer = i.Buffer && i.Buffer.prototype instanceof Uint8Array && "set" === i.Buffer.prototype.set.name ? function(t, e, r) {
                    e.set(t, r)
                } : function(t, e, r) {
                    if (t.copy) t.copy(e, r, 0, t.length);
                    else
                        for (var n = 0; n < t.length;) e[r++] = t[n++]
                }
            }, o.prototype.bytes = function(t) {
                i.isString(t) && (t = i._Buffer_from(t, "base64"));
                var e = t.length >>> 0;
                return this.uint32(e), e && this._push(o.writeBytesBuffer, e, t), this
            }, o.prototype.string = function(t) {
                var e = i.Buffer.byteLength(t);
                return this.uint32(e), e && this._push(s, e, t), this
            }, o._configure()
        }
    }
]);