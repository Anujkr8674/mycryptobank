(self.webpackChunkresearch_new_ui = self.webpackChunkresearch_new_ui || []).push([
    [515], {
        qARj: (n, t, e) => {
            "use strict";
            e.d(t, {
                default: () => wt
            });
            var i = e("TrCV"),
                r = e("Srb9"),
                o = e("uHCZ"),
                a = e("1TYZ"),
                l = e("pf6g"),
                s = e("71zA"),
                c = e("BK7R"),
                d = e("VP0d"),
                p = e("DTvD"),
                u = e.n(p),
                h = e("7vYB"),
                g = e("LCuF"),
                f = e("+Od7"),
                x = e("mIvk"),
                m = e("N/Z2"),
                b = e("lCj1"),
                y = e("hst2");

            function v() {
                var n = (0, m.A)(["\n  position: relative;\n  box-sizing: border-box;\n  display: flex;\n  margin-left: auto;\n  margin-right: auto;\n  height: 214px;\n\n  .pinned-post {\n    margin-top: 32px;\n  }\n\n  a {\n    color: #1e2329;\n    border: 1px solid ", ";\n    &:hover {\n      color: #1e2329 !important;\n      border: 1px solid var(--color-PrimaryText) !important;\n    }\n  }\n\n  @media ", " {\n    margin-bottom: 40px;\n    height: 170px;\n    display: flex;\n    flex-direction: column;\n\n    .slick-list {\n      border-radius: 16px;\n    }\n  }\n\n  @media ", " {\n    margin-bottom: 80px;\n    padding: 48px 0px 40px 0px;\n    display: flex;\n    flex-wrap: wrap;\n    gap: 24px;\n    height: 310px;\n    flex-direction: row;\n    a {\n      border: 1px solid ", "!important;\n    }\n  }\n  @media ", " {\n    margin-bottom: 48px;\n    flex-direction: row;\n    padding: 64px 24px 40px 24px;\n    padding-left: 0px;\n    display: flex;\n    flex-wrap: nowrap;\n    max-width: 1200px;\n    gap: 24px;\n    height: 235px;\n\n    a {\n      border: 1px solid ", "!important;\n    }\n  }\n\n  .slick-list {\n    :hover {\n      // box-shadow: 0px 8px 48px 0px rgba(0, 0, 0, 0.08);\n      border-radius: 16px;\n    }\n  }\n"]);
                return v = function() {
                    return n
                }, n
            }

            function w() {
                var n = (0, m.A)(["\n  margin-top: 32px;\n  box-sizing: border-box;\n  margin: 8px;\n  padding: 16px;\n  border-radius: 16px;\n  background: #fff;\n  -webkit-flex: 1;\n  -ms-flex: 1;\n  flex: 1;\n  font-size: 12px;\n  position: relative;\n  -webkit-text-decoration: none;\n  text-decoration: none;\n  box-shadow: none;\n  &:hover {\n    // box-shadow: 0px 8px 48px 0px rgba(0, 0, 0, 0.08);\n  }\n  @media ", " {\n    border-radius: 16px;\n    border: none !important;\n    padding: 0px;\n  }\n\n  @media ", " {\n    min-width: 45%;\n    padding: 16px;\n    margin: 0px;\n    // box-shadow: 0px 8px 48px 0px rgba(0, 0, 0, 0.08);\n  }\n\n  @media ", " {\n    box-shadow: none;\n    min-width: 282px;\n    padding: 16px;\n    margin: 8px 0px;\n  }\n"]);
                return w = function() {
                    return n
                }, n
            }

            function A() {
                var n = (0, m.A)(["\n  font-size: 16px;\n  font-weight: 500;\n  line-height: 24px;\n"]);
                return A = function() {
                    return n
                }, n
            }

            function S() {
                var n = (0, m.A)(["\n  margin: 4px 0 4px 0;\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-align-items: baseline;\n  -webkit-box-align: baseline;\n  -ms-flex-align: baseline;\n  align-items: baseline;\n"]);
                return S = function() {
                    return n
                }, n
            }

            function T() {
                var n = (0, m.A)(["\n  font-size: 24px;\n  font-weight: 600;\n  line-height: 34px;\n"]);
                return T = function() {
                    return n
                }, n
            }

            function P() {
                var n = (0, m.A)(["\n  font-size: 12px;\n  line-height: 18px;\n  margin-left: 4px;\n"]);
                return P = function() {
                    return n
                }, n
            }

            function E() {
                var n = (0, m.A)(["\n  box-sizing: border-box;\n  display: -webkit-box;\n  display: -webkit-flex;\n  display: -ms-flexbox;\n  display: flex;\n"]);
                return E = function() {
                    return n
                }, n
            }

            function j() {
                var n = (0, m.A)(["\n  margin-right: 4px;\n  font-weight: 500;\n  line-height: 18px;\n  &.green {\n    color: #03a66d;\n  }\n  &.red {\n    color: #cf304a;\n  }\n"]);
                return j = function() {
                    return n
                }, n
            }

            function k() {
                var n = (0, m.A)(["\n  font-size: 12px;\n  color: #76808f;\n  line-height: 18px;\n"]);
                return k = function() {
                    return n
                }, n
            }

            function C() {
                var n = (0, m.A)(["\n  margin-top: -20px;\n  top: 50%;\n  right: 20px;\n  width: 86px;\n  height: 28px;\n  position: absolute;\n  border-bottom: 1px dashed rgb(240, 185, 10);\n\n  @media ", " {\n    right: 75px;\n  }\n\n  @media ", " {\n    right: 20px;\n  }\n\n  @media ", " {\n    right: 20px;\n  }\n"]);
                return C = function() {
                    return n
                }, n
            }

            function I() {
                var n = (0, m.A)(["\n  width: 86px;\n  height: 28px;\n"]);
                return I = function() {
                    return n
                }, n
            }

            function D() {
                var n = (0, m.A)(["\n  position: absolute;\n  height: 3px;\n  display: flex;\n  gap: 4px;\n  bottom: 0px;\n\n  span {\n    display: inline-block;\n    width: 8px;\n    height: 3px;\n    background: var(--color-Line);\n\n    &.active {\n      background: var(--color-PrimaryText);\n    }\n  }\n\n  @media ", " {\n    display: flex;\n    margin-top: 16px;\n    position: relative;\n    bottom: unset;\n    margin-left: auto;\n    margin-right: auto;\n  }\n\n  @media ", " {\n    display: flex;\n    margin-top: 24px;\n    position: absolute;\n    bottom: 0px;\n  }\n"]);
                return D = function() {
                    return n
                }, n
            }
            var N = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-0"
                })(v(), (function(n) {
                    return n.isLight ? "#EAECEF" : "#2B3139"
                }), y.y.mobileS, y.y.tablet, (function(n) {
                    return n.isLight ? "#EAECEF" : "#2B3139"
                }), y.y.laptop, (function(n) {
                    return n.isLight ? "#EAECEF" : "#2B3139"
                })),
                _ = b.Ay.a.withConfig({
                    componentId: "sc-1f3980b2-1"
                })(w(), y.y.mobileS, y.y.tablet, y.y.laptop),
                z = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-2"
                })(A()),
                R = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-3"
                })(S()),
                L = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-4"
                })(T()),
                M = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-5"
                })(P()),
                Y = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-6"
                })(E()),
                O = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-7"
                })(j()),
                U = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-8"
                })(k()),
                G = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-9"
                })(C(), y.y.mobileS, y.y.tablet, y.y.laptop),
                H = b.Ay.img.withConfig({
                    componentId: "sc-1f3980b2-10"
                })(I()),
                B = b.Ay.div.withConfig({
                    componentId: "sc-1f3980b2-11"
                })(D(), y.y.mobileS, y.y.tablet),
                V = e("JyOs"),
                q = e("P5R0"),
                F = e("VmWQ"),
                W = F.ct.HOMEPAGE,
                X = function(n) {
                    var t = n.language,
                        e = n.base,
                        r = n.quote,
                        o = n.index,
                        a = n.percentChangeColor,
                        s = n.priceChangePercent,
                        c = n.lastPrice,
                        d = n.quoteVolume,
                        p = (n.current, n.counts, (0, V.s)().t),
                        u = (0, V.g)({
                            pageName: W,
                            skipPageViewTrack: !0,
                            extraInfo: {
                                product_type: l.RN,
                                coin: e
                            }
                        });
                    return (0, i.jsxs)(_, {
                        href: "".concat((0, q.mS)(t, e, r), "?utm_source=BinanceResearch"),
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "card-".concat(o),
                        onClick: function() {
                            (0, q.Tk)({
                                pageName: W,
                                elementId: F.ct.COIN_PRICE_WIDGETS,
                                payload: u
                            })
                        },
                        children: [(0, i.jsx)(z, {
                            children: "".concat(e, " / ").concat(r)
                        }), (0, i.jsxs)(R, {
                            children: [(0, i.jsx)(L, {
                                children: c
                            }), (0, i.jsx)(M, {
                                children: "$".concat(c)
                            })]
                        }), (0, i.jsxs)(Y, {
                            children: [(0, i.jsx)(O, {
                                className: "".concat(a),
                                children: "".concat(s, "%")
                            }), (0, i.jsx)(U, {
                                children: "".concat(p("fiat-volume"), ": ").concat(d, " USDT")
                            })]
                        }), (0, i.jsx)(G, {
                            children: (0, i.jsx)(H, {
                                alt: e + r,
                                src: "https://bin.bnbstatic.com/kline/".concat(e).concat(r, ".svg")
                            })
                        })]
                    }, "".concat(e, "_").concat(r))
                },
                Z = e("AlKg"),
                Q = e("wIZF"),
                $ = e("OKx2"),
                J = e("eh2c"),
                K = e("O94r"),
                nn = e.n(K),
                tn = e("7I3l"),
                en = e.n(tn),
                rn = e("2OVm"),
                on = e("UkUV"),
                an = Math.floor,
                ln = function(n) {
                    return an(100 * n) / 100
                },
                sn = !(0, $.dg)() || {
                    passive: !0,
                    capture: !0
                },
                cn = u().Fragment,
                dn = function(n) {
                    function t(t) {
                        var e = n.call(this, t) || this;
                        e.count = 0, e.timer = -1, e.pulling = !1, e.unmount = !1, e.pullElement = null, e.onMouse = function(n) {
                            var t = e.props.autoplay,
                                i = n.type;
                            n.currentTarget === n.target && t && ("mouseenter" === i ? e.pause() : e.autoplay())
                        }, e.onResize = (0, J.nF)((function() {
                            e.unmount || e.switchSlide(e.state.activeIndex, !1)
                        }), 100 / 6), e.autoplay = function() {
                            var n = e.props.interval;
                            e.pulling || -1 !== e.timer || (e.timer = setTimeout((function() {
                                e.unmount || (e.switchNext(!0), e.timer = -1, e.autoplay())
                            }), n))
                        }, e.pause = function() {
                            -1 !== e.timer && (clearTimeout(e.timer), e.timer = -1)
                        }, e.getTranslateIndex = function(n) {
                            var t = e.getCircular(),
                                i = e.props.slidesPerGroup;
                            return t ? n + i : n
                        }, e.indexGetter = function(n) {
                            var t = e.count,
                                i = e.getCircular(),
                                r = e.props,
                                o = r.slidesPerGroup,
                                a = r.slidesPerView,
                                l = an(a),
                                s = Math.max(0, t - l),
                                c = n,
                                d = n;
                            return c > 0 && o > 1 && (c += 1), i ? c < 0 ? d = c % t + t : c > s && (d = c % t) : (c < 0 ? c = 0 : c > s && (c = s), d = c), {
                                current: an(c / o) * o,
                                activeIndex: an(d / o) * o
                            }
                        }, e.switchPrev = function(n) {
                            var t = e.props.slidesPerGroup,
                                i = e.state.activeIndex;
                            e.switchSlide(i - t, n)
                        }, e.switchNext = function(n) {
                            var t = e.props.slidesPerGroup,
                                i = e.state.activeIndex;
                            e.switchSlide(i + t, n)
                        }, e.switchSlide = function(n, t) {
                            var i = e.props.onSlide,
                                r = e.indexGetter(n),
                                o = r.current,
                                a = r.activeIndex,
                                l = e.calculateDistance({
                                    translateIndex: e.getTranslateIndex(o)
                                }),
                                s = l.translateX,
                                c = l.translateY,
                                d = function() {
                                    !e.unmount && e.pullElement && (e.setState({
                                        activeIndex: a
                                    }), e.pullElement.animateTo(s, c).then((function() {
                                        i(a), o !== a && e.switchSlide(a, !1)
                                    })))
                                };
                            t || [null, void 0].indexOf(t) > -1 ? d() : (e.pullElement.setTranslate(s, c), rn.A.checkViewport(), setTimeout((function() {
                                return d()
                            }), 100))
                        }, e.calculateDistance = function(n) {
                            var t = e.isLtr(),
                                i = e.pxGetter(e.props.gap),
                                r = e.isHorizontal(),
                                o = e.getPadOffset(),
                                a = o.width,
                                l = o.height,
                                s = t ? n.translateIndex : -n.translateIndex,
                                c = ln((+a + i) * s),
                                d = ln((+l + i) * s);
                            return {
                                translateX: r ? -c : 0,
                                translateY: r ? 0 : -d
                            }
                        };
                        var i = t.initialSlide,
                            r = t.circular;
                        if (t.autoplay && !r) throw new Error("autoplay must be circular");
                        return e.state = {
                            activeIndex: i,
                            isClient: !1
                        }, e
                    }
                    return (0, Q.__extends)(t, n), t.prototype.componentDidMount = function() {
                        this.setState({
                            isClient: !0
                        }), this.initPullElement(), this.onResize(), this.eventConvert(!0)
                    }, t.prototype.eventConvert = function(n) {
                        var t = this.$refs.target,
                            e = n ? "addEventListener" : "removeEventListener";
                        if (window[e]("resize", this.onResize, sn), e in t) {
                            var i = t.parentNode;
                            i[e]("mouseenter", this.onMouse, sn), i[e]("mouseleave", this.onMouse, sn)
                        }
                    }, t.prototype.componentDidUpdate = function(n) {
                        var t = this.props,
                            e = t.slidesPerView,
                            i = t.autoplay,
                            r = t.circular;
                        if (i && !r) throw new Error("autoplay must be circular");
                        u().Children.count(n.children) === this.count && this.props.dir === n.dir && this.props.vertical === n.vertical || (console.log("re initPullElement"), this.pullElement && this.pullElement.destroy(), this.initPullElement()), r === n.circular && i === n.autoplay && e === n.slidesPerView || (this[i ? "autoplay" : "pause"](), this.onResize())
                    }, t.prototype.componentWillUnmount = function() {
                        this.pause(), this.eventConvert(), this.unmount = !0, this.pullElement && this.pullElement.destroy()
                    }, t.prototype.getPadOffset = function() {
                        var n = this.props.slidesPerView,
                            t = this.getGapPx(),
                            e = this.isHorizontal(),
                            i = this.$refs.target || {
                                clientWidth: 0,
                                clientHeight: 0
                            },
                            r = i.clientWidth,
                            o = i.clientHeight,
                            a = (n - 1) * t;
                        return {
                            height: e ? 0 : ln((o - a) / n),
                            width: e ? ln((r - a) / n) : 0
                        }
                    }, t.prototype.initPullElement = function() {
                        var n, t = this,
                            e = this.props,
                            i = e.autoplay,
                            r = e.initialSlide,
                            o = this.isHorizontal(),
                            a = this.isLtr();

                        function l() {
                            t.pulling = !0, t.pause()
                        }

                        function s(n) {
                            var e = n.translateX,
                                r = n.translateY;
                            this.preventDefault();
                            var l = t.state.activeIndex,
                                s = t.calculateDistance({
                                    translateIndex: t.getTranslateIndex(l)
                                }),
                                c = s.translateX,
                                d = s.translateY,
                                p = o ? e - c : r - d;
                            p > 20 ? t[a ? "switchPrev" : "switchNext"](!0) : p < -20 ? t[a ? "switchNext" : "switchPrev"](!0) : t.switchSlide(l, !0), t.pulling = !1, i && t.autoplay()
                        }
                        var c = o ? "Left" : "Up",
                            d = o ? "Right" : "Down";
                        this.pullElement = new(en())(((n = {
                            wait: !1,
                            target: this.$refs.target,
                            transitionProperty: "transform"
                        })["onPull".concat(c)] = l, n["onPull".concat(d)] = l, n["onPull".concat(c, "End")] = s, n["onPull".concat(d, "End")] = s, n.translateZ = this.props.translateZ, n)), this.pullElement.init(), this.switchSlide(r, !1), i && this.autoplay()
                    }, t.prototype.render = function() {
                        var n = this,
                            t = this.props,
                            e = t.className,
                            i = t.prefixCls,
                            r = void 0 === i ? "bn" : i,
                            o = t.slidesPerView,
                            a = t.slidesPerGroup,
                            l = t.children,
                            s = t.customPagination,
                            c = t.style,
                            d = this.state.activeIndex,
                            p = u().Children.count(l);
                        this.count = p;
                        var h = u().Children.toArray(l),
                            g = this.getCircular(),
                            f = "".concat(r, "-swiper");
                        if (g) {
                            var x = h.slice(0, a),
                                m = h.slice(-a);
                            h.push.apply(h, x), h.unshift.apply(h, m)
                        }
                        var b, y = this.isLtr(),
                            v = this.getGapPx(),
                            w = this.isHorizontal(),
                            A = ln((o - 1) * v / o),
                            S = h.map((function(n, t) {
                                var e = d === t;
                                g && (e = 0 === d ? t === a || t === p + a : d === p - 1 ? t === p + (a - 1) || t === a - 1 : d === t - a);
                                var i = {
                                    width: "calc(".concat(ln(100 / o), "% - ").concat(A, "px)")
                                };
                                i[w ? y ? "marginRight" : "marginLeft" : "marginBottom"] = "".concat(v, "px");
                                var r = nn()("".concat(f, "-item"), {
                                    active: e
                                });
                                return u().createElement("div", {
                                    key: t,
                                    className: r,
                                    style: i,
                                    children: n
                                })
                            }));
                        return "function" === typeof s && (b = s({
                            total: p,
                            currentIndex: d,
                            onClick: function(t) {
                                return n.switchSlide(t, !0)
                            }
                        })), u().createElement("div", {
                            className: nn()(f, {
                                vertical: !w
                            }, e),
                            style: c
                        }, u().createElement("div", {
                            className: "".concat(f, "-wrapper"),
                            ref: this.setRefs("target"),
                            children: S
                        }), b)
                    }, t.prototype.getCircular = function() {
                        var n = this.props,
                            t = n.circular,
                            e = n.slidesPerGroup;
                        return this.state.isClient && t && this.count > e
                    }, t.prototype.isHorizontal = function() {
                        return !this.props.vertical
                    }, t.prototype.isLtr = function() {
                        return "ltr" === this.props.dir
                    }, t.prototype.getGapPx = function() {
                        return parseFloat(this.props.gap)
                    }, t.prototype.pxGetter = function(n) {
                        return parseFloat(n)
                    }, t.defaultProps = {
                        gap: "0px",
                        initialSlide: 0,
                        slidesPerView: 1,
                        slidesPerGroup: 1,
                        autoplay: !1,
                        interval: 5e3,
                        vertical: !1,
                        translateZ: !0,
                        onSlide: function() {
                            return !1
                        },
                        dir: "ltr"
                    }, t
                }(on.A);
            const pn = dn;
            var un = e("zEAf"),
                hn = (0, p.forwardRef)((function(n, t) {
                    var e = (0, un.r)(),
                        i = e.prefixCls,
                        r = e.isRTL ? "rtl" : "ltr";
                    return u().createElement(pn, (0, Q.__assign)({}, n, {
                        ref: t,
                        dir: r,
                        prefixCls: i
                    }))
                }));
            (0, p.forwardRef)((function(n, t) {
                return u().createElement(cn, (0, Q.__assign)({}, n, {
                    ref: t
                }))
            }));
            const gn = hn;
            const fn = function() {
                var n = (0, V.s)().language,
                    t = (0, h.Ay)(x.n0, x.Wl).data,
                    e = (0, a.Q)().isMobile,
                    r = (0, Z.DP)().isLight,
                    o = (0, d.A)(u().useState(0), 2),
                    l = o[0],
                    s = o[1],
                    p = [(0, x.M6)("BTC", "USDT", t), (0, x.M6)("BNB", "USDT", t), (0, x.M6)("ETH", "USDT", t), (0, x.M6)("UNI", "USDT", t)];
                return (0, i.jsx)(f.t, {
                    children: (0, i.jsx)(N, {
                        isLight: r,
                        children: e ? (0, i.jsxs)(i.Fragment, {
                            children: [(0, i.jsxs)(g.A, {
                                sx: {
                                    display: "flex",
                                    flexDirection: "column",
                                    gap: "1px"
                                },
                                children: [(0, i.jsx)(gn, {
                                    autoplay: !0,
                                    circular: !0,
                                    className: "pinned-post",
                                    gap: "24px",
                                    onSlide: s,
                                    slidesPerGroup: 1,
                                    slidesPerView: 1,
                                    children: p.map((function(t, e) {
                                        return (0, i.jsx)(g.A, {
                                            id: "mobile-widget-card",
                                            sx: {
                                                borderRadius: "16px"
                                            },
                                            children: (0, i.jsx)(g.A, {
                                                sx: {
                                                    position: "relative",
                                                    px: "sm",
                                                    borderRadius: "16px",
                                                    border: "1px solid  var(--color-Line);"
                                                },
                                                children: (0, i.jsx)(X, (0, c.A)({
                                                    counts: p.length || 0,
                                                    current: e,
                                                    language: n,
                                                    index: e
                                                }, t), e)
                                            })
                                        }, e)
                                    }))
                                }), (0, i.jsx)(g.A, {
                                    height: 3
                                })]
                            }), (0, i.jsx)(B, {
                                children: new Array((null === p || void 0 === p ? void 0 : p.length) || 0).fill(0).map((function(n, t) {
                                    return (0, i.jsx)("span", {
                                        className: l === t ? "active" : ""
                                    })
                                }))
                            })]
                        }) : p.map((function(t, e) {
                            return (0, i.jsx)(X, (0, c.A)({
                                language: n,
                                index: e
                            }, t), e)
                        }))
                    })
                })
            };
            var xn = e("C6y2"),
                mn = e("yhUQ"),
                bn = e("ihIc");

            function yn() {
                var n = (0, m.A)(["\n  position: relative;\n  width: 100%;\n\n  @media ", " {\n    padding: 16px;\n\n    padding-top: 16px;\n\n    .body-wrapper {\n      padding-bottom: 0px;\n    }\n  }\n  @media ", " {\n    padding-left: 24px;\n    padding-top: 32px;\n    padding-bottom: 48px;\n  }\n  @media ", " {\n    padding: 0px;\n    padding-top: 48px;\n  }\n  margin-bottom: 0px;\n"]);
                return yn = function() {
                    return n
                }, n
            }
            var vn = b.Ay.header.withConfig({
                componentId: "sc-28fdcf97-0"
            })(yn(), bn.y.mobileS, bn.y.tablet, bn.y.laptop);
            const wn = function() {
                var n = (0, V.s)().t,
                    t = (0, a.Q)(),
                    e = t.isMobile,
                    r = (t.isIPad, (0, Z.DP)().isLight);
                return (0, i.jsx)(vn, {
                    children: (0, i.jsx)(s.dp, {
                        maxWidth: "1200px",
                        noInlinePadding: !0,
                        children: (0, i.jsxs)(xn.A, {
                            sx: {
                                gap: "8px"
                            },
                            flexDirection: "column",
                            children: [(0, i.jsx)(g.A, {
                                as: "h1",
                                maxWidth: ["327px", "588px", "588px"],
                                sx: e ? {
                                    fontSize: "24px",
                                    lineHeight: "34px",
                                    color: r ? "#202630" : "#EAECEF",
                                    fontWeight: 600
                                } : {
                                    fontSize: "32px",
                                    lineHeight: "40px",
                                    color: r ? "#202630" : "#EAECEF",
                                    fontWeight: 600
                                },
                                children: n("top-banner-title")
                            }), (0, i.jsx)(mn.A, {
                                mb: ["", "", "48px"],
                                sx: {
                                    fontSize: "14px",
                                    lineHeight: "22px",
                                    color: "var(--color-textSecondary)",
                                    fontWeight: 400
                                },
                                children: n("top-banner-description")
                            })]
                        })
                    })
                })
            };
            var An = e("Y4uf");
            const Sn = function(n) {
                return u().createElement(An.A, (0, Q.__assign)({
                    viewBox: "0 0 24 24",
                    fill: "none"
                }, n), u().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M12.288 12l-3.89 3.89 1.768 1.767L15.823 12l-1.768-1.768-3.889-3.889-1.768 1.768 3.89 3.89z",
                    fill: "currentColor"
                }))
            };

            function Tn() {
                var n = (0, m.A)(["\n  position: relative;\n\n  @media ", " {\n    margin-bottom: 64px;\n  }\n\n  @media ", " {\n    margin-bottom: 48px;\n  }\n\n  @media ", " {\n    margin-bottom: 120px;\n  }\n"]);
                return Tn = function() {
                    return n
                }, n
            }

            function Pn() {
                var n = (0, m.A)(["\n  @media ", " {\n    display: flex;\n    flex-direction: column;\n    gap: 16px;\n    align-items: baseline;\n  }\n\n  @media ", " {\n    display: flex;\n    flex-direction: row;\n    align-items: center;\n    justify-content: space-between;\n  }\n"]);
                return Pn = function() {
                    return n
                }, n
            }

            function En() {
                var n = (0, m.A)(["\n  @media ", " {\n    font-size: 24px;\n    font-weight: 600;\n    color: #1e2329;\n  }\n  @media ", " {\n    font-size: 32px;\n    font-weight: 600;\n    color: #1e2329;\n  }\n"]);
                return En = function() {
                    return n
                }, n
            }

            function jn() {
                var n = (0, m.A)(["\n  display: inline-flex;\n  align-items: center;\n  color: #707a8a;\n  font-size: 14px;\n  &:hover {\n    color: #1e2329;\n  }\n\n  svg {\n    font-size: 20px;\n  }\n"]);
                return jn = function() {
                    return n
                }, n
            }
            var kn = b.Ay.div.withConfig({
                    componentId: "sc-7f180a5-0"
                })(Tn(), y.y.mobileS, y.y.tablet, y.y.laptop),
                Cn = b.Ay.div.withConfig({
                    componentId: "sc-7f180a5-1"
                })(Pn(), y.y.mobileS, y.y.tablet),
                In = b.Ay.h2.withConfig({
                    componentId: "sc-7f180a5-2"
                })(En(), y.y.mobileS, y.y.tablet),
                Dn = b.Ay.a.withConfig({
                    componentId: "sc-7f180a5-3"
                })(jn()),
                Nn = F.ct.HOMEPAGE;
            const _n = function(n) {
                var t, e = n.title,
                    r = n.articles,
                    o = n.categoryId,
                    c = n.categorySlug,
                    d = (0, V.s)(),
                    p = d.t,
                    u = d.language,
                    h = (0, a.Q)(),
                    g = h.isMobile,
                    f = h.isIPad,
                    x = {
                        analysis: (0, q.Od)(u),
                        projects: (0, q.FO)(u)
                    },
                    m = x[c],
                    b = (0, q.bp)(m),
                    y = (0, V.g)({
                        pageName: Nn,
                        skipPageViewTrack: !0,
                        extraInfo: {
                            product_type: l.RN,
                            redirection_url: b,
                            redirection_url_path: m,
                            category_id: null === o || void 0 === o ? void 0 : o.toString(),
                            category_name: c
                        }
                    });
                return (0, i.jsxs)(kn, {
                    children: [(0, i.jsxs)(Cn, {
                        children: [(0, i.jsx)(In, {
                            children: p(e)
                        }), x[c] && (0, i.jsxs)(Dn, {
                            onClick: function() {
                                (0, q.Tk)({
                                    pageName: Nn,
                                    elementId: F.ct.SEE_ALL_BUTTON,
                                    payload: y
                                })
                            },
                            href: x[c],
                            children: [p("article-view-all"), (0, i.jsx)(Sn, {})]
                        })]
                    }), (0, i.jsx)(s.R2, {
                        children: r.filter((function(n) {
                            return !n.hidden
                        })).slice(0, g || f ? 2 : 3).map((function(n) {
                            return (0, i.jsx)(s._Z, {
                                articleId: n.id,
                                articleTitle: n.title,
                                categorySlug: c,
                                articleSlug: n.slug,
                                articleImage: n.image,
                                articleDesc: n.description,
                                language: u,
                                categoryTags: n.categoryTags,
                                updateTime: null !== (t = Number(n.time)) && void 0 !== t ? t : void 0,
                                pageName: Nn,
                                elementId: F.ct.ARTICLE_CARD
                            }, n.id)
                        }))
                    })]
                })
            };
            var zn = e("QUKP"),
                Rn = e("UsfP");

            function Ln() {
                var n = (0, m.A)(["\n  @media ", " {\n    margin-top: 80px;\n    margin-bottom: 40px;\n  }\n  @media ", " {\n    margin-top: 80px;\n    margin-bottom: 40px;\n  }\n  @media ", " {\n    margin-top: 0px;\n    margin-bottom: 80px;\n  }\n  color: #1e2329;\n\n  a {\n    color: #1e2329;\n  }\n"]);
                return Ln = function() {
                    return n
                }, n
            }

            function Mn() {
                var n = (0, m.A)(["\n  @media ", " {\n    margin-bottom: 24px;\n    font-size: 24px;\n    font-weight: 600;\n  }\n  @media ", " {\n    margin-bottom: 40px;\n    font-size: 32px;\n    font-weight: 600;\n  }\n"]);
                return Mn = function() {
                    return n
                }, n
            }

            function Yn() {
                var n = (0, m.A)(["\n  width: 100%;\n  th {\n    font-size: 12px;\n    font-weight: 400;\n  }\n  th,\n  td {\n    padding: 8px;\n    font-size: 16px;\n  }\n  th:first-child,\n  td:first-child {\n    padding-left: 16px;\n    border-radius: 8px 0 0 8px;\n  }\n  td:last-child,\n  th:last-child {\n    border-radius: 0 8px 8px 0;\n  }\n  td:first-child {\n    font-weight: 500;\n  }\n\n  td(:nth-child(n + 3)) {\n    font-weight: 600;\n  }\n\n  @media ", " {\n    th {\n      padding-block: 12px;\n      font-size: 12px;\n      font-weight: 400;\n    }\n    td {\n      padding-block: 16px;\n      font-size: 16px;\n    }\n    th:first-child,\n    td:first-child {\n      padding-left: 0px;\n      border-radius: 8px 0 0 8px;\n    }\n    td:last-child,\n    th:last-child {\n      border-radius: 0 8px 8px 0;\n      text-align: right;\n      padding: 0px;\n      a {\n        padding-block: 0px;\n        text-align: right;\n        width: 100%;\n      }\n    }\n\n    td(:nth-child(n + 3)) {\n      font-weight: 600;\n    }\n  }\n  @media ", " {\n    th {\n      padding-block: 12px;\n      font-size: 12px;\n      font-weight: 400;\n    }\n    td {\n      padding-block: 16px;\n      font-size: 16px;\n    }\n    th:first-child,\n    td:first-child {\n      padding-left: 0px;\n      border-radius: 8px 0 0 8px;\n    }\n    td:last-child {\n      padding-left: 0px;\n    }\n    td:last-child,\n    th:last-child {\n      border-radius: 0 8px 8px 0;\n      text-align: right;\n      padding: 0px;\n      a {\n        padding-block: 0px;\n        text-align: right;\n        width: 100%;\n      }\n    }\n\n    td(:nth-child(n + 3)) {\n      font-weight: 600;\n    }\n  }\n\n  @media ", " {\n    th {\n      font-size: 12px;\n      padding: 12px;\n      font-weight: 400;\n    }\n    td {\n      padding: 16px;\n      font-size: 16px;\n    }\n    th:first-child,\n    td:first-child {\n      padding-left: 16px;\n      border-radius: 8px 0 0 8px;\n    }\n    td:last-child,\n    th:last-child {\n      border-radius: 0 8px 8px 0;\n      text-align: left;\n      a {\n        padding-left: 12px;\n        text-align: left;\n      }\n    }\n    td:first-child {\n      font-weight: 500;\n    }\n    th: last-child {\n      text-align: right;\n      padding-right: 16px;\n    }\n    td:last-child {\n      padding-left: 0px;\n      padding-right: 16px;\n      text-align: right;\n      a {\n        text-align: right;\n        width: 100%;\n      }\n    }\n\n    td(:nth-child(n + 3)) {\n      font-weight: 600;\n    }\n  }\n\n  @media ", " {\n    table-layout: fixed;\n    th:first-child {\n      width: 35%;\n    }\n    th:last-child {\n      width: 15%;\n      padding-right: 16px;\n    }\n    td:last-child {\n      padding-inline: 0px;\n      text-align: center;\n      a {\n        padding: 8px 16px;\n        text-align: center;\n        width: fit-content;\n      }\n    }\n  }\n"]);
                return Yn = function() {
                    return n
                }, n
            }

            function On() {
                var n = (0, m.A)(["\n  &:hover {\n    background: #fafafa;\n    border-radius: 8px;\n  }\n"]);
                return On = function() {
                    return n
                }, n
            }

            function Un() {
                var n = (0, m.A)(["\n  width: 24px;\n  @media ", " {\n    width: 32px;\n  }\n  @media ", " {\n    width: 36px;\n  }\n"]);
                return Un = function() {
                    return n
                }, n
            }

            function Gn() {
                var n = (0, m.A)(["\n  margin: 0 16px 0 16px;\n  display: none;\n  @media ", " {\n    display: initial;\n  }\n"]);
                return Gn = function() {
                    return n
                }, n
            }

            function Hn() {
                var n = (0, m.A)(["\n  color: #707a8a;\n  display: none;\n  font-weight: 400;\n  @media ", " {\n    font-weight: 400;\n    display: initial;\n  }\n"]);
                return Hn = function() {
                    return n
                }, n
            }

            function Bn() {
                var n = (0, m.A)(["\n  font-weight: 600;\n  &.green {\n    color: #03a66d;\n  }\n  &.red {\n    color: #cf304a;\n  }\n"]);
                return Bn = function() {
                    return n
                }, n
            }

            function Vn() {
                var n = (0, m.A)(["\n  display: block;\n  text-align: right;\n  text-decoration: underline;\n  color: ", ";\n  width: fit-content;\n\n  @media ", " {\n    padding: 8px 0px;\n  }\n  @media ", " {\n    margin-left: auto;\n  }\n"]);
                return Vn = function() {
                    return n
                }, n
            }
            var qn = b.Ay.div.withConfig({
                    componentId: "sc-91a1d8d3-0"
                })(Ln(), Rn.y0.mobileS, Rn.y0.tablet, Rn.y0.laptop),
                Fn = b.Ay.h2.withConfig({
                    componentId: "sc-91a1d8d3-1"
                })(Mn(), Rn.y0.mobileS, Rn.y0.tablet),
                Wn = b.Ay.table.withConfig({
                    componentId: "sc-91a1d8d3-2"
                })(Yn(), Rn.y0.mobileS, Rn.y0.mobileM, Rn.y0.tablet, Rn.y0.laptop),
                Xn = b.Ay.tr.withConfig({
                    componentId: "sc-91a1d8d3-3"
                })(On()),
                Zn = b.Ay.img.withConfig({
                    componentId: "sc-91a1d8d3-4"
                })(Un(), Rn.y0.mobileS, Rn.y0.tablet),
                Qn = b.Ay.span.withConfig({
                    componentId: "sc-91a1d8d3-5"
                })(Gn(), Rn.y0.tablet),
                $n = b.Ay.span.withConfig({
                    componentId: "sc-91a1d8d3-6"
                })(Hn(), Rn.y0.tablet),
                Jn = b.Ay.a.withConfig({
                    componentId: "sc-91a1d8d3-7"
                })(Bn()),
                Kn = b.Ay.a.withConfig({
                    componentId: "sc-91a1d8d3-8"
                })(Vn(), (function(n) {
                    return n.isLight ? "#202630" : "#EAECEF"
                }), Rn.y0.mobileS, Rn.y0.tablet),
                nt = F.ct.HOMEPAGE;
            const tt = function() {
                var n = (0, h.Ay)(x.n0, x.Wl),
                    t = n.data,
                    e = n.error,
                    r = (0, V.s)(),
                    o = r.t,
                    a = r.language,
                    s = (0, Z.DP)().theme,
                    d = void 0 === s ? "light" : s,
                    p = (0, V.g)({
                        pageName: nt,
                        skipPageViewTrack: !0,
                        extraInfo: {
                            product_type: l.RN
                        }
                    });
                if (e) return null;
                if (!t) return null;
                var u = [(0, zn.A)((0, c.A)({}, (0, x.M6)("BNB", "USDT", t)), {
                    path: "bnb",
                    slug: "BNB"
                }), (0, zn.A)((0, c.A)({}, (0, x.M6)("BTC", "USDT", t)), {
                    path: "bitcoin",
                    slug: "Bitcoin"
                }), (0, zn.A)((0, c.A)({}, (0, x.M6)("ETH", "USDT", t)), {
                    path: "ethereum",
                    slug: "Ethereum"
                }), (0, zn.A)((0, c.A)({}, (0, x.M6)("XRP", "USDT", t)), {
                    path: "xrp",
                    slug: "XRP"
                }), (0, zn.A)((0, c.A)({}, (0, x.M6)("BCH", "USDT", t)), {
                    path: "bitcoin-cash",
                    slug: "Bitcoin Cash"
                }), (0, zn.A)((0, c.A)({}, (0, x.M6)("LTC", "USDT", t)), {
                    path: "litecoin",
                    slug: "Litecoin"
                })];
                return (0, i.jsxs)(qn, {
                    children: [(0, i.jsx)(Fn, {
                        children: o("price-info")
                    }), (0, i.jsx)(Wn, {
                        children: (0, i.jsxs)("tbody", {
                            children: [(0, i.jsxs)("tr", {
                                children: [(0, i.jsx)("th", {
                                    children: o("price-name")
                                }), (0, i.jsx)("th", {
                                    children: o("price-last-price")
                                }), (0, i.jsx)("th", {
                                    children: o("price-24-change")
                                }), (0, i.jsx)("th", {
                                    children: o("price-read-more")
                                })]
                            }), u.map((function(n) {
                                var t = n.slug,
                                    e = n.base,
                                    r = n.quote,
                                    s = n.path,
                                    u = n.lastPrice,
                                    h = n.percentChangeColor,
                                    g = n.priceChangePercent,
                                    f = (0, q.mS)(a, e, r);
                                return (0, i.jsxs)(Xn, {
                                    children: [(0, i.jsx)("td", {
                                        children: (0, i.jsxs)("a", {
                                            href: "".concat(f, "?utm_source=BinanceResearch"),
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: [(0, i.jsx)(Zn, {
                                                loading: "lazy",
                                                src: (0, q.EY)("/images/projects/".concat(s, "/logo.png")),
                                                alt: t
                                            }), (0, i.jsx)(Qn, {
                                                children: e
                                            }), (0, i.jsx)($n, {
                                                children: t
                                            })]
                                        })
                                    }), (0, i.jsx)("td", {
                                        children: (0, i.jsx)("a", {
                                            href: f,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: "$".concat(u)
                                        }, e)
                                    }), (0, i.jsx)("td", {
                                        children: (0, i.jsx)(Jn, {
                                            className: "".concat(h),
                                            href: f,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: "".concat(g, "%")
                                        }, e)
                                    }), (0, i.jsx)("td", {
                                        children: (0, i.jsx)(Kn, {
                                            className: "t-btnLink2",
                                            isLight: "light" === d,
                                            onClick: function() {
                                                return function(n, t) {
                                                    var e = (0, q.bp)(n);
                                                    (0, q.Tk)({
                                                        pageName: nt,
                                                        elementId: F.ct.READ_REPORT_BUTTON,
                                                        payload: (0, zn.A)((0, c.A)({}, p), {
                                                            coin: t,
                                                            redirection_url_path: n,
                                                            redirection_url: e
                                                        })
                                                    })
                                                }((0, q.Ez)(a, s, l.tY.PROJECTS), e)
                                            },
                                            href: (0, q.Ez)(a, s, l.tY.PROJECTS),
                                            children: o("price-read-report")
                                        })
                                    })]
                                }, e)
                            }))]
                        })
                    })]
                })
            };

            function et() {
                var n = (0, m.A)(["\n  @media ", " {\n    padding-bottom: 64px;\n  }\n  @media ", " {\n    padding-bottom: 80px;\n  }\n  @media ", " {\n    padding-bottom: 120px;\n  }\n"]);
                return et = function() {
                    return n
                }, n
            }

            function it() {
                var n = (0, m.A)(["\n  color: #1e2329;\n  font-weight: 500;\n  text-align: center;\n  margin: 0 0 38px 0;\n  @media ", " {\n    margin: 0 0 14px 0;\n  }\n  @media ", " {\n    margin: 0 0 38px 0;\n  }\n  font-size: 16px;\n"]);
                return it = function() {
                    return n
                }, n
            }

            function rt() {
                var n = (0, m.A)(["\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: 16px;\n"]);
                return rt = function() {
                    return n
                }, n
            }

            function ot() {
                var n = (0, m.A)(["\n  width: 138px;\n  height: 68px;\n  margin: 10px 0px;\n  cursor: pointer;\n\n  @media ", " {\n    margin: 0px;\n  }\n\n  @media ", " {\n    margin: 10px 0px;\n  }\n\n  @media ", " {\n    margin: 10px 0px;\n  }\n"]);
                return ot = function() {
                    return n
                }, n
            }
            var at = b.Ay.div.withConfig({
                    componentId: "sc-2565fe54-0"
                })(et(), y.y.mobileS, y.y.tablet, y.y.laptop),
                lt = b.Ay.p.withConfig({
                    componentId: "sc-2565fe54-1"
                })(it(), y.y.tablet, y.y.laptop),
                st = b.Ay.div.withConfig({
                    componentId: "sc-2565fe54-2"
                })(rt()),
                ct = b.Ay.img.withConfig({
                    componentId: "sc-2565fe54-3"
                })(ot(), y.y.mobileS, y.y.tablet, y.y.laptop),
                dt = F.ct.HOMEPAGE,
                pt = [{
                    link: "https://www.bloomberg.com/news/articles/2020-04-15/bitcoin-pioneer-bets-on-decentralized-finance-after-crash",
                    alt: "quoted by bloomberg",
                    img: "/images/quoted-by/bloomberg.svg"
                }, {
                    link: "https://uk.finance.yahoo.com/news/binance-facebook-libra-cryptocurrency-adoption-141515683.html",
                    alt: "quoted by yahoofinance",
                    img: "/images/quoted-by/yahoofinance.svg"
                }, {
                    link: "https://www.coindesk.com/litecoin-is-halving-soon-whats-happening-and-what-you-should-know",
                    alt: "quoted by coindesk",
                    img: "/images/quoted-by/coindesk.svg"
                }, {
                    link: "https://fortune.com/2020/06/14/bitcoin-stock-market-correlation-gold-investor-survey-fidelity/",
                    alt: "quoted by fortune",
                    img: "/images/quoted-by/fortune.svg"
                }, {
                    link: "https://www.bde.es/f/webbde/SES/Secciones/Publicaciones/PublicacionesSeriadas/DocumentosOcasionales/20/Fich/do2005.pdf",
                    alt: "quoted by bankofspain",
                    img: "/images/quoted-by/bankofspain.svg"
                }, {
                    link: "https://cointelegraph.com/news/binance-research-explains-recent-libra-spacex-comparison",
                    alt: "quoted by cointelegraph",
                    img: "/images/quoted-by/cointelegraph.svg"
                }, {
                    link: "https://www.independent.co.uk/life-style/gadgets-and-tech/news/china-cryptocurrency-binance-bitcoin-banks-a9085161.html",
                    alt: "quoted by independent",
                    img: "/images/quoted-by/independent.svg"
                }, {
                    link: "https://decrypt.co/15214/binance-cant-understand-irrational-bitcoin-cash-and-sv-miners",
                    alt: "quoted by decrypt",
                    img: "/images/quoted-by/decrypt.svg"
                }];
            const ut = function() {
                var n = (0, V.s)().t,
                    t = (0, V.g)({
                        pageName: dt,
                        skipPageViewTrack: !0,
                        extraInfo: {
                            product_type: l.RN
                        }
                    });
                return (0, i.jsxs)(at, {
                    children: [(0, i.jsx)(lt, {
                        children: n("quote-title")
                    }), (0, i.jsx)(st, {
                        children: pt.map((function(n) {
                            var e = n.img,
                                r = n.link,
                                o = n.alt;
                            return (0, i.jsx)("a", {
                                onClick: function() {
                                    return function(n) {
                                        (0, q.Tk)({
                                            pageName: dt,
                                            elementId: F.ct.MEDIA_LOGO,
                                            payload: (0, zn.A)((0, c.A)({}, t), {
                                                redirection_url: n
                                            })
                                        })
                                    }(r)
                                },
                                target: "_blank",
                                rel: "nonfollow noopener noreferrer",
                                href: r,
                                children: (0, i.jsx)(ct, {
                                    loading: "lazy",
                                    alt: o,
                                    src: (0, q.VG)(e)
                                })
                            }, e)
                        }))
                    })]
                })
            };
            var ht = e("wTtH"),
                gt = e("rLOQ"),
                ft = F.ct.HOMEPAGE,
                xt = function(n) {
                    var t = n.title,
                        e = n.description,
                        r = n.date,
                        o = n.tag,
                        a = n.isDesktop,
                        l = n.counts,
                        s = n.currentCount;
                    return (0, i.jsxs)(xn.A, {
                        sx: {
                            gap: a ? "16px" : "8px",
                            fontVariant: "normal",
                            fontFeatureSettings: "normal",
                            position: "relative"
                        },
                        flexDirection: "column",
                        alignItems: "baseline",
                        flex: a ? 3 : "",
                        children: [(0, i.jsx)(ht.A, {
                            variant: "gray",
                            children: o ? (0, i.jsx)(mn.A, {
                                variant: a ? "subtitle2" : "caption",
                                color: "var(--color-PrimaryText)",
                                children: o
                            }) : null
                        }), (0, i.jsx)(mn.A, {
                            variant: a ? "headline2" : "headline5",
                            color: "var(--color-PrimaryText)",
                            children: t
                        }), (0, i.jsx)(mn.A, {
                            className: "t-body1-1",
                            color: "var(--color-textSecondary)",
                            children: e
                        }), r ? (0, i.jsxs)(mn.A, {
                            variant: a ? "body1" : "body2",
                            fontSize: "14px",
                            fontWeight: "500",
                            color: "var(--color-PrimaryText)",
                            children: [r, " ", (0, i.jsxs)(mn.A, {
                                display: "inline-block",
                                ml: "16px",
                                children: ["#", o]
                            })]
                        }) : null, (0, i.jsx)(B, {
                            children: new Array(l).fill(0).map((function(n, t) {
                                return (0, i.jsx)("span", {
                                    className: s === t ? "active" : ""
                                }, "count__".concat(t))
                            }))
                        })]
                    })
                },
                mt = function(n) {
                    var t = n.pinnedPost,
                        e = n.isDesktop,
                        r = n.isMobile,
                        o = n.currentCount,
                        a = n.counts,
                        s = t.banner,
                        c = t.title,
                        d = t.category,
                        u = d.name,
                        h = void 0 === u ? "" : u,
                        g = d.translation,
                        f = void 0 === g ? "" : g,
                        x = t.brief,
                        m = t.releasedTime,
                        b = t.articlePath,
                        y = (0, V.s)().language,
                        v = h === l.Cr.ANALYSIS ? l.tY.ANALYSIS : l.tY.PROJECTS,
                        w = (0, q.Ez)(y, b, v),
                        A = (0, q.bp)(w),
                        S = (0, V.g)({
                            pageName: ft,
                            skipPageViewTrack: !0,
                            extraInfo: {
                                product_type: l.RN,
                                redirection_url: A,
                                redirection_url_path: w
                            }
                        }),
                        T = (0, p.useState)(s),
                        P = T[0],
                        E = T[1],
                        j = m ? (0, q.Yq)(m, "YYYY-MM-DD") : void 0;
                    return (0, i.jsxs)(xn.A, {
                        as: "a",
                        sx: {
                            gap: e ? "64px" : "16px"
                        },
                        flexDirection: r ? "column" : "row",
                        href: w,
                        onClick: function() {
                            (0, q.Tk)({
                                pageName: ft,
                                elementId: F.ct.PINNED_POST,
                                payload: S
                            })
                        },
                        children: [(0, i.jsx)(gt.A, {
                            sx: {
                                borderRadius: "16px",
                                minWidth: ["100%", "352px", "588px"],
                                width: ["100%", "352px", "588px"],
                                aspectRatio: "16/9",
                                objectFit: "cover",
                                zIndex: 2,
                                flex: e ? 2 : "",
                                mr: [0, "24px", 0]
                            },
                            loading: "lazy",
                            onError: function() {
                                E(l.U7)
                            },
                            src: P,
                            alt: c
                        }), (0, i.jsx)(xt, {
                            isDesktop: e,
                            currentCount: o,
                            counts: a,
                            title: c,
                            description: x,
                            date: j,
                            tag: h || f
                        })]
                    })
                },
                bt = function(n) {
                    var t = n.pinnedPosts,
                        e = (0, a.Q)(),
                        r = e.isMobile,
                        o = e.isIPad,
                        l = (0, d.A)(u().useState(0), 2),
                        s = (l[0], l[1]);
                    return (0, i.jsx)(gn, {
                        autoplay: !0,
                        circular: !0,
                        className: "pinned-post",
                        gap: "24px",
                        onSlide: s,
                        slidesPerGroup: 1,
                        slidesPerView: 1,
                        children: t.map((function(n, e) {
                            return (0, i.jsx)(mt, {
                                isMobile: r,
                                currentCount: e,
                                counts: t.length,
                                isDesktop: !r && !o,
                                pinnedPost: n
                            }, e)
                        }))
                    })
                },
                yt = e("HA26"),
                vt = F.ct.HOMEPAGE;
            const wt = function() {
                var n = (0, r.L)(),
                    t = n.currentUrl,
                    e = n.analysis,
                    c = n.projects,
                    d = n.pinnedPosts,
                    p = n.analysisCategoryId,
                    u = n.projectCategoryId,
                    h = (0, a.Q)(),
                    g = h.isMobile,
                    f = h.isIPad,
                    x = (0, V.s)(),
                    m = x.t,
                    b = x.language,
                    y = !g && !f,
                    v = (0, q.sC)({
                        pageUrl: t,
                        language: b,
                        desc: l.rV,
                        image: (0, q.VG)("/images/common/og-image.jpg")
                    });
                return (0, yt.g)({
                    pageName: vt,
                    extraInfo: {
                        product_type: "research"
                    }
                }), (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsxs)(o.A, {
                        children: [(0, i.jsx)("title", {
                            children: l.no
                        }), (0, i.jsx)("link", {
                            rel: "canonical",
                            href: "".concat(t)
                        }), v.map((function(n) {
                            var t = n.name,
                                e = n.content;
                            return (0, i.jsx)("meta", {
                                name: t,
                                property: t,
                                content: e
                            }, t)
                        }))]
                    }), (0, i.jsxs)(s.iH, {
                        pageName: vt,
                        footerProps: {
                            maxWidth: "1200px",
                            pageName: vt
                        },
                        children: [(0, i.jsx)(wn, {}), (0, i.jsxs)(s.dp, {
                            noInlinePadding: y,
                            maxWidth: "1200px",
                            children: [(0, i.jsx)(bt, {
                                pinnedPosts: d
                            }), (0, i.jsx)(fn, {}), (0, i.jsx)(_n, {
                                title: m("home-block-title-1"),
                                articles: e,
                                categoryId: Number(p),
                                categorySlug: l.tY.ANALYSIS
                            }), (0, i.jsx)(_n, {
                                title: m("home-block-title-2"),
                                articles: c,
                                categoryId: Number(u),
                                categorySlug: l.tY.PROJECTS
                            }), (0, i.jsx)(tt, {})]
                        }), (0, i.jsx)(ut, {})]
                    })]
                })
            }
        },
        "7I3l": function(n) {
            n.exports = function() {
                "use strict";

                function n(n) {
                    for (var t = arguments, e = t.length, i = 1; i < e; i++) {
                        var r = t[i];
                        for (var o in r) n[o] = r[o]
                    }
                    return n
                }

                function t(n) {
                    return "number" === typeof n && !isNaN(n)
                }

                function e(n) {
                    return "function" === typeof n
                }

                function i(n, t) {
                    var e, i, r, o, a = n.scrollWidth,
                        l = n.scrollHeight;
                    if (t) {
                        var s = document.documentElement,
                            c = document.body;
                        r = s.clientWidth, o = s.clientHeight, e = c.scrollTop || s.scrollTop, i = c.scrollLeft || s.scrollLeft
                    } else r = n.offsetWidth, o = n.offsetHeight, e = n.scrollTop, i = n.scrollLeft;
                    return {
                        isScrollTopEnd: e <= 0,
                        isScrollBottomEnd: o + e >= l,
                        isScrollLeftEnd: i <= 0,
                        isScrollRightEnd: r + i >= a
                    }
                }

                function r(n) {
                    return "string" === typeof n ? document.querySelector(n) : n
                }

                function o(n, t, e, i) {
                    n.addEventListener(t, e, i)
                }

                function a(n, t, e) {
                    n.removeEventListener(t, e)
                }

                function l(n) {
                    var t = n.touches[0];
                    return {
                        x: t.clientX,
                        y: t.clientY
                    }
                }

                function s(n, i) {
                    return e(i) ? i(n) : t(i) ? n / i : n
                }

                function c(n, t, e) {
                    var i = e ? "translate(" + n + "px," + t + "px) translateZ(0)" : "translate(" + n + "px," + t + "px)";
                    return {
                        transform: i,
                        webkitTransform: i
                    }
                }
                var d = {
                        passive: !1
                    },
                    p = {
                        transition: "",
                        transform: "",
                        webkitTransform: "",
                        webkitTransition: ""
                    },
                    u = {
                        transition: "",
                        webkitTransition: ""
                    },
                    h = {
                        pullDown: "onPullDown",
                        pullUp: "onPullUp",
                        pullRight: "onPullRight",
                        pullLeft: "onPullLeft"
                    },
                    g = {
                        pullDown: "isScrollTopEnd",
                        pullUp: "isScrollBottomEnd",
                        pullRight: "isScrollLeftEnd",
                        pullLeft: "isScrollRightEnd"
                    },
                    f = {
                        action: "",
                        axis: "",
                        translateX: 0,
                        translateY: 0
                    },
                    x = n({
                        isScrollTopEnd: !0,
                        isScrollLeftEnd: !0,
                        isScrollBottomEnd: !0,
                        isScrollRightEnd: !0,
                        clientX: 0,
                        clientY: 0
                    }, f),
                    m = {
                        target: "body",
                        scroller: "",
                        trigger: "",
                        damping: 1.6,
                        wait: !0,
                        pullUp: !1,
                        pullDown: !1,
                        pullLeft: !1,
                        pullRight: !1,
                        detectScroll: !1,
                        detectScrollOnStart: !1,
                        stopPropagation: !1,
                        drag: !1,
                        transitionProperty: "transform",
                        transitionDuration: "0.3s",
                        transitionTimingFunction: "ease-out",
                        translateZ: !0
                    },
                    b = "function" === typeof Promise;

                function y(t) {
                    this.options = n({}, m, t), this.state = n({}, x), this.target = null, this.scroller = null, this.trigger = null, this.transitionStyle = null, this.isTouching = !1, this.isPreventDefault = !1, this.isWaiting = !1, this.isGlobalScroller = !1, this.transitionDuration = 0, this.handleTouchStart = this.handleTouchStart.bind(this), this.handleTouchMove = this.handleTouchMove.bind(this), this.handleTouchEnd = this.handleTouchEnd.bind(this)
                }
                return n(y.prototype, {
                    init: function() {
                        var n = this.options,
                            t = r(n.target),
                            e = n.scroller ? r(n.scroller) : t,
                            i = n.trigger ? r(n.trigger) : t;
                        this.target = t, this.scroller = e, this.trigger = i, this.isGlobalScroller = e === document.body || e === window || e === document.documentElement, this.transitionStyle = {
                            transitionProperty: n.transitionProperty,
                            transitionDuration: n.transitionDuration,
                            transitionTimingFunction: n.transitionTimingFunction,
                            webkitTransitionProperty: n.transitionProperty,
                            webkitTransitionDuration: n.transitionDuration,
                            webkitTransitionTimingFunction: n.transitionTimingFunction
                        };
                        var o = Number(n.transitionDuration.replace(/[^.\d]+/g, ""));
                        /[\d\.]+s$/.test(n.transitionDuration) && (o *= 1e3), this.transitionDuration = o, this.enable()
                    },
                    destroy: function() {
                        this.disable()
                    },
                    setTranslate: function(t, e) {
                        n(this.target.style, u, c(t, e, this.options.translateZ))
                    },
                    animateTo: function(t, e, i) {
                        var r = this.state,
                            o = this.target,
                            a = this.transitionDuration,
                            l = this.transitionStyle,
                            s = c(t, e, this.options.translateZ);
                        r.translateX = t, r.translateY = e;
                        var d = function(t) {
                            n(o.style, l, s), setTimeout(t, a)
                        };
                        if (b) return new Promise(d).then(i);
                        d(i)
                    },
                    animateToOrigin: function(t) {
                        var e = this,
                            i = function() {
                                n(e.target.style, p), n(e.state, f), e.isWaiting = !1, t && t()
                            };
                        return this.animateTo(0, 0, i)
                    },
                    enable: function() {
                        o(this.trigger, "touchstart", this.handleTouchStart), o(document, "touchmove", this.handleTouchMove, d), o(document, "touchend", this.handleTouchEnd), o(document, "touchcancel", this.handleTouchEnd)
                    },
                    disable: function() {
                        a(this.trigger, "touchstart", this.handleTouchStart), a(document, "touchmove", this.handleTouchMove, d), a(document, "touchend", this.handleTouchEnd), a(document, "touchcancel", this.handleTouchEnd)
                    },
                    preventDefault: function() {
                        this.isPreventDefault = !0
                    },
                    getScrollInfo: function() {
                        return i(this.scroller, this.isGlobalScroller)
                    },
                    isActiveAction: function(n) {
                        var t = this.options,
                            e = h[n];
                        return t[e] || t[e + "End"] || t[n]
                    },
                    emit: function(n, t) {
                        var i = this.options[n];
                        e(i) && i.call(this, t)
                    },
                    handleTouchStart: function(t) {
                        if (!this.isTouching && !this.isWaiting) {
                            var e = this.options,
                                i = l(t);
                            n(this.state, {
                                clientX: i.x,
                                clientY: i.y,
                                axis: "",
                                action: ""
                            }), (e.detectScroll || e.detectScrollOnStart) && n(this.state, this.getScrollInfo()), e.stopPropagation && t.stopPropagation(), this.isTouching = !0
                        }
                    },
                    handleTouchMove: function(t) {
                        if (this.isTouching) {
                            var e = l(t),
                                i = this.options,
                                r = this.state,
                                o = e.x,
                                a = e.y,
                                c = o - r.clientX,
                                d = a - r.clientY,
                                p = r.translateX,
                                u = r.translateY,
                                f = r.axis,
                                x = r.action;
                            f || (f = Math.abs(d) >= Math.abs(c) ? "y" : "x"), x || ("y" === f ? d > 0 ? x = "pullDown" : d < 0 && (x = "pullUp") : "x" === f && (c > 0 ? x = "pullRight" : c < 0 && (x = "pullLeft")));
                            var m = this.isActiveAction(x);
                            m && i.detectScroll && !r[g[x]] && (n(r, this.getScrollInfo()), r[g[x]] && (c = 0, d = 0));
                            var b = m && r[g[x]];
                            b && (p += s(c, i.damping), u += s(d, i.damping)), n(r, {
                                clientX: o,
                                clientY: a,
                                translateX: p,
                                translateY: u,
                                action: x,
                                axis: f
                            }), b && (i.drag || ("y" === f ? p = 0 : "x" === f && (u = 0)), this.emit(h[x], {
                                translateX: p,
                                translateY: u
                            }), this.isPreventDefault ? this.isPreventDefault = !1 : (i.wait && (this.isWaiting = !0), t.preventDefault(), this.setTranslate(p, u)))
                        }
                    },
                    handleTouchEnd: function() {
                        if (this.isTouching) {
                            this.isTouching = !1;
                            var n = this.state,
                                t = n.action;
                            this.isActiveAction(t) && n[g[t]] && (this.emit(h[t] + "End", {
                                translateX: n.translateX,
                                translateY: n.translateY
                            }), this.isPreventDefault ? this.isPreventDefault = !1 : this.animateToOrigin())
                        }
                    }
                }), y
            }()
        }
    }
]);