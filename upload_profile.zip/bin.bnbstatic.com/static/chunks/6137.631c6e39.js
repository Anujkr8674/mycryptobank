"use strict";
(self.webpackChunkspot_trade_ui = self.webpackChunkspot_trade_ui || []).push([
    [6137], {
        HvDb: (s, e, a) => {
            a.r(e), a.d(e, {
                default: () => i
            });
            var n = a("mXdx"),
                t = a("DTvD"),
                r = a.n(t),
                o = a("1tqE"),
                c = a("ylXK"),
                l = a("Qhol"),
                u = a("wgI+"),
                d = function(s) {
                    var e = s.hideMask,
                        a = (0, l.nHk)();
                    return (0, n.jsxs)(n.Fragment, {
                        children: [a && (0, n.jsx)(c.A, {
                            sx: {
                                ml: "16px"
                            },
                            overlay: (0, n.jsx)(u.Z, {})
                        }), (0, n.jsx)(o.A, {
                            className: "trade-common-icon",
                            onClick: e
                        })]
                    })
                };
            const i = r().memo(d)
        }
    }
]);