"use strict";
(self.webpackChunkmain_exchange_ui = self.webpackChunkmain_exchange_ui || []).push([
    [6798], {
        xunz: (e, a, u) => {
            u.d(a, {
                default: () => n.Ay
            });
            var n = u("6DzZ")
        }
    }
]);
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "21f35af3-4ef5-511c-b2ac-3ccc9e7c37b9")
    } catch (e) {}
}();
//# debugId=21f35af3-4ef5-511c-b2ac-3ccc9e7c37b9