(self.webpackChunkresearch_new_ui = self.webpackChunkresearch_new_ui || []).push([
    [447], {
        jUiC: function(t, e, n) {
            t.exports = function(t) {
                "use strict";

                function e(t, e) {
                    return t(e = {
                        exports: {}
                    }, e.exports), e.exports
                }

                function n(t) {
                    return t && t.default || t
                }
                t = t && t.hasOwnProperty("default") ? t.default : t;
                var i = {
                        aliceblue: [240, 248, 255],
                        antiquewhite: [250, 235, 215],
                        aqua: [0, 255, 255],
                        aquamarine: [127, 255, 212],
                        azure: [240, 255, 255],
                        beige: [245, 245, 220],
                        bisque: [255, 228, 196],
                        black: [0, 0, 0],
                        blanchedalmond: [255, 235, 205],
                        blue: [0, 0, 255],
                        blueviolet: [138, 43, 226],
                        brown: [165, 42, 42],
                        burlywood: [222, 184, 135],
                        cadetblue: [95, 158, 160],
                        chartreuse: [127, 255, 0],
                        chocolate: [210, 105, 30],
                        coral: [255, 127, 80],
                        cornflowerblue: [100, 149, 237],
                        cornsilk: [255, 248, 220],
                        crimson: [220, 20, 60],
                        cyan: [0, 255, 255],
                        darkblue: [0, 0, 139],
                        darkcyan: [0, 139, 139],
                        darkgoldenrod: [184, 134, 11],
                        darkgray: [169, 169, 169],
                        darkgreen: [0, 100, 0],
                        darkgrey: [169, 169, 169],
                        darkkhaki: [189, 183, 107],
                        darkmagenta: [139, 0, 139],
                        darkolivegreen: [85, 107, 47],
                        darkorange: [255, 140, 0],
                        darkorchid: [153, 50, 204],
                        darkred: [139, 0, 0],
                        darksalmon: [233, 150, 122],
                        darkseagreen: [143, 188, 143],
                        darkslateblue: [72, 61, 139],
                        darkslategray: [47, 79, 79],
                        darkslategrey: [47, 79, 79],
                        darkturquoise: [0, 206, 209],
                        darkviolet: [148, 0, 211],
                        deeppink: [255, 20, 147],
                        deepskyblue: [0, 191, 255],
                        dimgray: [105, 105, 105],
                        dimgrey: [105, 105, 105],
                        dodgerblue: [30, 144, 255],
                        firebrick: [178, 34, 34],
                        floralwhite: [255, 250, 240],
                        forestgreen: [34, 139, 34],
                        fuchsia: [255, 0, 255],
                        gainsboro: [220, 220, 220],
                        ghostwhite: [248, 248, 255],
                        gold: [255, 215, 0],
                        goldenrod: [218, 165, 32],
                        gray: [128, 128, 128],
                        green: [0, 128, 0],
                        greenyellow: [173, 255, 47],
                        grey: [128, 128, 128],
                        honeydew: [240, 255, 240],
                        hotpink: [255, 105, 180],
                        indianred: [205, 92, 92],
                        indigo: [75, 0, 130],
                        ivory: [255, 255, 240],
                        khaki: [240, 230, 140],
                        lavender: [230, 230, 250],
                        lavenderblush: [255, 240, 245],
                        lawngreen: [124, 252, 0],
                        lemonchiffon: [255, 250, 205],
                        lightblue: [173, 216, 230],
                        lightcoral: [240, 128, 128],
                        lightcyan: [224, 255, 255],
                        lightgoldenrodyellow: [250, 250, 210],
                        lightgray: [211, 211, 211],
                        lightgreen: [144, 238, 144],
                        lightgrey: [211, 211, 211],
                        lightpink: [255, 182, 193],
                        lightsalmon: [255, 160, 122],
                        lightseagreen: [32, 178, 170],
                        lightskyblue: [135, 206, 250],
                        lightslategray: [119, 136, 153],
                        lightslategrey: [119, 136, 153],
                        lightsteelblue: [176, 196, 222],
                        lightyellow: [255, 255, 224],
                        lime: [0, 255, 0],
                        limegreen: [50, 205, 50],
                        linen: [250, 240, 230],
                        magenta: [255, 0, 255],
                        maroon: [128, 0, 0],
                        mediumaquamarine: [102, 205, 170],
                        mediumblue: [0, 0, 205],
                        mediumorchid: [186, 85, 211],
                        mediumpurple: [147, 112, 219],
                        mediumseagreen: [60, 179, 113],
                        mediumslateblue: [123, 104, 238],
                        mediumspringgreen: [0, 250, 154],
                        mediumturquoise: [72, 209, 204],
                        mediumvioletred: [199, 21, 133],
                        midnightblue: [25, 25, 112],
                        mintcream: [245, 255, 250],
                        mistyrose: [255, 228, 225],
                        moccasin: [255, 228, 181],
                        navajowhite: [255, 222, 173],
                        navy: [0, 0, 128],
                        oldlace: [253, 245, 230],
                        olive: [128, 128, 0],
                        olivedrab: [107, 142, 35],
                        orange: [255, 165, 0],
                        orangered: [255, 69, 0],
                        orchid: [218, 112, 214],
                        palegoldenrod: [238, 232, 170],
                        palegreen: [152, 251, 152],
                        paleturquoise: [175, 238, 238],
                        palevioletred: [219, 112, 147],
                        papayawhip: [255, 239, 213],
                        peachpuff: [255, 218, 185],
                        peru: [205, 133, 63],
                        pink: [255, 192, 203],
                        plum: [221, 160, 221],
                        powderblue: [176, 224, 230],
                        purple: [128, 0, 128],
                        rebeccapurple: [102, 51, 153],
                        red: [255, 0, 0],
                        rosybrown: [188, 143, 143],
                        royalblue: [65, 105, 225],
                        saddlebrown: [139, 69, 19],
                        salmon: [250, 128, 114],
                        sandybrown: [244, 164, 96],
                        seagreen: [46, 139, 87],
                        seashell: [255, 245, 238],
                        sienna: [160, 82, 45],
                        silver: [192, 192, 192],
                        skyblue: [135, 206, 235],
                        slateblue: [106, 90, 205],
                        slategray: [112, 128, 144],
                        slategrey: [112, 128, 144],
                        snow: [255, 250, 250],
                        springgreen: [0, 255, 127],
                        steelblue: [70, 130, 180],
                        tan: [210, 180, 140],
                        teal: [0, 128, 128],
                        thistle: [216, 191, 216],
                        tomato: [255, 99, 71],
                        turquoise: [64, 224, 208],
                        violet: [238, 130, 238],
                        wheat: [245, 222, 179],
                        white: [255, 255, 255],
                        whitesmoke: [245, 245, 245],
                        yellow: [255, 255, 0],
                        yellowgreen: [154, 205, 50]
                    },
                    a = e((function(t) {
                        var e = {};
                        for (var n in i) i.hasOwnProperty(n) && (e[i[n]] = n);
                        var a = t.exports = {
                            rgb: {
                                channels: 3,
                                labels: "rgb"
                            },
                            hsl: {
                                channels: 3,
                                labels: "hsl"
                            },
                            hsv: {
                                channels: 3,
                                labels: "hsv"
                            },
                            hwb: {
                                channels: 3,
                                labels: "hwb"
                            },
                            cmyk: {
                                channels: 4,
                                labels: "cmyk"
                            },
                            xyz: {
                                channels: 3,
                                labels: "xyz"
                            },
                            lab: {
                                channels: 3,
                                labels: "lab"
                            },
                            lch: {
                                channels: 3,
                                labels: "lch"
                            },
                            hex: {
                                channels: 1,
                                labels: ["hex"]
                            },
                            keyword: {
                                channels: 1,
                                labels: ["keyword"]
                            },
                            ansi16: {
                                channels: 1,
                                labels: ["ansi16"]
                            },
                            ansi256: {
                                channels: 1,
                                labels: ["ansi256"]
                            },
                            hcg: {
                                channels: 3,
                                labels: ["h", "c", "g"]
                            },
                            apple: {
                                channels: 3,
                                labels: ["r16", "g16", "b16"]
                            },
                            gray: {
                                channels: 1,
                                labels: ["gray"]
                            }
                        };
                        for (var r in a)
                            if (a.hasOwnProperty(r)) {
                                if (!("channels" in a[r])) throw new Error("missing channels property: " + r);
                                if (!("labels" in a[r])) throw new Error("missing channel labels property: " + r);
                                if (a[r].labels.length !== a[r].channels) throw new Error("channel and label counts mismatch: " + r);
                                var o = a[r].channels,
                                    l = a[r].labels;
                                delete a[r].channels, delete a[r].labels, Object.defineProperty(a[r], "channels", {
                                    value: o
                                }), Object.defineProperty(a[r], "labels", {
                                    value: l
                                })
                            }
                        function s(t, e) {
                            return Math.pow(t[0] - e[0], 2) + Math.pow(t[1] - e[1], 2) + Math.pow(t[2] - e[2], 2)
                        }
                        a.rgb.hsl = function(t) {
                            var e, n, i = t[0] / 255,
                                a = t[1] / 255,
                                r = t[2] / 255,
                                o = Math.min(i, a, r),
                                l = Math.max(i, a, r),
                                s = l - o;
                            return l === o ? e = 0 : i === l ? e = (a - r) / s : a === l ? e = 2 + (r - i) / s : r === l && (e = 4 + (i - a) / s), (e = Math.min(60 * e, 360)) < 0 && (e += 360), n = (o + l) / 2, [e, 100 * (l === o ? 0 : n <= .5 ? s / (l + o) : s / (2 - l - o)), 100 * n]
                        }, a.rgb.hsv = function(t) {
                            var e, n, i, a, r, o = t[0] / 255,
                                l = t[1] / 255,
                                s = t[2] / 255,
                                u = Math.max(o, l, s),
                                d = u - Math.min(o, l, s),
                                c = function(t) {
                                    return (u - t) / 6 / d + .5
                                };
                            return 0 === d ? a = r = 0 : (r = d / u, e = c(o), n = c(l), i = c(s), o === u ? a = i - n : l === u ? a = 1 / 3 + e - i : s === u && (a = 2 / 3 + n - e), a < 0 ? a += 1 : a > 1 && (a -= 1)), [360 * a, 100 * r, 100 * u]
                        }, a.rgb.hwb = function(t) {
                            var e = t[0],
                                n = t[1],
                                i = t[2];
                            return [a.rgb.hsl(t)[0], 1 / 255 * Math.min(e, Math.min(n, i)) * 100, 100 * (i = 1 - 1 / 255 * Math.max(e, Math.max(n, i)))]
                        }, a.rgb.cmyk = function(t) {
                            var e, n = t[0] / 255,
                                i = t[1] / 255,
                                a = t[2] / 255;
                            return [100 * ((1 - n - (e = Math.min(1 - n, 1 - i, 1 - a))) / (1 - e) || 0), 100 * ((1 - i - e) / (1 - e) || 0), 100 * ((1 - a - e) / (1 - e) || 0), 100 * e]
                        }, a.rgb.keyword = function(t) {
                            var n = e[t];
                            if (n) return n;
                            var a, r = 1 / 0;
                            for (var o in i)
                                if (i.hasOwnProperty(o)) {
                                    var l = s(t, i[o]);
                                    l < r && (r = l, a = o)
                                }
                            return a
                        }, a.keyword.rgb = function(t) {
                            return i[t]
                        }, a.rgb.xyz = function(t) {
                            var e = t[0] / 255,
                                n = t[1] / 255,
                                i = t[2] / 255;
                            return [100 * (.4124 * (e = e > .04045 ? Math.pow((e + .055) / 1.055, 2.4) : e / 12.92) + .3576 * (n = n > .04045 ? Math.pow((n + .055) / 1.055, 2.4) : n / 12.92) + .1805 * (i = i > .04045 ? Math.pow((i + .055) / 1.055, 2.4) : i / 12.92)), 100 * (.2126 * e + .7152 * n + .0722 * i), 100 * (.0193 * e + .1192 * n + .9505 * i)]
                        }, a.rgb.lab = function(t) {
                            var e = a.rgb.xyz(t),
                                n = e[0],
                                i = e[1],
                                r = e[2];
                            return i /= 100, r /= 108.883, n = (n /= 95.047) > .008856 ? Math.pow(n, 1 / 3) : 7.787 * n + 16 / 116, [116 * (i = i > .008856 ? Math.pow(i, 1 / 3) : 7.787 * i + 16 / 116) - 16, 500 * (n - i), 200 * (i - (r = r > .008856 ? Math.pow(r, 1 / 3) : 7.787 * r + 16 / 116))]
                        }, a.hsl.rgb = function(t) {
                            var e, n, i, a, r, o = t[0] / 360,
                                l = t[1] / 100,
                                s = t[2] / 100;
                            if (0 === l) return [r = 255 * s, r, r];
                            e = 2 * s - (n = s < .5 ? s * (1 + l) : s + l - s * l), a = [0, 0, 0];
                            for (var u = 0; u < 3; u++)(i = o + 1 / 3 * -(u - 1)) < 0 && i++, i > 1 && i--, r = 6 * i < 1 ? e + 6 * (n - e) * i : 2 * i < 1 ? n : 3 * i < 2 ? e + (n - e) * (2 / 3 - i) * 6 : e, a[u] = 255 * r;
                            return a
                        }, a.hsl.hsv = function(t) {
                            var e = t[0],
                                n = t[1] / 100,
                                i = t[2] / 100,
                                a = n,
                                r = Math.max(i, .01);
                            return n *= (i *= 2) <= 1 ? i : 2 - i, a *= r <= 1 ? r : 2 - r, [e, 100 * (0 === i ? 2 * a / (r + a) : 2 * n / (i + n)), (i + n) / 2 * 100]
                        }, a.hsv.rgb = function(t) {
                            var e = t[0] / 60,
                                n = t[1] / 100,
                                i = t[2] / 100,
                                a = Math.floor(e) % 6,
                                r = e - Math.floor(e),
                                o = 255 * i * (1 - n),
                                l = 255 * i * (1 - n * r),
                                s = 255 * i * (1 - n * (1 - r));
                            switch (i *= 255, a) {
                                case 0:
                                    return [i, s, o];
                                case 1:
                                    return [l, i, o];
                                case 2:
                                    return [o, i, s];
                                case 3:
                                    return [o, l, i];
                                case 4:
                                    return [s, o, i];
                                case 5:
                                    return [i, o, l]
                            }
                        }, a.hsv.hsl = function(t) {
                            var e, n, i, a = t[0],
                                r = t[1] / 100,
                                o = t[2] / 100,
                                l = Math.max(o, .01);
                            return i = (2 - r) * o, n = r * l, [a, 100 * (n = (n /= (e = (2 - r) * l) <= 1 ? e : 2 - e) || 0), 100 * (i /= 2)]
                        }, a.hwb.rgb = function(t) {
                            var e, n, i, a, r, o, l, s = t[0] / 360,
                                u = t[1] / 100,
                                d = t[2] / 100,
                                c = u + d;
                            switch (c > 1 && (u /= c, d /= c), i = 6 * s - (e = Math.floor(6 * s)), 0 !== (1 & e) && (i = 1 - i), a = u + i * ((n = 1 - d) - u), e) {
                                default:
                                    case 6:
                                    case 0:
                                    r = n,
                                o = a,
                                l = u;
                                break;
                                case 1:
                                        r = a,
                                    o = n,
                                    l = u;
                                    break;
                                case 2:
                                        r = u,
                                    o = n,
                                    l = a;
                                    break;
                                case 3:
                                        r = u,
                                    o = a,
                                    l = n;
                                    break;
                                case 4:
                                        r = a,
                                    o = u,
                                    l = n;
                                    break;
                                case 5:
                                        r = n,
                                    o = u,
                                    l = a
                            }
                            return [255 * r, 255 * o, 255 * l]
                        }, a.cmyk.rgb = function(t) {
                            var e = t[0] / 100,
                                n = t[1] / 100,
                                i = t[2] / 100,
                                a = t[3] / 100;
                            return [255 * (1 - Math.min(1, e * (1 - a) + a)), 255 * (1 - Math.min(1, n * (1 - a) + a)), 255 * (1 - Math.min(1, i * (1 - a) + a))]
                        }, a.xyz.rgb = function(t) {
                            var e, n, i, a = t[0] / 100,
                                r = t[1] / 100,
                                o = t[2] / 100;
                            return n = -.9689 * a + 1.8758 * r + .0415 * o, i = .0557 * a + -.204 * r + 1.057 * o, e = (e = 3.2406 * a + -1.5372 * r + -.4986 * o) > .0031308 ? 1.055 * Math.pow(e, 1 / 2.4) - .055 : 12.92 * e, n = n > .0031308 ? 1.055 * Math.pow(n, 1 / 2.4) - .055 : 12.92 * n, i = i > .0031308 ? 1.055 * Math.pow(i, 1 / 2.4) - .055 : 12.92 * i, [255 * (e = Math.min(Math.max(0, e), 1)), 255 * (n = Math.min(Math.max(0, n), 1)), 255 * (i = Math.min(Math.max(0, i), 1))]
                        }, a.xyz.lab = function(t) {
                            var e = t[0],
                                n = t[1],
                                i = t[2];
                            return n /= 100, i /= 108.883, e = (e /= 95.047) > .008856 ? Math.pow(e, 1 / 3) : 7.787 * e + 16 / 116, [116 * (n = n > .008856 ? Math.pow(n, 1 / 3) : 7.787 * n + 16 / 116) - 16, 500 * (e - n), 200 * (n - (i = i > .008856 ? Math.pow(i, 1 / 3) : 7.787 * i + 16 / 116))]
                        }, a.lab.xyz = function(t) {
                            var e, n, i, a = t[0];
                            e = t[1] / 500 + (n = (a + 16) / 116), i = n - t[2] / 200;
                            var r = Math.pow(n, 3),
                                o = Math.pow(e, 3),
                                l = Math.pow(i, 3);
                            return n = r > .008856 ? r : (n - 16 / 116) / 7.787, e = o > .008856 ? o : (e - 16 / 116) / 7.787, i = l > .008856 ? l : (i - 16 / 116) / 7.787, [e *= 95.047, n *= 100, i *= 108.883]
                        }, a.lab.lch = function(t) {
                            var e, n = t[0],
                                i = t[1],
                                a = t[2];
                            return (e = 360 * Math.atan2(a, i) / 2 / Math.PI) < 0 && (e += 360), [n, Math.sqrt(i * i + a * a), e]
                        }, a.lch.lab = function(t) {
                            var e, n = t[0],
                                i = t[1];
                            return e = t[2] / 360 * 2 * Math.PI, [n, i * Math.cos(e), i * Math.sin(e)]
                        }, a.rgb.ansi16 = function(t) {
                            var e = t[0],
                                n = t[1],
                                i = t[2],
                                r = 1 in arguments ? arguments[1] : a.rgb.hsv(t)[2];
                            if (0 === (r = Math.round(r / 50))) return 30;
                            var o = 30 + (Math.round(i / 255) << 2 | Math.round(n / 255) << 1 | Math.round(e / 255));
                            return 2 === r && (o += 60), o
                        }, a.hsv.ansi16 = function(t) {
                            return a.rgb.ansi16(a.hsv.rgb(t), t[2])
                        }, a.rgb.ansi256 = function(t) {
                            var e = t[0],
                                n = t[1],
                                i = t[2];
                            return e === n && n === i ? e < 8 ? 16 : e > 248 ? 231 : Math.round((e - 8) / 247 * 24) + 232 : 16 + 36 * Math.round(e / 255 * 5) + 6 * Math.round(n / 255 * 5) + Math.round(i / 255 * 5)
                        }, a.ansi16.rgb = function(t) {
                            var e = t % 10;
                            if (0 === e || 7 === e) return t > 50 && (e += 3.5), [e = e / 10.5 * 255, e, e];
                            var n = .5 * (1 + ~~(t > 50));
                            return [(1 & e) * n * 255, (e >> 1 & 1) * n * 255, (e >> 2 & 1) * n * 255]
                        }, a.ansi256.rgb = function(t) {
                            if (t >= 232) {
                                var e = 10 * (t - 232) + 8;
                                return [e, e, e]
                            }
                            var n;
                            return t -= 16, [Math.floor(t / 36) / 5 * 255, Math.floor((n = t % 36) / 6) / 5 * 255, n % 6 / 5 * 255]
                        }, a.rgb.hex = function(t) {
                            var e = (((255 & Math.round(t[0])) << 16) + ((255 & Math.round(t[1])) << 8) + (255 & Math.round(t[2]))).toString(16).toUpperCase();
                            return "000000".substring(e.length) + e
                        }, a.hex.rgb = function(t) {
                            var e = t.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
                            if (!e) return [0, 0, 0];
                            var n = e[0];
                            3 === e[0].length && (n = n.split("").map((function(t) {
                                return t + t
                            })).join(""));
                            var i = parseInt(n, 16);
                            return [i >> 16 & 255, i >> 8 & 255, 255 & i]
                        }, a.rgb.hcg = function(t) {
                            var e, n = t[0] / 255,
                                i = t[1] / 255,
                                a = t[2] / 255,
                                r = Math.max(Math.max(n, i), a),
                                o = Math.min(Math.min(n, i), a),
                                l = r - o;
                            return e = l <= 0 ? 0 : r === n ? (i - a) / l % 6 : r === i ? 2 + (a - n) / l : 4 + (n - i) / l + 4, e /= 6, [360 * (e %= 1), 100 * l, 100 * (l < 1 ? o / (1 - l) : 0)]
                        }, a.hsl.hcg = function(t) {
                            var e = t[1] / 100,
                                n = t[2] / 100,
                                i = 1,
                                a = 0;
                            return (i = n < .5 ? 2 * e * n : 2 * e * (1 - n)) < 1 && (a = (n - .5 * i) / (1 - i)), [t[0], 100 * i, 100 * a]
                        }, a.hsv.hcg = function(t) {
                            var e = t[1] / 100,
                                n = t[2] / 100,
                                i = e * n,
                                a = 0;
                            return i < 1 && (a = (n - i) / (1 - i)), [t[0], 100 * i, 100 * a]
                        }, a.hcg.rgb = function(t) {
                            var e = t[0] / 360,
                                n = t[1] / 100,
                                i = t[2] / 100;
                            if (0 === n) return [255 * i, 255 * i, 255 * i];
                            var a = [0, 0, 0],
                                r = e % 1 * 6,
                                o = r % 1,
                                l = 1 - o,
                                s = 0;
                            switch (Math.floor(r)) {
                                case 0:
                                    a[0] = 1, a[1] = o, a[2] = 0;
                                    break;
                                case 1:
                                    a[0] = l, a[1] = 1, a[2] = 0;
                                    break;
                                case 2:
                                    a[0] = 0, a[1] = 1, a[2] = o;
                                    break;
                                case 3:
                                    a[0] = 0, a[1] = l, a[2] = 1;
                                    break;
                                case 4:
                                    a[0] = o, a[1] = 0, a[2] = 1;
                                    break;
                                default:
                                    a[0] = 1, a[1] = 0, a[2] = l
                            }
                            return s = (1 - n) * i, [255 * (n * a[0] + s), 255 * (n * a[1] + s), 255 * (n * a[2] + s)]
                        }, a.hcg.hsv = function(t) {
                            var e = t[1] / 100,
                                n = e + t[2] / 100 * (1 - e),
                                i = 0;
                            return n > 0 && (i = e / n), [t[0], 100 * i, 100 * n]
                        }, a.hcg.hsl = function(t) {
                            var e = t[1] / 100,
                                n = t[2] / 100 * (1 - e) + .5 * e,
                                i = 0;
                            return n > 0 && n < .5 ? i = e / (2 * n) : n >= .5 && n < 1 && (i = e / (2 * (1 - n))), [t[0], 100 * i, 100 * n]
                        }, a.hcg.hwb = function(t) {
                            var e = t[1] / 100,
                                n = e + t[2] / 100 * (1 - e);
                            return [t[0], 100 * (n - e), 100 * (1 - n)]
                        }, a.hwb.hcg = function(t) {
                            var e = t[1] / 100,
                                n = 1 - t[2] / 100,
                                i = n - e,
                                a = 0;
                            return i < 1 && (a = (n - i) / (1 - i)), [t[0], 100 * i, 100 * a]
                        }, a.apple.rgb = function(t) {
                            return [t[0] / 65535 * 255, t[1] / 65535 * 255, t[2] / 65535 * 255]
                        }, a.rgb.apple = function(t) {
                            return [t[0] / 255 * 65535, t[1] / 255 * 65535, t[2] / 255 * 65535]
                        }, a.gray.rgb = function(t) {
                            return [t[0] / 100 * 255, t[0] / 100 * 255, t[0] / 100 * 255]
                        }, a.gray.hsl = a.gray.hsv = function(t) {
                            return [0, 0, t[0]]
                        }, a.gray.hwb = function(t) {
                            return [0, 100, t[0]]
                        }, a.gray.cmyk = function(t) {
                            return [0, 0, 0, t[0]]
                        }, a.gray.lab = function(t) {
                            return [t[0], 0, 0]
                        }, a.gray.hex = function(t) {
                            var e = 255 & Math.round(t[0] / 100 * 255),
                                n = ((e << 16) + (e << 8) + e).toString(16).toUpperCase();
                            return "000000".substring(n.length) + n
                        }, a.rgb.gray = function(t) {
                            return [(t[0] + t[1] + t[2]) / 3 / 255 * 100]
                        }
                    }));

                function r() {
                    for (var t = {}, e = Object.keys(a), n = e.length, i = 0; i < n; i++) t[e[i]] = {
                        distance: -1,
                        parent: null
                    };
                    return t
                }

                function o(t) {
                    var e = r(),
                        n = [t];
                    for (e[t].distance = 0; n.length;)
                        for (var i = n.pop(), o = Object.keys(a[i]), l = o.length, s = 0; s < l; s++) {
                            var u = o[s],
                                d = e[u]; - 1 === d.distance && (d.distance = e[i].distance + 1, d.parent = i, n.unshift(u))
                        }
                    return e
                }

                function l(t, e) {
                    return function(n) {
                        return e(t(n))
                    }
                }

                function s(t, e) {
                    for (var n = [e[t].parent, t], i = a[e[t].parent][t], r = e[t].parent; e[r].parent;) n.unshift(e[r].parent), i = l(a[e[r].parent][r], i), r = e[r].parent;
                    return i.conversion = n, i
                }
                a.rgb, a.hsl, a.hsv, a.hwb, a.cmyk, a.xyz, a.lab, a.lch, a.hex, a.keyword, a.ansi16, a.ansi256, a.hcg, a.apple, a.gray;
                var u = function(t) {
                        for (var e = o(t), n = {}, i = Object.keys(e), a = i.length, r = 0; r < a; r++) {
                            var l = i[r];
                            null !== e[l].parent && (n[l] = s(l, e))
                        }
                        return n
                    },
                    d = {};

                function c(t) {
                    var e = function(e) {
                        return void 0 === e || null === e ? e : (arguments.length > 1 && (e = Array.prototype.slice.call(arguments)), t(e))
                    };
                    return "conversion" in t && (e.conversion = t.conversion), e
                }

                function h(t) {
                    var e = function(e) {
                        if (void 0 === e || null === e) return e;
                        arguments.length > 1 && (e = Array.prototype.slice.call(arguments));
                        var n = t(e);
                        if ("object" === typeof n)
                            for (var i = n.length, a = 0; a < i; a++) n[a] = Math.round(n[a]);
                        return n
                    };
                    return "conversion" in t && (e.conversion = t.conversion), e
                }
                Object.keys(a).forEach((function(t) {
                    d[t] = {}, Object.defineProperty(d[t], "channels", {
                        value: a[t].channels
                    }), Object.defineProperty(d[t], "labels", {
                        value: a[t].labels
                    });
                    var e = u(t);
                    Object.keys(e).forEach((function(n) {
                        var i = e[n];
                        d[t][n] = h(i), d[t][n].raw = c(i)
                    }))
                }));
                var f = d,
                    g = {
                        aliceblue: [240, 248, 255],
                        antiquewhite: [250, 235, 215],
                        aqua: [0, 255, 255],
                        aquamarine: [127, 255, 212],
                        azure: [240, 255, 255],
                        beige: [245, 245, 220],
                        bisque: [255, 228, 196],
                        black: [0, 0, 0],
                        blanchedalmond: [255, 235, 205],
                        blue: [0, 0, 255],
                        blueviolet: [138, 43, 226],
                        brown: [165, 42, 42],
                        burlywood: [222, 184, 135],
                        cadetblue: [95, 158, 160],
                        chartreuse: [127, 255, 0],
                        chocolate: [210, 105, 30],
                        coral: [255, 127, 80],
                        cornflowerblue: [100, 149, 237],
                        cornsilk: [255, 248, 220],
                        crimson: [220, 20, 60],
                        cyan: [0, 255, 255],
                        darkblue: [0, 0, 139],
                        darkcyan: [0, 139, 139],
                        darkgoldenrod: [184, 134, 11],
                        darkgray: [169, 169, 169],
                        darkgreen: [0, 100, 0],
                        darkgrey: [169, 169, 169],
                        darkkhaki: [189, 183, 107],
                        darkmagenta: [139, 0, 139],
                        darkolivegreen: [85, 107, 47],
                        darkorange: [255, 140, 0],
                        darkorchid: [153, 50, 204],
                        darkred: [139, 0, 0],
                        darksalmon: [233, 150, 122],
                        darkseagreen: [143, 188, 143],
                        darkslateblue: [72, 61, 139],
                        darkslategray: [47, 79, 79],
                        darkslategrey: [47, 79, 79],
                        darkturquoise: [0, 206, 209],
                        darkviolet: [148, 0, 211],
                        deeppink: [255, 20, 147],
                        deepskyblue: [0, 191, 255],
                        dimgray: [105, 105, 105],
                        dimgrey: [105, 105, 105],
                        dodgerblue: [30, 144, 255],
                        firebrick: [178, 34, 34],
                        floralwhite: [255, 250, 240],
                        forestgreen: [34, 139, 34],
                        fuchsia: [255, 0, 255],
                        gainsboro: [220, 220, 220],
                        ghostwhite: [248, 248, 255],
                        gold: [255, 215, 0],
                        goldenrod: [218, 165, 32],
                        gray: [128, 128, 128],
                        green: [0, 128, 0],
                        greenyellow: [173, 255, 47],
                        grey: [128, 128, 128],
                        honeydew: [240, 255, 240],
                        hotpink: [255, 105, 180],
                        indianred: [205, 92, 92],
                        indigo: [75, 0, 130],
                        ivory: [255, 255, 240],
                        khaki: [240, 230, 140],
                        lavender: [230, 230, 250],
                        lavenderblush: [255, 240, 245],
                        lawngreen: [124, 252, 0],
                        lemonchiffon: [255, 250, 205],
                        lightblue: [173, 216, 230],
                        lightcoral: [240, 128, 128],
                        lightcyan: [224, 255, 255],
                        lightgoldenrodyellow: [250, 250, 210],
                        lightgray: [211, 211, 211],
                        lightgreen: [144, 238, 144],
                        lightgrey: [211, 211, 211],
                        lightpink: [255, 182, 193],
                        lightsalmon: [255, 160, 122],
                        lightseagreen: [32, 178, 170],
                        lightskyblue: [135, 206, 250],
                        lightslategray: [119, 136, 153],
                        lightslategrey: [119, 136, 153],
                        lightsteelblue: [176, 196, 222],
                        lightyellow: [255, 255, 224],
                        lime: [0, 255, 0],
                        limegreen: [50, 205, 50],
                        linen: [250, 240, 230],
                        magenta: [255, 0, 255],
                        maroon: [128, 0, 0],
                        mediumaquamarine: [102, 205, 170],
                        mediumblue: [0, 0, 205],
                        mediumorchid: [186, 85, 211],
                        mediumpurple: [147, 112, 219],
                        mediumseagreen: [60, 179, 113],
                        mediumslateblue: [123, 104, 238],
                        mediumspringgreen: [0, 250, 154],
                        mediumturquoise: [72, 209, 204],
                        mediumvioletred: [199, 21, 133],
                        midnightblue: [25, 25, 112],
                        mintcream: [245, 255, 250],
                        mistyrose: [255, 228, 225],
                        moccasin: [255, 228, 181],
                        navajowhite: [255, 222, 173],
                        navy: [0, 0, 128],
                        oldlace: [253, 245, 230],
                        olive: [128, 128, 0],
                        olivedrab: [107, 142, 35],
                        orange: [255, 165, 0],
                        orangered: [255, 69, 0],
                        orchid: [218, 112, 214],
                        palegoldenrod: [238, 232, 170],
                        palegreen: [152, 251, 152],
                        paleturquoise: [175, 238, 238],
                        palevioletred: [219, 112, 147],
                        papayawhip: [255, 239, 213],
                        peachpuff: [255, 218, 185],
                        peru: [205, 133, 63],
                        pink: [255, 192, 203],
                        plum: [221, 160, 221],
                        powderblue: [176, 224, 230],
                        purple: [128, 0, 128],
                        rebeccapurple: [102, 51, 153],
                        red: [255, 0, 0],
                        rosybrown: [188, 143, 143],
                        royalblue: [65, 105, 225],
                        saddlebrown: [139, 69, 19],
                        salmon: [250, 128, 114],
                        sandybrown: [244, 164, 96],
                        seagreen: [46, 139, 87],
                        seashell: [255, 245, 238],
                        sienna: [160, 82, 45],
                        silver: [192, 192, 192],
                        skyblue: [135, 206, 235],
                        slateblue: [106, 90, 205],
                        slategray: [112, 128, 144],
                        slategrey: [112, 128, 144],
                        snow: [255, 250, 250],
                        springgreen: [0, 255, 127],
                        steelblue: [70, 130, 180],
                        tan: [210, 180, 140],
                        teal: [0, 128, 128],
                        thistle: [216, 191, 216],
                        tomato: [255, 99, 71],
                        turquoise: [64, 224, 208],
                        violet: [238, 130, 238],
                        wheat: [245, 222, 179],
                        white: [255, 255, 255],
                        whitesmoke: [245, 245, 245],
                        yellow: [255, 255, 0],
                        yellowgreen: [154, 205, 50]
                    },
                    p = {
                        getRgba: m,
                        getHsla: v,
                        getRgb: x,
                        getHsl: y,
                        getHwb: b,
                        getAlpha: _,
                        hexString: k,
                        rgbString: w,
                        rgbaString: M,
                        percentString: S,
                        percentaString: C,
                        hslString: P,
                        hslaString: A,
                        hwbString: D,
                        keyword: T
                    };

                function m(t) {
                    if (t) {
                        var e = /^#([a-fA-F0-9]{3,4})$/i,
                            n = /^#([a-fA-F0-9]{6}([a-fA-F0-9]{2})?)$/i,
                            i = /^rgba?\(\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/i,
                            a = /^rgba?\(\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/i,
                            r = /(\w+)/,
                            o = [0, 0, 0],
                            l = 1,
                            s = t.match(e),
                            u = "";
                        if (s) {
                            u = (s = s[1])[3];
                            for (var d = 0; d < o.length; d++) o[d] = parseInt(s[d] + s[d], 16);
                            u && (l = Math.round(parseInt(u + u, 16) / 255 * 100) / 100)
                        } else if (s = t.match(n)) {
                            for (u = s[2], s = s[1], d = 0; d < o.length; d++) o[d] = parseInt(s.slice(2 * d, 2 * d + 2), 16);
                            u && (l = Math.round(parseInt(u, 16) / 255 * 100) / 100)
                        } else if (s = t.match(i)) {
                            for (d = 0; d < o.length; d++) o[d] = parseInt(s[d + 1]);
                            l = parseFloat(s[4])
                        } else if (s = t.match(a)) {
                            for (d = 0; d < o.length; d++) o[d] = Math.round(2.55 * parseFloat(s[d + 1]));
                            l = parseFloat(s[4])
                        } else if (s = t.match(r)) {
                            if ("transparent" == s[1]) return [0, 0, 0, 0];
                            if (!(o = g[s[1]])) return
                        }
                        for (d = 0; d < o.length; d++) o[d] = I(o[d], 0, 255);
                        return l = l || 0 == l ? I(l, 0, 1) : 1, o[3] = l, o
                    }
                }

                function v(t) {
                    if (t) {
                        var e = /^hsla?\(\s*([+-]?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)/,
                            n = t.match(e);
                        if (n) {
                            var i = parseFloat(n[4]);
                            return [I(parseInt(n[1]), 0, 360), I(parseFloat(n[2]), 0, 100), I(parseFloat(n[3]), 0, 100), I(isNaN(i) ? 1 : i, 0, 1)]
                        }
                    }
                }

                function b(t) {
                    if (t) {
                        var e = /^hwb\(\s*([+-]?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)/,
                            n = t.match(e);
                        if (n) {
                            var i = parseFloat(n[4]);
                            return [I(parseInt(n[1]), 0, 360), I(parseFloat(n[2]), 0, 100), I(parseFloat(n[3]), 0, 100), I(isNaN(i) ? 1 : i, 0, 1)]
                        }
                    }
                }

                function x(t) {
                    var e = m(t);
                    return e && e.slice(0, 3)
                }

                function y(t) {
                    var e = v(t);
                    return e && e.slice(0, 3)
                }

                function _(t) {
                    var e = m(t);
                    return e || (e = v(t)) || (e = b(t)) ? e[3] : void 0
                }

                function k(t, e) {
                    return e = void 0 !== e && 3 === t.length ? e : t[3], "#" + F(t[0]) + F(t[1]) + F(t[2]) + (e >= 0 && e < 1 ? F(Math.round(255 * e)) : "")
                }

                function w(t, e) {
                    return e < 1 || t[3] && t[3] < 1 ? M(t, e) : "rgb(" + t[0] + ", " + t[1] + ", " + t[2] + ")"
                }

                function M(t, e) {
                    return void 0 === e && (e = void 0 !== t[3] ? t[3] : 1), "rgba(" + t[0] + ", " + t[1] + ", " + t[2] + ", " + e + ")"
                }

                function S(t, e) {
                    return e < 1 || t[3] && t[3] < 1 ? C(t, e) : "rgb(" + Math.round(t[0] / 255 * 100) + "%, " + Math.round(t[1] / 255 * 100) + "%, " + Math.round(t[2] / 255 * 100) + "%)"
                }

                function C(t, e) {
                    return "rgba(" + Math.round(t[0] / 255 * 100) + "%, " + Math.round(t[1] / 255 * 100) + "%, " + Math.round(t[2] / 255 * 100) + "%, " + (e || t[3] || 1) + ")"
                }

                function P(t, e) {
                    return e < 1 || t[3] && t[3] < 1 ? A(t, e) : "hsl(" + t[0] + ", " + t[1] + "%, " + t[2] + "%)"
                }

                function A(t, e) {
                    return void 0 === e && (e = void 0 !== t[3] ? t[3] : 1), "hsla(" + t[0] + ", " + t[1] + "%, " + t[2] + "%, " + e + ")"
                }

                function D(t, e) {
                    return void 0 === e && (e = void 0 !== t[3] ? t[3] : 1), "hwb(" + t[0] + ", " + t[1] + "%, " + t[2] + "%" + (void 0 !== e && 1 !== e ? ", " + e : "") + ")"
                }

                function T(t) {
                    return O[t.slice(0, 3)]
                }

                function I(t, e, n) {
                    return Math.min(Math.max(e, t), n)
                }

                function F(t) {
                    var e = t.toString(16).toUpperCase();
                    return e.length < 2 ? "0" + e : e
                }
                var O = {};
                for (var L in g) O[g[L]] = L;
                var R = function(t) {
                    return t instanceof R ? t : this instanceof R ? (this.valid = !1, this.values = {
                        rgb: [0, 0, 0],
                        hsl: [0, 0, 0],
                        hsv: [0, 0, 0],
                        hwb: [0, 0, 0],
                        cmyk: [0, 0, 0, 0],
                        alpha: 1
                    }, void("string" === typeof t ? (e = p.getRgba(t)) ? this.setValues("rgb", e) : (e = p.getHsla(t)) ? this.setValues("hsl", e) : (e = p.getHwb(t)) && this.setValues("hwb", e) : "object" === typeof t && (void 0 !== (e = t).r || void 0 !== e.red ? this.setValues("rgb", e) : void 0 !== e.l || void 0 !== e.lightness ? this.setValues("hsl", e) : void 0 !== e.v || void 0 !== e.value ? this.setValues("hsv", e) : void 0 !== e.w || void 0 !== e.whiteness ? this.setValues("hwb", e) : void 0 === e.c && void 0 === e.cyan || this.setValues("cmyk", e)))) : new R(t);
                    var e
                };
                R.prototype = {
                    isValid: function() {
                        return this.valid
                    },
                    rgb: function() {
                        return this.setSpace("rgb", arguments)
                    },
                    hsl: function() {
                        return this.setSpace("hsl", arguments)
                    },
                    hsv: function() {
                        return this.setSpace("hsv", arguments)
                    },
                    hwb: function() {
                        return this.setSpace("hwb", arguments)
                    },
                    cmyk: function() {
                        return this.setSpace("cmyk", arguments)
                    },
                    rgbArray: function() {
                        return this.values.rgb
                    },
                    hslArray: function() {
                        return this.values.hsl
                    },
                    hsvArray: function() {
                        return this.values.hsv
                    },
                    hwbArray: function() {
                        var t = this.values;
                        return 1 !== t.alpha ? t.hwb.concat([t.alpha]) : t.hwb
                    },
                    cmykArray: function() {
                        return this.values.cmyk
                    },
                    rgbaArray: function() {
                        var t = this.values;
                        return t.rgb.concat([t.alpha])
                    },
                    hslaArray: function() {
                        var t = this.values;
                        return t.hsl.concat([t.alpha])
                    },
                    alpha: function(t) {
                        return void 0 === t ? this.values.alpha : (this.setValues("alpha", t), this)
                    },
                    red: function(t) {
                        return this.setChannel("rgb", 0, t)
                    },
                    green: function(t) {
                        return this.setChannel("rgb", 1, t)
                    },
                    blue: function(t) {
                        return this.setChannel("rgb", 2, t)
                    },
                    hue: function(t) {
                        return t && (t = (t %= 360) < 0 ? 360 + t : t), this.setChannel("hsl", 0, t)
                    },
                    saturation: function(t) {
                        return this.setChannel("hsl", 1, t)
                    },
                    lightness: function(t) {
                        return this.setChannel("hsl", 2, t)
                    },
                    saturationv: function(t) {
                        return this.setChannel("hsv", 1, t)
                    },
                    whiteness: function(t) {
                        return this.setChannel("hwb", 1, t)
                    },
                    blackness: function(t) {
                        return this.setChannel("hwb", 2, t)
                    },
                    value: function(t) {
                        return this.setChannel("hsv", 2, t)
                    },
                    cyan: function(t) {
                        return this.setChannel("cmyk", 0, t)
                    },
                    magenta: function(t) {
                        return this.setChannel("cmyk", 1, t)
                    },
                    yellow: function(t) {
                        return this.setChannel("cmyk", 2, t)
                    },
                    black: function(t) {
                        return this.setChannel("cmyk", 3, t)
                    },
                    hexString: function() {
                        return p.hexString(this.values.rgb)
                    },
                    rgbString: function() {
                        return p.rgbString(this.values.rgb, this.values.alpha)
                    },
                    rgbaString: function() {
                        return p.rgbaString(this.values.rgb, this.values.alpha)
                    },
                    percentString: function() {
                        return p.percentString(this.values.rgb, this.values.alpha)
                    },
                    hslString: function() {
                        return p.hslString(this.values.hsl, this.values.alpha)
                    },
                    hslaString: function() {
                        return p.hslaString(this.values.hsl, this.values.alpha)
                    },
                    hwbString: function() {
                        return p.hwbString(this.values.hwb, this.values.alpha)
                    },
                    keyword: function() {
                        return p.keyword(this.values.rgb, this.values.alpha)
                    },
                    rgbNumber: function() {
                        var t = this.values.rgb;
                        return t[0] << 16 | t[1] << 8 | t[2]
                    },
                    luminosity: function() {
                        for (var t = this.values.rgb, e = [], n = 0; n < t.length; n++) {
                            var i = t[n] / 255;
                            e[n] = i <= .03928 ? i / 12.92 : Math.pow((i + .055) / 1.055, 2.4)
                        }
                        return .2126 * e[0] + .7152 * e[1] + .0722 * e[2]
                    },
                    contrast: function(t) {
                        var e = this.luminosity(),
                            n = t.luminosity();
                        return e > n ? (e + .05) / (n + .05) : (n + .05) / (e + .05)
                    },
                    level: function(t) {
                        var e = this.contrast(t);
                        return e >= 7.1 ? "AAA" : e >= 4.5 ? "AA" : ""
                    },
                    dark: function() {
                        var t = this.values.rgb;
                        return (299 * t[0] + 587 * t[1] + 114 * t[2]) / 1e3 < 128
                    },
                    light: function() {
                        return !this.dark()
                    },
                    negate: function() {
                        for (var t = [], e = 0; e < 3; e++) t[e] = 255 - this.values.rgb[e];
                        return this.setValues("rgb", t), this
                    },
                    lighten: function(t) {
                        var e = this.values.hsl;
                        return e[2] += e[2] * t, this.setValues("hsl", e), this
                    },
                    darken: function(t) {
                        var e = this.values.hsl;
                        return e[2] -= e[2] * t, this.setValues("hsl", e), this
                    },
                    saturate: function(t) {
                        var e = this.values.hsl;
                        return e[1] += e[1] * t, this.setValues("hsl", e), this
                    },
                    desaturate: function(t) {
                        var e = this.values.hsl;
                        return e[1] -= e[1] * t, this.setValues("hsl", e), this
                    },
                    whiten: function(t) {
                        var e = this.values.hwb;
                        return e[1] += e[1] * t, this.setValues("hwb", e), this
                    },
                    blacken: function(t) {
                        var e = this.values.hwb;
                        return e[2] += e[2] * t, this.setValues("hwb", e), this
                    },
                    greyscale: function() {
                        var t = this.values.rgb,
                            e = .3 * t[0] + .59 * t[1] + .11 * t[2];
                        return this.setValues("rgb", [e, e, e]), this
                    },
                    clearer: function(t) {
                        var e = this.values.alpha;
                        return this.setValues("alpha", e - e * t), this
                    },
                    opaquer: function(t) {
                        var e = this.values.alpha;
                        return this.setValues("alpha", e + e * t), this
                    },
                    rotate: function(t) {
                        var e = this.values.hsl,
                            n = (e[0] + t) % 360;
                        return e[0] = n < 0 ? 360 + n : n, this.setValues("hsl", e), this
                    },
                    mix: function(t, e) {
                        var n = this,
                            i = t,
                            a = void 0 === e ? .5 : e,
                            r = 2 * a - 1,
                            o = n.alpha() - i.alpha(),
                            l = ((r * o === -1 ? r : (r + o) / (1 + r * o)) + 1) / 2,
                            s = 1 - l;
                        return this.rgb(l * n.red() + s * i.red(), l * n.green() + s * i.green(), l * n.blue() + s * i.blue()).alpha(n.alpha() * a + i.alpha() * (1 - a))
                    },
                    toJSON: function() {
                        return this.rgb()
                    },
                    clone: function() {
                        var t, e, n = new R,
                            i = this.values,
                            a = n.values;
                        for (var r in i) i.hasOwnProperty(r) && (t = i[r], "[object Array]" === (e = {}.toString.call(t)) ? a[r] = t.slice(0) : "[object Number]" === e ? a[r] = t : console.error("unexpected color value:", t));
                        return n
                    }
                }, R.prototype.spaces = {
                    rgb: ["red", "green", "blue"],
                    hsl: ["hue", "saturation", "lightness"],
                    hsv: ["hue", "saturation", "value"],
                    hwb: ["hue", "whiteness", "blackness"],
                    cmyk: ["cyan", "magenta", "yellow", "black"]
                }, R.prototype.maxes = {
                    rgb: [255, 255, 255],
                    hsl: [360, 100, 100],
                    hsv: [360, 100, 100],
                    hwb: [360, 100, 100],
                    cmyk: [100, 100, 100, 100]
                }, R.prototype.getValues = function(t) {
                    for (var e = this.values, n = {}, i = 0; i < t.length; i++) n[t.charAt(i)] = e[t][i];
                    return 1 !== e.alpha && (n.a = e.alpha), n
                }, R.prototype.setValues = function(t, e) {
                    var n, i, a = this.values,
                        r = this.spaces,
                        o = this.maxes,
                        l = 1;
                    if (this.valid = !0, "alpha" === t) l = e;
                    else if (e.length) a[t] = e.slice(0, t.length), l = e[t.length];
                    else if (void 0 !== e[t.charAt(0)]) {
                        for (n = 0; n < t.length; n++) a[t][n] = e[t.charAt(n)];
                        l = e.a
                    } else if (void 0 !== e[r[t][0]]) {
                        var s = r[t];
                        for (n = 0; n < t.length; n++) a[t][n] = e[s[n]];
                        l = e.alpha
                    }
                    if (a.alpha = Math.max(0, Math.min(1, void 0 === l ? a.alpha : l)), "alpha" === t) return !1;
                    for (n = 0; n < t.length; n++) i = Math.max(0, Math.min(o[t][n], a[t][n])), a[t][n] = Math.round(i);
                    for (var u in r) u !== t && (a[u] = f[t][u](a[t]));
                    return !0
                }, R.prototype.setSpace = function(t, e) {
                    var n = e[0];
                    return void 0 === n ? this.getValues(t) : ("number" === typeof n && (n = Array.prototype.slice.call(e)), this.setValues(t, n), this)
                }, R.prototype.setChannel = function(t, e, n) {
                    var i = this.values[t];
                    return void 0 === n ? i[e] : (n === i[e] || (i[e] = n, this.setValues(t, i)), this)
                }, window.Color = R;
                var z = R,
                    N = {
                        noop: function() {},
                        uid: function() {
                            var t = 0;
                            return function() {
                                return t++
                            }
                        }(),
                        isNullOrUndef: function(t) {
                            return null === t || "undefined" === typeof t
                        },
                        isArray: function(t) {
                            if (Array.isArray && Array.isArray(t)) return !0;
                            var e = Object.prototype.toString.call(t);
                            return "[object" === e.substr(0, 7) && "Array]" === e.substr(-6)
                        },
                        isObject: function(t) {
                            return null !== t && "[object Object]" === Object.prototype.toString.call(t)
                        },
                        isFinite: function(t) {
                            return ("number" === typeof t || t instanceof Number) && isFinite(t)
                        },
                        valueOrDefault: function(t, e) {
                            return "undefined" === typeof t ? e : t
                        },
                        valueAtIndexOrDefault: function(t, e, n) {
                            return N.valueOrDefault(N.isArray(t) ? t[e] : t, n)
                        },
                        callback: function(t, e, n) {
                            if (t && "function" === typeof t.call) return t.apply(n, e)
                        },
                        each: function(t, e, n, i) {
                            var a, r, o;
                            if (N.isArray(t))
                                if (r = t.length, i)
                                    for (a = r - 1; a >= 0; a--) e.call(n, t[a], a);
                                else
                                    for (a = 0; a < r; a++) e.call(n, t[a], a);
                            else if (N.isObject(t))
                                for (r = (o = Object.keys(t)).length, a = 0; a < r; a++) e.call(n, t[o[a]], o[a])
                        },
                        arrayEquals: function(t, e) {
                            var n, i, a, r;
                            if (!t || !e || t.length !== e.length) return !1;
                            for (n = 0, i = t.length; n < i; ++n)
                                if (a = t[n], r = e[n], a instanceof Array && r instanceof Array) {
                                    if (!N.arrayEquals(a, r)) return !1
                                } else if (a !== r) return !1;
                            return !0
                        },
                        clone: function(t) {
                            if (N.isArray(t)) return t.map(N.clone);
                            if (N.isObject(t)) {
                                for (var e = {}, n = Object.keys(t), i = n.length, a = 0; a < i; ++a) e[n[a]] = N.clone(t[n[a]]);
                                return e
                            }
                            return t
                        },
                        _merger: function(t, e, n, i) {
                            var a = e[t],
                                r = n[t];
                            N.isObject(a) && N.isObject(r) ? N.merge(a, r, i) : e[t] = N.clone(r)
                        },
                        _mergerIf: function(t, e, n) {
                            var i = e[t],
                                a = n[t];
                            N.isObject(i) && N.isObject(a) ? N.mergeIf(i, a) : e.hasOwnProperty(t) || (e[t] = N.clone(a))
                        },
                        merge: function(t, e, n) {
                            var i, a, r, o, l, s = N.isArray(e) ? e : [e],
                                u = s.length;
                            if (!N.isObject(t)) return t;
                            for (i = (n = n || {}).merger || N._merger, a = 0; a < u; ++a)
                                if (e = s[a], N.isObject(e))
                                    for (l = 0, o = (r = Object.keys(e)).length; l < o; ++l) i(r[l], t, e, n);
                            return t
                        },
                        mergeIf: function(t, e) {
                            return N.merge(t, e, {
                                merger: N._mergerIf
                            })
                        },
                        extend: Object.assign || function(t) {
                            return N.merge(t, [].slice.call(arguments, 1), {
                                merger: function(t, e, n) {
                                    e[t] = n[t]
                                }
                            })
                        },
                        inherits: function(t) {
                            var e = this,
                                n = t && t.hasOwnProperty("constructor") ? t.constructor : function() {
                                    return e.apply(this, arguments)
                                },
                                i = function() {
                                    this.constructor = n
                                };
                            return i.prototype = e.prototype, n.prototype = new i, n.extend = N.inherits, t && N.extend(n.prototype, t), n.__super__ = e.prototype, n
                        },
                        _deprecated: function(t, e, n, i) {
                            void 0 !== e && console.warn(t + ': "' + n + '" is deprecated. Please use "' + i + '" instead')
                        }
                    },
                    B = N;
                N.callCallback = N.callback, N.indexOf = function(t, e, n) {
                    return Array.prototype.indexOf.call(t, e, n)
                }, N.getValueOrDefault = N.valueOrDefault, N.getValueAtIndexOrDefault = N.valueAtIndexOrDefault;
                var E = {
                        linear: function(t) {
                            return t
                        },
                        easeInQuad: function(t) {
                            return t * t
                        },
                        easeOutQuad: function(t) {
                            return -t * (t - 2)
                        },
                        easeInOutQuad: function(t) {
                            return (t /= .5) < 1 ? .5 * t * t : -.5 * (--t * (t - 2) - 1)
                        },
                        easeInCubic: function(t) {
                            return t * t * t
                        },
                        easeOutCubic: function(t) {
                            return (t -= 1) * t * t + 1
                        },
                        easeInOutCubic: function(t) {
                            return (t /= .5) < 1 ? .5 * t * t * t : .5 * ((t -= 2) * t * t + 2)
                        },
                        easeInQuart: function(t) {
                            return t * t * t * t
                        },
                        easeOutQuart: function(t) {
                            return -((t -= 1) * t * t * t - 1)
                        },
                        easeInOutQuart: function(t) {
                            return (t /= .5) < 1 ? .5 * t * t * t * t : -.5 * ((t -= 2) * t * t * t - 2)
                        },
                        easeInQuint: function(t) {
                            return t * t * t * t * t
                        },
                        easeOutQuint: function(t) {
                            return (t -= 1) * t * t * t * t + 1
                        },
                        easeInOutQuint: function(t) {
                            return (t /= .5) < 1 ? .5 * t * t * t * t * t : .5 * ((t -= 2) * t * t * t * t + 2)
                        },
                        easeInSine: function(t) {
                            return 1 - Math.cos(t * (Math.PI / 2))
                        },
                        easeOutSine: function(t) {
                            return Math.sin(t * (Math.PI / 2))
                        },
                        easeInOutSine: function(t) {
                            return -.5 * (Math.cos(Math.PI * t) - 1)
                        },
                        easeInExpo: function(t) {
                            return 0 === t ? 0 : Math.pow(2, 10 * (t - 1))
                        },
                        easeOutExpo: function(t) {
                            return 1 === t ? 1 : 1 - Math.pow(2, -10 * t)
                        },
                        easeInOutExpo: function(t) {
                            return 0 === t ? 0 : 1 === t ? 1 : (t /= .5) < 1 ? .5 * Math.pow(2, 10 * (t - 1)) : .5 * (2 - Math.pow(2, -10 * --t))
                        },
                        easeInCirc: function(t) {
                            return t >= 1 ? t : -(Math.sqrt(1 - t * t) - 1)
                        },
                        easeOutCirc: function(t) {
                            return Math.sqrt(1 - (t -= 1) * t)
                        },
                        easeInOutCirc: function(t) {
                            return (t /= .5) < 1 ? -.5 * (Math.sqrt(1 - t * t) - 1) : .5 * (Math.sqrt(1 - (t -= 2) * t) + 1)
                        },
                        easeInElastic: function(t) {
                            var e = 1.70158,
                                n = 0,
                                i = 1;
                            return 0 === t ? 0 : 1 === t ? 1 : (n || (n = .3), i < 1 ? (i = 1, e = n / 4) : e = n / (2 * Math.PI) * Math.asin(1 / i), -i * Math.pow(2, 10 * (t -= 1)) * Math.sin((t - e) * (2 * Math.PI) / n))
                        },
                        easeOutElastic: function(t) {
                            var e = 1.70158,
                                n = 0,
                                i = 1;
                            return 0 === t ? 0 : 1 === t ? 1 : (n || (n = .3), i < 1 ? (i = 1, e = n / 4) : e = n / (2 * Math.PI) * Math.asin(1 / i), i * Math.pow(2, -10 * t) * Math.sin((t - e) * (2 * Math.PI) / n) + 1)
                        },
                        easeInOutElastic: function(t) {
                            var e = 1.70158,
                                n = 0,
                                i = 1;
                            return 0 === t ? 0 : 2 === (t /= .5) ? 1 : (n || (n = .45), i < 1 ? (i = 1, e = n / 4) : e = n / (2 * Math.PI) * Math.asin(1 / i), t < 1 ? i * Math.pow(2, 10 * (t -= 1)) * Math.sin((t - e) * (2 * Math.PI) / n) * -.5 : i * Math.pow(2, -10 * (t -= 1)) * Math.sin((t - e) * (2 * Math.PI) / n) * .5 + 1)
                        },
                        easeInBack: function(t) {
                            var e = 1.70158;
                            return t * t * ((e + 1) * t - e)
                        },
                        easeOutBack: function(t) {
                            var e = 1.70158;
                            return (t -= 1) * t * ((e + 1) * t + e) + 1
                        },
                        easeInOutBack: function(t) {
                            var e = 1.70158;
                            return (t /= .5) < 1 ? t * t * ((1 + (e *= 1.525)) * t - e) * .5 : .5 * ((t -= 2) * t * ((1 + (e *= 1.525)) * t + e) + 2)
                        },
                        easeInBounce: function(t) {
                            return 1 - E.easeOutBounce(1 - t)
                        },
                        easeOutBounce: function(t) {
                            return t < 1 / 2.75 ? 7.5625 * t * t : t < 2 / 2.75 ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : t < 2.5 / 2.75 ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375
                        },
                        easeInOutBounce: function(t) {
                            return t < .5 ? .5 * E.easeInBounce(2 * t) : .5 * E.easeOutBounce(2 * t - 1) + .5
                        }
                    },
                    W = {
                        effects: E
                    };
                B.easingEffects = E;
                var V = Math.PI,
                    H = V / 180,
                    j = 2 * V,
                    q = V / 2,
                    U = V / 4,
                    Y = 2 * V / 3,
                    G = {
                        clear: function(t) {
                            t.ctx.clearRect(0, 0, t.width, t.height)
                        },
                        roundedRect: function(t, e, n, i, a, r) {
                            if (r) {
                                var o = Math.min(r, a / 2, i / 2),
                                    l = e + o,
                                    s = n + o,
                                    u = e + i - o,
                                    d = n + a - o;
                                t.moveTo(e, s), l < u && s < d ? (t.arc(l, s, o, -V, -q), t.arc(u, s, o, -q, 0), t.arc(u, d, o, 0, q), t.arc(l, d, o, q, V)) : l < u ? (t.moveTo(l, n), t.arc(u, s, o, -q, q), t.arc(l, s, o, q, V + q)) : s < d ? (t.arc(l, s, o, -V, 0), t.arc(l, d, o, 0, V)) : t.arc(l, s, o, -V, V), t.closePath(), t.moveTo(e, n)
                            } else t.rect(e, n, i, a)
                        },
                        drawPoint: function(t, e, n, i, a, r) {
                            var o, l, s, u, d, c = (r || 0) * H;
                            if (e && "object" === typeof e && ("[object HTMLImageElement]" === (o = e.toString()) || "[object HTMLCanvasElement]" === o)) return t.save(), t.translate(i, a), t.rotate(c), t.drawImage(e, -e.width / 2, -e.height / 2, e.width, e.height), void t.restore();
                            if (!(isNaN(n) || n <= 0)) {
                                switch (t.beginPath(), e) {
                                    default: t.arc(i, a, n, 0, j),
                                    t.closePath();
                                    break;
                                    case "triangle":
                                            t.moveTo(i + Math.sin(c) * n, a - Math.cos(c) * n),
                                        c += Y,
                                        t.lineTo(i + Math.sin(c) * n, a - Math.cos(c) * n),
                                        c += Y,
                                        t.lineTo(i + Math.sin(c) * n, a - Math.cos(c) * n),
                                        t.closePath();
                                        break;
                                    case "rectRounded":
                                            u = n - (d = .516 * n),
                                        l = Math.cos(c + U) * u,
                                        s = Math.sin(c + U) * u,
                                        t.arc(i - l, a - s, d, c - V, c - q),
                                        t.arc(i + s, a - l, d, c - q, c),
                                        t.arc(i + l, a + s, d, c, c + q),
                                        t.arc(i - s, a + l, d, c + q, c + V),
                                        t.closePath();
                                        break;
                                    case "rect":
                                            if (!r) {
                                            u = Math.SQRT1_2 * n, t.rect(i - u, a - u, 2 * u, 2 * u);
                                            break
                                        }c += U;
                                    case "rectRot":
                                            l = Math.cos(c) * n,
                                        s = Math.sin(c) * n,
                                        t.moveTo(i - l, a - s),
                                        t.lineTo(i + s, a - l),
                                        t.lineTo(i + l, a + s),
                                        t.lineTo(i - s, a + l),
                                        t.closePath();
                                        break;
                                    case "crossRot":
                                            c += U;
                                    case "cross":
                                            l = Math.cos(c) * n,
                                        s = Math.sin(c) * n,
                                        t.moveTo(i - l, a - s),
                                        t.lineTo(i + l, a + s),
                                        t.moveTo(i + s, a - l),
                                        t.lineTo(i - s, a + l);
                                        break;
                                    case "star":
                                            l = Math.cos(c) * n,
                                        s = Math.sin(c) * n,
                                        t.moveTo(i - l, a - s),
                                        t.lineTo(i + l, a + s),
                                        t.moveTo(i + s, a - l),
                                        t.lineTo(i - s, a + l),
                                        c += U,
                                        l = Math.cos(c) * n,
                                        s = Math.sin(c) * n,
                                        t.moveTo(i - l, a - s),
                                        t.lineTo(i + l, a + s),
                                        t.moveTo(i + s, a - l),
                                        t.lineTo(i - s, a + l);
                                        break;
                                    case "line":
                                            l = Math.cos(c) * n,
                                        s = Math.sin(c) * n,
                                        t.moveTo(i - l, a - s),
                                        t.lineTo(i + l, a + s);
                                        break;
                                    case "dash":
                                            t.moveTo(i, a),
                                        t.lineTo(i + Math.cos(c) * n, a + Math.sin(c) * n)
                                }
                                t.fill(), t.stroke()
                            }
                        },
                        _isPointInArea: function(t, e) {
                            var n = 1e-6;
                            return t.x > e.left - n && t.x < e.right + n && t.y > e.top - n && t.y < e.bottom + n
                        },
                        clipArea: function(t, e) {
                            t.save(), t.beginPath(), t.rect(e.left, e.top, e.right - e.left, e.bottom - e.top), t.clip()
                        },
                        unclipArea: function(t) {
                            t.restore()
                        },
                        lineTo: function(t, e, n, i) {
                            var a = n.steppedLine;
                            if (a) {
                                if ("middle" === a) {
                                    var r = (e.x + n.x) / 2;
                                    t.lineTo(r, i ? n.y : e.y), t.lineTo(r, i ? e.y : n.y)
                                } else "after" === a && !i || "after" !== a && i ? t.lineTo(e.x, n.y) : t.lineTo(n.x, e.y);
                                t.lineTo(n.x, n.y)
                            } else n.tension ? t.bezierCurveTo(i ? e.controlPointPreviousX : e.controlPointNextX, i ? e.controlPointPreviousY : e.controlPointNextY, i ? n.controlPointNextX : n.controlPointPreviousX, i ? n.controlPointNextY : n.controlPointPreviousY, n.x, n.y) : t.lineTo(n.x, n.y)
                        }
                    },
                    X = G;
                B.clear = G.clear, B.drawRoundedRectangle = function(t) {
                    t.beginPath(), G.roundedRect.apply(G, arguments)
                };
                var K = {
                    _set: function(t, e) {
                        return B.merge(this[t] || (this[t] = {}), e)
                    }
                };
                K._set("global", {
                    defaultColor: "rgba(0,0,0,0.1)",
                    defaultFontColor: "#666",
                    defaultFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
                    defaultFontSize: 12,
                    defaultFontStyle: "normal",
                    defaultLineHeight: 1.2,
                    showLines: !0
                });
                var Z = K,
                    $ = B.valueOrDefault;

                function J(t) {
                    return !t || B.isNullOrUndef(t.size) || B.isNullOrUndef(t.family) ? null : (t.style ? t.style + " " : "") + (t.weight ? t.weight + " " : "") + t.size + "px " + t.family
                }
                var Q = {
                        toLineHeight: function(t, e) {
                            var n = ("" + t).match(/^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/);
                            if (!n || "normal" === n[1]) return 1.2 * e;
                            switch (t = +n[2], n[3]) {
                                case "px":
                                    return t;
                                case "%":
                                    t /= 100
                            }
                            return e * t
                        },
                        toPadding: function(t) {
                            var e, n, i, a;
                            return B.isObject(t) ? (e = +t.top || 0, n = +t.right || 0, i = +t.bottom || 0, a = +t.left || 0) : e = n = i = a = +t || 0, {
                                top: e,
                                right: n,
                                bottom: i,
                                left: a,
                                height: e + i,
                                width: a + n
                            }
                        },
                        _parseFont: function(t) {
                            var e = Z.global,
                                n = $(t.fontSize, e.defaultFontSize),
                                i = {
                                    family: $(t.fontFamily, e.defaultFontFamily),
                                    lineHeight: B.options.toLineHeight($(t.lineHeight, e.defaultLineHeight), n),
                                    size: n,
                                    style: $(t.fontStyle, e.defaultFontStyle),
                                    weight: null,
                                    string: ""
                                };
                            return i.string = J(i), i
                        },
                        resolve: function(t, e, n, i) {
                            var a, r, o, l = !0;
                            for (a = 0, r = t.length; a < r; ++a)
                                if (void 0 !== (o = t[a]) && (void 0 !== e && "function" === typeof o && (o = o(e), l = !1), void 0 !== n && B.isArray(o) && (o = o[n], l = !1), void 0 !== o)) return i && !l && (i.cacheable = !1), o
                        }
                    },
                    tt = {
                        _factorize: function(t) {
                            var e, n = [],
                                i = Math.sqrt(t);
                            for (e = 1; e < i; e++) t % e === 0 && (n.push(e), n.push(t / e));
                            return i === (0 | i) && n.push(i), n.sort((function(t, e) {
                                return t - e
                            })).pop(), n
                        },
                        log10: Math.log10 || function(t) {
                            var e = Math.log(t) * Math.LOG10E,
                                n = Math.round(e);
                            return t === Math.pow(10, n) ? n : e
                        }
                    },
                    et = tt;
                B.log10 = tt.log10;
                var nt = function(t, e) {
                        return {
                            x: function(n) {
                                return t + t + e - n
                            },
                            setWidth: function(t) {
                                e = t
                            },
                            textAlign: function(t) {
                                return "center" === t ? t : "right" === t ? "left" : "right"
                            },
                            xPlus: function(t, e) {
                                return t - e
                            },
                            leftForLtr: function(t, e) {
                                return t - e
                            }
                        }
                    },
                    it = function() {
                        return {
                            x: function(t) {
                                return t
                            },
                            setWidth: function(t) {},
                            textAlign: function(t) {
                                return t
                            },
                            xPlus: function(t, e) {
                                return t + e
                            },
                            leftForLtr: function(t, e) {
                                return t
                            }
                        }
                    },
                    at = function(t, e, n) {
                        return t ? nt(e, n) : it()
                    },
                    rt = B,
                    ot = W,
                    lt = X,
                    st = Q,
                    ut = et,
                    dt = {
                        getRtlAdapter: at,
                        overrideTextDirection: function(t, e) {
                            var n, i;
                            "ltr" !== e && "rtl" !== e || (i = [(n = t.canvas.style).getPropertyValue("direction"), n.getPropertyPriority("direction")], n.setProperty("direction", e, "important"), t.prevTextDirection = i)
                        },
                        restoreTextDirection: function(t) {
                            var e = t.prevTextDirection;
                            void 0 !== e && (delete t.prevTextDirection, t.canvas.style.setProperty("direction", e[0], e[1]))
                        }
                    };

                function ct(t, e, n, i) {
                    var a, r, o, l, s, u, d, c, h, f = Object.keys(n);
                    for (a = 0, r = f.length; a < r; ++a)
                        if (u = n[o = f[a]], e.hasOwnProperty(o) || (e[o] = u), (l = e[o]) !== u && "_" !== o[0]) {
                            if (t.hasOwnProperty(o) || (t[o] = l), (d = typeof u) === typeof(s = t[o]))
                                if ("string" === d) {
                                    if ((c = z(s)).valid && (h = z(u)).valid) {
                                        e[o] = h.mix(c, i).rgbString();
                                        continue
                                    }
                                } else if (rt.isFinite(s) && rt.isFinite(u)) {
                                e[o] = s + (u - s) * i;
                                continue
                            }
                            e[o] = u
                        }
                }
                rt.easing = ot, rt.canvas = lt, rt.options = st, rt.math = ut, rt.rtl = dt;
                var ht = function(t) {
                    rt.extend(this, t), this.initialize.apply(this, arguments)
                };
                rt.extend(ht.prototype, {
                    _type: void 0,
                    initialize: function() {
                        this.hidden = !1
                    },
                    pivot: function() {
                        var t = this;
                        return t._view || (t._view = rt.extend({}, t._model)), t._start = {}, t
                    },
                    transition: function(t) {
                        var e = this,
                            n = e._model,
                            i = e._start,
                            a = e._view;
                        return n && 1 !== t ? (a || (a = e._view = {}), i || (i = e._start = {}), ct(i, a, n, t), e) : (e._view = rt.extend({}, n), e._start = null, e)
                    },
                    tooltipPosition: function() {
                        return {
                            x: this._model.x,
                            y: this._model.y
                        }
                    },
                    hasValue: function() {
                        return rt.isNumber(this._model.x) && rt.isNumber(this._model.y)
                    }
                }), ht.extend = rt.inherits;
                var ft = ht,
                    gt = ft.extend({
                        chart: null,
                        currentStep: 0,
                        numSteps: 60,
                        easing: "",
                        render: null,
                        onAnimationProgress: null,
                        onAnimationComplete: null
                    }),
                    pt = gt;
                Object.defineProperty(gt.prototype, "animationObject", {
                    get: function() {
                        return this
                    }
                }), Object.defineProperty(gt.prototype, "chartInstance", {
                    get: function() {
                        return this.chart
                    },
                    set: function(t) {
                        this.chart = t
                    }
                }), Z._set("global", {
                    animation: {
                        duration: 1e3,
                        easing: "easeOutQuart",
                        onProgress: rt.noop,
                        onComplete: rt.noop
                    }
                });
                var mt = {
                        animations: [],
                        request: null,
                        addAnimation: function(t, e, n, i) {
                            var a, r, o = this.animations;
                            for (e.chart = t, e.startTime = Date.now(), e.duration = n, i || (t.animating = !0), a = 0, r = o.length; a < r; ++a)
                                if (o[a].chart === t) return void(o[a] = e);
                            o.push(e), 1 === o.length && this.requestAnimationFrame()
                        },
                        cancelAnimation: function(t) {
                            var e = rt.findIndex(this.animations, (function(e) {
                                return e.chart === t
                            })); - 1 !== e && (this.animations.splice(e, 1), t.animating = !1)
                        },
                        requestAnimationFrame: function() {
                            var t = this;
                            null === t.request && (t.request = rt.requestAnimFrame.call(window, (function() {
                                t.request = null, t.startDigest()
                            })))
                        },
                        startDigest: function() {
                            var t = this;
                            t.advance(), t.animations.length > 0 && t.requestAnimationFrame()
                        },
                        advance: function() {
                            for (var t, e, n, i, a = this.animations, r = 0; r < a.length;) e = (t = a[r]).chart, n = t.numSteps, i = Math.floor((Date.now() - t.startTime) / t.duration * n) + 1, t.currentStep = Math.min(i, n), rt.callback(t.render, [e, t], e), rt.callback(t.onAnimationProgress, [t], e), t.currentStep >= n ? (rt.callback(t.onAnimationComplete, [t], e), e.animating = !1, a.splice(r, 1)) : ++r
                        }
                    },
                    vt = rt.options.resolve,
                    bt = ["push", "pop", "shift", "splice", "unshift"];

                function xt(t, e) {
                    t._chartjs ? t._chartjs.listeners.push(e) : (Object.defineProperty(t, "_chartjs", {
                        configurable: !0,
                        enumerable: !1,
                        value: {
                            listeners: [e]
                        }
                    }), bt.forEach((function(e) {
                        var n = "onData" + e.charAt(0).toUpperCase() + e.slice(1),
                            i = t[e];
                        Object.defineProperty(t, e, {
                            configurable: !0,
                            enumerable: !1,
                            value: function() {
                                var e = Array.prototype.slice.call(arguments),
                                    a = i.apply(this, e);
                                return rt.each(t._chartjs.listeners, (function(t) {
                                    "function" === typeof t[n] && t[n].apply(t, e)
                                })), a
                            }
                        })
                    })))
                }

                function yt(t, e) {
                    var n = t._chartjs;
                    if (n) {
                        var i = n.listeners,
                            a = i.indexOf(e); - 1 !== a && i.splice(a, 1), i.length > 0 || (bt.forEach((function(e) {
                            delete t[e]
                        })), delete t._chartjs)
                    }
                }
                var _t = function(t, e) {
                    this.initialize(t, e)
                };
                rt.extend(_t.prototype, {
                    datasetElementType: null,
                    dataElementType: null,
                    _datasetElementOptions: ["backgroundColor", "borderCapStyle", "borderColor", "borderDash", "borderDashOffset", "borderJoinStyle", "borderWidth"],
                    _dataElementOptions: ["backgroundColor", "borderColor", "borderWidth", "pointStyle"],
                    initialize: function(t, e) {
                        var n = this;
                        n.chart = t, n.index = e, n.linkScales(), n.addElements(), n._type = n.getMeta().type
                    },
                    updateIndex: function(t) {
                        this.index = t
                    },
                    linkScales: function() {
                        var t = this,
                            e = t.getMeta(),
                            n = t.chart,
                            i = n.scales,
                            a = t.getDataset(),
                            r = n.options.scales;
                        null !== e.xAxisID && e.xAxisID in i && !a.xAxisID || (e.xAxisID = a.xAxisID || r.xAxes[0].id), null !== e.yAxisID && e.yAxisID in i && !a.yAxisID || (e.yAxisID = a.yAxisID || r.yAxes[0].id)
                    },
                    getDataset: function() {
                        return this.chart.data.datasets[this.index]
                    },
                    getMeta: function() {
                        return this.chart.getDatasetMeta(this.index)
                    },
                    getScaleForId: function(t) {
                        return this.chart.scales[t]
                    },
                    _getValueScaleId: function() {
                        return this.getMeta().yAxisID
                    },
                    _getIndexScaleId: function() {
                        return this.getMeta().xAxisID
                    },
                    _getValueScale: function() {
                        return this.getScaleForId(this._getValueScaleId())
                    },
                    _getIndexScale: function() {
                        return this.getScaleForId(this._getIndexScaleId())
                    },
                    reset: function() {
                        this._update(!0)
                    },
                    destroy: function() {
                        this._data && yt(this._data, this)
                    },
                    createMetaDataset: function() {
                        var t = this,
                            e = t.datasetElementType;
                        return e && new e({
                            _chart: t.chart,
                            _datasetIndex: t.index
                        })
                    },
                    createMetaData: function(t) {
                        var e = this,
                            n = e.dataElementType;
                        return n && new n({
                            _chart: e.chart,
                            _datasetIndex: e.index,
                            _index: t
                        })
                    },
                    addElements: function() {
                        var t, e, n = this,
                            i = n.getMeta(),
                            a = n.getDataset().data || [],
                            r = i.data;
                        for (t = 0, e = a.length; t < e; ++t) r[t] = r[t] || n.createMetaData(t);
                        i.dataset = i.dataset || n.createMetaDataset()
                    },
                    addElementAndReset: function(t) {
                        var e = this.createMetaData(t);
                        this.getMeta().data.splice(t, 0, e), this.updateElement(e, t, !0)
                    },
                    buildOrUpdateElements: function() {
                        var t = this,
                            e = t.getDataset(),
                            n = e.data || (e.data = []);
                        t._data !== n && (t._data && yt(t._data, t), n && Object.isExtensible(n) && xt(n, t), t._data = n), t.resyncElements()
                    },
                    _configure: function() {
                        var t = this;
                        t._config = rt.merge({}, [t.chart.options.datasets[t._type], t.getDataset()], {
                            merger: function(t, e, n) {
                                "_meta" !== t && "data" !== t && rt._merger(t, e, n)
                            }
                        })
                    },
                    _update: function(t) {
                        var e = this;
                        e._configure(), e._cachedDataOpts = null, e.update(t)
                    },
                    update: rt.noop,
                    transition: function(t) {
                        for (var e = this.getMeta(), n = e.data || [], i = n.length, a = 0; a < i; ++a) n[a].transition(t);
                        e.dataset && e.dataset.transition(t)
                    },
                    draw: function() {
                        var t = this.getMeta(),
                            e = t.data || [],
                            n = e.length,
                            i = 0;
                        for (t.dataset && t.dataset.draw(); i < n; ++i) e[i].draw()
                    },
                    getStyle: function(t) {
                        var e, n = this,
                            i = n.getMeta(),
                            a = i.dataset;
                        return n._configure(), a && void 0 === t ? e = n._resolveDatasetElementOptions(a || {}) : (t = t || 0, e = n._resolveDataElementOptions(i.data[t] || {}, t)), !1 !== e.fill && null !== e.fill || (e.backgroundColor = "rgba(0,0,0,0)"), e
                    },
                    _resolveDatasetElementOptions: function(t, e) {
                        var n, i, a, r, o = this,
                            l = o.chart,
                            s = o._config,
                            u = t.custom || {},
                            d = l.options.elements[o.datasetElementType.prototype._type] || {},
                            c = o._datasetElementOptions,
                            h = {},
                            f = {
                                chart: l,
                                dataset: o.getDataset(),
                                datasetIndex: o.index,
                                hover: e
                            };
                        for (n = 0, i = c.length; n < i; ++n) a = c[n], r = e ? "hover" + a.charAt(0).toUpperCase() + a.slice(1) : a, h[a] = vt([u[r], s[r], d[r]], f);
                        return h
                    },
                    _resolveDataElementOptions: function(t, e) {
                        var n = this,
                            i = t && t.custom,
                            a = n._cachedDataOpts;
                        if (a && !i) return a;
                        var r, o, l, s, u = n.chart,
                            d = n._config,
                            c = u.options.elements[n.dataElementType.prototype._type] || {},
                            h = n._dataElementOptions,
                            f = {},
                            g = {
                                chart: u,
                                dataIndex: e,
                                dataset: n.getDataset(),
                                datasetIndex: n.index
                            },
                            p = {
                                cacheable: !i
                            };
                        if (i = i || {}, rt.isArray(h))
                            for (o = 0, l = h.length; o < l; ++o) f[s = h[o]] = vt([i[s], d[s], c[s]], g, e, p);
                        else
                            for (o = 0, l = (r = Object.keys(h)).length; o < l; ++o) f[s = r[o]] = vt([i[s], d[h[s]], d[s], c[s]], g, e, p);
                        return p.cacheable && (n._cachedDataOpts = Object.freeze(f)), f
                    },
                    removeHoverStyle: function(t) {
                        rt.merge(t._model, t.$previousStyle || {}), delete t.$previousStyle
                    },
                    setHoverStyle: function(t) {
                        var e = this.chart.data.datasets[t._datasetIndex],
                            n = t._index,
                            i = t.custom || {},
                            a = t._model,
                            r = rt.getHoverColor;
                        t.$previousStyle = {
                            backgroundColor: a.backgroundColor,
                            borderColor: a.borderColor,
                            borderWidth: a.borderWidth
                        }, a.backgroundColor = vt([i.hoverBackgroundColor, e.hoverBackgroundColor, r(a.backgroundColor)], void 0, n), a.borderColor = vt([i.hoverBorderColor, e.hoverBorderColor, r(a.borderColor)], void 0, n), a.borderWidth = vt([i.hoverBorderWidth, e.hoverBorderWidth, a.borderWidth], void 0, n)
                    },
                    _removeDatasetHoverStyle: function() {
                        var t = this.getMeta().dataset;
                        t && this.removeHoverStyle(t)
                    },
                    _setDatasetHoverStyle: function() {
                        var t, e, n, i, a, r, o = this.getMeta().dataset,
                            l = {};
                        if (o) {
                            for (r = o._model, a = this._resolveDatasetElementOptions(o, !0), t = 0, e = (i = Object.keys(a)).length; t < e; ++t) l[n = i[t]] = r[n], r[n] = a[n];
                            o.$previousStyle = l
                        }
                    },
                    resyncElements: function() {
                        var t = this,
                            e = t.getMeta(),
                            n = t.getDataset().data,
                            i = e.data.length,
                            a = n.length;
                        a < i ? e.data.splice(a, i - a) : a > i && t.insertElements(i, a - i)
                    },
                    insertElements: function(t, e) {
                        for (var n = 0; n < e; ++n) this.addElementAndReset(t + n)
                    },
                    onDataPush: function() {
                        var t = arguments.length;
                        this.insertElements(this.getDataset().data.length - t, t)
                    },
                    onDataPop: function() {
                        this.getMeta().data.pop()
                    },
                    onDataShift: function() {
                        this.getMeta().data.shift()
                    },
                    onDataSplice: function(t, e) {
                        this.getMeta().data.splice(t, e), this.insertElements(t, arguments.length - 2)
                    },
                    onDataUnshift: function() {
                        this.insertElements(0, arguments.length)
                    }
                }), _t.extend = rt.inherits;
                var kt = _t,
                    wt = 2 * Math.PI;

                function Mt(t, e) {
                    var n = e.startAngle,
                        i = e.endAngle,
                        a = e.pixelMargin,
                        r = a / e.outerRadius,
                        o = e.x,
                        l = e.y;
                    t.beginPath(), t.arc(o, l, e.outerRadius, n - r, i + r), e.innerRadius > a ? (r = a / e.innerRadius, t.arc(o, l, e.innerRadius - a, i + r, n - r, !0)) : t.arc(o, l, a, i + Math.PI / 2, n - Math.PI / 2), t.closePath(), t.clip()
                }

                function St(t, e, n, i) {
                    var a, r = n.endAngle;
                    for (i && (n.endAngle = n.startAngle + wt, Mt(t, n), n.endAngle = r, n.endAngle === n.startAngle && n.fullCircles && (n.endAngle += wt, n.fullCircles--)), t.beginPath(), t.arc(n.x, n.y, n.innerRadius, n.startAngle + wt, n.startAngle, !0), a = 0; a < n.fullCircles; ++a) t.stroke();
                    for (t.beginPath(), t.arc(n.x, n.y, e.outerRadius, n.startAngle, n.startAngle + wt), a = 0; a < n.fullCircles; ++a) t.stroke()
                }

                function Ct(t, e, n) {
                    var i = "inner" === e.borderAlign;
                    i ? (t.lineWidth = 2 * e.borderWidth, t.lineJoin = "round") : (t.lineWidth = e.borderWidth, t.lineJoin = "bevel"), n.fullCircles && St(t, e, n, i), i && Mt(t, n), t.beginPath(), t.arc(n.x, n.y, e.outerRadius, n.startAngle, n.endAngle), t.arc(n.x, n.y, n.innerRadius, n.endAngle, n.startAngle, !0), t.closePath(), t.stroke()
                }
                Z._set("global", {
                    elements: {
                        arc: {
                            backgroundColor: Z.global.defaultColor,
                            borderColor: "#fff",
                            borderWidth: 2,
                            borderAlign: "center"
                        }
                    }
                });
                var Pt = ft.extend({
                        _type: "arc",
                        inLabelRange: function(t) {
                            var e = this._view;
                            return !!e && Math.pow(t - e.x, 2) < Math.pow(e.radius + e.hoverRadius, 2)
                        },
                        inRange: function(t, e) {
                            var n = this._view;
                            if (n) {
                                for (var i = rt.getAngleFromPoint(n, {
                                        x: t,
                                        y: e
                                    }), a = i.angle, r = i.distance, o = n.startAngle, l = n.endAngle; l < o;) l += wt;
                                for (; a > l;) a -= wt;
                                for (; a < o;) a += wt;
                                var s = a >= o && a <= l,
                                    u = r >= n.innerRadius && r <= n.outerRadius;
                                return s && u
                            }
                            return !1
                        },
                        getCenterPoint: function() {
                            var t = this._view,
                                e = (t.startAngle + t.endAngle) / 2,
                                n = (t.innerRadius + t.outerRadius) / 2;
                            return {
                                x: t.x + Math.cos(e) * n,
                                y: t.y + Math.sin(e) * n
                            }
                        },
                        getArea: function() {
                            var t = this._view;
                            return Math.PI * ((t.endAngle - t.startAngle) / (2 * Math.PI)) * (Math.pow(t.outerRadius, 2) - Math.pow(t.innerRadius, 2))
                        },
                        tooltipPosition: function() {
                            var t = this._view,
                                e = t.startAngle + (t.endAngle - t.startAngle) / 2,
                                n = (t.outerRadius - t.innerRadius) / 2 + t.innerRadius;
                            return {
                                x: t.x + Math.cos(e) * n,
                                y: t.y + Math.sin(e) * n
                            }
                        },
                        draw: function() {
                            var t, e = this._chart.ctx,
                                n = this._view,
                                i = "inner" === n.borderAlign ? .33 : 0,
                                a = {
                                    x: n.x,
                                    y: n.y,
                                    innerRadius: n.innerRadius,
                                    outerRadius: Math.max(n.outerRadius - i, 0),
                                    pixelMargin: i,
                                    startAngle: n.startAngle,
                                    endAngle: n.endAngle,
                                    fullCircles: Math.floor(n.circumference / wt)
                                };
                            if (e.save(), e.fillStyle = n.backgroundColor, e.strokeStyle = n.borderColor, a.fullCircles) {
                                for (a.endAngle = a.startAngle + wt, e.beginPath(), e.arc(a.x, a.y, a.outerRadius, a.startAngle, a.endAngle), e.arc(a.x, a.y, a.innerRadius, a.endAngle, a.startAngle, !0), e.closePath(), t = 0; t < a.fullCircles; ++t) e.fill();
                                a.endAngle = a.startAngle + n.circumference % wt
                            }
                            e.beginPath(), e.arc(a.x, a.y, a.outerRadius, a.startAngle, a.endAngle), e.arc(a.x, a.y, a.innerRadius, a.endAngle, a.startAngle, !0), e.closePath(), e.fill(), n.borderWidth && Ct(e, n, a), e.restore()
                        }
                    }),
                    At = rt.valueOrDefault,
                    Dt = Z.global.defaultColor;
                Z._set("global", {
                    elements: {
                        line: {
                            tension: .4,
                            backgroundColor: Dt,
                            borderWidth: 3,
                            borderColor: Dt,
                            borderCapStyle: "butt",
                            borderDash: [],
                            borderDashOffset: 0,
                            borderJoinStyle: "miter",
                            capBezierPoints: !0,
                            fill: !0
                        }
                    }
                });
                var Tt = ft.extend({
                        _type: "line",
                        draw: function() {
                            var t, e, n, i = this,
                                a = i._view,
                                r = i._chart.ctx,
                                o = a.spanGaps,
                                l = i._children.slice(),
                                s = Z.global,
                                u = s.elements.line,
                                d = -1,
                                c = i._loop;
                            if (l.length) {
                                if (i._loop) {
                                    for (t = 0; t < l.length; ++t)
                                        if (e = rt.previousItem(l, t), !l[t]._view.skip && e._view.skip) {
                                            l = l.slice(t).concat(l.slice(0, t)), c = o;
                                            break
                                        }
                                    c && l.push(l[0])
                                }
                                for (r.save(), r.lineCap = a.borderCapStyle || u.borderCapStyle, r.setLineDash && r.setLineDash(a.borderDash || u.borderDash), r.lineDashOffset = At(a.borderDashOffset, u.borderDashOffset), r.lineJoin = a.borderJoinStyle || u.borderJoinStyle, r.lineWidth = At(a.borderWidth, u.borderWidth), r.strokeStyle = a.borderColor || s.defaultColor, r.beginPath(), (n = l[0]._view).skip || (r.moveTo(n.x, n.y), d = 0), t = 1; t < l.length; ++t) n = l[t]._view, e = -1 === d ? rt.previousItem(l, t) : l[d], n.skip || (d !== t - 1 && !o || -1 === d ? r.moveTo(n.x, n.y) : rt.canvas.lineTo(r, e._view, n), d = t);
                                c && r.closePath(), r.stroke(), r.restore()
                            }
                        }
                    }),
                    It = rt.valueOrDefault,
                    Ft = Z.global.defaultColor;

                function Ot(t) {
                    var e = this._view;
                    return !!e && Math.abs(t - e.x) < e.radius + e.hitRadius
                }

                function Lt(t) {
                    var e = this._view;
                    return !!e && Math.abs(t - e.y) < e.radius + e.hitRadius
                }
                Z._set("global", {
                    elements: {
                        point: {
                            radius: 3,
                            pointStyle: "circle",
                            backgroundColor: Ft,
                            borderColor: Ft,
                            borderWidth: 1,
                            hitRadius: 1,
                            hoverRadius: 4,
                            hoverBorderWidth: 1
                        }
                    }
                });
                var Rt = ft.extend({
                        _type: "point",
                        inRange: function(t, e) {
                            var n = this._view;
                            return !!n && Math.pow(t - n.x, 2) + Math.pow(e - n.y, 2) < Math.pow(n.hitRadius + n.radius, 2)
                        },
                        inLabelRange: Ot,
                        inXRange: Ot,
                        inYRange: Lt,
                        getCenterPoint: function() {
                            var t = this._view;
                            return {
                                x: t.x,
                                y: t.y
                            }
                        },
                        getArea: function() {
                            return Math.PI * Math.pow(this._view.radius, 2)
                        },
                        tooltipPosition: function() {
                            var t = this._view;
                            return {
                                x: t.x,
                                y: t.y,
                                padding: t.radius + t.borderWidth
                            }
                        },
                        draw: function(t) {
                            var e = this._view,
                                n = this._chart.ctx,
                                i = e.pointStyle,
                                a = e.rotation,
                                r = e.radius,
                                o = e.x,
                                l = e.y,
                                s = Z.global,
                                u = s.defaultColor;
                            e.skip || (void 0 === t || rt.canvas._isPointInArea(e, t)) && (n.strokeStyle = e.borderColor || u, n.lineWidth = It(e.borderWidth, s.elements.point.borderWidth), n.fillStyle = e.backgroundColor || u, rt.canvas.drawPoint(n, i, r, o, l, a))
                        }
                    }),
                    zt = Z.global.defaultColor;

                function Nt(t) {
                    return t && void 0 !== t.width
                }

                function Bt(t) {
                    var e, n, i, a, r;
                    return Nt(t) ? (r = t.width / 2, e = t.x - r, n = t.x + r, i = Math.min(t.y, t.base), a = Math.max(t.y, t.base)) : (r = t.height / 2, e = Math.min(t.x, t.base), n = Math.max(t.x, t.base), i = t.y - r, a = t.y + r), {
                        left: e,
                        top: i,
                        right: n,
                        bottom: a
                    }
                }

                function Et(t, e, n) {
                    return t === e ? n : t === n ? e : t
                }

                function Wt(t) {
                    var e = t.borderSkipped,
                        n = {};
                    return e ? (t.horizontal ? t.base > t.x && (e = Et(e, "left", "right")) : t.base < t.y && (e = Et(e, "bottom", "top")), n[e] = !0, n) : n
                }

                function Vt(t, e, n) {
                    var i, a, r, o, l = t.borderWidth,
                        s = Wt(t);
                    return rt.isObject(l) ? (i = +l.top || 0, a = +l.right || 0, r = +l.bottom || 0, o = +l.left || 0) : i = a = r = o = +l || 0, {
                        t: s.top || i < 0 ? 0 : i > n ? n : i,
                        r: s.right || a < 0 ? 0 : a > e ? e : a,
                        b: s.bottom || r < 0 ? 0 : r > n ? n : r,
                        l: s.left || o < 0 ? 0 : o > e ? e : o
                    }
                }

                function Ht(t) {
                    var e = Bt(t),
                        n = e.right - e.left,
                        i = e.bottom - e.top,
                        a = Vt(t, n / 2, i / 2);
                    return {
                        outer: {
                            x: e.left,
                            y: e.top,
                            w: n,
                            h: i
                        },
                        inner: {
                            x: e.left + a.l,
                            y: e.top + a.t,
                            w: n - a.l - a.r,
                            h: i - a.t - a.b
                        }
                    }
                }

                function jt(t, e, n) {
                    var i = null === e,
                        a = null === n,
                        r = !(!t || i && a) && Bt(t);
                    return r && (i || e >= r.left && e <= r.right) && (a || n >= r.top && n <= r.bottom)
                }
                Z._set("global", {
                    elements: {
                        rectangle: {
                            backgroundColor: zt,
                            borderColor: zt,
                            borderSkipped: "bottom",
                            borderWidth: 0
                        }
                    }
                });
                var qt = ft.extend({
                        _type: "rectangle",
                        draw: function() {
                            var t = this._chart.ctx,
                                e = this._view,
                                n = Ht(e),
                                i = n.outer,
                                a = n.inner;
                            t.fillStyle = e.backgroundColor, t.fillRect(i.x, i.y, i.w, i.h), i.w === a.w && i.h === a.h || (t.save(), t.beginPath(), t.rect(i.x, i.y, i.w, i.h), t.clip(), t.fillStyle = e.borderColor, t.rect(a.x, a.y, a.w, a.h), t.fill("evenodd"), t.restore())
                        },
                        height: function() {
                            var t = this._view;
                            return t.base - t.y
                        },
                        inRange: function(t, e) {
                            return jt(this._view, t, e)
                        },
                        inLabelRange: function(t, e) {
                            var n = this._view;
                            return Nt(n) ? jt(n, t, null) : jt(n, null, e)
                        },
                        inXRange: function(t) {
                            return jt(this._view, t, null)
                        },
                        inYRange: function(t) {
                            return jt(this._view, null, t)
                        },
                        getCenterPoint: function() {
                            var t, e, n = this._view;
                            return Nt(n) ? (t = n.x, e = (n.y + n.base) / 2) : (t = (n.x + n.base) / 2, e = n.y), {
                                x: t,
                                y: e
                            }
                        },
                        getArea: function() {
                            var t = this._view;
                            return Nt(t) ? t.width * Math.abs(t.y - t.base) : t.height * Math.abs(t.x - t.base)
                        },
                        tooltipPosition: function() {
                            var t = this._view;
                            return {
                                x: t.x,
                                y: t.y
                            }
                        }
                    }),
                    Ut = {},
                    Yt = Pt,
                    Gt = Tt,
                    Xt = Rt,
                    Kt = qt;
                Ut.Arc = Yt, Ut.Line = Gt, Ut.Point = Xt, Ut.Rectangle = Kt;
                var Zt = rt._deprecated,
                    $t = rt.valueOrDefault;

                function Jt(t, e) {
                    var n, i, a, r, o = t._length;
                    for (a = 1, r = e.length; a < r; ++a) o = Math.min(o, Math.abs(e[a] - e[a - 1]));
                    for (a = 0, r = t.getTicks().length; a < r; ++a) i = t.getPixelForTick(a), o = a > 0 ? Math.min(o, Math.abs(i - n)) : o, n = i;
                    return o
                }

                function Qt(t, e, n) {
                    var i, a, r = n.barThickness,
                        o = e.stackCount,
                        l = e.pixels[t],
                        s = rt.isNullOrUndef(r) ? Jt(e.scale, e.pixels) : -1;
                    return rt.isNullOrUndef(r) ? (i = s * n.categoryPercentage, a = n.barPercentage) : (i = r * o, a = 1), {
                        chunk: i / o,
                        ratio: a,
                        start: l - i / 2
                    }
                }

                function te(t, e, n) {
                    var i, a = e.pixels,
                        r = a[t],
                        o = t > 0 ? a[t - 1] : null,
                        l = t < a.length - 1 ? a[t + 1] : null,
                        s = n.categoryPercentage;
                    return null === o && (o = r - (null === l ? e.end - e.start : l - r)), null === l && (l = r + r - o), i = r - (r - Math.min(o, l)) / 2 * s, {
                        chunk: Math.abs(l - o) / 2 * s / e.stackCount,
                        ratio: n.barPercentage,
                        start: i
                    }
                }
                Z._set("bar", {
                    hover: {
                        mode: "label"
                    },
                    scales: {
                        xAxes: [{
                            type: "category",
                            offset: !0,
                            gridLines: {
                                offsetGridLines: !0
                            }
                        }],
                        yAxes: [{
                            type: "linear"
                        }]
                    }
                }), Z._set("global", {
                    datasets: {
                        bar: {
                            categoryPercentage: .8,
                            barPercentage: .9
                        }
                    }
                });
                var ee = kt.extend({
                        dataElementType: Ut.Rectangle,
                        _dataElementOptions: ["backgroundColor", "borderColor", "borderSkipped", "borderWidth", "barPercentage", "barThickness", "categoryPercentage", "maxBarThickness", "minBarLength"],
                        initialize: function() {
                            var t, e, n = this;
                            kt.prototype.initialize.apply(n, arguments), (t = n.getMeta()).stack = n.getDataset().stack, t.bar = !0, e = n._getIndexScale().options, Zt("bar chart", e.barPercentage, "scales.[x/y]Axes.barPercentage", "dataset.barPercentage"), Zt("bar chart", e.barThickness, "scales.[x/y]Axes.barThickness", "dataset.barThickness"), Zt("bar chart", e.categoryPercentage, "scales.[x/y]Axes.categoryPercentage", "dataset.categoryPercentage"), Zt("bar chart", n._getValueScale().options.minBarLength, "scales.[x/y]Axes.minBarLength", "dataset.minBarLength"), Zt("bar chart", e.maxBarThickness, "scales.[x/y]Axes.maxBarThickness", "dataset.maxBarThickness")
                        },
                        update: function(t) {
                            var e, n, i = this,
                                a = i.getMeta().data;
                            for (i._ruler = i.getRuler(), e = 0, n = a.length; e < n; ++e) i.updateElement(a[e], e, t)
                        },
                        updateElement: function(t, e, n) {
                            var i = this,
                                a = i.getMeta(),
                                r = i.getDataset(),
                                o = i._resolveDataElementOptions(t, e);
                            t._xScale = i.getScaleForId(a.xAxisID), t._yScale = i.getScaleForId(a.yAxisID), t._datasetIndex = i.index, t._index = e, t._model = {
                                backgroundColor: o.backgroundColor,
                                borderColor: o.borderColor,
                                borderSkipped: o.borderSkipped,
                                borderWidth: o.borderWidth,
                                datasetLabel: r.label,
                                label: i.chart.data.labels[e]
                            }, rt.isArray(r.data[e]) && (t._model.borderSkipped = null), i._updateElementGeometry(t, e, n, o), t.pivot()
                        },
                        _updateElementGeometry: function(t, e, n, i) {
                            var a = this,
                                r = t._model,
                                o = a._getValueScale(),
                                l = o.getBasePixel(),
                                s = o.isHorizontal(),
                                u = a._ruler || a.getRuler(),
                                d = a.calculateBarValuePixels(a.index, e, i),
                                c = a.calculateBarIndexPixels(a.index, e, u, i);
                            r.horizontal = s, r.base = n ? l : d.base, r.x = s ? n ? l : d.head : c.center, r.y = s ? c.center : n ? l : d.head, r.height = s ? c.size : void 0, r.width = s ? void 0 : c.size
                        },
                        _getStacks: function(t) {
                            var e, n, i = this,
                                a = i._getIndexScale(),
                                r = a._getMatchingVisibleMetas(i._type),
                                o = a.options.stacked,
                                l = r.length,
                                s = [];
                            for (e = 0; e < l && (n = r[e], (!1 === o || -1 === s.indexOf(n.stack) || void 0 === o && void 0 === n.stack) && s.push(n.stack), n.index !== t); ++e);
                            return s
                        },
                        getStackCount: function() {
                            return this._getStacks().length
                        },
                        getStackIndex: function(t, e) {
                            var n = this._getStacks(t),
                                i = void 0 !== e ? n.indexOf(e) : -1;
                            return -1 === i ? n.length - 1 : i
                        },
                        getRuler: function() {
                            var t, e, n = this,
                                i = n._getIndexScale(),
                                a = [];
                            for (t = 0, e = n.getMeta().data.length; t < e; ++t) a.push(i.getPixelForValue(null, t, n.index));
                            return {
                                pixels: a,
                                start: i._startPixel,
                                end: i._endPixel,
                                stackCount: n.getStackCount(),
                                scale: i
                            }
                        },
                        calculateBarValuePixels: function(t, e, n) {
                            var i, a, r, o, l, s, u, d = this,
                                c = d.chart,
                                h = d._getValueScale(),
                                f = h.isHorizontal(),
                                g = c.data.datasets,
                                p = h._getMatchingVisibleMetas(d._type),
                                m = h._parseValue(g[t].data[e]),
                                v = n.minBarLength,
                                b = h.options.stacked,
                                x = d.getMeta().stack,
                                y = void 0 === m.start ? 0 : m.max >= 0 && m.min >= 0 ? m.min : m.max,
                                _ = void 0 === m.start ? m.end : m.max >= 0 && m.min >= 0 ? m.max - m.min : m.min - m.max,
                                k = p.length;
                            if (b || void 0 === b && void 0 !== x)
                                for (i = 0; i < k && (a = p[i]).index !== t; ++i) a.stack === x && (r = void 0 === (u = h._parseValue(g[a.index].data[e])).start ? u.end : u.min >= 0 && u.max >= 0 ? u.max : u.min, (m.min < 0 && r < 0 || m.max >= 0 && r > 0) && (y += r));
                            return o = h.getPixelForValue(y), s = (l = h.getPixelForValue(y + _)) - o, void 0 !== v && Math.abs(s) < v && (s = v, l = _ >= 0 && !f || _ < 0 && f ? o - v : o + v), {
                                size: s,
                                base: o,
                                head: l,
                                center: l + s / 2
                            }
                        },
                        calculateBarIndexPixels: function(t, e, n, i) {
                            var a = this,
                                r = "flex" === i.barThickness ? te(e, n, i) : Qt(e, n, i),
                                o = a.getStackIndex(t, a.getMeta().stack),
                                l = r.start + r.chunk * o + r.chunk / 2,
                                s = Math.min($t(i.maxBarThickness, 1 / 0), r.chunk * r.ratio);
                            return {
                                base: l - s / 2,
                                head: l + s / 2,
                                center: l,
                                size: s
                            }
                        },
                        draw: function() {
                            var t = this,
                                e = t.chart,
                                n = t._getValueScale(),
                                i = t.getMeta().data,
                                a = t.getDataset(),
                                r = i.length,
                                o = 0;
                            for (rt.canvas.clipArea(e.ctx, e.chartArea); o < r; ++o) {
                                var l = n._parseValue(a.data[o]);
                                isNaN(l.min) || isNaN(l.max) || i[o].draw()
                            }
                            rt.canvas.unclipArea(e.ctx)
                        },
                        _resolveDataElementOptions: function() {
                            var t = this,
                                e = rt.extend({}, kt.prototype._resolveDataElementOptions.apply(t, arguments)),
                                n = t._getIndexScale().options,
                                i = t._getValueScale().options;
                            return e.barPercentage = $t(n.barPercentage, e.barPercentage), e.barThickness = $t(n.barThickness, e.barThickness), e.categoryPercentage = $t(n.categoryPercentage, e.categoryPercentage), e.maxBarThickness = $t(n.maxBarThickness, e.maxBarThickness), e.minBarLength = $t(i.minBarLength, e.minBarLength), e
                        }
                    }),
                    ne = rt.valueOrDefault,
                    ie = rt.options.resolve;
                Z._set("bubble", {
                    hover: {
                        mode: "single"
                    },
                    scales: {
                        xAxes: [{
                            type: "linear",
                            position: "bottom",
                            id: "x-axis-0"
                        }],
                        yAxes: [{
                            type: "linear",
                            position: "left",
                            id: "y-axis-0"
                        }]
                    },
                    tooltips: {
                        callbacks: {
                            title: function() {
                                return ""
                            },
                            label: function(t, e) {
                                var n = e.datasets[t.datasetIndex].label || "",
                                    i = e.datasets[t.datasetIndex].data[t.index];
                                return n + ": (" + t.xLabel + ", " + t.yLabel + ", " + i.r + ")"
                            }
                        }
                    }
                });
                var ae = kt.extend({
                        dataElementType: Ut.Point,
                        _dataElementOptions: ["backgroundColor", "borderColor", "borderWidth", "hoverBackgroundColor", "hoverBorderColor", "hoverBorderWidth", "hoverRadius", "hitRadius", "pointStyle", "rotation"],
                        update: function(t) {
                            var e = this,
                                n = e.getMeta().data;
                            rt.each(n, (function(n, i) {
                                e.updateElement(n, i, t)
                            }))
                        },
                        updateElement: function(t, e, n) {
                            var i = this,
                                a = i.getMeta(),
                                r = t.custom || {},
                                o = i.getScaleForId(a.xAxisID),
                                l = i.getScaleForId(a.yAxisID),
                                s = i._resolveDataElementOptions(t, e),
                                u = i.getDataset().data[e],
                                d = i.index,
                                c = n ? o.getPixelForDecimal(.5) : o.getPixelForValue("object" === typeof u ? u : NaN, e, d),
                                h = n ? l.getBasePixel() : l.getPixelForValue(u, e, d);
                            t._xScale = o, t._yScale = l, t._options = s, t._datasetIndex = d, t._index = e, t._model = {
                                backgroundColor: s.backgroundColor,
                                borderColor: s.borderColor,
                                borderWidth: s.borderWidth,
                                hitRadius: s.hitRadius,
                                pointStyle: s.pointStyle,
                                rotation: s.rotation,
                                radius: n ? 0 : s.radius,
                                skip: r.skip || isNaN(c) || isNaN(h),
                                x: c,
                                y: h
                            }, t.pivot()
                        },
                        setHoverStyle: function(t) {
                            var e = t._model,
                                n = t._options,
                                i = rt.getHoverColor;
                            t.$previousStyle = {
                                backgroundColor: e.backgroundColor,
                                borderColor: e.borderColor,
                                borderWidth: e.borderWidth,
                                radius: e.radius
                            }, e.backgroundColor = ne(n.hoverBackgroundColor, i(n.backgroundColor)), e.borderColor = ne(n.hoverBorderColor, i(n.borderColor)), e.borderWidth = ne(n.hoverBorderWidth, n.borderWidth), e.radius = n.radius + n.hoverRadius
                        },
                        _resolveDataElementOptions: function(t, e) {
                            var n = this,
                                i = n.chart,
                                a = n.getDataset(),
                                r = t.custom || {},
                                o = a.data[e] || {},
                                l = kt.prototype._resolveDataElementOptions.apply(n, arguments),
                                s = {
                                    chart: i,
                                    dataIndex: e,
                                    dataset: a,
                                    datasetIndex: n.index
                                };
                            return n._cachedDataOpts === l && (l = rt.extend({}, l)), l.radius = ie([r.radius, o.r, n._config.radius, i.options.elements.point.radius], s, e), l
                        }
                    }),
                    re = rt.valueOrDefault,
                    oe = Math.PI,
                    le = 2 * oe,
                    se = oe / 2;
                Z._set("doughnut", {
                    animation: {
                        animateRotate: !0,
                        animateScale: !1
                    },
                    hover: {
                        mode: "single"
                    },
                    legendCallback: function(t) {
                        var e, n, i, a = document.createElement("ul"),
                            r = t.data,
                            o = r.datasets,
                            l = r.labels;
                        if (a.setAttribute("class", t.id + "-legend"), o.length)
                            for (e = 0, n = o[0].data.length; e < n; ++e)(i = a.appendChild(document.createElement("li"))).appendChild(document.createElement("span")).style.backgroundColor = o[0].backgroundColor[e], l[e] && i.appendChild(document.createTextNode(l[e]));
                        return a.outerHTML
                    },
                    legend: {
                        labels: {
                            generateLabels: function(t) {
                                var e = t.data;
                                return e.labels.length && e.datasets.length ? e.labels.map((function(n, i) {
                                    var a = t.getDatasetMeta(0),
                                        r = a.controller.getStyle(i);
                                    return {
                                        text: n,
                                        fillStyle: r.backgroundColor,
                                        strokeStyle: r.borderColor,
                                        lineWidth: r.borderWidth,
                                        hidden: isNaN(e.datasets[0].data[i]) || a.data[i].hidden,
                                        index: i
                                    }
                                })) : []
                            }
                        },
                        onClick: function(t, e) {
                            var n, i, a, r = e.index,
                                o = this.chart;
                            for (n = 0, i = (o.data.datasets || []).length; n < i; ++n)(a = o.getDatasetMeta(n)).data[r] && (a.data[r].hidden = !a.data[r].hidden);
                            o.update()
                        }
                    },
                    cutoutPercentage: 50,
                    rotation: -se,
                    circumference: le,
                    tooltips: {
                        callbacks: {
                            title: function() {
                                return ""
                            },
                            label: function(t, e) {
                                var n = e.labels[t.index],
                                    i = ": " + e.datasets[t.datasetIndex].data[t.index];
                                return rt.isArray(n) ? (n = n.slice())[0] += i : n += i, n
                            }
                        }
                    }
                });
                var ue = kt.extend({
                    dataElementType: Ut.Arc,
                    linkScales: rt.noop,
                    _dataElementOptions: ["backgroundColor", "borderColor", "borderWidth", "borderAlign", "hoverBackgroundColor", "hoverBorderColor", "hoverBorderWidth"],
                    getRingIndex: function(t) {
                        for (var e = 0, n = 0; n < t; ++n) this.chart.isDatasetVisible(n) && ++e;
                        return e
                    },
                    update: function(t) {
                        var e, n, i, a, r = this,
                            o = r.chart,
                            l = o.chartArea,
                            s = o.options,
                            u = 1,
                            d = 1,
                            c = 0,
                            h = 0,
                            f = r.getMeta(),
                            g = f.data,
                            p = s.cutoutPercentage / 100 || 0,
                            m = s.circumference,
                            v = r._getRingWeight(r.index);
                        if (m < le) {
                            var b = s.rotation % le,
                                x = (b += b >= oe ? -le : b < -oe ? le : 0) + m,
                                y = Math.cos(b),
                                _ = Math.sin(b),
                                k = Math.cos(x),
                                w = Math.sin(x),
                                M = b <= 0 && x >= 0 || x >= le,
                                S = b <= se && x >= se || x >= le + se,
                                C = b <= -se && x >= -se || x >= oe + se,
                                P = b === -oe || x >= oe ? -1 : Math.min(y, y * p, k, k * p),
                                A = C ? -1 : Math.min(_, _ * p, w, w * p),
                                D = M ? 1 : Math.max(y, y * p, k, k * p),
                                T = S ? 1 : Math.max(_, _ * p, w, w * p);
                            u = (D - P) / 2, d = (T - A) / 2, c = -(D + P) / 2, h = -(T + A) / 2
                        }
                        for (i = 0, a = g.length; i < a; ++i) g[i]._options = r._resolveDataElementOptions(g[i], i);
                        for (o.borderWidth = r.getMaxBorderWidth(), e = (l.right - l.left - o.borderWidth) / u, n = (l.bottom - l.top - o.borderWidth) / d, o.outerRadius = Math.max(Math.min(e, n) / 2, 0), o.innerRadius = Math.max(o.outerRadius * p, 0), o.radiusLength = (o.outerRadius - o.innerRadius) / (r._getVisibleDatasetWeightTotal() || 1), o.offsetX = c * o.outerRadius, o.offsetY = h * o.outerRadius, f.total = r.calculateTotal(), r.outerRadius = o.outerRadius - o.radiusLength * r._getRingWeightOffset(r.index), r.innerRadius = Math.max(r.outerRadius - o.radiusLength * v, 0), i = 0, a = g.length; i < a; ++i) r.updateElement(g[i], i, t)
                    },
                    updateElement: function(t, e, n) {
                        var i = this,
                            a = i.chart,
                            r = a.chartArea,
                            o = a.options,
                            l = o.animation,
                            s = (r.left + r.right) / 2,
                            u = (r.top + r.bottom) / 2,
                            d = o.rotation,
                            c = o.rotation,
                            h = i.getDataset(),
                            f = n && l.animateRotate || t.hidden ? 0 : i.calculateCircumference(h.data[e]) * (o.circumference / le),
                            g = n && l.animateScale ? 0 : i.innerRadius,
                            p = n && l.animateScale ? 0 : i.outerRadius,
                            m = t._options || {};
                        rt.extend(t, {
                            _datasetIndex: i.index,
                            _index: e,
                            _model: {
                                backgroundColor: m.backgroundColor,
                                borderColor: m.borderColor,
                                borderWidth: m.borderWidth,
                                borderAlign: m.borderAlign,
                                x: s + a.offsetX,
                                y: u + a.offsetY,
                                startAngle: d,
                                endAngle: c,
                                circumference: f,
                                outerRadius: p,
                                innerRadius: g,
                                label: rt.valueAtIndexOrDefault(h.label, e, a.data.labels[e])
                            }
                        });
                        var v = t._model;
                        n && l.animateRotate || (v.startAngle = 0 === e ? o.rotation : i.getMeta().data[e - 1]._model.endAngle, v.endAngle = v.startAngle + v.circumference), t.pivot()
                    },
                    calculateTotal: function() {
                        var t, e = this.getDataset(),
                            n = this.getMeta(),
                            i = 0;
                        return rt.each(n.data, (function(n, a) {
                            t = e.data[a], isNaN(t) || n.hidden || (i += Math.abs(t))
                        })), i
                    },
                    calculateCircumference: function(t) {
                        var e = this.getMeta().total;
                        return e > 0 && !isNaN(t) ? le * (Math.abs(t) / e) : 0
                    },
                    getMaxBorderWidth: function(t) {
                        var e, n, i, a, r, o, l, s, u = this,
                            d = 0,
                            c = u.chart;
                        if (!t)
                            for (e = 0, n = c.data.datasets.length; e < n; ++e)
                                if (c.isDatasetVisible(e)) {
                                    t = (i = c.getDatasetMeta(e)).data, e !== u.index && (r = i.controller);
                                    break
                                }
                        if (!t) return 0;
                        for (e = 0, n = t.length; e < n; ++e) a = t[e], r ? (r._configure(), o = r._resolveDataElementOptions(a, e)) : o = a._options, "inner" !== o.borderAlign && (l = o.borderWidth, d = (s = o.hoverBorderWidth) > (d = l > d ? l : d) ? s : d);
                        return d
                    },
                    setHoverStyle: function(t) {
                        var e = t._model,
                            n = t._options,
                            i = rt.getHoverColor;
                        t.$previousStyle = {
                            backgroundColor: e.backgroundColor,
                            borderColor: e.borderColor,
                            borderWidth: e.borderWidth
                        }, e.backgroundColor = re(n.hoverBackgroundColor, i(n.backgroundColor)), e.borderColor = re(n.hoverBorderColor, i(n.borderColor)), e.borderWidth = re(n.hoverBorderWidth, n.borderWidth)
                    },
                    _getRingWeightOffset: function(t) {
                        for (var e = 0, n = 0; n < t; ++n) this.chart.isDatasetVisible(n) && (e += this._getRingWeight(n));
                        return e
                    },
                    _getRingWeight: function(t) {
                        return Math.max(re(this.chart.data.datasets[t].weight, 1), 0)
                    },
                    _getVisibleDatasetWeightTotal: function() {
                        return this._getRingWeightOffset(this.chart.data.datasets.length)
                    }
                });
                Z._set("horizontalBar", {
                    hover: {
                        mode: "index",
                        axis: "y"
                    },
                    scales: {
                        xAxes: [{
                            type: "linear",
                            position: "bottom"
                        }],
                        yAxes: [{
                            type: "category",
                            position: "left",
                            offset: !0,
                            gridLines: {
                                offsetGridLines: !0
                            }
                        }]
                    },
                    elements: {
                        rectangle: {
                            borderSkipped: "left"
                        }
                    },
                    tooltips: {
                        mode: "index",
                        axis: "y"
                    }
                }), Z._set("global", {
                    datasets: {
                        horizontalBar: {
                            categoryPercentage: .8,
                            barPercentage: .9
                        }
                    }
                });
                var de = ee.extend({
                        _getValueScaleId: function() {
                            return this.getMeta().xAxisID
                        },
                        _getIndexScaleId: function() {
                            return this.getMeta().yAxisID
                        }
                    }),
                    ce = rt.valueOrDefault,
                    he = rt.options.resolve,
                    fe = rt.canvas._isPointInArea;

                function ge(t, e) {
                    var n = t && t.options.ticks || {},
                        i = n.reverse,
                        a = void 0 === n.min ? e : 0,
                        r = void 0 === n.max ? e : 0;
                    return {
                        start: i ? r : a,
                        end: i ? a : r
                    }
                }

                function pe(t, e, n) {
                    var i = n / 2,
                        a = ge(t, i),
                        r = ge(e, i);
                    return {
                        top: r.end,
                        right: a.end,
                        bottom: r.start,
                        left: a.start
                    }
                }

                function me(t) {
                    var e, n, i, a;
                    return rt.isObject(t) ? (e = t.top, n = t.right, i = t.bottom, a = t.left) : e = n = i = a = t, {
                        top: e,
                        right: n,
                        bottom: i,
                        left: a
                    }
                }
                Z._set("line", {
                    showLines: !0,
                    spanGaps: !1,
                    hover: {
                        mode: "label"
                    },
                    scales: {
                        xAxes: [{
                            type: "category",
                            id: "x-axis-0"
                        }],
                        yAxes: [{
                            type: "linear",
                            id: "y-axis-0"
                        }]
                    }
                });
                var ve = kt.extend({
                        datasetElementType: Ut.Line,
                        dataElementType: Ut.Point,
                        _datasetElementOptions: ["backgroundColor", "borderCapStyle", "borderColor", "borderDash", "borderDashOffset", "borderJoinStyle", "borderWidth", "cubicInterpolationMode", "fill"],
                        _dataElementOptions: {
                            backgroundColor: "pointBackgroundColor",
                            borderColor: "pointBorderColor",
                            borderWidth: "pointBorderWidth",
                            hitRadius: "pointHitRadius",
                            hoverBackgroundColor: "pointHoverBackgroundColor",
                            hoverBorderColor: "pointHoverBorderColor",
                            hoverBorderWidth: "pointHoverBorderWidth",
                            hoverRadius: "pointHoverRadius",
                            pointStyle: "pointStyle",
                            radius: "pointRadius",
                            rotation: "pointRotation"
                        },
                        update: function(t) {
                            var e, n, i = this,
                                a = i.getMeta(),
                                r = a.dataset,
                                o = a.data || [],
                                l = i.chart.options,
                                s = i._config,
                                u = i._showLine = ce(s.showLine, l.showLines);
                            for (i._xScale = i.getScaleForId(a.xAxisID), i._yScale = i.getScaleForId(a.yAxisID), u && (void 0 !== s.tension && void 0 === s.lineTension && (s.lineTension = s.tension), r._scale = i._yScale, r._datasetIndex = i.index, r._children = o, r._model = i._resolveDatasetElementOptions(r), r.pivot()), e = 0, n = o.length; e < n; ++e) i.updateElement(o[e], e, t);
                            for (u && 0 !== r._model.tension && i.updateBezierControlPoints(), e = 0, n = o.length; e < n; ++e) o[e].pivot()
                        },
                        updateElement: function(t, e, n) {
                            var i, a, r = this,
                                o = r.getMeta(),
                                l = t.custom || {},
                                s = r.getDataset(),
                                u = r.index,
                                d = s.data[e],
                                c = r._xScale,
                                h = r._yScale,
                                f = o.dataset._model,
                                g = r._resolveDataElementOptions(t, e);
                            i = c.getPixelForValue("object" === typeof d ? d : NaN, e, u), a = n ? h.getBasePixel() : r.calculatePointY(d, e, u), t._xScale = c, t._yScale = h, t._options = g, t._datasetIndex = u, t._index = e, t._model = {
                                x: i,
                                y: a,
                                skip: l.skip || isNaN(i) || isNaN(a),
                                radius: g.radius,
                                pointStyle: g.pointStyle,
                                rotation: g.rotation,
                                backgroundColor: g.backgroundColor,
                                borderColor: g.borderColor,
                                borderWidth: g.borderWidth,
                                tension: ce(l.tension, f ? f.tension : 0),
                                steppedLine: !!f && f.steppedLine,
                                hitRadius: g.hitRadius
                            }
                        },
                        _resolveDatasetElementOptions: function(t) {
                            var e = this,
                                n = e._config,
                                i = t.custom || {},
                                a = e.chart.options,
                                r = a.elements.line,
                                o = kt.prototype._resolveDatasetElementOptions.apply(e, arguments);
                            return o.spanGaps = ce(n.spanGaps, a.spanGaps), o.tension = ce(n.lineTension, r.tension), o.steppedLine = he([i.steppedLine, n.steppedLine, r.stepped]), o.clip = me(ce(n.clip, pe(e._xScale, e._yScale, o.borderWidth))), o
                        },
                        calculatePointY: function(t, e, n) {
                            var i, a, r, o, l, s, u, d = this,
                                c = d.chart,
                                h = d._yScale,
                                f = 0,
                                g = 0;
                            if (h.options.stacked) {
                                for (l = +h.getRightValue(t), u = (s = c._getSortedVisibleDatasetMetas()).length, i = 0; i < u && (r = s[i]).index !== n; ++i) a = c.data.datasets[r.index], "line" === r.type && r.yAxisID === h.id && ((o = +h.getRightValue(a.data[e])) < 0 ? g += o || 0 : f += o || 0);
                                return l < 0 ? h.getPixelForValue(g + l) : h.getPixelForValue(f + l)
                            }
                            return h.getPixelForValue(t)
                        },
                        updateBezierControlPoints: function() {
                            var t, e, n, i, a = this,
                                r = a.chart,
                                o = a.getMeta(),
                                l = o.dataset._model,
                                s = r.chartArea,
                                u = o.data || [];

                            function d(t, e, n) {
                                return Math.max(Math.min(t, n), e)
                            }
                            if (l.spanGaps && (u = u.filter((function(t) {
                                    return !t._model.skip
                                }))), "monotone" === l.cubicInterpolationMode) rt.splineCurveMonotone(u);
                            else
                                for (t = 0, e = u.length; t < e; ++t) n = u[t]._model, i = rt.splineCurve(rt.previousItem(u, t)._model, n, rt.nextItem(u, t)._model, l.tension), n.controlPointPreviousX = i.previous.x, n.controlPointPreviousY = i.previous.y, n.controlPointNextX = i.next.x, n.controlPointNextY = i.next.y;
                            if (r.options.elements.line.capBezierPoints)
                                for (t = 0, e = u.length; t < e; ++t) n = u[t]._model, fe(n, s) && (t > 0 && fe(u[t - 1]._model, s) && (n.controlPointPreviousX = d(n.controlPointPreviousX, s.left, s.right), n.controlPointPreviousY = d(n.controlPointPreviousY, s.top, s.bottom)), t < u.length - 1 && fe(u[t + 1]._model, s) && (n.controlPointNextX = d(n.controlPointNextX, s.left, s.right), n.controlPointNextY = d(n.controlPointNextY, s.top, s.bottom)))
                        },
                        draw: function() {
                            var t, e = this,
                                n = e.chart,
                                i = e.getMeta(),
                                a = i.data || [],
                                r = n.chartArea,
                                o = n.canvas,
                                l = 0,
                                s = a.length;
                            for (e._showLine && (t = i.dataset._model.clip, rt.canvas.clipArea(n.ctx, {
                                    left: !1 === t.left ? 0 : r.left - t.left,
                                    right: !1 === t.right ? o.width : r.right + t.right,
                                    top: !1 === t.top ? 0 : r.top - t.top,
                                    bottom: !1 === t.bottom ? o.height : r.bottom + t.bottom
                                }), i.dataset.draw(), rt.canvas.unclipArea(n.ctx)); l < s; ++l) a[l].draw(r)
                        },
                        setHoverStyle: function(t) {
                            var e = t._model,
                                n = t._options,
                                i = rt.getHoverColor;
                            t.$previousStyle = {
                                backgroundColor: e.backgroundColor,
                                borderColor: e.borderColor,
                                borderWidth: e.borderWidth,
                                radius: e.radius
                            }, e.backgroundColor = ce(n.hoverBackgroundColor, i(n.backgroundColor)), e.borderColor = ce(n.hoverBorderColor, i(n.borderColor)), e.borderWidth = ce(n.hoverBorderWidth, n.borderWidth), e.radius = ce(n.hoverRadius, n.radius)
                        }
                    }),
                    be = rt.options.resolve;
                Z._set("polarArea", {
                    scale: {
                        type: "radialLinear",
                        angleLines: {
                            display: !1
                        },
                        gridLines: {
                            circular: !0
                        },
                        pointLabels: {
                            display: !1
                        },
                        ticks: {
                            beginAtZero: !0
                        }
                    },
                    animation: {
                        animateRotate: !0,
                        animateScale: !0
                    },
                    startAngle: -.5 * Math.PI,
                    legendCallback: function(t) {
                        var e, n, i, a = document.createElement("ul"),
                            r = t.data,
                            o = r.datasets,
                            l = r.labels;
                        if (a.setAttribute("class", t.id + "-legend"), o.length)
                            for (e = 0, n = o[0].data.length; e < n; ++e)(i = a.appendChild(document.createElement("li"))).appendChild(document.createElement("span")).style.backgroundColor = o[0].backgroundColor[e], l[e] && i.appendChild(document.createTextNode(l[e]));
                        return a.outerHTML
                    },
                    legend: {
                        labels: {
                            generateLabels: function(t) {
                                var e = t.data;
                                return e.labels.length && e.datasets.length ? e.labels.map((function(n, i) {
                                    var a = t.getDatasetMeta(0),
                                        r = a.controller.getStyle(i);
                                    return {
                                        text: n,
                                        fillStyle: r.backgroundColor,
                                        strokeStyle: r.borderColor,
                                        lineWidth: r.borderWidth,
                                        hidden: isNaN(e.datasets[0].data[i]) || a.data[i].hidden,
                                        index: i
                                    }
                                })) : []
                            }
                        },
                        onClick: function(t, e) {
                            var n, i, a, r = e.index,
                                o = this.chart;
                            for (n = 0, i = (o.data.datasets || []).length; n < i; ++n)(a = o.getDatasetMeta(n)).data[r].hidden = !a.data[r].hidden;
                            o.update()
                        }
                    },
                    tooltips: {
                        callbacks: {
                            title: function() {
                                return ""
                            },
                            label: function(t, e) {
                                return e.labels[t.index] + ": " + t.yLabel
                            }
                        }
                    }
                });
                var xe = kt.extend({
                    dataElementType: Ut.Arc,
                    linkScales: rt.noop,
                    _dataElementOptions: ["backgroundColor", "borderColor", "borderWidth", "borderAlign", "hoverBackgroundColor", "hoverBorderColor", "hoverBorderWidth"],
                    _getIndexScaleId: function() {
                        return this.chart.scale.id
                    },
                    _getValueScaleId: function() {
                        return this.chart.scale.id
                    },
                    update: function(t) {
                        var e, n, i, a = this,
                            r = a.getDataset(),
                            o = a.getMeta(),
                            l = a.chart.options.startAngle || 0,
                            s = a._starts = [],
                            u = a._angles = [],
                            d = o.data;
                        for (a._updateRadius(), o.count = a.countVisibleElements(), e = 0, n = r.data.length; e < n; e++) s[e] = l, i = a._computeAngle(e), u[e] = i, l += i;
                        for (e = 0, n = d.length; e < n; ++e) d[e]._options = a._resolveDataElementOptions(d[e], e), a.updateElement(d[e], e, t)
                    },
                    _updateRadius: function() {
                        var t = this,
                            e = t.chart,
                            n = e.chartArea,
                            i = e.options,
                            a = Math.min(n.right - n.left, n.bottom - n.top);
                        e.outerRadius = Math.max(a / 2, 0), e.innerRadius = Math.max(i.cutoutPercentage ? e.outerRadius / 100 * i.cutoutPercentage : 1, 0), e.radiusLength = (e.outerRadius - e.innerRadius) / e.getVisibleDatasetCount(), t.outerRadius = e.outerRadius - e.radiusLength * t.index, t.innerRadius = t.outerRadius - e.radiusLength
                    },
                    updateElement: function(t, e, n) {
                        var i = this,
                            a = i.chart,
                            r = i.getDataset(),
                            o = a.options,
                            l = o.animation,
                            s = a.scale,
                            u = a.data.labels,
                            d = s.xCenter,
                            c = s.yCenter,
                            h = o.startAngle,
                            f = t.hidden ? 0 : s.getDistanceFromCenterForValue(r.data[e]),
                            g = i._starts[e],
                            p = g + (t.hidden ? 0 : i._angles[e]),
                            m = l.animateScale ? 0 : s.getDistanceFromCenterForValue(r.data[e]),
                            v = t._options || {};
                        rt.extend(t, {
                            _datasetIndex: i.index,
                            _index: e,
                            _scale: s,
                            _model: {
                                backgroundColor: v.backgroundColor,
                                borderColor: v.borderColor,
                                borderWidth: v.borderWidth,
                                borderAlign: v.borderAlign,
                                x: d,
                                y: c,
                                innerRadius: 0,
                                outerRadius: n ? m : f,
                                startAngle: n && l.animateRotate ? h : g,
                                endAngle: n && l.animateRotate ? h : p,
                                label: rt.valueAtIndexOrDefault(u, e, u[e])
                            }
                        }), t.pivot()
                    },
                    countVisibleElements: function() {
                        var t = this.getDataset(),
                            e = this.getMeta(),
                            n = 0;
                        return rt.each(e.data, (function(e, i) {
                            isNaN(t.data[i]) || e.hidden || n++
                        })), n
                    },
                    setHoverStyle: function(t) {
                        var e = t._model,
                            n = t._options,
                            i = rt.getHoverColor,
                            a = rt.valueOrDefault;
                        t.$previousStyle = {
                            backgroundColor: e.backgroundColor,
                            borderColor: e.borderColor,
                            borderWidth: e.borderWidth
                        }, e.backgroundColor = a(n.hoverBackgroundColor, i(n.backgroundColor)), e.borderColor = a(n.hoverBorderColor, i(n.borderColor)), e.borderWidth = a(n.hoverBorderWidth, n.borderWidth)
                    },
                    _computeAngle: function(t) {
                        var e = this,
                            n = this.getMeta().count,
                            i = e.getDataset(),
                            a = e.getMeta();
                        if (isNaN(i.data[t]) || a.data[t].hidden) return 0;
                        var r = {
                            chart: e.chart,
                            dataIndex: t,
                            dataset: i,
                            datasetIndex: e.index
                        };
                        return be([e.chart.options.elements.arc.angle, 2 * Math.PI / n], r, t)
                    }
                });
                Z._set("pie", rt.clone(Z.doughnut)), Z._set("pie", {
                    cutoutPercentage: 0
                });
                var ye = ue,
                    _e = rt.valueOrDefault;
                Z._set("radar", {
                    spanGaps: !1,
                    scale: {
                        type: "radialLinear"
                    },
                    elements: {
                        line: {
                            fill: "start",
                            tension: 0
                        }
                    }
                });
                var ke = kt.extend({
                    datasetElementType: Ut.Line,
                    dataElementType: Ut.Point,
                    linkScales: rt.noop,
                    _datasetElementOptions: ["backgroundColor", "borderWidth", "borderColor", "borderCapStyle", "borderDash", "borderDashOffset", "borderJoinStyle", "fill"],
                    _dataElementOptions: {
                        backgroundColor: "pointBackgroundColor",
                        borderColor: "pointBorderColor",
                        borderWidth: "pointBorderWidth",
                        hitRadius: "pointHitRadius",
                        hoverBackgroundColor: "pointHoverBackgroundColor",
                        hoverBorderColor: "pointHoverBorderColor",
                        hoverBorderWidth: "pointHoverBorderWidth",
                        hoverRadius: "pointHoverRadius",
                        pointStyle: "pointStyle",
                        radius: "pointRadius",
                        rotation: "pointRotation"
                    },
                    _getIndexScaleId: function() {
                        return this.chart.scale.id
                    },
                    _getValueScaleId: function() {
                        return this.chart.scale.id
                    },
                    update: function(t) {
                        var e, n, i = this,
                            a = i.getMeta(),
                            r = a.dataset,
                            o = a.data || [],
                            l = i.chart.scale,
                            s = i._config;
                        for (void 0 !== s.tension && void 0 === s.lineTension && (s.lineTension = s.tension), r._scale = l, r._datasetIndex = i.index, r._children = o, r._loop = !0, r._model = i._resolveDatasetElementOptions(r), r.pivot(), e = 0, n = o.length; e < n; ++e) i.updateElement(o[e], e, t);
                        for (i.updateBezierControlPoints(), e = 0, n = o.length; e < n; ++e) o[e].pivot()
                    },
                    updateElement: function(t, e, n) {
                        var i = this,
                            a = t.custom || {},
                            r = i.getDataset(),
                            o = i.chart.scale,
                            l = o.getPointPositionForValue(e, r.data[e]),
                            s = i._resolveDataElementOptions(t, e),
                            u = i.getMeta().dataset._model,
                            d = n ? o.xCenter : l.x,
                            c = n ? o.yCenter : l.y;
                        t._scale = o, t._options = s, t._datasetIndex = i.index, t._index = e, t._model = {
                            x: d,
                            y: c,
                            skip: a.skip || isNaN(d) || isNaN(c),
                            radius: s.radius,
                            pointStyle: s.pointStyle,
                            rotation: s.rotation,
                            backgroundColor: s.backgroundColor,
                            borderColor: s.borderColor,
                            borderWidth: s.borderWidth,
                            tension: _e(a.tension, u ? u.tension : 0),
                            hitRadius: s.hitRadius
                        }
                    },
                    _resolveDatasetElementOptions: function() {
                        var t = this,
                            e = t._config,
                            n = t.chart.options,
                            i = kt.prototype._resolveDatasetElementOptions.apply(t, arguments);
                        return i.spanGaps = _e(e.spanGaps, n.spanGaps), i.tension = _e(e.lineTension, n.elements.line.tension), i
                    },
                    updateBezierControlPoints: function() {
                        var t, e, n, i, a = this,
                            r = a.getMeta(),
                            o = a.chart.chartArea,
                            l = r.data || [];

                        function s(t, e, n) {
                            return Math.max(Math.min(t, n), e)
                        }
                        for (r.dataset._model.spanGaps && (l = l.filter((function(t) {
                                return !t._model.skip
                            }))), t = 0, e = l.length; t < e; ++t) n = l[t]._model, i = rt.splineCurve(rt.previousItem(l, t, !0)._model, n, rt.nextItem(l, t, !0)._model, n.tension), n.controlPointPreviousX = s(i.previous.x, o.left, o.right), n.controlPointPreviousY = s(i.previous.y, o.top, o.bottom), n.controlPointNextX = s(i.next.x, o.left, o.right), n.controlPointNextY = s(i.next.y, o.top, o.bottom)
                    },
                    setHoverStyle: function(t) {
                        var e = t._model,
                            n = t._options,
                            i = rt.getHoverColor;
                        t.$previousStyle = {
                            backgroundColor: e.backgroundColor,
                            borderColor: e.borderColor,
                            borderWidth: e.borderWidth,
                            radius: e.radius
                        }, e.backgroundColor = _e(n.hoverBackgroundColor, i(n.backgroundColor)), e.borderColor = _e(n.hoverBorderColor, i(n.borderColor)), e.borderWidth = _e(n.hoverBorderWidth, n.borderWidth), e.radius = _e(n.hoverRadius, n.radius)
                    }
                });
                Z._set("scatter", {
                    hover: {
                        mode: "single"
                    },
                    scales: {
                        xAxes: [{
                            id: "x-axis-1",
                            type: "linear",
                            position: "bottom"
                        }],
                        yAxes: [{
                            id: "y-axis-1",
                            type: "linear",
                            position: "left"
                        }]
                    },
                    tooltips: {
                        callbacks: {
                            title: function() {
                                return ""
                            },
                            label: function(t) {
                                return "(" + t.xLabel + ", " + t.yLabel + ")"
                            }
                        }
                    }
                }), Z._set("global", {
                    datasets: {
                        scatter: {
                            showLine: !1
                        }
                    }
                });
                var we = {
                    bar: ee,
                    bubble: ae,
                    doughnut: ue,
                    horizontalBar: de,
                    line: ve,
                    polarArea: xe,
                    pie: ye,
                    radar: ke,
                    scatter: ve
                };

                function Me(t, e) {
                    return t.native ? {
                        x: t.x,
                        y: t.y
                    } : rt.getRelativePosition(t, e)
                }

                function Se(t, e) {
                    var n, i, a, r, o, l, s = t._getSortedVisibleDatasetMetas();
                    for (i = 0, r = s.length; i < r; ++i)
                        for (a = 0, o = (n = s[i].data).length; a < o; ++a)(l = n[a])._view.skip || e(l)
                }

                function Ce(t, e) {
                    var n = [];
                    return Se(t, (function(t) {
                        t.inRange(e.x, e.y) && n.push(t)
                    })), n
                }

                function Pe(t, e, n, i) {
                    var a = Number.POSITIVE_INFINITY,
                        r = [];
                    return Se(t, (function(t) {
                        if (!n || t.inRange(e.x, e.y)) {
                            var o = t.getCenterPoint(),
                                l = i(e, o);
                            l < a ? (r = [t], a = l) : l === a && r.push(t)
                        }
                    })), r
                }

                function Ae(t) {
                    var e = -1 !== t.indexOf("x"),
                        n = -1 !== t.indexOf("y");
                    return function(t, i) {
                        var a = e ? Math.abs(t.x - i.x) : 0,
                            r = n ? Math.abs(t.y - i.y) : 0;
                        return Math.sqrt(Math.pow(a, 2) + Math.pow(r, 2))
                    }
                }

                function De(t, e, n) {
                    var i = Me(e, t);
                    n.axis = n.axis || "x";
                    var a = Ae(n.axis),
                        r = n.intersect ? Ce(t, i) : Pe(t, i, !1, a),
                        o = [];
                    return r.length ? (t._getSortedVisibleDatasetMetas().forEach((function(t) {
                        var e = t.data[r[0]._index];
                        e && !e._view.skip && o.push(e)
                    })), o) : []
                }
                var Te = {
                        modes: {
                            single: function(t, e) {
                                var n = Me(e, t),
                                    i = [];
                                return Se(t, (function(t) {
                                    if (t.inRange(n.x, n.y)) return i.push(t), i
                                })), i.slice(0, 1)
                            },
                            label: De,
                            index: De,
                            dataset: function(t, e, n) {
                                var i = Me(e, t);
                                n.axis = n.axis || "xy";
                                var a = Ae(n.axis),
                                    r = n.intersect ? Ce(t, i) : Pe(t, i, !1, a);
                                return r.length > 0 && (r = t.getDatasetMeta(r[0]._datasetIndex).data), r
                            },
                            "x-axis": function(t, e) {
                                return De(t, e, {
                                    intersect: !1
                                })
                            },
                            point: function(t, e) {
                                return Ce(t, Me(e, t))
                            },
                            nearest: function(t, e, n) {
                                var i = Me(e, t);
                                n.axis = n.axis || "xy";
                                var a = Ae(n.axis);
                                return Pe(t, i, n.intersect, a)
                            },
                            x: function(t, e, n) {
                                var i = Me(e, t),
                                    a = [],
                                    r = !1;
                                return Se(t, (function(t) {
                                    t.inXRange(i.x) && a.push(t), t.inRange(i.x, i.y) && (r = !0)
                                })), n.intersect && !r && (a = []), a
                            },
                            y: function(t, e, n) {
                                var i = Me(e, t),
                                    a = [],
                                    r = !1;
                                return Se(t, (function(t) {
                                    t.inYRange(i.y) && a.push(t), t.inRange(i.x, i.y) && (r = !0)
                                })), n.intersect && !r && (a = []), a
                            }
                        }
                    },
                    Ie = rt.extend;

                function Fe(t, e) {
                    return rt.where(t, (function(t) {
                        return t.pos === e
                    }))
                }

                function Oe(t, e) {
                    return t.sort((function(t, n) {
                        var i = e ? n : t,
                            a = e ? t : n;
                        return i.weight === a.weight ? i.index - a.index : i.weight - a.weight
                    }))
                }

                function Le(t) {
                    var e, n, i, a = [];
                    for (e = 0, n = (t || []).length; e < n; ++e) i = t[e], a.push({
                        index: e,
                        box: i,
                        pos: i.position,
                        horizontal: i.isHorizontal(),
                        weight: i.weight
                    });
                    return a
                }

                function Re(t, e) {
                    var n, i, a;
                    for (n = 0, i = t.length; n < i; ++n)(a = t[n]).width = a.horizontal ? a.box.fullWidth && e.availableWidth : e.vBoxMaxWidth, a.height = a.horizontal && e.hBoxMaxHeight
                }

                function ze(t) {
                    var e = Le(t),
                        n = Oe(Fe(e, "left"), !0),
                        i = Oe(Fe(e, "right")),
                        a = Oe(Fe(e, "top"), !0),
                        r = Oe(Fe(e, "bottom"));
                    return {
                        leftAndTop: n.concat(a),
                        rightAndBottom: i.concat(r),
                        chartArea: Fe(e, "chartArea"),
                        vertical: n.concat(i),
                        horizontal: a.concat(r)
                    }
                }

                function Ne(t, e, n, i) {
                    return Math.max(t[n], e[n]) + Math.max(t[i], e[i])
                }

                function Be(t, e, n) {
                    var i, a, r = n.box,
                        o = t.maxPadding;
                    if (n.size && (t[n.pos] -= n.size), n.size = n.horizontal ? r.height : r.width, t[n.pos] += n.size, r.getPadding) {
                        var l = r.getPadding();
                        o.top = Math.max(o.top, l.top), o.left = Math.max(o.left, l.left), o.bottom = Math.max(o.bottom, l.bottom), o.right = Math.max(o.right, l.right)
                    }
                    if (i = e.outerWidth - Ne(o, t, "left", "right"), a = e.outerHeight - Ne(o, t, "top", "bottom"), i !== t.w || a !== t.h) return t.w = i, t.h = a, n.horizontal ? i !== t.w : a !== t.h
                }

                function Ee(t) {
                    var e = t.maxPadding;

                    function n(n) {
                        var i = Math.max(e[n] - t[n], 0);
                        return t[n] += i, i
                    }
                    t.y += n("top"), t.x += n("left"), n("right"), n("bottom")
                }

                function We(t, e) {
                    var n = e.maxPadding;

                    function i(t) {
                        var i = {
                            left: 0,
                            top: 0,
                            right: 0,
                            bottom: 0
                        };
                        return t.forEach((function(t) {
                            i[t] = Math.max(e[t], n[t])
                        })), i
                    }
                    return i(t ? ["left", "right"] : ["top", "bottom"])
                }

                function Ve(t, e, n) {
                    var i, a, r, o, l, s, u = [];
                    for (i = 0, a = t.length; i < a; ++i)(o = (r = t[i]).box).update(r.width || e.w, r.height || e.h, We(r.horizontal, e)), Be(e, n, r) && (s = !0, u.length && (l = !0)), o.fullWidth || u.push(r);
                    return l && Ve(u, e, n) || s
                }

                function He(t, e, n) {
                    var i, a, r, o, l = n.padding,
                        s = e.x,
                        u = e.y;
                    for (i = 0, a = t.length; i < a; ++i) o = (r = t[i]).box, r.horizontal ? (o.left = o.fullWidth ? l.left : e.left, o.right = o.fullWidth ? n.outerWidth - l.right : e.left + e.w, o.top = u, o.bottom = u + o.height, o.width = o.right - o.left, u = o.bottom) : (o.left = s, o.right = s + o.width, o.top = e.top, o.bottom = e.top + e.h, o.height = o.bottom - o.top, s = o.right);
                    e.x = s, e.y = u
                }
                Z._set("global", {
                    layout: {
                        padding: {
                            top: 0,
                            right: 0,
                            bottom: 0,
                            left: 0
                        }
                    }
                });
                var je = {
                        defaults: {},
                        addBox: function(t, e) {
                            t.boxes || (t.boxes = []), e.fullWidth = e.fullWidth || !1, e.position = e.position || "top", e.weight = e.weight || 0, e._layers = e._layers || function() {
                                return [{
                                    z: 0,
                                    draw: function() {
                                        e.draw.apply(e, arguments)
                                    }
                                }]
                            }, t.boxes.push(e)
                        },
                        removeBox: function(t, e) {
                            var n = t.boxes ? t.boxes.indexOf(e) : -1; - 1 !== n && t.boxes.splice(n, 1)
                        },
                        configure: function(t, e, n) {
                            for (var i, a = ["fullWidth", "position", "weight"], r = a.length, o = 0; o < r; ++o) i = a[o], n.hasOwnProperty(i) && (e[i] = n[i])
                        },
                        update: function(t, e, n) {
                            if (t) {
                                var i = t.options.layout || {},
                                    a = rt.options.toPadding(i.padding),
                                    r = e - a.width,
                                    o = n - a.height,
                                    l = ze(t.boxes),
                                    s = l.vertical,
                                    u = l.horizontal,
                                    d = Object.freeze({
                                        outerWidth: e,
                                        outerHeight: n,
                                        padding: a,
                                        availableWidth: r,
                                        vBoxMaxWidth: r / 2 / s.length,
                                        hBoxMaxHeight: o / 2
                                    }),
                                    c = Ie({
                                        maxPadding: Ie({}, a),
                                        w: r,
                                        h: o,
                                        x: a.left,
                                        y: a.top
                                    }, a);
                                Re(s.concat(u), d), Ve(s, c, d), Ve(u, c, d) && Ve(s, c, d), Ee(c), He(l.leftAndTop, c, d), c.x += c.w, c.y += c.h, He(l.rightAndBottom, c, d), t.chartArea = {
                                    left: c.left,
                                    top: c.top,
                                    right: c.left + c.w,
                                    bottom: c.top + c.h
                                }, rt.each(l.chartArea, (function(e) {
                                    var n = e.box;
                                    Ie(n, t.chartArea), n.update(c.w, c.h)
                                }))
                            }
                        }
                    },
                    qe = {
                        acquireContext: function(t) {
                            return t && t.canvas && (t = t.canvas), t && t.getContext("2d") || null
                        }
                    },
                    Ue = "/*\n * DOM element rendering detection\n * https://davidwalsh.name/detect-node-insertion\n */\n@keyframes chartjs-render-animation {\n\tfrom { opacity: 0.99; }\n\tto { opacity: 1; }\n}\n\n.chartjs-render-monitor {\n\tanimation: chartjs-render-animation 0.001s;\n}\n\n/*\n * DOM element resizing detection\n * https://github.com/marcj/css-element-queries\n */\n.chartjs-size-monitor,\n.chartjs-size-monitor-expand,\n.chartjs-size-monitor-shrink {\n\tposition: absolute;\n\tdirection: ltr;\n\tleft: 0;\n\ttop: 0;\n\tright: 0;\n\tbottom: 0;\n\toverflow: hidden;\n\tpointer-events: none;\n\tvisibility: hidden;\n\tz-index: -1;\n}\n\n.chartjs-size-monitor-expand > div {\n\tposition: absolute;\n\twidth: 1000000px;\n\theight: 1000000px;\n\tleft: 0;\n\ttop: 0;\n}\n\n.chartjs-size-monitor-shrink > div {\n\tposition: absolute;\n\twidth: 200%;\n\theight: 200%;\n\tleft: 0;\n\ttop: 0;\n}\n",
                    Ye = n(Object.freeze({
                        __proto__: null,
                        default: Ue
                    })),
                    Ge = "$chartjs",
                    Xe = "chartjs-",
                    Ke = Xe + "size-monitor",
                    Ze = Xe + "render-monitor",
                    $e = Xe + "render-animation",
                    Je = ["animationstart", "webkitAnimationStart"],
                    Qe = {
                        touchstart: "mousedown",
                        touchmove: "mousemove",
                        touchend: "mouseup",
                        pointerenter: "mouseenter",
                        pointerdown: "mousedown",
                        pointermove: "mousemove",
                        pointerup: "mouseup",
                        pointerleave: "mouseout",
                        pointerout: "mouseout"
                    };

                function tn(t, e) {
                    var n = rt.getStyle(t, e),
                        i = n && n.match(/^(\d+)(\.\d+)?px$/);
                    return i ? Number(i[1]) : void 0
                }

                function en(t, e) {
                    var n = t.style,
                        i = t.getAttribute("height"),
                        a = t.getAttribute("width");
                    if (t[Ge] = {
                            initial: {
                                height: i,
                                width: a,
                                style: {
                                    display: n.display,
                                    height: n.height,
                                    width: n.width
                                }
                            }
                        }, n.display = n.display || "block", null === a || "" === a) {
                        var r = tn(t, "width");
                        void 0 !== r && (t.width = r)
                    }
                    if (null === i || "" === i)
                        if ("" === t.style.height) t.height = t.width / (e.options.aspectRatio || 2);
                        else {
                            var o = tn(t, "height");
                            void 0 !== r && (t.height = o)
                        }
                    return t
                }
                var nn = function() {
                        var t = !1;
                        try {
                            var e = Object.defineProperty({}, "passive", {
                                get: function() {
                                    t = !0
                                }
                            });
                            window.addEventListener("e", null, e)
                        } catch (n) {}
                        return t
                    }(),
                    an = !!nn && {
                        passive: !0
                    };

                function rn(t, e, n) {
                    t.addEventListener(e, n, an)
                }

                function on(t, e, n) {
                    t.removeEventListener(e, n, an)
                }

                function ln(t, e, n, i, a) {
                    return {
                        type: t,
                        chart: e,
                        native: a || null,
                        x: void 0 !== n ? n : null,
                        y: void 0 !== i ? i : null
                    }
                }

                function sn(t, e) {
                    var n = Qe[t.type] || t.type,
                        i = rt.getRelativePosition(t, e);
                    return ln(n, e, i.x, i.y, t)
                }

                function un(t, e) {
                    var n = !1,
                        i = [];
                    return function() {
                        i = Array.prototype.slice.call(arguments), e = e || this, n || (n = !0, rt.requestAnimFrame.call(window, (function() {
                            n = !1, t.apply(e, i)
                        })))
                    }
                }

                function dn(t) {
                    var e = document.createElement("div");
                    return e.className = t || "", e
                }

                function cn(t) {
                    var e = 1e6,
                        n = dn(Ke),
                        i = dn(Ke + "-expand"),
                        a = dn(Ke + "-shrink");
                    i.appendChild(dn()), a.appendChild(dn()), n.appendChild(i), n.appendChild(a), n._reset = function() {
                        i.scrollLeft = e, i.scrollTop = e, a.scrollLeft = e, a.scrollTop = e
                    };
                    var r = function() {
                        n._reset(), t()
                    };
                    return rn(i, "scroll", r.bind(i, "expand")), rn(a, "scroll", r.bind(a, "shrink")), n
                }

                function hn(t, e) {
                    var n = t[Ge] || (t[Ge] = {}),
                        i = n.renderProxy = function(t) {
                            t.animationName === $e && e()
                        };
                    rt.each(Je, (function(e) {
                        rn(t, e, i)
                    })), n.reflow = !!t.offsetParent, t.classList.add(Ze)
                }

                function fn(t) {
                    var e = t[Ge] || {},
                        n = e.renderProxy;
                    n && (rt.each(Je, (function(e) {
                        on(t, e, n)
                    })), delete e.renderProxy), t.classList.remove(Ze)
                }

                function gn(t, e, n) {
                    var i = t[Ge] || (t[Ge] = {}),
                        a = i.resizer = cn(un((function() {
                            if (i.resizer) {
                                var a = n.options.maintainAspectRatio && t.parentNode,
                                    r = a ? a.clientWidth : 0;
                                e(ln("resize", n)), a && a.clientWidth < r && n.canvas && e(ln("resize", n))
                            }
                        })));
                    hn(t, (function() {
                        if (i.resizer) {
                            var e = t.parentNode;
                            e && e !== a.parentNode && e.insertBefore(a, e.firstChild), a._reset()
                        }
                    }))
                }

                function pn(t) {
                    var e = t[Ge] || {},
                        n = e.resizer;
                    delete e.resizer, fn(t), n && n.parentNode && n.parentNode.removeChild(n)
                }

                function mn(t, e) {
                    var n = t[Ge] || (t[Ge] = {});
                    if (!n.containsStyles) {
                        n.containsStyles = !0, e = "/* Chart.js */\n" + e;
                        var i = document.createElement("style");
                        i.setAttribute("type", "text/css"), i.appendChild(document.createTextNode(e)), t.appendChild(i)
                    }
                }
                var vn = {
                    disableCSSInjection: !1,
                    _enabled: "undefined" !== typeof document,
                    _ensureLoaded: function(t) {
                        if (!this.disableCSSInjection) {
                            var e = t.getRootNode ? t.getRootNode() : document;
                            mn(e.host ? e : document.head, Ye)
                        }
                    },
                    acquireContext: function(t, e) {
                        "string" === typeof t ? t = document.getElementById(t) : t.length && (t = t[0]), t && t.canvas && (t = t.canvas);
                        var n = t && t.getContext && t.getContext("2d");
                        return n && n.canvas === t ? (this._ensureLoaded(t), en(t, e), n) : null
                    },
                    releaseContext: function(t) {
                        var e = t.canvas;
                        if (e[Ge]) {
                            var n = e[Ge].initial;
                            ["height", "width"].forEach((function(t) {
                                var i = n[t];
                                rt.isNullOrUndef(i) ? e.removeAttribute(t) : e.setAttribute(t, i)
                            })), rt.each(n.style || {}, (function(t, n) {
                                e.style[n] = t
                            })), e.width = e.width, delete e[Ge]
                        }
                    },
                    addEventListener: function(t, e, n) {
                        var i = t.canvas;
                        if ("resize" !== e) {
                            var a = n[Ge] || (n[Ge] = {});
                            rn(i, e, (a.proxies || (a.proxies = {}))[t.id + "_" + e] = function(e) {
                                n(sn(e, t))
                            })
                        } else gn(i, n, t)
                    },
                    removeEventListener: function(t, e, n) {
                        var i = t.canvas;
                        if ("resize" !== e) {
                            var a = ((n[Ge] || {}).proxies || {})[t.id + "_" + e];
                            a && on(i, e, a)
                        } else pn(i)
                    }
                };
                rt.addEvent = rn, rt.removeEvent = on;
                var bn = vn._enabled ? vn : qe,
                    xn = rt.extend({
                        initialize: function() {},
                        acquireContext: function() {},
                        releaseContext: function() {},
                        addEventListener: function() {},
                        removeEventListener: function() {}
                    }, bn);
                Z._set("global", {
                    plugins: {}
                });
                var yn = {
                        _plugins: [],
                        _cacheId: 0,
                        register: function(t) {
                            var e = this._plugins;
                            [].concat(t).forEach((function(t) {
                                -1 === e.indexOf(t) && e.push(t)
                            })), this._cacheId++
                        },
                        unregister: function(t) {
                            var e = this._plugins;
                            [].concat(t).forEach((function(t) {
                                var n = e.indexOf(t); - 1 !== n && e.splice(n, 1)
                            })), this._cacheId++
                        },
                        clear: function() {
                            this._plugins = [], this._cacheId++
                        },
                        count: function() {
                            return this._plugins.length
                        },
                        getAll: function() {
                            return this._plugins
                        },
                        notify: function(t, e, n) {
                            var i, a, r, o, l, s = this.descriptors(t),
                                u = s.length;
                            for (i = 0; i < u; ++i)
                                if ("function" === typeof(l = (r = (a = s[i]).plugin)[e]) && ((o = [t].concat(n || [])).push(a.options), !1 === l.apply(r, o))) return !1;
                            return !0
                        },
                        descriptors: function(t) {
                            var e = t.$plugins || (t.$plugins = {});
                            if (e.id === this._cacheId) return e.descriptors;
                            var n = [],
                                i = [],
                                a = t && t.config || {},
                                r = a.options && a.options.plugins || {};
                            return this._plugins.concat(a.plugins || []).forEach((function(t) {
                                if (-1 === n.indexOf(t)) {
                                    var e = t.id,
                                        a = r[e];
                                    !1 !== a && (!0 === a && (a = rt.clone(Z.global.plugins[e])), n.push(t), i.push({
                                        plugin: t,
                                        options: a || {}
                                    }))
                                }
                            })), e.descriptors = i, e.id = this._cacheId, i
                        },
                        _invalidate: function(t) {
                            delete t.$plugins
                        }
                    },
                    _n = {
                        constructors: {},
                        defaults: {},
                        registerScaleType: function(t, e, n) {
                            this.constructors[t] = e, this.defaults[t] = rt.clone(n)
                        },
                        getScaleConstructor: function(t) {
                            return this.constructors.hasOwnProperty(t) ? this.constructors[t] : void 0
                        },
                        getScaleDefaults: function(t) {
                            return this.defaults.hasOwnProperty(t) ? rt.merge({}, [Z.scale, this.defaults[t]]) : {}
                        },
                        updateScaleDefaults: function(t, e) {
                            var n = this;
                            n.defaults.hasOwnProperty(t) && (n.defaults[t] = rt.extend(n.defaults[t], e))
                        },
                        addScalesToLayout: function(t) {
                            rt.each(t.scales, (function(e) {
                                e.fullWidth = e.options.fullWidth, e.position = e.options.position, e.weight = e.options.weight, je.addBox(t, e)
                            }))
                        }
                    },
                    kn = rt.valueOrDefault,
                    wn = rt.rtl.getRtlAdapter;
                Z._set("global", {
                    tooltips: {
                        enabled: !0,
                        custom: null,
                        mode: "nearest",
                        position: "average",
                        intersect: !0,
                        backgroundColor: "rgba(0,0,0,0.8)",
                        titleFontStyle: "bold",
                        titleSpacing: 2,
                        titleMarginBottom: 6,
                        titleFontColor: "#fff",
                        titleAlign: "left",
                        bodySpacing: 2,
                        bodyFontColor: "#fff",
                        bodyAlign: "left",
                        footerFontStyle: "bold",
                        footerSpacing: 2,
                        footerMarginTop: 6,
                        footerFontColor: "#fff",
                        footerAlign: "left",
                        yPadding: 6,
                        xPadding: 6,
                        caretPadding: 2,
                        caretSize: 5,
                        cornerRadius: 6,
                        multiKeyBackground: "#fff",
                        displayColors: !0,
                        borderColor: "rgba(0,0,0,0)",
                        borderWidth: 0,
                        callbacks: {
                            beforeTitle: rt.noop,
                            title: function(t, e) {
                                var n = "",
                                    i = e.labels,
                                    a = i ? i.length : 0;
                                if (t.length > 0) {
                                    var r = t[0];
                                    r.label ? n = r.label : r.xLabel ? n = r.xLabel : a > 0 && r.index < a && (n = i[r.index])
                                }
                                return n
                            },
                            afterTitle: rt.noop,
                            beforeBody: rt.noop,
                            beforeLabel: rt.noop,
                            label: function(t, e) {
                                var n = e.datasets[t.datasetIndex].label || "";
                                return n && (n += ": "), rt.isNullOrUndef(t.value) ? n += t.yLabel : n += t.value, n
                            },
                            labelColor: function(t, e) {
                                var n = e.getDatasetMeta(t.datasetIndex).data[t.index]._view;
                                return {
                                    borderColor: n.borderColor,
                                    backgroundColor: n.backgroundColor
                                }
                            },
                            labelTextColor: function() {
                                return this._options.bodyFontColor
                            },
                            afterLabel: rt.noop,
                            afterBody: rt.noop,
                            beforeFooter: rt.noop,
                            footer: rt.noop,
                            afterFooter: rt.noop
                        }
                    }
                });
                var Mn = {
                    average: function(t) {
                        if (!t.length) return !1;
                        var e, n, i = 0,
                            a = 0,
                            r = 0;
                        for (e = 0, n = t.length; e < n; ++e) {
                            var o = t[e];
                            if (o && o.hasValue()) {
                                var l = o.tooltipPosition();
                                i += l.x, a += l.y, ++r
                            }
                        }
                        return {
                            x: i / r,
                            y: a / r
                        }
                    },
                    nearest: function(t, e) {
                        var n, i, a, r = e.x,
                            o = e.y,
                            l = Number.POSITIVE_INFINITY;
                        for (n = 0, i = t.length; n < i; ++n) {
                            var s = t[n];
                            if (s && s.hasValue()) {
                                var u = s.getCenterPoint(),
                                    d = rt.distanceBetweenPoints(e, u);
                                d < l && (l = d, a = s)
                            }
                        }
                        if (a) {
                            var c = a.tooltipPosition();
                            r = c.x, o = c.y
                        }
                        return {
                            x: r,
                            y: o
                        }
                    }
                };

                function Sn(t, e) {
                    return e && (rt.isArray(e) ? Array.prototype.push.apply(t, e) : t.push(e)), t
                }

                function Cn(t) {
                    return ("string" === typeof t || t instanceof String) && t.indexOf("\n") > -1 ? t.split("\n") : t
                }

                function Pn(t) {
                    var e = t._xScale,
                        n = t._yScale || t._scale,
                        i = t._index,
                        a = t._datasetIndex,
                        r = t._chart.getDatasetMeta(a).controller,
                        o = r._getIndexScale(),
                        l = r._getValueScale();
                    return {
                        xLabel: e ? e.getLabelForIndex(i, a) : "",
                        yLabel: n ? n.getLabelForIndex(i, a) : "",
                        label: o ? "" + o.getLabelForIndex(i, a) : "",
                        value: l ? "" + l.getLabelForIndex(i, a) : "",
                        index: i,
                        datasetIndex: a,
                        x: t._model.x,
                        y: t._model.y
                    }
                }

                function An(t) {
                    var e = Z.global;
                    return {
                        xPadding: t.xPadding,
                        yPadding: t.yPadding,
                        xAlign: t.xAlign,
                        yAlign: t.yAlign,
                        rtl: t.rtl,
                        textDirection: t.textDirection,
                        bodyFontColor: t.bodyFontColor,
                        _bodyFontFamily: kn(t.bodyFontFamily, e.defaultFontFamily),
                        _bodyFontStyle: kn(t.bodyFontStyle, e.defaultFontStyle),
                        _bodyAlign: t.bodyAlign,
                        bodyFontSize: kn(t.bodyFontSize, e.defaultFontSize),
                        bodySpacing: t.bodySpacing,
                        titleFontColor: t.titleFontColor,
                        _titleFontFamily: kn(t.titleFontFamily, e.defaultFontFamily),
                        _titleFontStyle: kn(t.titleFontStyle, e.defaultFontStyle),
                        titleFontSize: kn(t.titleFontSize, e.defaultFontSize),
                        _titleAlign: t.titleAlign,
                        titleSpacing: t.titleSpacing,
                        titleMarginBottom: t.titleMarginBottom,
                        footerFontColor: t.footerFontColor,
                        _footerFontFamily: kn(t.footerFontFamily, e.defaultFontFamily),
                        _footerFontStyle: kn(t.footerFontStyle, e.defaultFontStyle),
                        footerFontSize: kn(t.footerFontSize, e.defaultFontSize),
                        _footerAlign: t.footerAlign,
                        footerSpacing: t.footerSpacing,
                        footerMarginTop: t.footerMarginTop,
                        caretSize: t.caretSize,
                        cornerRadius: t.cornerRadius,
                        backgroundColor: t.backgroundColor,
                        opacity: 0,
                        legendColorBackground: t.multiKeyBackground,
                        displayColors: t.displayColors,
                        borderColor: t.borderColor,
                        borderWidth: t.borderWidth
                    }
                }

                function Dn(t, e) {
                    var n = t._chart.ctx,
                        i = 2 * e.yPadding,
                        a = 0,
                        r = e.body,
                        o = r.reduce((function(t, e) {
                            return t + e.before.length + e.lines.length + e.after.length
                        }), 0);
                    o += e.beforeBody.length + e.afterBody.length;
                    var l = e.title.length,
                        s = e.footer.length,
                        u = e.titleFontSize,
                        d = e.bodyFontSize,
                        c = e.footerFontSize;
                    i += l * u, i += l ? (l - 1) * e.titleSpacing : 0, i += l ? e.titleMarginBottom : 0, i += o * d, i += o ? (o - 1) * e.bodySpacing : 0, i += s ? e.footerMarginTop : 0, i += s * c, i += s ? (s - 1) * e.footerSpacing : 0;
                    var h = 0,
                        f = function(t) {
                            a = Math.max(a, n.measureText(t).width + h)
                        };
                    return n.font = rt.fontString(u, e._titleFontStyle, e._titleFontFamily), rt.each(e.title, f), n.font = rt.fontString(d, e._bodyFontStyle, e._bodyFontFamily), rt.each(e.beforeBody.concat(e.afterBody), f), h = e.displayColors ? d + 2 : 0, rt.each(r, (function(t) {
                        rt.each(t.before, f), rt.each(t.lines, f), rt.each(t.after, f)
                    })), h = 0, n.font = rt.fontString(c, e._footerFontStyle, e._footerFontFamily), rt.each(e.footer, f), {
                        width: a += 2 * e.xPadding,
                        height: i
                    }
                }

                function Tn(t, e) {
                    var n, i, a, r, o, l = t._model,
                        s = t._chart,
                        u = t._chart.chartArea,
                        d = "center",
                        c = "center";
                    l.y < e.height ? c = "top" : l.y > s.height - e.height && (c = "bottom");
                    var h = (u.left + u.right) / 2,
                        f = (u.top + u.bottom) / 2;
                    "center" === c ? (n = function(t) {
                        return t <= h
                    }, i = function(t) {
                        return t > h
                    }) : (n = function(t) {
                        return t <= e.width / 2
                    }, i = function(t) {
                        return t >= s.width - e.width / 2
                    }), a = function(t) {
                        return t + e.width + l.caretSize + l.caretPadding > s.width
                    }, r = function(t) {
                        return t - e.width - l.caretSize - l.caretPadding < 0
                    }, o = function(t) {
                        return t <= f ? "top" : "bottom"
                    }, n(l.x) ? (d = "left", a(l.x) && (d = "center", c = o(l.y))) : i(l.x) && (d = "right", r(l.x) && (d = "center", c = o(l.y)));
                    var g = t._options;
                    return {
                        xAlign: g.xAlign ? g.xAlign : d,
                        yAlign: g.yAlign ? g.yAlign : c
                    }
                }

                function In(t, e, n, i) {
                    var a = t.x,
                        r = t.y,
                        o = t.caretSize,
                        l = t.caretPadding,
                        s = t.cornerRadius,
                        u = n.xAlign,
                        d = n.yAlign,
                        c = o + l,
                        h = s + l;
                    return "right" === u ? a -= e.width : "center" === u && ((a -= e.width / 2) + e.width > i.width && (a = i.width - e.width), a < 0 && (a = 0)), "top" === d ? r += c : r -= "bottom" === d ? e.height + c : e.height / 2, "center" === d ? "left" === u ? a += c : "right" === u && (a -= c) : "left" === u ? a -= h : "right" === u && (a += h), {
                        x: a,
                        y: r
                    }
                }

                function Fn(t, e) {
                    return "center" === e ? t.x + t.width / 2 : "right" === e ? t.x + t.width - t.xPadding : t.x + t.xPadding
                }

                function On(t) {
                    return Sn([], Cn(t))
                }
                var Ln = ft.extend({
                        initialize: function() {
                            this._model = An(this._options), this._lastActive = []
                        },
                        getTitle: function() {
                            var t = this,
                                e = t._options.callbacks,
                                n = e.beforeTitle.apply(t, arguments),
                                i = e.title.apply(t, arguments),
                                a = e.afterTitle.apply(t, arguments),
                                r = [];
                            return r = Sn(r, Cn(n)), r = Sn(r, Cn(i)), r = Sn(r, Cn(a))
                        },
                        getBeforeBody: function() {
                            return On(this._options.callbacks.beforeBody.apply(this, arguments))
                        },
                        getBody: function(t, e) {
                            var n = this,
                                i = n._options.callbacks,
                                a = [];
                            return rt.each(t, (function(t) {
                                var r = {
                                    before: [],
                                    lines: [],
                                    after: []
                                };
                                Sn(r.before, Cn(i.beforeLabel.call(n, t, e))), Sn(r.lines, i.label.call(n, t, e)), Sn(r.after, Cn(i.afterLabel.call(n, t, e))), a.push(r)
                            })), a
                        },
                        getAfterBody: function() {
                            return On(this._options.callbacks.afterBody.apply(this, arguments))
                        },
                        getFooter: function() {
                            var t = this,
                                e = t._options.callbacks,
                                n = e.beforeFooter.apply(t, arguments),
                                i = e.footer.apply(t, arguments),
                                a = e.afterFooter.apply(t, arguments),
                                r = [];
                            return r = Sn(r, Cn(n)), r = Sn(r, Cn(i)), r = Sn(r, Cn(a))
                        },
                        update: function(t) {
                            var e, n, i = this,
                                a = i._options,
                                r = i._model,
                                o = i._model = An(a),
                                l = i._active,
                                s = i._data,
                                u = {
                                    xAlign: r.xAlign,
                                    yAlign: r.yAlign
                                },
                                d = {
                                    x: r.x,
                                    y: r.y
                                },
                                c = {
                                    width: r.width,
                                    height: r.height
                                },
                                h = {
                                    x: r.caretX,
                                    y: r.caretY
                                };
                            if (l.length) {
                                o.opacity = 1;
                                var f = [],
                                    g = [];
                                h = Mn[a.position].call(i, l, i._eventPosition);
                                var p = [];
                                for (e = 0, n = l.length; e < n; ++e) p.push(Pn(l[e]));
                                a.filter && (p = p.filter((function(t) {
                                    return a.filter(t, s)
                                }))), a.itemSort && (p = p.sort((function(t, e) {
                                    return a.itemSort(t, e, s)
                                }))), rt.each(p, (function(t) {
                                    f.push(a.callbacks.labelColor.call(i, t, i._chart)), g.push(a.callbacks.labelTextColor.call(i, t, i._chart))
                                })), o.title = i.getTitle(p, s), o.beforeBody = i.getBeforeBody(p, s), o.body = i.getBody(p, s), o.afterBody = i.getAfterBody(p, s), o.footer = i.getFooter(p, s), o.x = h.x, o.y = h.y, o.caretPadding = a.caretPadding, o.labelColors = f, o.labelTextColors = g, o.dataPoints = p, d = In(o, c = Dn(this, o), u = Tn(this, c), i._chart)
                            } else o.opacity = 0;
                            return o.xAlign = u.xAlign, o.yAlign = u.yAlign, o.x = d.x, o.y = d.y, o.width = c.width, o.height = c.height, o.caretX = h.x, o.caretY = h.y, i._model = o, t && a.custom && a.custom.call(i, o), i
                        },
                        drawCaret: function(t, e) {
                            var n = this._chart.ctx,
                                i = this._view,
                                a = this.getCaretPosition(t, e, i);
                            n.lineTo(a.x1, a.y1), n.lineTo(a.x2, a.y2), n.lineTo(a.x3, a.y3)
                        },
                        getCaretPosition: function(t, e, n) {
                            var i, a, r, o, l, s, u = n.caretSize,
                                d = n.cornerRadius,
                                c = n.xAlign,
                                h = n.yAlign,
                                f = t.x,
                                g = t.y,
                                p = e.width,
                                m = e.height;
                            if ("center" === h) l = g + m / 2, "left" === c ? (a = (i = f) - u, r = i, o = l + u, s = l - u) : (a = (i = f + p) + u, r = i, o = l - u, s = l + u);
                            else if ("left" === c ? (i = (a = f + d + u) - u, r = a + u) : "right" === c ? (i = (a = f + p - d - u) - u, r = a + u) : (i = (a = n.caretX) - u, r = a + u), "top" === h) l = (o = g) - u, s = o;
                            else {
                                l = (o = g + m) + u, s = o;
                                var v = r;
                                r = i, i = v
                            }
                            return {
                                x1: i,
                                x2: a,
                                x3: r,
                                y1: o,
                                y2: l,
                                y3: s
                            }
                        },
                        drawTitle: function(t, e, n) {
                            var i, a, r, o = e.title,
                                l = o.length;
                            if (l) {
                                var s = wn(e.rtl, e.x, e.width);
                                for (t.x = Fn(e, e._titleAlign), n.textAlign = s.textAlign(e._titleAlign), n.textBaseline = "middle", i = e.titleFontSize, a = e.titleSpacing, n.fillStyle = e.titleFontColor, n.font = rt.fontString(i, e._titleFontStyle, e._titleFontFamily), r = 0; r < l; ++r) n.fillText(o[r], s.x(t.x), t.y + i / 2), t.y += i + a, r + 1 === l && (t.y += e.titleMarginBottom - a)
                            }
                        },
                        drawBody: function(t, e, n) {
                            var i, a, r, o, l, s, u, d, c = e.bodyFontSize,
                                h = e.bodySpacing,
                                f = e._bodyAlign,
                                g = e.body,
                                p = e.displayColors,
                                m = 0,
                                v = p ? Fn(e, "left") : 0,
                                b = wn(e.rtl, e.x, e.width),
                                x = function(e) {
                                    n.fillText(e, b.x(t.x + m), t.y + c / 2), t.y += c + h
                                },
                                y = b.textAlign(f);
                            for (n.textAlign = f, n.textBaseline = "middle", n.font = rt.fontString(c, e._bodyFontStyle, e._bodyFontFamily), t.x = Fn(e, y), n.fillStyle = e.bodyFontColor, rt.each(e.beforeBody, x), m = p && "right" !== y ? "center" === f ? c / 2 + 1 : c + 2 : 0, l = 0, u = g.length; l < u; ++l) {
                                for (i = g[l], a = e.labelTextColors[l], r = e.labelColors[l], n.fillStyle = a, rt.each(i.before, x), s = 0, d = (o = i.lines).length; s < d; ++s) {
                                    if (p) {
                                        var _ = b.x(v);
                                        n.fillStyle = e.legendColorBackground, n.fillRect(b.leftForLtr(_, c), t.y, c, c), n.lineWidth = 1, n.strokeStyle = r.borderColor, n.strokeRect(b.leftForLtr(_, c), t.y, c, c), n.fillStyle = r.backgroundColor, n.fillRect(b.leftForLtr(b.xPlus(_, 1), c - 2), t.y + 1, c - 2, c - 2), n.fillStyle = a
                                    }
                                    x(o[s])
                                }
                                rt.each(i.after, x)
                            }
                            m = 0, rt.each(e.afterBody, x), t.y -= h
                        },
                        drawFooter: function(t, e, n) {
                            var i, a, r = e.footer,
                                o = r.length;
                            if (o) {
                                var l = wn(e.rtl, e.x, e.width);
                                for (t.x = Fn(e, e._footerAlign), t.y += e.footerMarginTop, n.textAlign = l.textAlign(e._footerAlign), n.textBaseline = "middle", i = e.footerFontSize, n.fillStyle = e.footerFontColor, n.font = rt.fontString(i, e._footerFontStyle, e._footerFontFamily), a = 0; a < o; ++a) n.fillText(r[a], l.x(t.x), t.y + i / 2), t.y += i + e.footerSpacing
                            }
                        },
                        drawBackground: function(t, e, n, i) {
                            n.fillStyle = e.backgroundColor, n.strokeStyle = e.borderColor, n.lineWidth = e.borderWidth;
                            var a = e.xAlign,
                                r = e.yAlign,
                                o = t.x,
                                l = t.y,
                                s = i.width,
                                u = i.height,
                                d = e.cornerRadius;
                            n.beginPath(), n.moveTo(o + d, l), "top" === r && this.drawCaret(t, i), n.lineTo(o + s - d, l), n.quadraticCurveTo(o + s, l, o + s, l + d), "center" === r && "right" === a && this.drawCaret(t, i), n.lineTo(o + s, l + u - d), n.quadraticCurveTo(o + s, l + u, o + s - d, l + u), "bottom" === r && this.drawCaret(t, i), n.lineTo(o + d, l + u), n.quadraticCurveTo(o, l + u, o, l + u - d), "center" === r && "left" === a && this.drawCaret(t, i), n.lineTo(o, l + d), n.quadraticCurveTo(o, l, o + d, l), n.closePath(), n.fill(), e.borderWidth > 0 && n.stroke()
                        },
                        draw: function() {
                            var t = this._chart.ctx,
                                e = this._view;
                            if (0 !== e.opacity) {
                                var n = {
                                        width: e.width,
                                        height: e.height
                                    },
                                    i = {
                                        x: e.x,
                                        y: e.y
                                    },
                                    a = Math.abs(e.opacity < .001) ? 0 : e.opacity,
                                    r = e.title.length || e.beforeBody.length || e.body.length || e.afterBody.length || e.footer.length;
                                this._options.enabled && r && (t.save(), t.globalAlpha = a, this.drawBackground(i, e, t, n), i.y += e.yPadding, rt.rtl.overrideTextDirection(t, e.textDirection), this.drawTitle(i, e, t), this.drawBody(i, e, t), this.drawFooter(i, e, t), rt.rtl.restoreTextDirection(t, e.textDirection), t.restore())
                            }
                        },
                        handleEvent: function(t) {
                            var e = this,
                                n = e._options,
                                i = !1;
                            return e._lastActive = e._lastActive || [], "mouseout" === t.type ? e._active = [] : (e._active = e._chart.getElementsAtEventForMode(t, n.mode, n), n.reverse && e._active.reverse()), (i = !rt.arrayEquals(e._active, e._lastActive)) && (e._lastActive = e._active, (n.enabled || n.custom) && (e._eventPosition = {
                                x: t.x,
                                y: t.y
                            }, e.update(!0), e.pivot())), i
                        }
                    }),
                    Rn = Mn,
                    zn = Ln;
                zn.positioners = Rn;
                var Nn = rt.valueOrDefault;

                function Bn() {
                    return rt.merge({}, [].slice.call(arguments), {
                        merger: function(t, e, n, i) {
                            if ("xAxes" === t || "yAxes" === t) {
                                var a, r, o, l = n[t].length;
                                for (e[t] || (e[t] = []), a = 0; a < l; ++a) o = n[t][a], r = Nn(o.type, "xAxes" === t ? "category" : "linear"), a >= e[t].length && e[t].push({}), !e[t][a].type || o.type && o.type !== e[t][a].type ? rt.merge(e[t][a], [_n.getScaleDefaults(r), o]) : rt.merge(e[t][a], o)
                            } else rt._merger(t, e, n, i)
                        }
                    })
                }

                function En() {
                    return rt.merge({}, [].slice.call(arguments), {
                        merger: function(t, e, n, i) {
                            var a = e[t] || {},
                                r = n[t];
                            "scales" === t ? e[t] = Bn(a, r) : "scale" === t ? e[t] = rt.merge(a, [_n.getScaleDefaults(r.type), r]) : rt._merger(t, e, n, i)
                        }
                    })
                }

                function Wn(t) {
                    var e = (t = t || {}).data = t.data || {};
                    return e.datasets = e.datasets || [], e.labels = e.labels || [], t.options = En(Z.global, Z[t.type], t.options || {}), t
                }

                function Vn(t) {
                    var e = t.options;
                    rt.each(t.scales, (function(e) {
                        je.removeBox(t, e)
                    })), e = En(Z.global, Z[t.config.type], e), t.options = t.config.options = e, t.ensureScalesHaveIDs(), t.buildOrUpdateScales(), t.tooltip._options = e.tooltips, t.tooltip.initialize()
                }

                function Hn(t, e, n) {
                    var i, a = function(t) {
                        return t.id === i
                    };
                    do {
                        i = e + n++
                    } while (rt.findIndex(t, a) >= 0);
                    return i
                }

                function jn(t) {
                    return "top" === t || "bottom" === t
                }

                function qn(t, e) {
                    return function(n, i) {
                        return n[t] === i[t] ? n[e] - i[e] : n[t] - i[t]
                    }
                }
                Z._set("global", {
                    elements: {},
                    events: ["mousemove", "mouseout", "click", "touchstart", "touchmove"],
                    hover: {
                        onHover: null,
                        mode: "nearest",
                        intersect: !0,
                        animationDuration: 400
                    },
                    onClick: null,
                    maintainAspectRatio: !0,
                    responsive: !0,
                    responsiveAnimationDuration: 0
                });
                var Un = function(t, e) {
                    return this.construct(t, e), this
                };
                rt.extend(Un.prototype, {
                    construct: function(t, e) {
                        var n = this;
                        e = Wn(e);
                        var i = xn.acquireContext(t, e),
                            a = i && i.canvas,
                            r = a && a.height,
                            o = a && a.width;
                        n.id = rt.uid(), n.ctx = i, n.canvas = a, n.config = e, n.width = o, n.height = r, n.aspectRatio = r ? o / r : null, n.options = e.options, n._bufferedRender = !1, n._layers = [], n.chart = n, n.controller = n, Un.instances[n.id] = n, Object.defineProperty(n, "data", {
                            get: function() {
                                return n.config.data
                            },
                            set: function(t) {
                                n.config.data = t
                            }
                        }), i && a ? (n.initialize(), n.update()) : console.error("Failed to create chart: can't acquire context from the given item")
                    },
                    initialize: function() {
                        var t = this;
                        return yn.notify(t, "beforeInit"), rt.retinaScale(t, t.options.devicePixelRatio), t.bindEvents(), t.options.responsive && t.resize(!0), t.initToolTip(), yn.notify(t, "afterInit"), t
                    },
                    clear: function() {
                        return rt.canvas.clear(this), this
                    },
                    stop: function() {
                        return mt.cancelAnimation(this), this
                    },
                    resize: function(t) {
                        var e = this,
                            n = e.options,
                            i = e.canvas,
                            a = n.maintainAspectRatio && e.aspectRatio || null,
                            r = Math.max(0, Math.floor(rt.getMaximumWidth(i))),
                            o = Math.max(0, Math.floor(a ? r / a : rt.getMaximumHeight(i)));
                        if ((e.width !== r || e.height !== o) && (i.width = e.width = r, i.height = e.height = o, i.style.width = r + "px", i.style.height = o + "px", rt.retinaScale(e, n.devicePixelRatio), !t)) {
                            var l = {
                                width: r,
                                height: o
                            };
                            yn.notify(e, "resize", [l]), n.onResize && n.onResize(e, l), e.stop(), e.update({
                                duration: n.responsiveAnimationDuration
                            })
                        }
                    },
                    ensureScalesHaveIDs: function() {
                        var t = this.options,
                            e = t.scales || {},
                            n = t.scale;
                        rt.each(e.xAxes, (function(t, n) {
                            t.id || (t.id = Hn(e.xAxes, "x-axis-", n))
                        })), rt.each(e.yAxes, (function(t, n) {
                            t.id || (t.id = Hn(e.yAxes, "y-axis-", n))
                        })), n && (n.id = n.id || "scale")
                    },
                    buildOrUpdateScales: function() {
                        var t = this,
                            e = t.options,
                            n = t.scales || {},
                            i = [],
                            a = Object.keys(n).reduce((function(t, e) {
                                return t[e] = !1, t
                            }), {});
                        e.scales && (i = i.concat((e.scales.xAxes || []).map((function(t) {
                            return {
                                options: t,
                                dtype: "category",
                                dposition: "bottom"
                            }
                        })), (e.scales.yAxes || []).map((function(t) {
                            return {
                                options: t,
                                dtype: "linear",
                                dposition: "left"
                            }
                        })))), e.scale && i.push({
                            options: e.scale,
                            dtype: "radialLinear",
                            isDefault: !0,
                            dposition: "chartArea"
                        }), rt.each(i, (function(e) {
                            var i = e.options,
                                r = i.id,
                                o = Nn(i.type, e.dtype);
                            jn(i.position) !== jn(e.dposition) && (i.position = e.dposition), a[r] = !0;
                            var l = null;
                            if (r in n && n[r].type === o)(l = n[r]).options = i, l.ctx = t.ctx, l.chart = t;
                            else {
                                var s = _n.getScaleConstructor(o);
                                if (!s) return;
                                l = new s({
                                    id: r,
                                    type: o,
                                    options: i,
                                    ctx: t.ctx,
                                    chart: t
                                }), n[l.id] = l
                            }
                            l.mergeTicksOptions(), e.isDefault && (t.scale = l)
                        })), rt.each(a, (function(t, e) {
                            t || delete n[e]
                        })), t.scales = n, _n.addScalesToLayout(this)
                    },
                    buildOrUpdateControllers: function() {
                        var t, e, n = this,
                            i = [],
                            a = n.data.datasets;
                        for (t = 0, e = a.length; t < e; t++) {
                            var r = a[t],
                                o = n.getDatasetMeta(t),
                                l = r.type || n.config.type;
                            if (o.type && o.type !== l && (n.destroyDatasetMeta(t), o = n.getDatasetMeta(t)), o.type = l, o.order = r.order || 0, o.index = t, o.controller) o.controller.updateIndex(t), o.controller.linkScales();
                            else {
                                var s = we[o.type];
                                if (void 0 === s) throw new Error('"' + o.type + '" is not a chart type.');
                                o.controller = new s(n, t), i.push(o.controller)
                            }
                        }
                        return i
                    },
                    resetElements: function() {
                        var t = this;
                        rt.each(t.data.datasets, (function(e, n) {
                            t.getDatasetMeta(n).controller.reset()
                        }), t)
                    },
                    reset: function() {
                        this.resetElements(), this.tooltip.initialize()
                    },
                    update: function(t) {
                        var e, n, i = this;
                        if (t && "object" === typeof t || (t = {
                                duration: t,
                                lazy: arguments[1]
                            }), Vn(i), yn._invalidate(i), !1 !== yn.notify(i, "beforeUpdate")) {
                            i.tooltip._data = i.data;
                            var a = i.buildOrUpdateControllers();
                            for (e = 0, n = i.data.datasets.length; e < n; e++) i.getDatasetMeta(e).controller.buildOrUpdateElements();
                            i.updateLayout(), i.options.animation && i.options.animation.duration && rt.each(a, (function(t) {
                                t.reset()
                            })), i.updateDatasets(), i.tooltip.initialize(), i.lastActive = [], yn.notify(i, "afterUpdate"), i._layers.sort(qn("z", "_idx")), i._bufferedRender ? i._bufferedRequest = {
                                duration: t.duration,
                                easing: t.easing,
                                lazy: t.lazy
                            } : i.render(t)
                        }
                    },
                    updateLayout: function() {
                        var t = this;
                        !1 !== yn.notify(t, "beforeLayout") && (je.update(this, this.width, this.height), t._layers = [], rt.each(t.boxes, (function(e) {
                            e._configure && e._configure(), t._layers.push.apply(t._layers, e._layers())
                        }), t), t._layers.forEach((function(t, e) {
                            t._idx = e
                        })), yn.notify(t, "afterScaleUpdate"), yn.notify(t, "afterLayout"))
                    },
                    updateDatasets: function() {
                        var t = this;
                        if (!1 !== yn.notify(t, "beforeDatasetsUpdate")) {
                            for (var e = 0, n = t.data.datasets.length; e < n; ++e) t.updateDataset(e);
                            yn.notify(t, "afterDatasetsUpdate")
                        }
                    },
                    updateDataset: function(t) {
                        var e = this,
                            n = e.getDatasetMeta(t),
                            i = {
                                meta: n,
                                index: t
                            };
                        !1 !== yn.notify(e, "beforeDatasetUpdate", [i]) && (n.controller._update(), yn.notify(e, "afterDatasetUpdate", [i]))
                    },
                    render: function(t) {
                        var e = this;
                        t && "object" === typeof t || (t = {
                            duration: t,
                            lazy: arguments[1]
                        });
                        var n = e.options.animation,
                            i = Nn(t.duration, n && n.duration),
                            a = t.lazy;
                        if (!1 !== yn.notify(e, "beforeRender")) {
                            var r = function(t) {
                                yn.notify(e, "afterRender"), rt.callback(n && n.onComplete, [t], e)
                            };
                            if (n && i) {
                                var o = new pt({
                                    numSteps: i / 16.66,
                                    easing: t.easing || n.easing,
                                    render: function(t, e) {
                                        var n = rt.easing.effects[e.easing],
                                            i = e.currentStep,
                                            a = i / e.numSteps;
                                        t.draw(n(a), a, i)
                                    },
                                    onAnimationProgress: n.onProgress,
                                    onAnimationComplete: r
                                });
                                mt.addAnimation(e, o, i, a)
                            } else e.draw(), r(new pt({
                                numSteps: 0,
                                chart: e
                            }));
                            return e
                        }
                    },
                    draw: function(t) {
                        var e, n, i = this;
                        if (i.clear(), rt.isNullOrUndef(t) && (t = 1), i.transition(t), !(i.width <= 0 || i.height <= 0) && !1 !== yn.notify(i, "beforeDraw", [t])) {
                            for (n = i._layers, e = 0; e < n.length && n[e].z <= 0; ++e) n[e].draw(i.chartArea);
                            for (i.drawDatasets(t); e < n.length; ++e) n[e].draw(i.chartArea);
                            i._drawTooltip(t), yn.notify(i, "afterDraw", [t])
                        }
                    },
                    transition: function(t) {
                        for (var e = this, n = 0, i = (e.data.datasets || []).length; n < i; ++n) e.isDatasetVisible(n) && e.getDatasetMeta(n).controller.transition(t);
                        e.tooltip.transition(t)
                    },
                    _getSortedDatasetMetas: function(t) {
                        var e, n, i = this,
                            a = [];
                        for (e = 0, n = (i.data.datasets || []).length; e < n; ++e) t && !i.isDatasetVisible(e) || a.push(i.getDatasetMeta(e));
                        return a.sort(qn("order", "index")), a
                    },
                    _getSortedVisibleDatasetMetas: function() {
                        return this._getSortedDatasetMetas(!0)
                    },
                    drawDatasets: function(t) {
                        var e, n, i = this;
                        if (!1 !== yn.notify(i, "beforeDatasetsDraw", [t])) {
                            for (n = (e = i._getSortedVisibleDatasetMetas()).length - 1; n >= 0; --n) i.drawDataset(e[n], t);
                            yn.notify(i, "afterDatasetsDraw", [t])
                        }
                    },
                    drawDataset: function(t, e) {
                        var n = this,
                            i = {
                                meta: t,
                                index: t.index,
                                easingValue: e
                            };
                        !1 !== yn.notify(n, "beforeDatasetDraw", [i]) && (t.controller.draw(e), yn.notify(n, "afterDatasetDraw", [i]))
                    },
                    _drawTooltip: function(t) {
                        var e = this,
                            n = e.tooltip,
                            i = {
                                tooltip: n,
                                easingValue: t
                            };
                        !1 !== yn.notify(e, "beforeTooltipDraw", [i]) && (n.draw(), yn.notify(e, "afterTooltipDraw", [i]))
                    },
                    getElementAtEvent: function(t) {
                        return Te.modes.single(this, t)
                    },
                    getElementsAtEvent: function(t) {
                        return Te.modes.label(this, t, {
                            intersect: !0
                        })
                    },
                    getElementsAtXAxis: function(t) {
                        return Te.modes["x-axis"](this, t, {
                            intersect: !0
                        })
                    },
                    getElementsAtEventForMode: function(t, e, n) {
                        var i = Te.modes[e];
                        return "function" === typeof i ? i(this, t, n) : []
                    },
                    getDatasetAtEvent: function(t) {
                        return Te.modes.dataset(this, t, {
                            intersect: !0
                        })
                    },
                    getDatasetMeta: function(t) {
                        var e = this,
                            n = e.data.datasets[t];
                        n._meta || (n._meta = {});
                        var i = n._meta[e.id];
                        return i || (i = n._meta[e.id] = {
                            type: null,
                            data: [],
                            dataset: null,
                            controller: null,
                            hidden: null,
                            xAxisID: null,
                            yAxisID: null,
                            order: n.order || 0,
                            index: t
                        }), i
                    },
                    getVisibleDatasetCount: function() {
                        for (var t = 0, e = 0, n = this.data.datasets.length; e < n; ++e) this.isDatasetVisible(e) && t++;
                        return t
                    },
                    isDatasetVisible: function(t) {
                        var e = this.getDatasetMeta(t);
                        return "boolean" === typeof e.hidden ? !e.hidden : !this.data.datasets[t].hidden
                    },
                    generateLegend: function() {
                        return this.options.legendCallback(this)
                    },
                    destroyDatasetMeta: function(t) {
                        var e = this.id,
                            n = this.data.datasets[t],
                            i = n._meta && n._meta[e];
                        i && (i.controller.destroy(), delete n._meta[e])
                    },
                    destroy: function() {
                        var t, e, n = this,
                            i = n.canvas;
                        for (n.stop(), t = 0, e = n.data.datasets.length; t < e; ++t) n.destroyDatasetMeta(t);
                        i && (n.unbindEvents(), rt.canvas.clear(n), xn.releaseContext(n.ctx), n.canvas = null, n.ctx = null), yn.notify(n, "destroy"), delete Un.instances[n.id]
                    },
                    toBase64Image: function() {
                        return this.canvas.toDataURL.apply(this.canvas, arguments)
                    },
                    initToolTip: function() {
                        var t = this;
                        t.tooltip = new zn({
                            _chart: t,
                            _chartInstance: t,
                            _data: t.data,
                            _options: t.options.tooltips
                        }, t)
                    },
                    bindEvents: function() {
                        var t = this,
                            e = t._listeners = {},
                            n = function() {
                                t.eventHandler.apply(t, arguments)
                            };
                        rt.each(t.options.events, (function(i) {
                            xn.addEventListener(t, i, n), e[i] = n
                        })), t.options.responsive && (n = function() {
                            t.resize()
                        }, xn.addEventListener(t, "resize", n), e.resize = n)
                    },
                    unbindEvents: function() {
                        var t = this,
                            e = t._listeners;
                        e && (delete t._listeners, rt.each(e, (function(e, n) {
                            xn.removeEventListener(t, n, e)
                        })))
                    },
                    updateHoverStyle: function(t, e, n) {
                        var i, a, r, o = n ? "set" : "remove";
                        for (a = 0, r = t.length; a < r; ++a)(i = t[a]) && this.getDatasetMeta(i._datasetIndex).controller[o + "HoverStyle"](i);
                        "dataset" === e && this.getDatasetMeta(t[0]._datasetIndex).controller["_" + o + "DatasetHoverStyle"]()
                    },
                    eventHandler: function(t) {
                        var e = this,
                            n = e.tooltip;
                        if (!1 !== yn.notify(e, "beforeEvent", [t])) {
                            e._bufferedRender = !0, e._bufferedRequest = null;
                            var i = e.handleEvent(t);
                            n && (i = n._start ? n.handleEvent(t) : i | n.handleEvent(t)), yn.notify(e, "afterEvent", [t]);
                            var a = e._bufferedRequest;
                            return a ? e.render(a) : i && !e.animating && (e.stop(), e.render({
                                duration: e.options.hover.animationDuration,
                                lazy: !0
                            })), e._bufferedRender = !1, e._bufferedRequest = null, e
                        }
                    },
                    handleEvent: function(t) {
                        var e = this,
                            n = e.options || {},
                            i = n.hover,
                            a = !1;
                        return e.lastActive = e.lastActive || [], "mouseout" === t.type ? e.active = [] : e.active = e.getElementsAtEventForMode(t, i.mode, i), rt.callback(n.onHover || n.hover.onHover, [t.native, e.active], e), "mouseup" !== t.type && "click" !== t.type || n.onClick && n.onClick.call(e, t.native, e.active), e.lastActive.length && e.updateHoverStyle(e.lastActive, i.mode, !1), e.active.length && i.mode && e.updateHoverStyle(e.active, i.mode, !0), a = !rt.arrayEquals(e.active, e.lastActive), e.lastActive = e.active, a
                    }
                }), Un.instances = {};
                var Yn = Un;
                Un.Controller = Un, Un.types = {}, rt.configMerge = En, rt.scaleMerge = Bn;
                var Gn = function() {
                    function t(t, e, n) {
                        var i;
                        return "string" === typeof t ? (i = parseInt(t, 10), -1 !== t.indexOf("%") && (i = i / 100 * e.parentNode[n])) : i = t, i
                    }

                    function e(t) {
                        return void 0 !== t && null !== t && "none" !== t
                    }

                    function n(n, i, a) {
                        var r = document.defaultView,
                            o = rt._getParentNode(n),
                            l = r.getComputedStyle(n)[i],
                            s = r.getComputedStyle(o)[i],
                            u = e(l),
                            d = e(s),
                            c = Number.POSITIVE_INFINITY;
                        return u || d ? Math.min(u ? t(l, n, a) : c, d ? t(s, o, a) : c) : "none"
                    }
                    rt.where = function(t, e) {
                        if (rt.isArray(t) && Array.prototype.filter) return t.filter(e);
                        var n = [];
                        return rt.each(t, (function(t) {
                            e(t) && n.push(t)
                        })), n
                    }, rt.findIndex = Array.prototype.findIndex ? function(t, e, n) {
                        return t.findIndex(e, n)
                    } : function(t, e, n) {
                        n = void 0 === n ? t : n;
                        for (var i = 0, a = t.length; i < a; ++i)
                            if (e.call(n, t[i], i, t)) return i;
                        return -1
                    }, rt.findNextWhere = function(t, e, n) {
                        rt.isNullOrUndef(n) && (n = -1);
                        for (var i = n + 1; i < t.length; i++) {
                            var a = t[i];
                            if (e(a)) return a
                        }
                    }, rt.findPreviousWhere = function(t, e, n) {
                        rt.isNullOrUndef(n) && (n = t.length);
                        for (var i = n - 1; i >= 0; i--) {
                            var a = t[i];
                            if (e(a)) return a
                        }
                    }, rt.isNumber = function(t) {
                        return !isNaN(parseFloat(t)) && isFinite(t)
                    }, rt.almostEquals = function(t, e, n) {
                        return Math.abs(t - e) < n
                    }, rt.almostWhole = function(t, e) {
                        var n = Math.round(t);
                        return n - e <= t && n + e >= t
                    }, rt.max = function(t) {
                        return t.reduce((function(t, e) {
                            return isNaN(e) ? t : Math.max(t, e)
                        }), Number.NEGATIVE_INFINITY)
                    }, rt.min = function(t) {
                        return t.reduce((function(t, e) {
                            return isNaN(e) ? t : Math.min(t, e)
                        }), Number.POSITIVE_INFINITY)
                    }, rt.sign = Math.sign ? function(t) {
                        return Math.sign(t)
                    } : function(t) {
                        return 0 === (t = +t) || isNaN(t) ? t : t > 0 ? 1 : -1
                    }, rt.toRadians = function(t) {
                        return t * (Math.PI / 180)
                    }, rt.toDegrees = function(t) {
                        return t * (180 / Math.PI)
                    }, rt._decimalPlaces = function(t) {
                        if (rt.isFinite(t)) {
                            for (var e = 1, n = 0; Math.round(t * e) / e !== t;) e *= 10, n++;
                            return n
                        }
                    }, rt.getAngleFromPoint = function(t, e) {
                        var n = e.x - t.x,
                            i = e.y - t.y,
                            a = Math.sqrt(n * n + i * i),
                            r = Math.atan2(i, n);
                        return r < -.5 * Math.PI && (r += 2 * Math.PI), {
                            angle: r,
                            distance: a
                        }
                    }, rt.distanceBetweenPoints = function(t, e) {
                        return Math.sqrt(Math.pow(e.x - t.x, 2) + Math.pow(e.y - t.y, 2))
                    }, rt.aliasPixel = function(t) {
                        return t % 2 === 0 ? 0 : .5
                    }, rt._alignPixel = function(t, e, n) {
                        var i = t.currentDevicePixelRatio,
                            a = n / 2;
                        return Math.round((e - a) * i) / i + a
                    }, rt.splineCurve = function(t, e, n, i) {
                        var a = t.skip ? e : t,
                            r = e,
                            o = n.skip ? e : n,
                            l = Math.sqrt(Math.pow(r.x - a.x, 2) + Math.pow(r.y - a.y, 2)),
                            s = Math.sqrt(Math.pow(o.x - r.x, 2) + Math.pow(o.y - r.y, 2)),
                            u = l / (l + s),
                            d = s / (l + s),
                            c = i * (u = isNaN(u) ? 0 : u),
                            h = i * (d = isNaN(d) ? 0 : d);
                        return {
                            previous: {
                                x: r.x - c * (o.x - a.x),
                                y: r.y - c * (o.y - a.y)
                            },
                            next: {
                                x: r.x + h * (o.x - a.x),
                                y: r.y + h * (o.y - a.y)
                            }
                        }
                    }, rt.EPSILON = Number.EPSILON || 1e-14, rt.splineCurveMonotone = function(t) {
                        var e, n, i, a, r, o, l, s, u, d = (t || []).map((function(t) {
                                return {
                                    model: t._model,
                                    deltaK: 0,
                                    mK: 0
                                }
                            })),
                            c = d.length;
                        for (e = 0; e < c; ++e)
                            if (!(i = d[e]).model.skip) {
                                if (n = e > 0 ? d[e - 1] : null, (a = e < c - 1 ? d[e + 1] : null) && !a.model.skip) {
                                    var h = a.model.x - i.model.x;
                                    i.deltaK = 0 !== h ? (a.model.y - i.model.y) / h : 0
                                }!n || n.model.skip ? i.mK = i.deltaK : !a || a.model.skip ? i.mK = n.deltaK : this.sign(n.deltaK) !== this.sign(i.deltaK) ? i.mK = 0 : i.mK = (n.deltaK + i.deltaK) / 2
                            }
                        for (e = 0; e < c - 1; ++e) i = d[e], a = d[e + 1], i.model.skip || a.model.skip || (rt.almostEquals(i.deltaK, 0, this.EPSILON) ? i.mK = a.mK = 0 : (r = i.mK / i.deltaK, o = a.mK / i.deltaK, (s = Math.pow(r, 2) + Math.pow(o, 2)) <= 9 || (l = 3 / Math.sqrt(s), i.mK = r * l * i.deltaK, a.mK = o * l * i.deltaK)));
                        for (e = 0; e < c; ++e)(i = d[e]).model.skip || (n = e > 0 ? d[e - 1] : null, a = e < c - 1 ? d[e + 1] : null, n && !n.model.skip && (u = (i.model.x - n.model.x) / 3, i.model.controlPointPreviousX = i.model.x - u, i.model.controlPointPreviousY = i.model.y - u * i.mK), a && !a.model.skip && (u = (a.model.x - i.model.x) / 3, i.model.controlPointNextX = i.model.x + u, i.model.controlPointNextY = i.model.y + u * i.mK))
                    }, rt.nextItem = function(t, e, n) {
                        return n ? e >= t.length - 1 ? t[0] : t[e + 1] : e >= t.length - 1 ? t[t.length - 1] : t[e + 1]
                    }, rt.previousItem = function(t, e, n) {
                        return n ? e <= 0 ? t[t.length - 1] : t[e - 1] : e <= 0 ? t[0] : t[e - 1]
                    }, rt.niceNum = function(t, e) {
                        var n = Math.floor(rt.log10(t)),
                            i = t / Math.pow(10, n);
                        return (e ? i < 1.5 ? 1 : i < 3 ? 2 : i < 7 ? 5 : 10 : i <= 1 ? 1 : i <= 2 ? 2 : i <= 5 ? 5 : 10) * Math.pow(10, n)
                    }, rt.requestAnimFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(t) {
                        return window.setTimeout(t, 1e3 / 60)
                    }, rt.getRelativePosition = function(t, e) {
                        var n, i, a = t.originalEvent || t,
                            r = t.target || t.srcElement,
                            o = r.getBoundingClientRect(),
                            l = a.touches;
                        l && l.length > 0 ? (n = l[0].clientX, i = l[0].clientY) : (n = a.clientX, i = a.clientY);
                        var s = parseFloat(rt.getStyle(r, "padding-left")),
                            u = parseFloat(rt.getStyle(r, "padding-top")),
                            d = parseFloat(rt.getStyle(r, "padding-right")),
                            c = parseFloat(rt.getStyle(r, "padding-bottom")),
                            h = o.right - o.left - s - d,
                            f = o.bottom - o.top - u - c;
                        return {
                            x: n = Math.round((n - o.left - s) / h * r.width / e.currentDevicePixelRatio),
                            y: i = Math.round((i - o.top - u) / f * r.height / e.currentDevicePixelRatio)
                        }
                    }, rt.getConstraintWidth = function(t) {
                        return n(t, "max-width", "clientWidth")
                    }, rt.getConstraintHeight = function(t) {
                        return n(t, "max-height", "clientHeight")
                    }, rt._calculatePadding = function(t, e, n) {
                        return (e = rt.getStyle(t, e)).indexOf("%") > -1 ? n * parseInt(e, 10) / 100 : parseInt(e, 10)
                    }, rt._getParentNode = function(t) {
                        var e = t.parentNode;
                        return e && "[object ShadowRoot]" === e.toString() && (e = e.host), e
                    }, rt.getMaximumWidth = function(t) {
                        var e = rt._getParentNode(t);
                        if (!e) return t.clientWidth;
                        var n = e.clientWidth,
                            i = n - rt._calculatePadding(e, "padding-left", n) - rt._calculatePadding(e, "padding-right", n),
                            a = rt.getConstraintWidth(t);
                        return isNaN(a) ? i : Math.min(i, a)
                    }, rt.getMaximumHeight = function(t) {
                        var e = rt._getParentNode(t);
                        if (!e) return t.clientHeight;
                        var n = e.clientHeight,
                            i = n - rt._calculatePadding(e, "padding-top", n) - rt._calculatePadding(e, "padding-bottom", n),
                            a = rt.getConstraintHeight(t);
                        return isNaN(a) ? i : Math.min(i, a)
                    }, rt.getStyle = function(t, e) {
                        return t.currentStyle ? t.currentStyle[e] : document.defaultView.getComputedStyle(t, null).getPropertyValue(e)
                    }, rt.retinaScale = function(t, e) {
                        var n = t.currentDevicePixelRatio = e || window.devicePixelRatio || 1;
                        if (1 !== n) {
                            var i = t.canvas,
                                a = t.height,
                                r = t.width;
                            i.height = a * n, i.width = r * n, t.ctx.scale(n, n), i.style.height || i.style.width || (i.style.height = a + "px", i.style.width = r + "px")
                        }
                    }, rt.fontString = function(t, e, n) {
                        return e + " " + t + "px " + n
                    }, rt.longestText = function(t, e, n, i) {
                        var a = (i = i || {}).data = i.data || {},
                            r = i.garbageCollect = i.garbageCollect || [];
                        i.font !== e && (a = i.data = {}, r = i.garbageCollect = [], i.font = e), t.font = e;
                        var o, l, s, u, d, c = 0,
                            h = n.length;
                        for (o = 0; o < h; o++)
                            if (void 0 !== (u = n[o]) && null !== u && !0 !== rt.isArray(u)) c = rt.measureText(t, a, r, c, u);
                            else if (rt.isArray(u))
                            for (l = 0, s = u.length; l < s; l++) void 0 === (d = u[l]) || null === d || rt.isArray(d) || (c = rt.measureText(t, a, r, c, d));
                        var f = r.length / 2;
                        if (f > n.length) {
                            for (o = 0; o < f; o++) delete a[r[o]];
                            r.splice(0, f)
                        }
                        return c
                    }, rt.measureText = function(t, e, n, i, a) {
                        var r = e[a];
                        return r || (r = e[a] = t.measureText(a).width, n.push(a)), r > i && (i = r), i
                    }, rt.numberOfLabelLines = function(t) {
                        var e = 1;
                        return rt.each(t, (function(t) {
                            rt.isArray(t) && t.length > e && (e = t.length)
                        })), e
                    }, rt.color = z ? function(t) {
                        return t instanceof CanvasGradient && (t = Z.global.defaultColor), z(t)
                    } : function(t) {
                        return console.error("Color.js not found!"), t
                    }, rt.getHoverColor = function(t) {
                        return t instanceof CanvasPattern || t instanceof CanvasGradient ? t : rt.color(t).saturate(.5).darken(.1).rgbString()
                    }
                };

                function Xn() {
                    throw new Error("This method is not implemented: either no adapter can be found or an incomplete integration was provided.")
                }

                function Kn(t) {
                    this.options = t || {}
                }
                rt.extend(Kn.prototype, {
                    formats: Xn,
                    parse: Xn,
                    format: Xn,
                    add: Xn,
                    diff: Xn,
                    startOf: Xn,
                    endOf: Xn,
                    _create: function(t) {
                        return t
                    }
                }), Kn.override = function(t) {
                    rt.extend(Kn.prototype, t)
                };
                var Zn = {
                        _date: Kn
                    },
                    $n = {
                        formatters: {
                            values: function(t) {
                                return rt.isArray(t) ? t : "" + t
                            },
                            linear: function(t, e, n) {
                                var i = n.length > 3 ? n[2] - n[1] : n[1] - n[0];
                                Math.abs(i) > 1 && t !== Math.floor(t) && (i = t - Math.floor(t));
                                var a = rt.log10(Math.abs(i)),
                                    r = "";
                                if (0 !== t)
                                    if (Math.max(Math.abs(n[0]), Math.abs(n[n.length - 1])) < 1e-4) {
                                        var o = rt.log10(Math.abs(t)),
                                            l = Math.floor(o) - Math.floor(a);
                                        l = Math.max(Math.min(l, 20), 0), r = t.toExponential(l)
                                    } else {
                                        var s = -1 * Math.floor(a);
                                        s = Math.max(Math.min(s, 20), 0), r = t.toFixed(s)
                                    }
                                else r = "0";
                                return r
                            },
                            logarithmic: function(t, e, n) {
                                var i = t / Math.pow(10, Math.floor(rt.log10(t)));
                                return 0 === t ? "0" : 1 === i || 2 === i || 5 === i || 0 === e || e === n.length - 1 ? t.toExponential() : ""
                            }
                        }
                    },
                    Jn = rt.isArray,
                    Qn = rt.isNullOrUndef,
                    ti = rt.valueOrDefault,
                    ei = rt.valueAtIndexOrDefault;

                function ni(t, e) {
                    for (var n = [], i = t.length / e, a = 0, r = t.length; a < r; a += i) n.push(t[Math.floor(a)]);
                    return n
                }

                function ii(t, e, n) {
                    var i, a = t.getTicks().length,
                        r = Math.min(e, a - 1),
                        o = t.getPixelForTick(r),
                        l = t._startPixel,
                        s = t._endPixel,
                        u = 1e-6;
                    if (!(n && (i = 1 === a ? Math.max(o - l, s - o) : 0 === e ? (t.getPixelForTick(1) - o) / 2 : (o - t.getPixelForTick(r - 1)) / 2, (o += r < e ? i : -i) < l - u || o > s + u))) return o
                }

                function ai(t, e) {
                    rt.each(t, (function(t) {
                        var n, i = t.gc,
                            a = i.length / 2;
                        if (a > e) {
                            for (n = 0; n < a; ++n) delete t.data[i[n]];
                            i.splice(0, a)
                        }
                    }))
                }

                function ri(t, e, n, i) {
                    var a, r, o, l, s, u, d, c, h, f, g, p, m, v = n.length,
                        b = [],
                        x = [],
                        y = [];
                    for (a = 0; a < v; ++a) {
                        if (l = n[a].label, s = n[a].major ? e.major : e.minor, t.font = u = s.string, d = i[u] = i[u] || {
                                data: {},
                                gc: []
                            }, c = s.lineHeight, h = f = 0, Qn(l) || Jn(l)) {
                            if (Jn(l))
                                for (r = 0, o = l.length; r < o; ++r) g = l[r], Qn(g) || Jn(g) || (h = rt.measureText(t, d.data, d.gc, h, g), f += c)
                        } else h = rt.measureText(t, d.data, d.gc, h, l), f = c;
                        b.push(h), x.push(f), y.push(c / 2)
                    }

                    function _(t) {
                        return {
                            width: b[t] || 0,
                            height: x[t] || 0,
                            offset: y[t] || 0
                        }
                    }
                    return ai(i, v), p = b.indexOf(Math.max.apply(null, b)), m = x.indexOf(Math.max.apply(null, x)), {
                        first: _(0),
                        last: _(v - 1),
                        widest: _(p),
                        highest: _(m)
                    }
                }

                function oi(t) {
                    return t.drawTicks ? t.tickMarkLength : 0
                }

                function li(t) {
                    var e, n;
                    return t.display ? (e = rt.options._parseFont(t), n = rt.options.toPadding(t.padding), e.lineHeight + n.height) : 0
                }

                function si(t, e) {
                    return rt.extend(rt.options._parseFont({
                        fontFamily: ti(e.fontFamily, t.fontFamily),
                        fontSize: ti(e.fontSize, t.fontSize),
                        fontStyle: ti(e.fontStyle, t.fontStyle),
                        lineHeight: ti(e.lineHeight, t.lineHeight)
                    }), {
                        color: rt.options.resolve([e.fontColor, t.fontColor, Z.global.defaultFontColor])
                    })
                }

                function ui(t) {
                    var e = si(t, t.minor);
                    return {
                        minor: e,
                        major: t.major.enabled ? si(t, t.major) : e
                    }
                }

                function di(t) {
                    var e, n, i, a = [];
                    for (n = 0, i = t.length; n < i; ++n) "undefined" !== typeof(e = t[n])._index && a.push(e);
                    return a
                }

                function ci(t) {
                    var e, n, i = t.length;
                    if (i < 2) return !1;
                    for (n = t[0], e = 1; e < i; ++e)
                        if (t[e] - t[e - 1] !== n) return !1;
                    return n
                }

                function hi(t, e, n, i) {
                    var a, r, o, l, s = ci(t),
                        u = (e.length - 1) / i;
                    if (!s) return Math.max(u, 1);
                    for (o = 0, l = (a = rt.math._factorize(s)).length - 1; o < l; o++)
                        if ((r = a[o]) > u) return r;
                    return Math.max(u, 1)
                }

                function fi(t) {
                    var e, n, i = [];
                    for (e = 0, n = t.length; e < n; e++) t[e].major && i.push(e);
                    return i
                }

                function gi(t, e, n) {
                    var i, a, r = 0,
                        o = e[0];
                    for (n = Math.ceil(n), i = 0; i < t.length; i++) a = t[i], i === o ? (a._index = i, o = e[++r * n]) : delete a.label
                }

                function pi(t, e, n, i) {
                    var a, r, o, l, s = ti(n, 0),
                        u = Math.min(ti(i, t.length), t.length),
                        d = 0;
                    for (e = Math.ceil(e), i && (e = (a = i - n) / Math.floor(a / e)), l = s; l < 0;) d++, l = Math.round(s + d * e);
                    for (r = Math.max(s, 0); r < u; r++) o = t[r], r === l ? (o._index = r, d++, l = Math.round(s + d * e)) : delete o.label
                }
                Z._set("scale", {
                    display: !0,
                    position: "left",
                    offset: !1,
                    gridLines: {
                        display: !0,
                        color: "rgba(0,0,0,0.1)",
                        lineWidth: 1,
                        drawBorder: !0,
                        drawOnChartArea: !0,
                        drawTicks: !0,
                        tickMarkLength: 10,
                        zeroLineWidth: 1,
                        zeroLineColor: "rgba(0,0,0,0.25)",
                        zeroLineBorderDash: [],
                        zeroLineBorderDashOffset: 0,
                        offsetGridLines: !1,
                        borderDash: [],
                        borderDashOffset: 0
                    },
                    scaleLabel: {
                        display: !1,
                        labelString: "",
                        padding: {
                            top: 4,
                            bottom: 4
                        }
                    },
                    ticks: {
                        beginAtZero: !1,
                        minRotation: 0,
                        maxRotation: 50,
                        mirror: !1,
                        padding: 0,
                        reverse: !1,
                        display: !0,
                        autoSkip: !0,
                        autoSkipPadding: 0,
                        labelOffset: 0,
                        callback: $n.formatters.values,
                        minor: {},
                        major: {}
                    }
                });
                var mi = ft.extend({
                    zeroLineIndex: 0,
                    getPadding: function() {
                        var t = this;
                        return {
                            left: t.paddingLeft || 0,
                            top: t.paddingTop || 0,
                            right: t.paddingRight || 0,
                            bottom: t.paddingBottom || 0
                        }
                    },
                    getTicks: function() {
                        return this._ticks
                    },
                    _getLabels: function() {
                        var t = this.chart.data;
                        return this.options.labels || (this.isHorizontal() ? t.xLabels : t.yLabels) || t.labels
                    },
                    mergeTicksOptions: function() {},
                    beforeUpdate: function() {
                        rt.callback(this.options.beforeUpdate, [this])
                    },
                    update: function(t, e, n) {
                        var i, a, r, o, l, s = this,
                            u = s.options.ticks,
                            d = u.sampleSize;
                        if (s.beforeUpdate(), s.maxWidth = t, s.maxHeight = e, s.margins = rt.extend({
                                left: 0,
                                right: 0,
                                top: 0,
                                bottom: 0
                            }, n), s._ticks = null, s.ticks = null, s._labelSizes = null, s._maxLabelLines = 0, s.longestLabelWidth = 0, s.longestTextCache = s.longestTextCache || {}, s._gridLineItems = null, s._labelItems = null, s.beforeSetDimensions(), s.setDimensions(), s.afterSetDimensions(), s.beforeDataLimits(), s.determineDataLimits(), s.afterDataLimits(), s.beforeBuildTicks(), o = s.buildTicks() || [], (!(o = s.afterBuildTicks(o) || o) || !o.length) && s.ticks)
                            for (o = [], i = 0, a = s.ticks.length; i < a; ++i) o.push({
                                value: s.ticks[i],
                                major: !1
                            });
                        return s._ticks = o, l = d < o.length, r = s._convertTicksToLabels(l ? ni(o, d) : o), s._configure(), s.beforeCalculateTickRotation(), s.calculateTickRotation(), s.afterCalculateTickRotation(), s.beforeFit(), s.fit(), s.afterFit(), s._ticksToDraw = u.display && (u.autoSkip || "auto" === u.source) ? s._autoSkip(o) : o, l && (r = s._convertTicksToLabels(s._ticksToDraw)), s.ticks = r, s.afterUpdate(), s.minSize
                    },
                    _configure: function() {
                        var t, e, n = this,
                            i = n.options.ticks.reverse;
                        n.isHorizontal() ? (t = n.left, e = n.right) : (t = n.top, e = n.bottom, i = !i), n._startPixel = t, n._endPixel = e, n._reversePixels = i, n._length = e - t
                    },
                    afterUpdate: function() {
                        rt.callback(this.options.afterUpdate, [this])
                    },
                    beforeSetDimensions: function() {
                        rt.callback(this.options.beforeSetDimensions, [this])
                    },
                    setDimensions: function() {
                        var t = this;
                        t.isHorizontal() ? (t.width = t.maxWidth, t.left = 0, t.right = t.width) : (t.height = t.maxHeight, t.top = 0, t.bottom = t.height), t.paddingLeft = 0, t.paddingTop = 0, t.paddingRight = 0, t.paddingBottom = 0
                    },
                    afterSetDimensions: function() {
                        rt.callback(this.options.afterSetDimensions, [this])
                    },
                    beforeDataLimits: function() {
                        rt.callback(this.options.beforeDataLimits, [this])
                    },
                    determineDataLimits: rt.noop,
                    afterDataLimits: function() {
                        rt.callback(this.options.afterDataLimits, [this])
                    },
                    beforeBuildTicks: function() {
                        rt.callback(this.options.beforeBuildTicks, [this])
                    },
                    buildTicks: rt.noop,
                    afterBuildTicks: function(t) {
                        var e = this;
                        return Jn(t) && t.length ? rt.callback(e.options.afterBuildTicks, [e, t]) : (e.ticks = rt.callback(e.options.afterBuildTicks, [e, e.ticks]) || e.ticks, t)
                    },
                    beforeTickToLabelConversion: function() {
                        rt.callback(this.options.beforeTickToLabelConversion, [this])
                    },
                    convertTicksToLabels: function() {
                        var t = this,
                            e = t.options.ticks;
                        t.ticks = t.ticks.map(e.userCallback || e.callback, this)
                    },
                    afterTickToLabelConversion: function() {
                        rt.callback(this.options.afterTickToLabelConversion, [this])
                    },
                    beforeCalculateTickRotation: function() {
                        rt.callback(this.options.beforeCalculateTickRotation, [this])
                    },
                    calculateTickRotation: function() {
                        var t, e, n, i, a, r, o, l = this,
                            s = l.options,
                            u = s.ticks,
                            d = l.getTicks().length,
                            c = u.minRotation || 0,
                            h = u.maxRotation,
                            f = c;
                        !l._isVisible() || !u.display || c >= h || d <= 1 || !l.isHorizontal() ? l.labelRotation = c : (e = (t = l._getLabelSizes()).widest.width, n = t.highest.height - t.highest.offset, i = Math.min(l.maxWidth, l.chart.width - e), e + 6 > (a = s.offset ? l.maxWidth / d : i / (d - 1)) && (a = i / (d - (s.offset ? .5 : 1)), r = l.maxHeight - oi(s.gridLines) - u.padding - li(s.scaleLabel), o = Math.sqrt(e * e + n * n), f = rt.toDegrees(Math.min(Math.asin(Math.min((t.highest.height + 6) / a, 1)), Math.asin(Math.min(r / o, 1)) - Math.asin(n / o))), f = Math.max(c, Math.min(h, f))), l.labelRotation = f)
                    },
                    afterCalculateTickRotation: function() {
                        rt.callback(this.options.afterCalculateTickRotation, [this])
                    },
                    beforeFit: function() {
                        rt.callback(this.options.beforeFit, [this])
                    },
                    fit: function() {
                        var t = this,
                            e = t.minSize = {
                                width: 0,
                                height: 0
                            },
                            n = t.chart,
                            i = t.options,
                            a = i.ticks,
                            r = i.scaleLabel,
                            o = i.gridLines,
                            l = t._isVisible(),
                            s = "bottom" === i.position,
                            u = t.isHorizontal();
                        if (u ? e.width = t.maxWidth : l && (e.width = oi(o) + li(r)), u ? l && (e.height = oi(o) + li(r)) : e.height = t.maxHeight, a.display && l) {
                            var d = ui(a),
                                c = t._getLabelSizes(),
                                h = c.first,
                                f = c.last,
                                g = c.widest,
                                p = c.highest,
                                m = .4 * d.minor.lineHeight,
                                v = a.padding;
                            if (u) {
                                var b = 0 !== t.labelRotation,
                                    x = rt.toRadians(t.labelRotation),
                                    y = Math.cos(x),
                                    _ = Math.sin(x),
                                    k = _ * g.width + y * (p.height - (b ? p.offset : 0)) + (b ? 0 : m);
                                e.height = Math.min(t.maxHeight, e.height + k + v);
                                var w, M, S = t.getPixelForTick(0) - t.left,
                                    C = t.right - t.getPixelForTick(t.getTicks().length - 1);
                                b ? (w = s ? y * h.width + _ * h.offset : _ * (h.height - h.offset), M = s ? _ * (f.height - f.offset) : y * f.width + _ * f.offset) : (w = h.width / 2, M = f.width / 2), t.paddingLeft = Math.max((w - S) * t.width / (t.width - S), 0) + 3, t.paddingRight = Math.max((M - C) * t.width / (t.width - C), 0) + 3
                            } else {
                                var P = a.mirror ? 0 : g.width + v + m;
                                e.width = Math.min(t.maxWidth, e.width + P), t.paddingTop = h.height / 2, t.paddingBottom = f.height / 2
                            }
                        }
                        t.handleMargins(), u ? (t.width = t._length = n.width - t.margins.left - t.margins.right, t.height = e.height) : (t.width = e.width, t.height = t._length = n.height - t.margins.top - t.margins.bottom)
                    },
                    handleMargins: function() {
                        var t = this;
                        t.margins && (t.margins.left = Math.max(t.paddingLeft, t.margins.left), t.margins.top = Math.max(t.paddingTop, t.margins.top), t.margins.right = Math.max(t.paddingRight, t.margins.right), t.margins.bottom = Math.max(t.paddingBottom, t.margins.bottom))
                    },
                    afterFit: function() {
                        rt.callback(this.options.afterFit, [this])
                    },
                    isHorizontal: function() {
                        var t = this.options.position;
                        return "top" === t || "bottom" === t
                    },
                    isFullWidth: function() {
                        return this.options.fullWidth
                    },
                    getRightValue: function(t) {
                        if (Qn(t)) return NaN;
                        if (("number" === typeof t || t instanceof Number) && !isFinite(t)) return NaN;
                        if (t)
                            if (this.isHorizontal()) {
                                if (void 0 !== t.x) return this.getRightValue(t.x)
                            } else if (void 0 !== t.y) return this.getRightValue(t.y);
                        return t
                    },
                    _convertTicksToLabels: function(t) {
                        var e, n, i, a = this;
                        for (a.ticks = t.map((function(t) {
                                return t.value
                            })), a.beforeTickToLabelConversion(), e = a.convertTicksToLabels(t) || a.ticks, a.afterTickToLabelConversion(), n = 0, i = t.length; n < i; ++n) t[n].label = e[n];
                        return e
                    },
                    _getLabelSizes: function() {
                        var t = this,
                            e = t._labelSizes;
                        return e || (t._labelSizes = e = ri(t.ctx, ui(t.options.ticks), t.getTicks(), t.longestTextCache), t.longestLabelWidth = e.widest.width), e
                    },
                    _parseValue: function(t) {
                        var e, n, i, a;
                        return Jn(t) ? (e = +this.getRightValue(t[0]), n = +this.getRightValue(t[1]), i = Math.min(e, n), a = Math.max(e, n)) : (e = void 0, n = t = +this.getRightValue(t), i = t, a = t), {
                            min: i,
                            max: a,
                            start: e,
                            end: n
                        }
                    },
                    _getScaleLabel: function(t) {
                        var e = this._parseValue(t);
                        return void 0 !== e.start ? "[" + e.start + ", " + e.end + "]" : +this.getRightValue(t)
                    },
                    getLabelForIndex: rt.noop,
                    getPixelForValue: rt.noop,
                    getValueForPixel: rt.noop,
                    getPixelForTick: function(t) {
                        var e = this,
                            n = e.options.offset,
                            i = e._ticks.length,
                            a = 1 / Math.max(i - (n ? 0 : 1), 1);
                        return t < 0 || t > i - 1 ? null : e.getPixelForDecimal(t * a + (n ? a / 2 : 0))
                    },
                    getPixelForDecimal: function(t) {
                        var e = this;
                        return e._reversePixels && (t = 1 - t), e._startPixel + t * e._length
                    },
                    getDecimalForPixel: function(t) {
                        var e = (t - this._startPixel) / this._length;
                        return this._reversePixels ? 1 - e : e
                    },
                    getBasePixel: function() {
                        return this.getPixelForValue(this.getBaseValue())
                    },
                    getBaseValue: function() {
                        var t = this,
                            e = t.min,
                            n = t.max;
                        return t.beginAtZero ? 0 : e < 0 && n < 0 ? n : e > 0 && n > 0 ? e : 0
                    },
                    _autoSkip: function(t) {
                        var e, n, i, a, r = this,
                            o = r.options.ticks,
                            l = r._length,
                            s = o.maxTicksLimit || l / r._tickSize() + 1,
                            u = o.major.enabled ? fi(t) : [],
                            d = u.length,
                            c = u[0],
                            h = u[d - 1];
                        if (d > s) return gi(t, u, d / s), di(t);
                        if (i = hi(u, t, l, s), d > 0) {
                            for (e = 0, n = d - 1; e < n; e++) pi(t, i, u[e], u[e + 1]);
                            return a = d > 1 ? (h - c) / (d - 1) : null, pi(t, i, rt.isNullOrUndef(a) ? 0 : c - a, c), pi(t, i, h, rt.isNullOrUndef(a) ? t.length : h + a), di(t)
                        }
                        return pi(t, i), di(t)
                    },
                    _tickSize: function() {
                        var t = this,
                            e = t.options.ticks,
                            n = rt.toRadians(t.labelRotation),
                            i = Math.abs(Math.cos(n)),
                            a = Math.abs(Math.sin(n)),
                            r = t._getLabelSizes(),
                            o = e.autoSkipPadding || 0,
                            l = r ? r.widest.width + o : 0,
                            s = r ? r.highest.height + o : 0;
                        return t.isHorizontal() ? s * i > l * a ? l / i : s / a : s * a < l * i ? s / i : l / a
                    },
                    _isVisible: function() {
                        var t, e, n, i = this,
                            a = i.chart,
                            r = i.options.display;
                        if ("auto" !== r) return !!r;
                        for (t = 0, e = a.data.datasets.length; t < e; ++t)
                            if (a.isDatasetVisible(t) && ((n = a.getDatasetMeta(t)).xAxisID === i.id || n.yAxisID === i.id)) return !0;
                        return !1
                    },
                    _computeGridLineItems: function(t) {
                        var e, n, i, a, r, o, l, s, u, d, c, h, f, g, p, m, v, b = this,
                            x = b.chart,
                            y = b.options,
                            _ = y.gridLines,
                            k = y.position,
                            w = _.offsetGridLines,
                            M = b.isHorizontal(),
                            S = b._ticksToDraw,
                            C = S.length + (w ? 1 : 0),
                            P = oi(_),
                            A = [],
                            D = _.drawBorder ? ei(_.lineWidth, 0, 0) : 0,
                            T = D / 2,
                            I = rt._alignPixel,
                            F = function(t) {
                                return I(x, t, D)
                            };
                        for ("top" === k ? (e = F(b.bottom), l = b.bottom - P, u = e - T, c = F(t.top) + T, f = t.bottom) : "bottom" === k ? (e = F(b.top), c = t.top, f = F(t.bottom) - T, l = e + T, u = b.top + P) : "left" === k ? (e = F(b.right), o = b.right - P, s = e - T, d = F(t.left) + T, h = t.right) : (e = F(b.left), d = t.left, h = F(t.right) - T, o = e + T, s = b.left + P), n = 0; n < C; ++n) i = S[n] || {}, Qn(i.label) && n < S.length || (n === b.zeroLineIndex && y.offset === w ? (g = _.zeroLineWidth, p = _.zeroLineColor, m = _.zeroLineBorderDash || [], v = _.zeroLineBorderDashOffset || 0) : (g = ei(_.lineWidth, n, 1), p = ei(_.color, n, "rgba(0,0,0,0.1)"), m = _.borderDash || [], v = _.borderDashOffset || 0), void 0 !== (a = ii(b, i._index || n, w)) && (r = I(x, a, g), M ? o = s = d = h = r : l = u = c = f = r, A.push({
                            tx1: o,
                            ty1: l,
                            tx2: s,
                            ty2: u,
                            x1: d,
                            y1: c,
                            x2: h,
                            y2: f,
                            width: g,
                            color: p,
                            borderDash: m,
                            borderDashOffset: v
                        })));
                        return A.ticksLength = C, A.borderValue = e, A
                    },
                    _computeLabelItems: function() {
                        var t, e, n, i, a, r, o, l, s, u, d, c, h = this,
                            f = h.options,
                            g = f.ticks,
                            p = f.position,
                            m = g.mirror,
                            v = h.isHorizontal(),
                            b = h._ticksToDraw,
                            x = ui(g),
                            y = g.padding,
                            _ = oi(f.gridLines),
                            k = -rt.toRadians(h.labelRotation),
                            w = [];
                        for ("top" === p ? (r = h.bottom - _ - y, o = k ? "left" : "center") : "bottom" === p ? (r = h.top + _ + y, o = k ? "right" : "center") : "left" === p ? (a = h.right - (m ? 0 : _) - y, o = m ? "left" : "right") : (a = h.left + (m ? 0 : _) + y, o = m ? "right" : "left"), t = 0, e = b.length; t < e; ++t) i = (n = b[t]).label, Qn(i) || (l = h.getPixelForTick(n._index || t) + g.labelOffset, u = (s = n.major ? x.major : x.minor).lineHeight, d = Jn(i) ? i.length : 1, v ? (a = l, c = "top" === p ? ((k ? 1 : .5) - d) * u : (k ? 0 : .5) * u) : (r = l, c = (1 - d) * u / 2), w.push({
                            x: a,
                            y: r,
                            rotation: k,
                            label: i,
                            font: s,
                            textOffset: c,
                            textAlign: o
                        }));
                        return w
                    },
                    _drawGrid: function(t) {
                        var e = this,
                            n = e.options.gridLines;
                        if (n.display) {
                            var i, a, r, o, l, s = e.ctx,
                                u = e.chart,
                                d = rt._alignPixel,
                                c = n.drawBorder ? ei(n.lineWidth, 0, 0) : 0,
                                h = e._gridLineItems || (e._gridLineItems = e._computeGridLineItems(t));
                            for (r = 0, o = h.length; r < o; ++r) i = (l = h[r]).width, a = l.color, i && a && (s.save(), s.lineWidth = i, s.strokeStyle = a, s.setLineDash && (s.setLineDash(l.borderDash), s.lineDashOffset = l.borderDashOffset), s.beginPath(), n.drawTicks && (s.moveTo(l.tx1, l.ty1), s.lineTo(l.tx2, l.ty2)), n.drawOnChartArea && (s.moveTo(l.x1, l.y1), s.lineTo(l.x2, l.y2)), s.stroke(), s.restore());
                            if (c) {
                                var f, g, p, m, v = c,
                                    b = ei(n.lineWidth, h.ticksLength - 1, 1),
                                    x = h.borderValue;
                                e.isHorizontal() ? (f = d(u, e.left, v) - v / 2, g = d(u, e.right, b) + b / 2, p = m = x) : (p = d(u, e.top, v) - v / 2, m = d(u, e.bottom, b) + b / 2, f = g = x), s.lineWidth = c, s.strokeStyle = ei(n.color, 0), s.beginPath(), s.moveTo(f, p), s.lineTo(g, m), s.stroke()
                            }
                        }
                    },
                    _drawLabels: function() {
                        var t = this;
                        if (t.options.ticks.display) {
                            var e, n, i, a, r, o, l, s, u = t.ctx,
                                d = t._labelItems || (t._labelItems = t._computeLabelItems());
                            for (e = 0, i = d.length; e < i; ++e) {
                                if (o = (r = d[e]).font, u.save(), u.translate(r.x, r.y), u.rotate(r.rotation), u.font = o.string, u.fillStyle = o.color, u.textBaseline = "middle", u.textAlign = r.textAlign, l = r.label, s = r.textOffset, Jn(l))
                                    for (n = 0, a = l.length; n < a; ++n) u.fillText("" + l[n], 0, s), s += o.lineHeight;
                                else u.fillText(l, 0, s);
                                u.restore()
                            }
                        }
                    },
                    _drawTitle: function() {
                        var t = this,
                            e = t.ctx,
                            n = t.options,
                            i = n.scaleLabel;
                        if (i.display) {
                            var a, r, o = ti(i.fontColor, Z.global.defaultFontColor),
                                l = rt.options._parseFont(i),
                                s = rt.options.toPadding(i.padding),
                                u = l.lineHeight / 2,
                                d = n.position,
                                c = 0;
                            if (t.isHorizontal()) a = t.left + t.width / 2, r = "bottom" === d ? t.bottom - u - s.bottom : t.top + u + s.top;
                            else {
                                var h = "left" === d;
                                a = h ? t.left + u + s.top : t.right - u - s.top, r = t.top + t.height / 2, c = h ? -.5 * Math.PI : .5 * Math.PI
                            }
                            e.save(), e.translate(a, r), e.rotate(c), e.textAlign = "center", e.textBaseline = "middle", e.fillStyle = o, e.font = l.string, e.fillText(i.labelString, 0, 0), e.restore()
                        }
                    },
                    draw: function(t) {
                        var e = this;
                        e._isVisible() && (e._drawGrid(t), e._drawTitle(), e._drawLabels())
                    },
                    _layers: function() {
                        var t = this,
                            e = t.options,
                            n = e.ticks && e.ticks.z || 0,
                            i = e.gridLines && e.gridLines.z || 0;
                        return t._isVisible() && n !== i && t.draw === t._draw ? [{
                            z: i,
                            draw: function() {
                                t._drawGrid.apply(t, arguments), t._drawTitle.apply(t, arguments)
                            }
                        }, {
                            z: n,
                            draw: function() {
                                t._drawLabels.apply(t, arguments)
                            }
                        }] : [{
                            z: n,
                            draw: function() {
                                t.draw.apply(t, arguments)
                            }
                        }]
                    },
                    _getMatchingVisibleMetas: function(t) {
                        var e = this,
                            n = e.isHorizontal();
                        return e.chart._getSortedVisibleDatasetMetas().filter((function(i) {
                            return (!t || i.type === t) && (n ? i.xAxisID === e.id : i.yAxisID === e.id)
                        }))
                    }
                });
                mi.prototype._draw = mi.prototype.draw;
                var vi = mi,
                    bi = rt.isNullOrUndef,
                    xi = {
                        position: "bottom"
                    },
                    yi = vi.extend({
                        determineDataLimits: function() {
                            var t, e = this,
                                n = e._getLabels(),
                                i = e.options.ticks,
                                a = i.min,
                                r = i.max,
                                o = 0,
                                l = n.length - 1;
                            void 0 !== a && (t = n.indexOf(a)) >= 0 && (o = t), void 0 !== r && (t = n.indexOf(r)) >= 0 && (l = t), e.minIndex = o, e.maxIndex = l, e.min = n[o], e.max = n[l]
                        },
                        buildTicks: function() {
                            var t = this,
                                e = t._getLabels(),
                                n = t.minIndex,
                                i = t.maxIndex;
                            t.ticks = 0 === n && i === e.length - 1 ? e : e.slice(n, i + 1)
                        },
                        getLabelForIndex: function(t, e) {
                            var n = this,
                                i = n.chart;
                            return i.getDatasetMeta(e).controller._getValueScaleId() === n.id ? n.getRightValue(i.data.datasets[e].data[t]) : n._getLabels()[t]
                        },
                        _configure: function() {
                            var t = this,
                                e = t.options.offset,
                                n = t.ticks;
                            vi.prototype._configure.call(t), t.isHorizontal() || (t._reversePixels = !t._reversePixels), n && (t._startValue = t.minIndex - (e ? .5 : 0), t._valueRange = Math.max(n.length - (e ? 0 : 1), 1))
                        },
                        getPixelForValue: function(t, e, n) {
                            var i, a, r, o = this;
                            return bi(e) || bi(n) || (t = o.chart.data.datasets[n].data[e]), bi(t) || (i = o.isHorizontal() ? t.x : t.y), (void 0 !== i || void 0 !== t && isNaN(e)) && (a = o._getLabels(), t = rt.valueOrDefault(i, t), e = -1 !== (r = a.indexOf(t)) ? r : e, isNaN(e) && (e = t)), o.getPixelForDecimal((e - o._startValue) / o._valueRange)
                        },
                        getPixelForTick: function(t) {
                            var e = this.ticks;
                            return t < 0 || t > e.length - 1 ? null : this.getPixelForValue(e[t], t + this.minIndex)
                        },
                        getValueForPixel: function(t) {
                            var e = this,
                                n = Math.round(e._startValue + e.getDecimalForPixel(t) * e._valueRange);
                            return Math.min(Math.max(n, 0), e.ticks.length - 1)
                        },
                        getBasePixel: function() {
                            return this.bottom
                        }
                    }),
                    _i = xi;
                yi._defaults = _i;
                var ki = rt.noop,
                    wi = rt.isNullOrUndef;

                function Mi(t, e) {
                    var n, i, a, r, o = [],
                        l = 1e-14,
                        s = t.stepSize,
                        u = s || 1,
                        d = t.maxTicks - 1,
                        c = t.min,
                        h = t.max,
                        f = t.precision,
                        g = e.min,
                        p = e.max,
                        m = rt.niceNum((p - g) / d / u) * u;
                    if (m < l && wi(c) && wi(h)) return [g, p];
                    (r = Math.ceil(p / m) - Math.floor(g / m)) > d && (m = rt.niceNum(r * m / d / u) * u), s || wi(f) ? n = Math.pow(10, rt._decimalPlaces(m)) : (n = Math.pow(10, f), m = Math.ceil(m * n) / n), i = Math.floor(g / m) * m, a = Math.ceil(p / m) * m, s && (!wi(c) && rt.almostWhole(c / m, m / 1e3) && (i = c), !wi(h) && rt.almostWhole(h / m, m / 1e3) && (a = h)), r = (a - i) / m, r = rt.almostEquals(r, Math.round(r), m / 1e3) ? Math.round(r) : Math.ceil(r), i = Math.round(i * n) / n, a = Math.round(a * n) / n, o.push(wi(c) ? i : c);
                    for (var v = 1; v < r; ++v) o.push(Math.round((i + v * m) * n) / n);
                    return o.push(wi(h) ? a : h), o
                }
                var Si = vi.extend({
                        getRightValue: function(t) {
                            return "string" === typeof t ? +t : vi.prototype.getRightValue.call(this, t)
                        },
                        handleTickRangeOptions: function() {
                            var t = this,
                                e = t.options.ticks;
                            if (e.beginAtZero) {
                                var n = rt.sign(t.min),
                                    i = rt.sign(t.max);
                                n < 0 && i < 0 ? t.max = 0 : n > 0 && i > 0 && (t.min = 0)
                            }
                            var a = void 0 !== e.min || void 0 !== e.suggestedMin,
                                r = void 0 !== e.max || void 0 !== e.suggestedMax;
                            void 0 !== e.min ? t.min = e.min : void 0 !== e.suggestedMin && (null === t.min ? t.min = e.suggestedMin : t.min = Math.min(t.min, e.suggestedMin)), void 0 !== e.max ? t.max = e.max : void 0 !== e.suggestedMax && (null === t.max ? t.max = e.suggestedMax : t.max = Math.max(t.max, e.suggestedMax)), a !== r && t.min >= t.max && (a ? t.max = t.min + 1 : t.min = t.max - 1), t.min === t.max && (t.max++, e.beginAtZero || t.min--)
                        },
                        getTickLimit: function() {
                            var t, e = this,
                                n = e.options.ticks,
                                i = n.stepSize,
                                a = n.maxTicksLimit;
                            return i ? t = Math.ceil(e.max / i) - Math.floor(e.min / i) + 1 : (t = e._computeTickLimit(), a = a || 11), a && (t = Math.min(a, t)), t
                        },
                        _computeTickLimit: function() {
                            return Number.POSITIVE_INFINITY
                        },
                        handleDirectionalChanges: ki,
                        buildTicks: function() {
                            var t = this,
                                e = t.options.ticks,
                                n = t.getTickLimit(),
                                i = {
                                    maxTicks: n = Math.max(2, n),
                                    min: e.min,
                                    max: e.max,
                                    precision: e.precision,
                                    stepSize: rt.valueOrDefault(e.fixedStepSize, e.stepSize)
                                },
                                a = t.ticks = Mi(i, t);
                            t.handleDirectionalChanges(), t.max = rt.max(a), t.min = rt.min(a), e.reverse ? (a.reverse(), t.start = t.max, t.end = t.min) : (t.start = t.min, t.end = t.max)
                        },
                        convertTicksToLabels: function() {
                            var t = this;
                            t.ticksAsNumbers = t.ticks.slice(), t.zeroLineIndex = t.ticks.indexOf(0), vi.prototype.convertTicksToLabels.call(t)
                        },
                        _configure: function() {
                            var t, e = this,
                                n = e.getTicks(),
                                i = e.min,
                                a = e.max;
                            vi.prototype._configure.call(e), e.options.offset && n.length && (i -= t = (a - i) / Math.max(n.length - 1, 1) / 2, a += t), e._startValue = i, e._endValue = a, e._valueRange = a - i
                        }
                    }),
                    Ci = {
                        position: "left",
                        ticks: {
                            callback: $n.formatters.linear
                        }
                    },
                    Pi = 0,
                    Ai = 1;

                function Di(t, e, n) {
                    var i = [n.type, void 0 === e && void 0 === n.stack ? n.index : "", n.stack].join(".");
                    return void 0 === t[i] && (t[i] = {
                        pos: [],
                        neg: []
                    }), t[i]
                }

                function Ti(t, e, n, i) {
                    var a, r, o = t.options,
                        l = Di(e, o.stacked, n),
                        s = l.pos,
                        u = l.neg,
                        d = i.length;
                    for (a = 0; a < d; ++a) r = t._parseValue(i[a]), isNaN(r.min) || isNaN(r.max) || n.data[a].hidden || (s[a] = s[a] || 0, u[a] = u[a] || 0, o.relativePoints ? s[a] = 100 : r.min < 0 || r.max < 0 ? u[a] += r.min : s[a] += r.max)
                }

                function Ii(t, e, n) {
                    var i, a, r = n.length;
                    for (i = 0; i < r; ++i) a = t._parseValue(n[i]), isNaN(a.min) || isNaN(a.max) || e.data[i].hidden || (t.min = Math.min(t.min, a.min), t.max = Math.max(t.max, a.max))
                }
                var Fi = Si.extend({
                        determineDataLimits: function() {
                            var t, e, n, i, a = this,
                                r = a.options,
                                o = a.chart.data.datasets,
                                l = a._getMatchingVisibleMetas(),
                                s = r.stacked,
                                u = {},
                                d = l.length;
                            if (a.min = Number.POSITIVE_INFINITY, a.max = Number.NEGATIVE_INFINITY, void 0 === s)
                                for (t = 0; !s && t < d; ++t) s = void 0 !== (e = l[t]).stack;
                            for (t = 0; t < d; ++t) n = o[(e = l[t]).index].data, s ? Ti(a, u, e, n) : Ii(a, e, n);
                            rt.each(u, (function(t) {
                                i = t.pos.concat(t.neg), a.min = Math.min(a.min, rt.min(i)), a.max = Math.max(a.max, rt.max(i))
                            })), a.min = rt.isFinite(a.min) && !isNaN(a.min) ? a.min : Pi, a.max = rt.isFinite(a.max) && !isNaN(a.max) ? a.max : Ai, a.handleTickRangeOptions()
                        },
                        _computeTickLimit: function() {
                            var t, e = this;
                            return e.isHorizontal() ? Math.ceil(e.width / 40) : (t = rt.options._parseFont(e.options.ticks), Math.ceil(e.height / t.lineHeight))
                        },
                        handleDirectionalChanges: function() {
                            this.isHorizontal() || this.ticks.reverse()
                        },
                        getLabelForIndex: function(t, e) {
                            return this._getScaleLabel(this.chart.data.datasets[e].data[t])
                        },
                        getPixelForValue: function(t) {
                            var e = this;
                            return e.getPixelForDecimal((+e.getRightValue(t) - e._startValue) / e._valueRange)
                        },
                        getValueForPixel: function(t) {
                            return this._startValue + this.getDecimalForPixel(t) * this._valueRange
                        },
                        getPixelForTick: function(t) {
                            var e = this.ticksAsNumbers;
                            return t < 0 || t > e.length - 1 ? null : this.getPixelForValue(e[t])
                        }
                    }),
                    Oi = Ci;
                Fi._defaults = Oi;
                var Li = rt.valueOrDefault,
                    Ri = rt.math.log10;

                function zi(t, e) {
                    var n, i, a = [],
                        r = Li(t.min, Math.pow(10, Math.floor(Ri(e.min)))),
                        o = Math.floor(Ri(e.max)),
                        l = Math.ceil(e.max / Math.pow(10, o));
                    0 === r ? (n = Math.floor(Ri(e.minNotZero)), i = Math.floor(e.minNotZero / Math.pow(10, n)), a.push(r), r = i * Math.pow(10, n)) : (n = Math.floor(Ri(r)), i = Math.floor(r / Math.pow(10, n)));
                    var s = n < 0 ? Math.pow(10, Math.abs(n)) : 1;
                    do {
                        a.push(r), 10 === ++i && (i = 1, s = ++n >= 0 ? 1 : s), r = Math.round(i * Math.pow(10, n) * s) / s
                    } while (n < o || n === o && i < l);
                    var u = Li(t.max, r);
                    return a.push(u), a
                }
                var Ni = {
                    position: "left",
                    ticks: {
                        callback: $n.formatters.logarithmic
                    }
                };

                function Bi(t, e) {
                    return rt.isFinite(t) && t >= 0 ? t : e
                }
                var Ei = vi.extend({
                        determineDataLimits: function() {
                            var t, e, n, i, a, r, o = this,
                                l = o.options,
                                s = o.chart,
                                u = s.data.datasets,
                                d = o.isHorizontal();

                            function c(t) {
                                return d ? t.xAxisID === o.id : t.yAxisID === o.id
                            }
                            o.min = Number.POSITIVE_INFINITY, o.max = Number.NEGATIVE_INFINITY, o.minNotZero = Number.POSITIVE_INFINITY;
                            var h = l.stacked;
                            if (void 0 === h)
                                for (t = 0; t < u.length; t++)
                                    if (e = s.getDatasetMeta(t), s.isDatasetVisible(t) && c(e) && void 0 !== e.stack) {
                                        h = !0;
                                        break
                                    }
                            if (l.stacked || h) {
                                var f = {};
                                for (t = 0; t < u.length; t++) {
                                    var g = [(e = s.getDatasetMeta(t)).type, void 0 === l.stacked && void 0 === e.stack ? t : "", e.stack].join(".");
                                    if (s.isDatasetVisible(t) && c(e))
                                        for (void 0 === f[g] && (f[g] = []), a = 0, r = (i = u[t].data).length; a < r; a++) {
                                            var p = f[g];
                                            n = o._parseValue(i[a]), isNaN(n.min) || isNaN(n.max) || e.data[a].hidden || n.min < 0 || n.max < 0 || (p[a] = p[a] || 0, p[a] += n.max)
                                        }
                                }
                                rt.each(f, (function(t) {
                                    if (t.length > 0) {
                                        var e = rt.min(t),
                                            n = rt.max(t);
                                        o.min = Math.min(o.min, e), o.max = Math.max(o.max, n)
                                    }
                                }))
                            } else
                                for (t = 0; t < u.length; t++)
                                    if (e = s.getDatasetMeta(t), s.isDatasetVisible(t) && c(e))
                                        for (a = 0, r = (i = u[t].data).length; a < r; a++) n = o._parseValue(i[a]), isNaN(n.min) || isNaN(n.max) || e.data[a].hidden || n.min < 0 || n.max < 0 || (o.min = Math.min(n.min, o.min), o.max = Math.max(n.max, o.max), 0 !== n.min && (o.minNotZero = Math.min(n.min, o.minNotZero)));
                            o.min = rt.isFinite(o.min) ? o.min : null, o.max = rt.isFinite(o.max) ? o.max : null, o.minNotZero = rt.isFinite(o.minNotZero) ? o.minNotZero : null, this.handleTickRangeOptions()
                        },
                        handleTickRangeOptions: function() {
                            var t = this,
                                e = t.options.ticks,
                                n = 1,
                                i = 10;
                            t.min = Bi(e.min, t.min), t.max = Bi(e.max, t.max), t.min === t.max && (0 !== t.min && null !== t.min ? (t.min = Math.pow(10, Math.floor(Ri(t.min)) - 1), t.max = Math.pow(10, Math.floor(Ri(t.max)) + 1)) : (t.min = n, t.max = i)), null === t.min && (t.min = Math.pow(10, Math.floor(Ri(t.max)) - 1)), null === t.max && (t.max = 0 !== t.min ? Math.pow(10, Math.floor(Ri(t.min)) + 1) : i), null === t.minNotZero && (t.min > 0 ? t.minNotZero = t.min : t.max < 1 ? t.minNotZero = Math.pow(10, Math.floor(Ri(t.max))) : t.minNotZero = n)
                        },
                        buildTicks: function() {
                            var t = this,
                                e = t.options.ticks,
                                n = !t.isHorizontal(),
                                i = {
                                    min: Bi(e.min),
                                    max: Bi(e.max)
                                },
                                a = t.ticks = zi(i, t);
                            t.max = rt.max(a), t.min = rt.min(a), e.reverse ? (n = !n, t.start = t.max, t.end = t.min) : (t.start = t.min, t.end = t.max), n && a.reverse()
                        },
                        convertTicksToLabels: function() {
                            this.tickValues = this.ticks.slice(), vi.prototype.convertTicksToLabels.call(this)
                        },
                        getLabelForIndex: function(t, e) {
                            return this._getScaleLabel(this.chart.data.datasets[e].data[t])
                        },
                        getPixelForTick: function(t) {
                            var e = this.tickValues;
                            return t < 0 || t > e.length - 1 ? null : this.getPixelForValue(e[t])
                        },
                        _getFirstTickValue: function(t) {
                            var e = Math.floor(Ri(t));
                            return Math.floor(t / Math.pow(10, e)) * Math.pow(10, e)
                        },
                        _configure: function() {
                            var t = this,
                                e = t.min,
                                n = 0;
                            vi.prototype._configure.call(t), 0 === e && (e = t._getFirstTickValue(t.minNotZero), n = Li(t.options.ticks.fontSize, Z.global.defaultFontSize) / t._length), t._startValue = Ri(e), t._valueOffset = n, t._valueRange = (Ri(t.max) - Ri(e)) / (1 - n)
                        },
                        getPixelForValue: function(t) {
                            var e = this,
                                n = 0;
                            return (t = +e.getRightValue(t)) > e.min && t > 0 && (n = (Ri(t) - e._startValue) / e._valueRange + e._valueOffset), e.getPixelForDecimal(n)
                        },
                        getValueForPixel: function(t) {
                            var e = this,
                                n = e.getDecimalForPixel(t);
                            return 0 === n && 0 === e.min ? 0 : Math.pow(10, e._startValue + (n - e._valueOffset) * e._valueRange)
                        }
                    }),
                    Wi = Ni;
                Ei._defaults = Wi;
                var Vi = rt.valueOrDefault,
                    Hi = rt.valueAtIndexOrDefault,
                    ji = rt.options.resolve,
                    qi = {
                        display: !0,
                        animate: !0,
                        position: "chartArea",
                        angleLines: {
                            display: !0,
                            color: "rgba(0,0,0,0.1)",
                            lineWidth: 1,
                            borderDash: [],
                            borderDashOffset: 0
                        },
                        gridLines: {
                            circular: !1
                        },
                        ticks: {
                            showLabelBackdrop: !0,
                            backdropColor: "rgba(255,255,255,0.75)",
                            backdropPaddingY: 2,
                            backdropPaddingX: 2,
                            callback: $n.formatters.linear
                        },
                        pointLabels: {
                            display: !0,
                            fontSize: 10,
                            callback: function(t) {
                                return t
                            }
                        }
                    };

                function Ui(t) {
                    var e = t.ticks;
                    return e.display && t.display ? Vi(e.fontSize, Z.global.defaultFontSize) + 2 * e.backdropPaddingY : 0
                }

                function Yi(t, e, n) {
                    return rt.isArray(n) ? {
                        w: rt.longestText(t, t.font, n),
                        h: n.length * e
                    } : {
                        w: t.measureText(n).width,
                        h: e
                    }
                }

                function Gi(t, e, n, i, a) {
                    return t === i || t === a ? {
                        start: e - n / 2,
                        end: e + n / 2
                    } : t < i || t > a ? {
                        start: e - n,
                        end: e
                    } : {
                        start: e,
                        end: e + n
                    }
                }

                function Xi(t) {
                    var e, n, i, a = rt.options._parseFont(t.options.pointLabels),
                        r = {
                            l: 0,
                            r: t.width,
                            t: 0,
                            b: t.height - t.paddingTop
                        },
                        o = {};
                    t.ctx.font = a.string, t._pointLabelSizes = [];
                    var l = t.chart.data.labels.length;
                    for (e = 0; e < l; e++) {
                        i = t.getPointPosition(e, t.drawingArea + 5), n = Yi(t.ctx, a.lineHeight, t.pointLabels[e]), t._pointLabelSizes[e] = n;
                        var s = t.getIndexAngle(e),
                            u = rt.toDegrees(s) % 360,
                            d = Gi(u, i.x, n.w, 0, 180),
                            c = Gi(u, i.y, n.h, 90, 270);
                        d.start < r.l && (r.l = d.start, o.l = s), d.end > r.r && (r.r = d.end, o.r = s), c.start < r.t && (r.t = c.start, o.t = s), c.end > r.b && (r.b = c.end, o.b = s)
                    }
                    t.setReductions(t.drawingArea, r, o)
                }

                function Ki(t) {
                    return 0 === t || 180 === t ? "center" : t < 180 ? "left" : "right"
                }

                function Zi(t, e, n, i) {
                    var a, r, o = n.y + i / 2;
                    if (rt.isArray(e))
                        for (a = 0, r = e.length; a < r; ++a) t.fillText(e[a], n.x, o), o += i;
                    else t.fillText(e, n.x, o)
                }

                function $i(t, e, n) {
                    90 === t || 270 === t ? n.y -= e.h / 2 : (t > 270 || t < 90) && (n.y -= e.h)
                }

                function Ji(t) {
                    var e = t.ctx,
                        n = t.options,
                        i = n.pointLabels,
                        a = Ui(n),
                        r = t.getDistanceFromCenterForValue(n.ticks.reverse ? t.min : t.max),
                        o = rt.options._parseFont(i);
                    e.save(), e.font = o.string, e.textBaseline = "middle";
                    for (var l = t.chart.data.labels.length - 1; l >= 0; l--) {
                        var s = 0 === l ? a / 2 : 0,
                            u = t.getPointPosition(l, r + s + 5),
                            d = Hi(i.fontColor, l, Z.global.defaultFontColor);
                        e.fillStyle = d;
                        var c = t.getIndexAngle(l),
                            h = rt.toDegrees(c);
                        e.textAlign = Ki(h), $i(h, t._pointLabelSizes[l], u), Zi(e, t.pointLabels[l], u, o.lineHeight)
                    }
                    e.restore()
                }

                function Qi(t, e, n, i) {
                    var a, r = t.ctx,
                        o = e.circular,
                        l = t.chart.data.labels.length,
                        s = Hi(e.color, i - 1),
                        u = Hi(e.lineWidth, i - 1);
                    if ((o || l) && s && u) {
                        if (r.save(), r.strokeStyle = s, r.lineWidth = u, r.setLineDash && (r.setLineDash(e.borderDash || []), r.lineDashOffset = e.borderDashOffset || 0), r.beginPath(), o) r.arc(t.xCenter, t.yCenter, n, 0, 2 * Math.PI);
                        else {
                            a = t.getPointPosition(0, n), r.moveTo(a.x, a.y);
                            for (var d = 1; d < l; d++) a = t.getPointPosition(d, n), r.lineTo(a.x, a.y)
                        }
                        r.closePath(), r.stroke(), r.restore()
                    }
                }

                function ta(t) {
                    return rt.isNumber(t) ? t : 0
                }
                var ea = Si.extend({
                        setDimensions: function() {
                            var t = this;
                            t.width = t.maxWidth, t.height = t.maxHeight, t.paddingTop = Ui(t.options) / 2, t.xCenter = Math.floor(t.width / 2), t.yCenter = Math.floor((t.height - t.paddingTop) / 2), t.drawingArea = Math.min(t.height - t.paddingTop, t.width) / 2
                        },
                        determineDataLimits: function() {
                            var t = this,
                                e = t.chart,
                                n = Number.POSITIVE_INFINITY,
                                i = Number.NEGATIVE_INFINITY;
                            rt.each(e.data.datasets, (function(a, r) {
                                if (e.isDatasetVisible(r)) {
                                    var o = e.getDatasetMeta(r);
                                    rt.each(a.data, (function(e, a) {
                                        var r = +t.getRightValue(e);
                                        isNaN(r) || o.data[a].hidden || (n = Math.min(r, n), i = Math.max(r, i))
                                    }))
                                }
                            })), t.min = n === Number.POSITIVE_INFINITY ? 0 : n, t.max = i === Number.NEGATIVE_INFINITY ? 0 : i, t.handleTickRangeOptions()
                        },
                        _computeTickLimit: function() {
                            return Math.ceil(this.drawingArea / Ui(this.options))
                        },
                        convertTicksToLabels: function() {
                            var t = this;
                            Si.prototype.convertTicksToLabels.call(t), t.pointLabels = t.chart.data.labels.map((function() {
                                var e = rt.callback(t.options.pointLabels.callback, arguments, t);
                                return e || 0 === e ? e : ""
                            }))
                        },
                        getLabelForIndex: function(t, e) {
                            return +this.getRightValue(this.chart.data.datasets[e].data[t])
                        },
                        fit: function() {
                            var t = this,
                                e = t.options;
                            e.display && e.pointLabels.display ? Xi(t) : t.setCenterPoint(0, 0, 0, 0)
                        },
                        setReductions: function(t, e, n) {
                            var i = this,
                                a = e.l / Math.sin(n.l),
                                r = Math.max(e.r - i.width, 0) / Math.sin(n.r),
                                o = -e.t / Math.cos(n.t),
                                l = -Math.max(e.b - (i.height - i.paddingTop), 0) / Math.cos(n.b);
                            a = ta(a), r = ta(r), o = ta(o), l = ta(l), i.drawingArea = Math.min(Math.floor(t - (a + r) / 2), Math.floor(t - (o + l) / 2)), i.setCenterPoint(a, r, o, l)
                        },
                        setCenterPoint: function(t, e, n, i) {
                            var a = this,
                                r = a.width - e - a.drawingArea,
                                o = t + a.drawingArea,
                                l = n + a.drawingArea,
                                s = a.height - a.paddingTop - i - a.drawingArea;
                            a.xCenter = Math.floor((o + r) / 2 + a.left), a.yCenter = Math.floor((l + s) / 2 + a.top + a.paddingTop)
                        },
                        getIndexAngle: function(t) {
                            var e = this.chart,
                                n = (t * (360 / e.data.labels.length) + ((e.options || {}).startAngle || 0)) % 360;
                            return (n < 0 ? n + 360 : n) * Math.PI * 2 / 360
                        },
                        getDistanceFromCenterForValue: function(t) {
                            var e = this;
                            if (rt.isNullOrUndef(t)) return NaN;
                            var n = e.drawingArea / (e.max - e.min);
                            return e.options.ticks.reverse ? (e.max - t) * n : (t - e.min) * n
                        },
                        getPointPosition: function(t, e) {
                            var n = this,
                                i = n.getIndexAngle(t) - Math.PI / 2;
                            return {
                                x: Math.cos(i) * e + n.xCenter,
                                y: Math.sin(i) * e + n.yCenter
                            }
                        },
                        getPointPositionForValue: function(t, e) {
                            return this.getPointPosition(t, this.getDistanceFromCenterForValue(e))
                        },
                        getBasePosition: function(t) {
                            var e = this,
                                n = e.min,
                                i = e.max;
                            return e.getPointPositionForValue(t || 0, e.beginAtZero ? 0 : n < 0 && i < 0 ? i : n > 0 && i > 0 ? n : 0)
                        },
                        _drawGrid: function() {
                            var t, e, n, i = this,
                                a = i.ctx,
                                r = i.options,
                                o = r.gridLines,
                                l = r.angleLines,
                                s = Vi(l.lineWidth, o.lineWidth),
                                u = Vi(l.color, o.color);
                            if (r.pointLabels.display && Ji(i), o.display && rt.each(i.ticks, (function(t, n) {
                                    0 !== n && (e = i.getDistanceFromCenterForValue(i.ticksAsNumbers[n]), Qi(i, o, e, n))
                                })), l.display && s && u) {
                                for (a.save(), a.lineWidth = s, a.strokeStyle = u, a.setLineDash && (a.setLineDash(ji([l.borderDash, o.borderDash, []])), a.lineDashOffset = ji([l.borderDashOffset, o.borderDashOffset, 0])), t = i.chart.data.labels.length - 1; t >= 0; t--) e = i.getDistanceFromCenterForValue(r.ticks.reverse ? i.min : i.max), n = i.getPointPosition(t, e), a.beginPath(), a.moveTo(i.xCenter, i.yCenter), a.lineTo(n.x, n.y), a.stroke();
                                a.restore()
                            }
                        },
                        _drawLabels: function() {
                            var t = this,
                                e = t.ctx,
                                n = t.options.ticks;
                            if (n.display) {
                                var i, a, r = t.getIndexAngle(0),
                                    o = rt.options._parseFont(n),
                                    l = Vi(n.fontColor, Z.global.defaultFontColor);
                                e.save(), e.font = o.string, e.translate(t.xCenter, t.yCenter), e.rotate(r), e.textAlign = "center", e.textBaseline = "middle", rt.each(t.ticks, (function(r, s) {
                                    (0 !== s || n.reverse) && (i = t.getDistanceFromCenterForValue(t.ticksAsNumbers[s]), n.showLabelBackdrop && (a = e.measureText(r).width, e.fillStyle = n.backdropColor, e.fillRect(-a / 2 - n.backdropPaddingX, -i - o.size / 2 - n.backdropPaddingY, a + 2 * n.backdropPaddingX, o.size + 2 * n.backdropPaddingY)), e.fillStyle = l, e.fillText(r, 0, -i))
                                })), e.restore()
                            }
                        },
                        _drawTitle: rt.noop
                    }),
                    na = qi;
                ea._defaults = na;
                var ia = rt._deprecated,
                    aa = rt.options.resolve,
                    ra = rt.valueOrDefault,
                    oa = Number.MIN_SAFE_INTEGER || -9007199254740991,
                    la = Number.MAX_SAFE_INTEGER || 9007199254740991,
                    sa = {
                        millisecond: {
                            common: !0,
                            size: 1,
                            steps: 1e3
                        },
                        second: {
                            common: !0,
                            size: 1e3,
                            steps: 60
                        },
                        minute: {
                            common: !0,
                            size: 6e4,
                            steps: 60
                        },
                        hour: {
                            common: !0,
                            size: 36e5,
                            steps: 24
                        },
                        day: {
                            common: !0,
                            size: 864e5,
                            steps: 30
                        },
                        week: {
                            common: !1,
                            size: 6048e5,
                            steps: 4
                        },
                        month: {
                            common: !0,
                            size: 2628e6,
                            steps: 12
                        },
                        quarter: {
                            common: !1,
                            size: 7884e6,
                            steps: 4
                        },
                        year: {
                            common: !0,
                            size: 3154e7
                        }
                    },
                    ua = Object.keys(sa);

                function da(t, e) {
                    return t - e
                }

                function ca(t) {
                    var e, n, i, a = {},
                        r = [];
                    for (e = 0, n = t.length; e < n; ++e) a[i = t[e]] || (a[i] = !0, r.push(i));
                    return r
                }

                function ha(t) {
                    return rt.valueOrDefault(t.time.min, t.ticks.min)
                }

                function fa(t) {
                    return rt.valueOrDefault(t.time.max, t.ticks.max)
                }

                function ga(t, e, n, i) {
                    if ("linear" === i || !t.length) return [{
                        time: e,
                        pos: 0
                    }, {
                        time: n,
                        pos: 1
                    }];
                    var a, r, o, l, s, u = [],
                        d = [e];
                    for (a = 0, r = t.length; a < r; ++a)(l = t[a]) > e && l < n && d.push(l);
                    for (d.push(n), a = 0, r = d.length; a < r; ++a) s = d[a + 1], o = d[a - 1], l = d[a], void 0 !== o && void 0 !== s && Math.round((s + o) / 2) === l || u.push({
                        time: l,
                        pos: a / (r - 1)
                    });
                    return u
                }

                function pa(t, e, n) {
                    for (var i, a, r, o = 0, l = t.length - 1; o >= 0 && o <= l;) {
                        if (a = t[(i = o + l >> 1) - 1] || null, r = t[i], !a) return {
                            lo: null,
                            hi: r
                        };
                        if (r[e] < n) o = i + 1;
                        else {
                            if (!(a[e] > n)) return {
                                lo: a,
                                hi: r
                            };
                            l = i - 1
                        }
                    }
                    return {
                        lo: r,
                        hi: null
                    }
                }

                function ma(t, e, n, i) {
                    var a = pa(t, e, n),
                        r = a.lo ? a.hi ? a.lo : t[t.length - 2] : t[0],
                        o = a.lo ? a.hi ? a.hi : t[t.length - 1] : t[1],
                        l = o[e] - r[e],
                        s = l ? (n - r[e]) / l : 0,
                        u = (o[i] - r[i]) * s;
                    return r[i] + u
                }

                function va(t, e) {
                    var n = t._adapter,
                        i = t.options.time,
                        a = i.parser,
                        r = a || i.format,
                        o = e;
                    return "function" === typeof a && (o = a(o)), rt.isFinite(o) || (o = "string" === typeof r ? n.parse(o, r) : n.parse(o)), null !== o ? +o : (a || "function" !== typeof r || (o = r(e), rt.isFinite(o) || (o = n.parse(o))), o)
                }

                function ba(t, e) {
                    if (rt.isNullOrUndef(e)) return null;
                    var n = t.options.time,
                        i = va(t, t.getRightValue(e));
                    return null === i || n.round && (i = +t._adapter.startOf(i, n.round)), i
                }

                function xa(t, e, n, i) {
                    var a, r, o, l = ua.length;
                    for (a = ua.indexOf(t); a < l - 1; ++a)
                        if (o = (r = sa[ua[a]]).steps ? r.steps : la, r.common && Math.ceil((n - e) / (o * r.size)) <= i) return ua[a];
                    return ua[l - 1]
                }

                function ya(t, e, n, i, a) {
                    var r, o;
                    for (r = ua.length - 1; r >= ua.indexOf(n); r--)
                        if (o = ua[r], sa[o].common && t._adapter.diff(a, i, o) >= e - 1) return o;
                    return ua[n ? ua.indexOf(n) : 0]
                }

                function _a(t) {
                    for (var e = ua.indexOf(t) + 1, n = ua.length; e < n; ++e)
                        if (sa[ua[e]].common) return ua[e]
                }

                function ka(t, e, n, i) {
                    var a, r = t._adapter,
                        o = t.options,
                        l = o.time,
                        s = l.unit || xa(l.minUnit, e, n, i),
                        u = aa([l.stepSize, l.unitStepSize, 1]),
                        d = "week" === s && l.isoWeekday,
                        c = e,
                        h = [];
                    if (d && (c = +r.startOf(c, "isoWeek", d)), c = +r.startOf(c, d ? "day" : s), r.diff(n, e, s) > 1e5 * u) throw e + " and " + n + " are too far apart with stepSize of " + u + " " + s;
                    for (a = c; a < n; a = +r.add(a, u, s)) h.push(a);
                    return a !== n && "ticks" !== o.bounds || h.push(a), h
                }

                function wa(t, e, n, i, a) {
                    var r, o, l = 0,
                        s = 0;
                    return a.offset && e.length && (r = ma(t, "time", e[0], "pos"), l = 1 === e.length ? 1 - r : (ma(t, "time", e[1], "pos") - r) / 2, o = ma(t, "time", e[e.length - 1], "pos"), s = 1 === e.length ? o : (o - ma(t, "time", e[e.length - 2], "pos")) / 2), {
                        start: l,
                        end: s,
                        factor: 1 / (l + 1 + s)
                    }
                }

                function Ma(t, e, n, i) {
                    var a, r, o = t._adapter,
                        l = +o.startOf(e[0].value, i),
                        s = e[e.length - 1].value;
                    for (a = l; a <= s; a = +o.add(a, 1, i))(r = n[a]) >= 0 && (e[r].major = !0);
                    return e
                }

                function Sa(t, e, n) {
                    var i, a, r = [],
                        o = {},
                        l = e.length;
                    for (i = 0; i < l; ++i) o[a = e[i]] = i, r.push({
                        value: a,
                        major: !1
                    });
                    return 0 !== l && n ? Ma(t, r, o, n) : r
                }
                var Ca = {
                        position: "bottom",
                        distribution: "linear",
                        bounds: "data",
                        adapters: {},
                        time: {
                            parser: !1,
                            unit: !1,
                            round: !1,
                            displayFormat: !1,
                            isoWeekday: !1,
                            minUnit: "millisecond",
                            displayFormats: {}
                        },
                        ticks: {
                            autoSkip: !1,
                            source: "auto",
                            major: {
                                enabled: !1
                            }
                        }
                    },
                    Pa = vi.extend({
                        initialize: function() {
                            this.mergeTicksOptions(), vi.prototype.initialize.call(this)
                        },
                        update: function() {
                            var t = this,
                                e = t.options,
                                n = e.time || (e.time = {}),
                                i = t._adapter = new Zn._date(e.adapters.date);
                            return ia("time scale", n.format, "time.format", "time.parser"), ia("time scale", n.min, "time.min", "ticks.min"), ia("time scale", n.max, "time.max", "ticks.max"), rt.mergeIf(n.displayFormats, i.formats()), vi.prototype.update.apply(t, arguments)
                        },
                        getRightValue: function(t) {
                            return t && void 0 !== t.t && (t = t.t), vi.prototype.getRightValue.call(this, t)
                        },
                        determineDataLimits: function() {
                            var t, e, n, i, a, r, o, l = this,
                                s = l.chart,
                                u = l._adapter,
                                d = l.options,
                                c = d.time.unit || "day",
                                h = la,
                                f = oa,
                                g = [],
                                p = [],
                                m = [],
                                v = l._getLabels();
                            for (t = 0, n = v.length; t < n; ++t) m.push(ba(l, v[t]));
                            for (t = 0, n = (s.data.datasets || []).length; t < n; ++t)
                                if (s.isDatasetVisible(t))
                                    if (a = s.data.datasets[t].data, rt.isObject(a[0]))
                                        for (p[t] = [], e = 0, i = a.length; e < i; ++e) r = ba(l, a[e]), g.push(r), p[t][e] = r;
                                    else p[t] = m.slice(0), o || (g = g.concat(m), o = !0);
                            else p[t] = [];
                            m.length && (h = Math.min(h, m[0]), f = Math.max(f, m[m.length - 1])), g.length && (g = n > 1 ? ca(g).sort(da) : g.sort(da), h = Math.min(h, g[0]), f = Math.max(f, g[g.length - 1])), h = ba(l, ha(d)) || h, f = ba(l, fa(d)) || f, h = h === la ? +u.startOf(Date.now(), c) : h, f = f === oa ? +u.endOf(Date.now(), c) + 1 : f, l.min = Math.min(h, f), l.max = Math.max(h + 1, f), l._table = [], l._timestamps = {
                                data: g,
                                datasets: p,
                                labels: m
                            }
                        },
                        buildTicks: function() {
                            var t, e, n, i = this,
                                a = i.min,
                                r = i.max,
                                o = i.options,
                                l = o.ticks,
                                s = o.time,
                                u = i._timestamps,
                                d = [],
                                c = i.getLabelCapacity(a),
                                h = l.source,
                                f = o.distribution;
                            for (u = "data" === h || "auto" === h && "series" === f ? u.data : "labels" === h ? u.labels : ka(i, a, r, c), "ticks" === o.bounds && u.length && (a = u[0], r = u[u.length - 1]), a = ba(i, ha(o)) || a, r = ba(i, fa(o)) || r, t = 0, e = u.length; t < e; ++t)(n = u[t]) >= a && n <= r && d.push(n);
                            return i.min = a, i.max = r, i._unit = s.unit || (l.autoSkip ? xa(s.minUnit, i.min, i.max, c) : ya(i, d.length, s.minUnit, i.min, i.max)), i._majorUnit = l.major.enabled && "year" !== i._unit ? _a(i._unit) : void 0, i._table = ga(i._timestamps.data, a, r, f), i._offsets = wa(i._table, d, a, r, o), l.reverse && d.reverse(), Sa(i, d, i._majorUnit)
                        },
                        getLabelForIndex: function(t, e) {
                            var n = this,
                                i = n._adapter,
                                a = n.chart.data,
                                r = n.options.time,
                                o = a.labels && t < a.labels.length ? a.labels[t] : "",
                                l = a.datasets[e].data[t];
                            return rt.isObject(l) && (o = n.getRightValue(l)), r.tooltipFormat ? i.format(va(n, o), r.tooltipFormat) : "string" === typeof o ? o : i.format(va(n, o), r.displayFormats.datetime)
                        },
                        tickFormatFunction: function(t, e, n, i) {
                            var a = this,
                                r = a._adapter,
                                o = a.options,
                                l = o.time.displayFormats,
                                s = l[a._unit],
                                u = a._majorUnit,
                                d = l[u],
                                c = n[e],
                                h = o.ticks,
                                f = u && d && c && c.major,
                                g = r.format(t, i || (f ? d : s)),
                                p = f ? h.major : h.minor,
                                m = aa([p.callback, p.userCallback, h.callback, h.userCallback]);
                            return m ? m(g, e, n) : g
                        },
                        convertTicksToLabels: function(t) {
                            var e, n, i = [];
                            for (e = 0, n = t.length; e < n; ++e) i.push(this.tickFormatFunction(t[e].value, e, t));
                            return i
                        },
                        getPixelForOffset: function(t) {
                            var e = this,
                                n = e._offsets,
                                i = ma(e._table, "time", t, "pos");
                            return e.getPixelForDecimal((n.start + i) * n.factor)
                        },
                        getPixelForValue: function(t, e, n) {
                            var i = this,
                                a = null;
                            if (void 0 !== e && void 0 !== n && (a = i._timestamps.datasets[n][e]), null === a && (a = ba(i, t)), null !== a) return i.getPixelForOffset(a)
                        },
                        getPixelForTick: function(t) {
                            var e = this.getTicks();
                            return t >= 0 && t < e.length ? this.getPixelForOffset(e[t].value) : null
                        },
                        getValueForPixel: function(t) {
                            var e = this,
                                n = e._offsets,
                                i = e.getDecimalForPixel(t) / n.factor - n.end,
                                a = ma(e._table, "pos", i, "time");
                            return e._adapter._create(a)
                        },
                        _getLabelSize: function(t) {
                            var e = this,
                                n = e.options.ticks,
                                i = e.ctx.measureText(t).width,
                                a = rt.toRadians(e.isHorizontal() ? n.maxRotation : n.minRotation),
                                r = Math.cos(a),
                                o = Math.sin(a),
                                l = ra(n.fontSize, Z.global.defaultFontSize);
                            return {
                                w: i * r + l * o,
                                h: i * o + l * r
                            }
                        },
                        getLabelWidth: function(t) {
                            return this._getLabelSize(t).w
                        },
                        getLabelCapacity: function(t) {
                            var e = this,
                                n = e.options.time,
                                i = n.displayFormats,
                                a = i[n.unit] || i.millisecond,
                                r = e.tickFormatFunction(t, 0, Sa(e, [t], e._majorUnit), a),
                                o = e._getLabelSize(r),
                                l = Math.floor(e.isHorizontal() ? e.width / o.w : e.height / o.h);
                            return e.options.offset && l--, l > 0 ? l : 1
                        }
                    }),
                    Aa = Ca;
                Pa._defaults = Aa;
                var Da = {
                        category: yi,
                        linear: Fi,
                        logarithmic: Ei,
                        radialLinear: ea,
                        time: Pa
                    },
                    Ta = {
                        datetime: "MMM D, YYYY, h:mm:ss a",
                        millisecond: "h:mm:ss.SSS a",
                        second: "h:mm:ss a",
                        minute: "h:mm a",
                        hour: "hA",
                        day: "MMM D",
                        week: "ll",
                        month: "MMM YYYY",
                        quarter: "[Q]Q - YYYY",
                        year: "YYYY"
                    };
                Zn._date.override("function" === typeof t ? {
                    _id: "moment",
                    formats: function() {
                        return Ta
                    },
                    parse: function(e, n) {
                        return "string" === typeof e && "string" === typeof n ? e = t(e, n) : e instanceof t || (e = t(e)), e.isValid() ? e.valueOf() : null
                    },
                    format: function(e, n) {
                        return t(e).format(n)
                    },
                    add: function(e, n, i) {
                        return t(e).add(n, i).valueOf()
                    },
                    diff: function(e, n, i) {
                        return t(e).diff(t(n), i)
                    },
                    startOf: function(e, n, i) {
                        return e = t(e), "isoWeek" === n ? e.isoWeekday(i).valueOf() : e.startOf(n).valueOf()
                    },
                    endOf: function(e, n) {
                        return t(e).endOf(n).valueOf()
                    },
                    _create: function(e) {
                        return t(e)
                    }
                } : {}), Z._set("global", {
                    plugins: {
                        filler: {
                            propagate: !0
                        }
                    }
                });
                var Ia = {
                    dataset: function(t) {
                        var e = t.fill,
                            n = t.chart,
                            i = n.getDatasetMeta(e),
                            a = i && n.isDatasetVisible(e) && i.dataset._children || [],
                            r = a.length || 0;
                        return r ? function(t, e) {
                            return e < r && a[e]._view || null
                        } : null
                    },
                    boundary: function(t) {
                        var e = t.boundary,
                            n = e ? e.x : null,
                            i = e ? e.y : null;
                        return rt.isArray(e) ? function(t, n) {
                            return e[n]
                        } : function(t) {
                            return {
                                x: null === n ? t.x : n,
                                y: null === i ? t.y : i
                            }
                        }
                    }
                };

                function Fa(t, e, n) {
                    var i, a = t._model || {},
                        r = a.fill;
                    if (void 0 === r && (r = !!a.backgroundColor), !1 === r || null === r) return !1;
                    if (!0 === r) return "origin";
                    if (i = parseFloat(r, 10), isFinite(i) && Math.floor(i) === i) return "-" !== r[0] && "+" !== r[0] || (i = e + i), !(i === e || i < 0 || i >= n) && i;
                    switch (r) {
                        case "bottom":
                            return "start";
                        case "top":
                            return "end";
                        case "zero":
                            return "origin";
                        case "origin":
                        case "start":
                        case "end":
                            return r;
                        default:
                            return !1
                    }
                }

                function Oa(t) {
                    var e, n = t.el._model || {},
                        i = t.el._scale || {},
                        a = t.fill,
                        r = null;
                    if (isFinite(a)) return null;
                    if ("start" === a ? r = void 0 === n.scaleBottom ? i.bottom : n.scaleBottom : "end" === a ? r = void 0 === n.scaleTop ? i.top : n.scaleTop : void 0 !== n.scaleZero ? r = n.scaleZero : i.getBasePixel && (r = i.getBasePixel()), void 0 !== r && null !== r) {
                        if (void 0 !== r.x && void 0 !== r.y) return r;
                        if (rt.isFinite(r)) return {
                            x: (e = i.isHorizontal()) ? r : null,
                            y: e ? null : r
                        }
                    }
                    return null
                }

                function La(t) {
                    var e, n, i, a, r, o = t.el._scale,
                        l = o.options,
                        s = o.chart.data.labels.length,
                        u = t.fill,
                        d = [];
                    if (!s) return null;
                    for (e = l.ticks.reverse ? o.max : o.min, n = l.ticks.reverse ? o.min : o.max, i = o.getPointPositionForValue(0, e), a = 0; a < s; ++a) r = "start" === u || "end" === u ? o.getPointPositionForValue(a, "start" === u ? e : n) : o.getBasePosition(a), l.gridLines.circular && (r.cx = i.x, r.cy = i.y, r.angle = o.getIndexAngle(a) - Math.PI / 2), d.push(r);
                    return d
                }

                function Ra(t) {
                    return (t.el._scale || {}).getPointPositionForValue ? La(t) : Oa(t)
                }

                function za(t, e, n) {
                    var i, a = t[e].fill,
                        r = [e];
                    if (!n) return a;
                    for (; !1 !== a && -1 === r.indexOf(a);) {
                        if (!isFinite(a)) return a;
                        if (!(i = t[a])) return !1;
                        if (i.visible) return a;
                        r.push(a), a = i.fill
                    }
                    return !1
                }

                function Na(t) {
                    var e = t.fill,
                        n = "dataset";
                    return !1 === e ? null : (isFinite(e) || (n = "boundary"), Ia[n](t))
                }

                function Ba(t) {
                    return t && !t.skip
                }

                function Ea(t, e, n, i, a) {
                    var r, o, l, s;
                    if (i && a) {
                        for (t.moveTo(e[0].x, e[0].y), r = 1; r < i; ++r) rt.canvas.lineTo(t, e[r - 1], e[r]);
                        if (void 0 === n[0].angle)
                            for (t.lineTo(n[a - 1].x, n[a - 1].y), r = a - 1; r > 0; --r) rt.canvas.lineTo(t, n[r], n[r - 1], !0);
                        else
                            for (o = n[0].cx, l = n[0].cy, s = Math.sqrt(Math.pow(n[0].x - o, 2) + Math.pow(n[0].y - l, 2)), r = a - 1; r > 0; --r) t.arc(o, l, s, n[r].angle, n[r - 1].angle, !0)
                    }
                }

                function Wa(t, e, n, i, a, r) {
                    var o, l, s, u, d, c, h, f, g = e.length,
                        p = i.spanGaps,
                        m = [],
                        v = [],
                        b = 0,
                        x = 0;
                    for (t.beginPath(), o = 0, l = g; o < l; ++o) d = n(u = e[s = o % g]._view, s, i), c = Ba(u), h = Ba(d), r && void 0 === f && c && (l = g + (f = o + 1)), c && h ? (b = m.push(u), x = v.push(d)) : b && x && (p ? (c && m.push(u), h && v.push(d)) : (Ea(t, m, v, b, x), b = x = 0, m = [], v = []));
                    Ea(t, m, v, b, x), t.closePath(), t.fillStyle = a, t.fill()
                }
                var Va = {
                        id: "filler",
                        afterDatasetsUpdate: function(t, e) {
                            var n, i, a, r, o = (t.data.datasets || []).length,
                                l = e.propagate,
                                s = [];
                            for (i = 0; i < o; ++i) r = null, (a = (n = t.getDatasetMeta(i)).dataset) && a._model && a instanceof Ut.Line && (r = {
                                visible: t.isDatasetVisible(i),
                                fill: Fa(a, i, o),
                                chart: t,
                                el: a
                            }), n.$filler = r, s.push(r);
                            for (i = 0; i < o; ++i)(r = s[i]) && (r.fill = za(s, i, l), r.boundary = Ra(r), r.mapper = Na(r))
                        },
                        beforeDatasetsDraw: function(t) {
                            var e, n, i, a, r, o, l, s = t._getSortedVisibleDatasetMetas(),
                                u = t.ctx;
                            for (n = s.length - 1; n >= 0; --n)(e = s[n].$filler) && e.visible && (a = (i = e.el)._view, r = i._children || [], o = e.mapper, l = a.backgroundColor || Z.global.defaultColor, o && l && r.length && (rt.canvas.clipArea(u, t.chartArea), Wa(u, r, o, a, l, i._loop), rt.canvas.unclipArea(u)))
                        }
                    },
                    Ha = rt.rtl.getRtlAdapter,
                    ja = rt.noop,
                    qa = rt.valueOrDefault;

                function Ua(t, e) {
                    return t.usePointStyle && t.boxWidth > e ? e : t.boxWidth
                }
                Z._set("global", {
                    legend: {
                        display: !0,
                        position: "top",
                        align: "center",
                        fullWidth: !0,
                        reverse: !1,
                        weight: 1e3,
                        onClick: function(t, e) {
                            var n = e.datasetIndex,
                                i = this.chart,
                                a = i.getDatasetMeta(n);
                            a.hidden = null === a.hidden ? !i.data.datasets[n].hidden : null, i.update()
                        },
                        onHover: null,
                        onLeave: null,
                        labels: {
                            boxWidth: 40,
                            padding: 10,
                            generateLabels: function(t) {
                                var e = t.data.datasets,
                                    n = t.options.legend || {},
                                    i = n.labels && n.labels.usePointStyle;
                                return t._getSortedDatasetMetas().map((function(n) {
                                    var a = n.controller.getStyle(i ? 0 : void 0);
                                    return {
                                        text: e[n.index].label,
                                        fillStyle: a.backgroundColor,
                                        hidden: !t.isDatasetVisible(n.index),
                                        lineCap: a.borderCapStyle,
                                        lineDash: a.borderDash,
                                        lineDashOffset: a.borderDashOffset,
                                        lineJoin: a.borderJoinStyle,
                                        lineWidth: a.borderWidth,
                                        strokeStyle: a.borderColor,
                                        pointStyle: a.pointStyle,
                                        rotation: a.rotation,
                                        datasetIndex: n.index
                                    }
                                }), this)
                            }
                        }
                    },
                    legendCallback: function(t) {
                        var e, n, i, a = document.createElement("ul"),
                            r = t.data.datasets;
                        for (a.setAttribute("class", t.id + "-legend"), e = 0, n = r.length; e < n; e++)(i = a.appendChild(document.createElement("li"))).appendChild(document.createElement("span")).style.backgroundColor = r[e].backgroundColor, r[e].label && i.appendChild(document.createTextNode(r[e].label));
                        return a.outerHTML
                    }
                });
                var Ya = ft.extend({
                    initialize: function(t) {
                        var e = this;
                        rt.extend(e, t), e.legendHitBoxes = [], e._hoveredItem = null, e.doughnutMode = !1
                    },
                    beforeUpdate: ja,
                    update: function(t, e, n) {
                        var i = this;
                        return i.beforeUpdate(), i.maxWidth = t, i.maxHeight = e, i.margins = n, i.beforeSetDimensions(), i.setDimensions(), i.afterSetDimensions(), i.beforeBuildLabels(), i.buildLabels(), i.afterBuildLabels(), i.beforeFit(), i.fit(), i.afterFit(), i.afterUpdate(), i.minSize
                    },
                    afterUpdate: ja,
                    beforeSetDimensions: ja,
                    setDimensions: function() {
                        var t = this;
                        t.isHorizontal() ? (t.width = t.maxWidth, t.left = 0, t.right = t.width) : (t.height = t.maxHeight, t.top = 0, t.bottom = t.height), t.paddingLeft = 0, t.paddingTop = 0, t.paddingRight = 0, t.paddingBottom = 0, t.minSize = {
                            width: 0,
                            height: 0
                        }
                    },
                    afterSetDimensions: ja,
                    beforeBuildLabels: ja,
                    buildLabels: function() {
                        var t = this,
                            e = t.options.labels || {},
                            n = rt.callback(e.generateLabels, [t.chart], t) || [];
                        e.filter && (n = n.filter((function(n) {
                            return e.filter(n, t.chart.data)
                        }))), t.options.reverse && n.reverse(), t.legendItems = n
                    },
                    afterBuildLabels: ja,
                    beforeFit: ja,
                    fit: function() {
                        var t = this,
                            e = t.options,
                            n = e.labels,
                            i = e.display,
                            a = t.ctx,
                            r = rt.options._parseFont(n),
                            o = r.size,
                            l = t.legendHitBoxes = [],
                            s = t.minSize,
                            u = t.isHorizontal();
                        if (u ? (s.width = t.maxWidth, s.height = i ? 10 : 0) : (s.width = i ? 10 : 0, s.height = t.maxHeight), i) {
                            if (a.font = r.string, u) {
                                var d = t.lineWidths = [0],
                                    c = 0;
                                a.textAlign = "left", a.textBaseline = "middle", rt.each(t.legendItems, (function(t, e) {
                                    var i = Ua(n, o) + o / 2 + a.measureText(t.text).width;
                                    (0 === e || d[d.length - 1] + i + 2 * n.padding > s.width) && (c += o + n.padding, d[d.length - (e > 0 ? 0 : 1)] = 0), l[e] = {
                                        left: 0,
                                        top: 0,
                                        width: i,
                                        height: o
                                    }, d[d.length - 1] += i + n.padding
                                })), s.height += c
                            } else {
                                var h = n.padding,
                                    f = t.columnWidths = [],
                                    g = t.columnHeights = [],
                                    p = n.padding,
                                    m = 0,
                                    v = 0;
                                rt.each(t.legendItems, (function(t, e) {
                                    var i = Ua(n, o) + o / 2 + a.measureText(t.text).width;
                                    e > 0 && v + o + 2 * h > s.height && (p += m + n.padding, f.push(m), g.push(v), m = 0, v = 0), m = Math.max(m, i), v += o + h, l[e] = {
                                        left: 0,
                                        top: 0,
                                        width: i,
                                        height: o
                                    }
                                })), p += m, f.push(m), g.push(v), s.width += p
                            }
                            t.width = s.width, t.height = s.height
                        } else t.width = s.width = t.height = s.height = 0
                    },
                    afterFit: ja,
                    isHorizontal: function() {
                        return "top" === this.options.position || "bottom" === this.options.position
                    },
                    draw: function() {
                        var t = this,
                            e = t.options,
                            n = e.labels,
                            i = Z.global,
                            a = i.defaultColor,
                            r = i.elements.line,
                            o = t.height,
                            l = t.columnHeights,
                            s = t.width,
                            u = t.lineWidths;
                        if (e.display) {
                            var d, c = Ha(e.rtl, t.left, t.minSize.width),
                                h = t.ctx,
                                f = qa(n.fontColor, i.defaultFontColor),
                                g = rt.options._parseFont(n),
                                p = g.size;
                            h.textAlign = c.textAlign("left"), h.textBaseline = "middle", h.lineWidth = .5, h.strokeStyle = f, h.fillStyle = f, h.font = g.string;
                            var m = Ua(n, p),
                                v = t.legendHitBoxes,
                                b = function(t, e, i) {
                                    if (!(isNaN(m) || m <= 0)) {
                                        h.save();
                                        var o = qa(i.lineWidth, r.borderWidth);
                                        if (h.fillStyle = qa(i.fillStyle, a), h.lineCap = qa(i.lineCap, r.borderCapStyle), h.lineDashOffset = qa(i.lineDashOffset, r.borderDashOffset), h.lineJoin = qa(i.lineJoin, r.borderJoinStyle), h.lineWidth = o, h.strokeStyle = qa(i.strokeStyle, a), h.setLineDash && h.setLineDash(qa(i.lineDash, r.borderDash)), n && n.usePointStyle) {
                                            var l = m * Math.SQRT2 / 2,
                                                s = c.xPlus(t, m / 2),
                                                u = e + p / 2;
                                            rt.canvas.drawPoint(h, i.pointStyle, l, s, u, i.rotation)
                                        } else h.fillRect(c.leftForLtr(t, m), e, m, p), 0 !== o && h.strokeRect(c.leftForLtr(t, m), e, m, p);
                                        h.restore()
                                    }
                                },
                                x = function(t, e, n, i) {
                                    var a = p / 2,
                                        r = c.xPlus(t, m + a),
                                        o = e + a;
                                    h.fillText(n.text, r, o), n.hidden && (h.beginPath(), h.lineWidth = 2, h.moveTo(r, o), h.lineTo(c.xPlus(r, i), o), h.stroke())
                                },
                                y = function(t, i) {
                                    switch (e.align) {
                                        case "start":
                                            return n.padding;
                                        case "end":
                                            return t - i;
                                        default:
                                            return (t - i + n.padding) / 2
                                    }
                                },
                                _ = t.isHorizontal();
                            d = _ ? {
                                x: t.left + y(s, u[0]),
                                y: t.top + n.padding,
                                line: 0
                            } : {
                                x: t.left + n.padding,
                                y: t.top + y(o, l[0]),
                                line: 0
                            }, rt.rtl.overrideTextDirection(t.ctx, e.textDirection);
                            var k = p + n.padding;
                            rt.each(t.legendItems, (function(e, i) {
                                var a = h.measureText(e.text).width,
                                    r = m + p / 2 + a,
                                    f = d.x,
                                    g = d.y;
                                c.setWidth(t.minSize.width), _ ? i > 0 && f + r + n.padding > t.left + t.minSize.width && (g = d.y += k, d.line++, f = d.x = t.left + y(s, u[d.line])) : i > 0 && g + k > t.top + t.minSize.height && (f = d.x = f + t.columnWidths[d.line] + n.padding, d.line++, g = d.y = t.top + y(o, l[d.line]));
                                var w = c.x(f);
                                b(w, g, e), v[i].left = c.leftForLtr(w, v[i].width), v[i].top = g, x(w, g, e, a), _ ? d.x += r + n.padding : d.y += k
                            })), rt.rtl.restoreTextDirection(t.ctx, e.textDirection)
                        }
                    },
                    _getLegendItemAt: function(t, e) {
                        var n, i, a, r = this;
                        if (t >= r.left && t <= r.right && e >= r.top && e <= r.bottom)
                            for (a = r.legendHitBoxes, n = 0; n < a.length; ++n)
                                if (t >= (i = a[n]).left && t <= i.left + i.width && e >= i.top && e <= i.top + i.height) return r.legendItems[n];
                        return null
                    },
                    handleEvent: function(t) {
                        var e, n = this,
                            i = n.options,
                            a = "mouseup" === t.type ? "click" : t.type;
                        if ("mousemove" === a) {
                            if (!i.onHover && !i.onLeave) return
                        } else {
                            if ("click" !== a) return;
                            if (!i.onClick) return
                        }
                        e = n._getLegendItemAt(t.x, t.y), "click" === a ? e && i.onClick && i.onClick.call(n, t.native, e) : (i.onLeave && e !== n._hoveredItem && (n._hoveredItem && i.onLeave.call(n, t.native, n._hoveredItem), n._hoveredItem = e), i.onHover && e && i.onHover.call(n, t.native, e))
                    }
                });

                function Ga(t, e) {
                    var n = new Ya({
                        ctx: t.ctx,
                        options: e,
                        chart: t
                    });
                    je.configure(t, n, e), je.addBox(t, n), t.legend = n
                }
                var Xa = {
                        id: "legend",
                        _element: Ya,
                        beforeInit: function(t) {
                            var e = t.options.legend;
                            e && Ga(t, e)
                        },
                        beforeUpdate: function(t) {
                            var e = t.options.legend,
                                n = t.legend;
                            e ? (rt.mergeIf(e, Z.global.legend), n ? (je.configure(t, n, e), n.options = e) : Ga(t, e)) : n && (je.removeBox(t, n), delete t.legend)
                        },
                        afterEvent: function(t, e) {
                            var n = t.legend;
                            n && n.handleEvent(e)
                        }
                    },
                    Ka = rt.noop;
                Z._set("global", {
                    title: {
                        display: !1,
                        fontStyle: "bold",
                        fullWidth: !0,
                        padding: 10,
                        position: "top",
                        text: "",
                        weight: 2e3
                    }
                });
                var Za = ft.extend({
                    initialize: function(t) {
                        var e = this;
                        rt.extend(e, t), e.legendHitBoxes = []
                    },
                    beforeUpdate: Ka,
                    update: function(t, e, n) {
                        var i = this;
                        return i.beforeUpdate(), i.maxWidth = t, i.maxHeight = e, i.margins = n, i.beforeSetDimensions(), i.setDimensions(), i.afterSetDimensions(), i.beforeBuildLabels(), i.buildLabels(), i.afterBuildLabels(), i.beforeFit(), i.fit(), i.afterFit(), i.afterUpdate(), i.minSize
                    },
                    afterUpdate: Ka,
                    beforeSetDimensions: Ka,
                    setDimensions: function() {
                        var t = this;
                        t.isHorizontal() ? (t.width = t.maxWidth, t.left = 0, t.right = t.width) : (t.height = t.maxHeight, t.top = 0, t.bottom = t.height), t.paddingLeft = 0, t.paddingTop = 0, t.paddingRight = 0, t.paddingBottom = 0, t.minSize = {
                            width: 0,
                            height: 0
                        }
                    },
                    afterSetDimensions: Ka,
                    beforeBuildLabels: Ka,
                    buildLabels: Ka,
                    afterBuildLabels: Ka,
                    beforeFit: Ka,
                    fit: function() {
                        var t, e = this,
                            n = e.options,
                            i = e.minSize = {},
                            a = e.isHorizontal();
                        n.display ? (t = (rt.isArray(n.text) ? n.text.length : 1) * rt.options._parseFont(n).lineHeight + 2 * n.padding, e.width = i.width = a ? e.maxWidth : t, e.height = i.height = a ? t : e.maxHeight) : e.width = i.width = e.height = i.height = 0
                    },
                    afterFit: Ka,
                    isHorizontal: function() {
                        var t = this.options.position;
                        return "top" === t || "bottom" === t
                    },
                    draw: function() {
                        var t = this,
                            e = t.ctx,
                            n = t.options;
                        if (n.display) {
                            var i, a, r, o = rt.options._parseFont(n),
                                l = o.lineHeight,
                                s = l / 2 + n.padding,
                                u = 0,
                                d = t.top,
                                c = t.left,
                                h = t.bottom,
                                f = t.right;
                            e.fillStyle = rt.valueOrDefault(n.fontColor, Z.global.defaultFontColor), e.font = o.string, t.isHorizontal() ? (a = c + (f - c) / 2, r = d + s, i = f - c) : (a = "left" === n.position ? c + s : f - s, r = d + (h - d) / 2, i = h - d, u = Math.PI * ("left" === n.position ? -.5 : .5)), e.save(), e.translate(a, r), e.rotate(u), e.textAlign = "center", e.textBaseline = "middle";
                            var g = n.text;
                            if (rt.isArray(g))
                                for (var p = 0, m = 0; m < g.length; ++m) e.fillText(g[m], 0, p, i), p += l;
                            else e.fillText(g, 0, 0, i);
                            e.restore()
                        }
                    }
                });

                function $a(t, e) {
                    var n = new Za({
                        ctx: t.ctx,
                        options: e,
                        chart: t
                    });
                    je.configure(t, n, e), je.addBox(t, n), t.titleBlock = n
                }
                var Ja = {},
                    Qa = Va,
                    tr = Xa,
                    er = {
                        id: "title",
                        _element: Za,
                        beforeInit: function(t) {
                            var e = t.options.title;
                            e && $a(t, e)
                        },
                        beforeUpdate: function(t) {
                            var e = t.options.title,
                                n = t.titleBlock;
                            e ? (rt.mergeIf(e, Z.global.title), n ? (je.configure(t, n, e), n.options = e) : $a(t, e)) : n && (je.removeBox(t, n), delete t.titleBlock)
                        }
                    };
                for (var nr in Ja.filler = Qa, Ja.legend = tr, Ja.title = er, Yn.helpers = rt, Gn(), Yn._adapters = Zn, Yn.Animation = pt, Yn.animationService = mt, Yn.controllers = we, Yn.DatasetController = kt, Yn.defaults = Z, Yn.Element = ft, Yn.elements = Ut, Yn.Interaction = Te, Yn.layouts = je, Yn.platform = xn, Yn.plugins = yn, Yn.Scale = vi, Yn.scaleService = _n, Yn.Ticks = $n, Yn.Tooltip = zn, Yn.helpers.each(Da, (function(t, e) {
                        Yn.scaleService.registerScaleType(e, t, t._defaults)
                    })), Ja) Ja.hasOwnProperty(nr) && Yn.plugins.register(Ja[nr]);
                Yn.platform.initialize();
                var ir = Yn;
                return window.Chart = Yn, Yn.Chart = Yn, Yn.Legend = Ja.legend._element, Yn.Title = Ja.title._element, Yn.pluginService = Yn.plugins, Yn.PluginBase = Yn.Element.extend({}), Yn.canvasHelpers = Yn.helpers.canvas, Yn.layoutService = Yn.layouts, Yn.LinearScaleBase = Si, Yn.helpers.each(["Bar", "Bubble", "Doughnut", "Line", "PolarArea", "Radar", "Scatter"], (function(t) {
                    Yn[t] = function(e, n) {
                        return new Yn(e, Yn.helpers.merge(n || {}, {
                            type: t.charAt(0).toLowerCase() + t.slice(1)
                        }))
                    }
                })), ir
            }(function() {
                try {
                    return n("wgY5")
                } catch (t) {}
            }())
        }
    }
]);