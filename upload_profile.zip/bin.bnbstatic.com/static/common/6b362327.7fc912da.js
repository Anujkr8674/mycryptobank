! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "e0f4f941-e9b0-5c4e-9293-946f8e966d22")
    } catch (e) {}
}();
(self.webpackChunkconvert_ui = self.webpackChunkconvert_ui || []).push([
    [144], {
        nghm: (e, t, n) => {
            "use strict";
            n.d(t, {
                j: () => c
            });
            var r = n("DTvD"),
                o = n.n(r),
                a = n("W3Ja"),
                i = n("QFE7"),
                c = function(e) {
                    var t = e.checked,
                        n = e.defaultChecked,
                        c = e.onChange,
                        s = e.disabled,
                        l = o().useState(!!n),
                        u = l[0],
                        f = l[1];
                    (0, a.op)((function() {
                        "undefined" !== typeof t && u !== !!t && f(!u)
                    }));
                    var d = (0, i.d)({
                            fn: c
                        }).debounceFn,
                        p = (0, r.useCallback)((function(e) {
                            s || f((function(t) {
                                var n = "boolean" === typeof e ? e : !t;
                                return t !== n && d(n), t !== n ? n : t
                            }))
                        }), [d, s]);
                    return {
                        checked: u,
                        onChecked: p
                    }
                }
        },
        "7+bj": (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => c
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("Y4uf");
            const c = function(e) {
                return a().createElement(i.A, (0, r.__assign)({
                    viewBox: "0 0 24 24",
                    fill: "none"
                }, e), a().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M12.11 12.178L16 8.287l1.768 1.768-5.657 5.657-1.768-1.768-3.889-3.889 1.768-1.768 3.889 3.89z",
                    fill: "currentColor"
                }))
            }
        },
        zRna: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => c
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("Y4uf");
            const c = function(e) {
                return a().createElement(i.A, (0, r.__assign)({
                    viewBox: "0 0 24 24",
                    fill: "none"
                }, e), a().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-4.934-4.483L10.2 13.383l-2.716-2.716-1.768 1.767 4.484 4.484 7.634-7.634-1.768-1.767z",
                    fill: "currentColor"
                }))
            }
        },
        X0Bn: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => c
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("Y4uf");
            const c = function(e) {
                return a().createElement(i.A, (0, r.__assign)({
                    viewBox: "0 0 24 24",
                    fill: "none"
                }, e), a().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-7.233 0l3.006 3.005-1.768 1.768L12 13.767l-3.005 3.005-1.768-1.768 3.005-3.005-3.005-3.005 1.768-1.767L12 10.23l3.005-3.005 1.768 1.767L13.767 12z",
                    fill: "currentColor"
                }))
            }
        },
        "9mmq": (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => c
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("Y4uf");
            const c = function(e) {
                return a().createElement(i.A, (0, r.__assign)({
                    viewBox: "0 0 24 24",
                    fill: "none"
                }, e), a().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M12 21a9 9 0 100-18 9 9 0 000 18zM10.75 8.5V6h2.5v2.5h-2.5zm0 9.5v-7h2.5v7h-2.5z",
                    fill: "currentColor"
                }))
            }
        },
        SR26: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => c
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("Y4uf");
            const c = function(e) {
                return a().createElement(i.A, (0, r.__assign)({
                    viewBox: "0 0 24 24",
                    fill: "none"
                }, e), a().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M12 21a9 9 0 100-18 9 9 0 000 18zm-1.25-5.5V18h2.5v-2.5h-2.5zm0-9.5v7h2.5V6h-2.5z",
                    fill: "currentColor"
                }))
            }
        },
        DzvH: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => c
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("Y4uf");
            const c = function(e) {
                return a().createElement(i.A, (0, r.__assign)({
                    viewBox: "0 0 24 24",
                    fill: "none"
                }, e), a().createElement("path", {
                    d: "M3 10.5v3h18v-3H3z",
                    fill: "currentColor"
                }))
            }
        },
        vtOj: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => c
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("Y4uf");
            const c = function(e) {
                return a().createElement(i.A, (0, r.__assign)({
                    viewBox: "0 0 96 96",
                    fill: "none"
                }, e), a().createElement("path", {
                    opacity: .5,
                    d: "M84 28H64V8l20 20z",
                    fill: "#AEB4BC"
                }), a().createElement("path", {
                    opacity: .2,
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M24 8h40v20h20v60H24V8zm10 30h40v4H34v-4zm40 8H34v4h40v-4zm-40 8h40v4H34v-4z",
                    fill: "#AEB4BC"
                }), a().createElement("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M22.137 64.105c7.828 5.781 18.916 5.127 26.005-1.963 7.81-7.81 7.81-20.474 0-28.284-7.81-7.81-20.474-7.81-28.284 0-7.09 7.09-7.744 18.177-1.964 26.005l-14.3 14.3 4.243 4.243 14.3-14.3zM43.9 57.9c-5.467 5.468-14.331 5.468-19.799 0-5.467-5.467-5.467-14.331 0-19.799 5.468-5.467 14.332-5.467 19.8 0 5.467 5.468 5.467 14.332 0 19.8z",
                    fill: "#AEB4BC"
                }))
            }
        },
        oVj4: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => d
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("vtOj"),
                c = n("O94r"),
                s = n.n(c),
                l = n("eeEA"),
                u = n("fvKX"),
                f = function(e) {
                    var t, n = e.action,
                        o = e.children,
                        c = e.size,
                        f = (0, r.__rest)(e, ["action", "children", "size"]),
                        d = (0, u.r)(),
                        p = d.prefixCls,
                        m = d.isRTL,
                        v = "".concat(p, "-emptyState"),
                        h = s()(v, ((t = {})["".concat(v, "-rtl")] = !!m, t["data-size-".concat(c)] = !!c, t), e.className);
                    return a().createElement(l.Ay, (0, r.__assign)({}, f, {
                        className: h
                    }), a().createElement(i.A, {
                        name: "NotFoundData",
                        className: "".concat(v, "-icon")
                    }), o && a().createElement(l.Ay, {
                        className: "".concat(v, "-content"),
                        children: o
                    }), n && a().createElement(l.Ay, {
                        className: "".concat(v, "-action"),
                        children: n
                    }))
                };
            f.displayName = "EmptyState";
            const d = f
        },
        JyHn: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => A,
                Z: () => k
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("hyZw"),
                c = n("H2//"),
                s = n("k5JY"),
                l = n("Svbh");
            const u = function(e) {
                var t = e.willClose,
                    n = e.closeCallback,
                    i = e.content,
                    c = (0, r.__rest)(e, ["willClose", "closeCallback", "content"]),
                    u = a().useState(!0),
                    f = u[0],
                    d = u[1],
                    p = (0, o.useCallback)((function() {
                        d(!1), setTimeout((function() {
                            n && n()
                        }), l.p)
                    }), [n]);
                return a().useEffect((function() {
                    t && p()
                }), [t, p]), a().createElement(s.Ay, (0, r.__assign)({}, c, {
                    visible: f,
                    onClose: p,
                    children: i
                }))
            };
            var f = n("O94r"),
                d = n.n(f),
                p = n("eeEA"),
                m = n("mk7A"),
                v = n("fvKX");
            const h = function(e) {
                var t = e.duration,
                    n = void 0 === t ? 3e3 : t,
                    o = e.visible,
                    c = e.onClose,
                    s = void 0 === c ? i.es : c,
                    l = e.children,
                    u = (0, r.__rest)(e, ["duration", "visible", "onClose", "children"]),
                    f = a().useRef(),
                    h = (0, v.r)().prefixCls,
                    b = d()("".concat(h, "-toast"), e.className);
                return a().useEffect((function() {
                    return n ? (f.current = setTimeout((function() {
                        o && s(), f.current = null
                    }), n), function() {
                        return clearTimeout(f.current)
                    }) : function() {}
                }), [o, n, s]), a().createElement(m.A, (0, r.__assign)({}, u, {
                    visible: o,
                    onClose: s,
                    className: b
                }), a().createElement(p.Ay, {
                    className: "".concat(h, "-toast-wrap"),
                    children: l
                }))
            };
            const b = function(e) {
                var t = e.willClose,
                    n = e.closeCallback,
                    i = e.content,
                    c = (0, r.__rest)(e, ["willClose", "closeCallback", "content"]),
                    s = a().useState(!0),
                    u = s[0],
                    f = s[1],
                    d = (0, o.useCallback)((function() {
                        f(!1), setTimeout((function() {
                            n && n()
                        }), l.p)
                    }), [n]);
                return a().useEffect((function() {
                    t && d()
                }), [t, d]), a().createElement(h, (0, r.__assign)({}, c, {
                    visible: u,
                    onClose: d,
                    children: i
                }))
            };
            var g = n("cZx9");
            const y = function(e) {
                var t = e.willClose,
                    n = e.closeCallback,
                    i = e.direction,
                    c = void 0 === i ? "bottom" : i,
                    s = e.content,
                    u = (0, r.__rest)(e, ["willClose", "closeCallback", "direction", "content"]),
                    f = a().useState(!0),
                    d = f[0],
                    p = f[1],
                    m = (0, o.useCallback)((function() {
                        p(!1), setTimeout((function() {
                            n && n()
                        }), l.p)
                    }), [n]);
                return a().useEffect((function() {
                    t && m()
                }), [t, m]), a().createElement(g.A, (0, r.__assign)({}, u, {
                    direction: c,
                    visible: d,
                    onClose: m,
                    children: s
                }))
            };
            var w = n("rbiW");
            const _ = function(e) {
                var t = e.className,
                    n = e.duration,
                    i = void 0 === n ? 3e3 : n,
                    c = e.willClose,
                    s = e.closeCallback,
                    u = (0, r.__rest)(e, ["className", "duration", "willClose", "closeCallback"]),
                    f = a().useState(!0),
                    d = f[0],
                    p = f[1],
                    m = a().useRef(),
                    v = (0, o.useCallback)((function() {
                        p(!1), setTimeout((function() {
                            s && s()
                        }), l.p)
                    }), [s]);
                return a().useEffect((function() {
                    c && v()
                }), [c, v]), a().useEffect((function() {
                    return i ? (m.current = setTimeout((function() {
                        d && v(), m.current = null
                    }), i), function() {
                        return clearTimeout(m.current)
                    }) : function() {}
                }), [d, i, v]), a().createElement(l.A, {
                    className: t,
                    visible: d
                }, a().createElement(w.A, (0, r.__assign)({
                    closable: !0,
                    variant: "push"
                }, u, {
                    onClose: v
                })))
            };
            var x = function(e) {
                var t = e.placement,
                    n = e.offsetX,
                    r = e.offsetY,
                    o = t.split("-"),
                    a = o[0],
                    i = o[1],
                    c = i ? 0 : "50%",
                    s = r,
                    l = i ? n : "50%";
                return ("end" === i ? {
                    top: {
                        transform: "translate(-".concat(c, ", 0)"),
                        top: s,
                        right: l
                    },
                    bottom: {
                        transform: "translate(-".concat(c, ", 0)"),
                        bottom: s,
                        right: l
                    }
                } : {
                    top: {
                        transform: "translate(-".concat(c, ", 0)"),
                        top: s,
                        left: l
                    },
                    bottom: {
                        transform: "translate(-".concat(c, ", 0)"),
                        bottom: s,
                        left: l
                    }
                })[a]
            };
            const C = function(e) {
                var t = e.offsetX,
                    n = void 0 === t ? 16 : t,
                    o = e.offsetY,
                    i = void 0 === o ? 16 : o,
                    c = e.notifies,
                    s = (0, v.r)().prefixCls,
                    l = "".concat(s, "-layer-notifies");
                if (!c.length) return null;
                var u = c.reduce((function(e, t) {
                    var n = t.uid,
                        o = t.placement,
                        i = void 0 === o ? "top-end" : o,
                        c = (0, r.__rest)(t, ["uid", "placement"]);
                    return e[i].push(a().createElement(_, (0, r.__assign)({
                        key: n
                    }, c))), e
                }), {
                    "top-start": [],
                    top: [],
                    "top-end": [],
                    "bottom-start": [],
                    bottom: [],
                    "bottom-end": []
                });
                return a().createElement(p.Ay, {
                    className: "".concat(l, "-wrap")
                }, Object.keys(u).map((function(e) {
                    var t, r = e.split("-"),
                        o = (r[0], r[1]),
                        c = u[e],
                        s = d()(l, ((t = {})["data-pos-".concat(o)] = o, t));
                    return c.length ? a().createElement(p.Ay, {
                        key: e,
                        className: s,
                        children: c,
                        style: x({
                            placement: e,
                            offsetX: n,
                            offsetY: i
                        })
                    }) : null
                })))
            };
            var E = (0, o.createContext)({
                    openModal: i.es,
                    closeModal: i.es,
                    openToast: i.es,
                    closeToast: i.es,
                    openDrawer: i.es,
                    closeDrawer: i.es,
                    pushNotify: i.es,
                    closeNotify: i.es
                }),
                k = function() {
                    return a().useContext(E)
                };
            const A = function(e) {
                var t = e.children,
                    n = e.notifiesPosition,
                    i = (0, o.useState)(),
                    s = i[0],
                    l = i[1],
                    f = (0, o.useState)(),
                    d = f[0],
                    p = f[1],
                    m = (0, o.useState)(),
                    v = m[0],
                    h = m[1],
                    g = (0, o.useState)([]),
                    w = g[0],
                    _ = g[1],
                    x = {};
                return x.openModal = (0, o.useCallback)((function(e) {
                    var t = e.closeCallback;
                    l((0, r.__assign)((0, r.__assign)({}, e), {
                        closeCallback: function() {
                            l(null), t && t()
                        },
                        willClose: !1
                    }))
                }), []), x.closeModal = (0, o.useCallback)((function() {
                    l((function(e) {
                        return e ? (0, r.__assign)((0, r.__assign)({}, e), {
                            willClose: !0
                        }) : e
                    }))
                }), []), x.openToast = (0, o.useCallback)((function(e) {
                    var t = e.closeCallback;
                    p((0, r.__assign)((0, r.__assign)({}, e), {
                        closeCallback: function() {
                            p(null), t && t()
                        },
                        willClose: !1
                    }))
                }), []), x.closeToast = (0, o.useCallback)((function() {
                    p((function(e) {
                        return e ? (0, r.__assign)((0, r.__assign)({}, e), {
                            willClose: !0
                        }) : e
                    }))
                }), []), x.openDrawer = (0, o.useCallback)((function(e) {
                    var t = e.closeCallback;
                    h((0, r.__assign)((0, r.__assign)({}, e), {
                        closeCallback: function() {
                            h(null), t && t()
                        },
                        willClose: !1
                    }))
                }), []), x.closeDrawer = (0, o.useCallback)((function() {
                    h((function(e) {
                        return e ? (0, r.__assign)((0, r.__assign)({}, e), {
                            willClose: !0
                        }) : e
                    }))
                }), []), x.pushNotify = (0, o.useCallback)((function(e) {
                    var t = (0, c.uR)(8),
                        n = (0, r.__assign)((0, r.__assign)({}, e), {
                            uid: t,
                            closeCallback: function() {
                                e.closeCallback && e.closeCallback(), _((function(e) {
                                    return e.filter((function(e) {
                                        return e.uid !== t
                                    }))
                                }))
                            },
                            willClose: !1
                        });
                    return _((function(e) {
                        return (0, r.__spreadArray)((0, r.__spreadArray)([], e, !0), [n], !1)
                    })), n.uid
                }), []), x.closeNotify = (0, o.useCallback)((function(e) {
                    _((function(t) {
                        return t.map((function(t) {
                            return t.uid === e ? (0, r.__assign)((0, r.__assign)({}, t), {
                                willClose: !0
                            }) : t
                        }))
                    }))
                }), []), a().createElement(E.Provider, {
                    value: x
                }, t, d && a().createElement(b, (0, r.__assign)({}, d)), s && a().createElement(u, (0, r.__assign)({}, s)), v && a().createElement(y, (0, r.__assign)({}, v)), a().createElement(C, (0, r.__assign)({
                    notifies: w
                }, n)))
            }
        },
        rbiW: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => v
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("X0Bn"),
                c = n("SR26"),
                s = n("zRna"),
                l = n("X4b0"),
                u = n("O94r"),
                f = n.n(u),
                d = n("eeEA"),
                p = n("fvKX"),
                m = {
                    error: a().createElement(i.A, {
                        name: "CircledCloseF",
                        color: "error"
                    }),
                    warn: a().createElement(c.A, {
                        name: "CircledWarningF",
                        color: "PrimaryYellow"
                    }),
                    success: a().createElement(s.A, {
                        name: "CircledCheckmarkF",
                        color: "success"
                    }),
                    push: a().createElement(s.A, {
                        name: "CircledCheckmarkF",
                        color: "success"
                    })
                };
            const v = function(e) {
                var t, n, i = e.variant,
                    c = void 0 === i ? "primary" : i,
                    s = e.sz,
                    u = void 0 === s ? "middle" : s,
                    v = e.icon,
                    h = e.title,
                    b = e.message,
                    g = e.closable,
                    y = e.onClose,
                    w = e.closeIcon,
                    _ = e.minWidth,
                    x = (0, r.__rest)(e, ["variant", "sz", "icon", "title", "message", "closable", "onClose", "closeIcon", "minWidth"]),
                    C = (0, p.r)(),
                    E = C.prefixCls,
                    k = C.isRTL,
                    A = "".concat(E, "-notification"),
                    O = f()(A, ((t = {})["".concat(A, "-rtl")] = !!k, t["".concat(A, "__").concat(c)] = !!c, t["data-size-".concat(u)] = !!u, t["".concat(A, "-mw")] = !!_, t), e.className),
                    N = f()("".concat(A, "-content-message"), {
                        "data-push-message": "push" === c && !h
                    });
                if (!h && !b) return null;
                var M = !1 === v ? null : (0, o.isValidElement)(v) ? v : m[c],
                    D = (0, o.useMemo)((function() {
                        var e;
                        return g ? w ? a().cloneElement(w, {
                            color: "IconNormal",
                            className: f()("".concat(A, "-close"), null === (e = null === w || void 0 === w ? void 0 : w.props) || void 0 === e ? void 0 : e.className),
                            onClick: y
                        }) : a().createElement(l.A, {
                            name: "CloseF",
                            color: "IconNormal",
                            className: "".concat(A, "-close"),
                            onClick: y
                        }) : null
                    }), [A, y, w, g]);
                return a().createElement(d.Ay, (0, r.__assign)({}, x, {
                    className: O
                }), !!M && a().cloneElement(M, {
                    className: f()("".concat(A, "-prefix"), null === (n = null === M || void 0 === M ? void 0 : M.props) || void 0 === n ? void 0 : n.className)
                }), a().createElement(d.Ay, {
                    className: f()("".concat(A, "-content"), {
                        closable: g
                    })
                }, !!h && a().createElement(d.Ay, {
                    className: "".concat(A, "-content-title"),
                    children: h
                }), !!b && a().createElement(d.Ay, {
                    className: N,
                    children: b
                }), D))
            }
        },
        lEYW: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => v
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("nghm"),
                c = n("DzvH"),
                s = n("Y4uf");
            const l = function(e) {
                return a().createElement(s.A, (0, r.__assign)({
                    viewBox: "0 0 24 25",
                    fill: "none"
                }, e), a().createElement("path", {
                    d: "M19.357 4.687L9.301 14.743l-4.656-4.657-3.03 3.031L9.3 20.804 22.388 7.717l-3.03-3.03z",
                    fill: "currentColor"
                }))
            };
            var u = n("O94r"),
                f = n.n(u),
                d = n("eeEA"),
                p = n("fvKX"),
                m = function(e) {
                    var t, n = e.value,
                        s = e.checked,
                        u = e.disabled,
                        m = e.indeterminate,
                        v = e.defaultChecked,
                        h = e.variant,
                        b = void 0 === h ? "square" : h,
                        g = e.onChange,
                        y = e.sz,
                        w = void 0 === y ? "md" : y,
                        _ = (0, r.__rest)(e, ["value", "checked", "disabled", "indeterminate", "defaultChecked", "variant", "onChange", "sz"]),
                        x = (0, o.useCallback)((function(e) {
                            return g && g(n, e)
                        }), [g, n]),
                        C = (0, i.j)({
                            defaultChecked: v,
                            checked: s,
                            disabled: u,
                            onChange: x
                        }),
                        E = C.onChecked,
                        k = C.checked,
                        A = (0, p.r)(),
                        O = A.prefixCls,
                        N = A.isRTL,
                        M = "".concat(O, "-checkbox"),
                        D = f()(M, ((t = {})["".concat(M, "-rtl")] = N, t["".concat(M, "__").concat(b)] = !!b, t.disabled = !!u, t.checked = !!k, t["data-size-".concat(w)] = !!w, t), e.className),
                        R = m ? a().createElement(c.A, {
                            name: "MinusF",
                            color: "BasicBg"
                        }) : a().createElement(l, {
                            name: "CheckboxControl1C",
                            color: "BasicBg"
                        }),
                        S = {
                            role: "checkbox",
                            "aria-checked": k,
                            "aria-disabled": u,
                            tabIndex: u ? -1 : 0,
                            onKeyDown: function(e) {
                                "Enter" !== e.key && " " !== e.key || (e.preventDefault(), E())
                            }
                        };
                    return a().createElement(d.Ay, (0, r.__assign)({}, S, _, {
                        onClick: E,
                        className: D
                    }), a().createElement(d.Ay, {
                        className: "".concat(M, "-icon"),
                        children: R
                    }), e.children)
                };
            m.__name = "Checkbox";
            const v = m
        },
        R2Ip: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => tt
            });
            var r = n("wIZF"),
                o = n("DTvD"),
                a = n.n(o),
                i = n("qrIQ"),
                c = n("QFE7"),
                s = n("hyZw"),
                l = n("O94r"),
                u = n.n(l),
                f = n("eeEA"),
                d = n("hTvQ"),
                p = n.n(d),
                m = n("fvKX"),
                v = {
                    top: "marginBottom",
                    left: "marginRight",
                    right: "marginLeft",
                    bottom: "marginTop"
                },
                h = function(e) {
                    var t = e.placement,
                        n = e.offset,
                        r = e.isArrow,
                        o = t.split("-"),
                        a = o[0],
                        i = o[1],
                        c = i ? 0 : "50%",
                        s = r ? {
                            top: " rotate(-135deg)",
                            right: " rotate(-45deg)",
                            bottom: " rotate(45deg)",
                            left: " rotate(135deg)"
                        }[a] : "",
                        l = r ? n - Math.floor(3) : "100%",
                        u = i ? r ? 9 : 0 : "50%";
                    return ("end" === i ? {
                        top: {
                            transform: "translate(-".concat(c, ", 0)").concat(s),
                            bottom: l,
                            right: u
                        },
                        left: {
                            transform: "translate(0, -".concat(c, ")").concat(s),
                            right: l,
                            bottom: u
                        },
                        right: {
                            transform: "translate(0, -".concat(c, ")").concat(s),
                            left: l,
                            bottom: u
                        },
                        bottom: {
                            transform: "translate(-".concat(c, ", 0)").concat(s),
                            top: l,
                            right: u
                        }
                    } : {
                        top: {
                            transform: "translate(-".concat(c, ", 0)").concat(s),
                            bottom: l,
                            left: u
                        },
                        left: {
                            transform: "translate(0, -".concat(c, ")").concat(s),
                            right: l,
                            top: u
                        },
                        right: {
                            transform: "translate(0, -".concat(c, ")").concat(s),
                            left: l,
                            top: u
                        },
                        bottom: {
                            transform: "translate(-".concat(c, ", 0)").concat(s),
                            top: l,
                            left: u
                        }
                    })[a]
                },
                b = function(e) {
                    var t, n, o = e.arrow,
                        c = e.shadow,
                        s = e.isFloat,
                        l = e.offset,
                        d = void 0 === l ? 6 : l,
                        b = e.variant,
                        g = void 0 === b ? "primary" : b,
                        y = e.placement,
                        w = void 0 === y ? "top" : y,
                        _ = e.enablePortal,
                        x = e.portalNode,
                        C = e.style,
                        E = e.radius,
                        k = e.bubbleFontSize,
                        A = void 0 === k ? 14 : k,
                        O = (0, r.__rest)(e, ["arrow", "shadow", "isFloat", "offset", "variant", "placement", "enablePortal", "portalNode", "style", "radius", "bubbleFontSize"]),
                        N = (0, m.r)().prefixCls,
                        M = "".concat(N, "-bubble"),
                        D = u()(M, ((t = {})["".concat(M, "__").concat(g)] = !!g, t["data-shadow"] = !!c, t["data-font-".concat(A)] = !!A, t), e.className);
                    d = o ? Math.max(d, 4) : d;
                    var R = w.split("-")[0],
                        S = s ? h({
                            offset: d,
                            placement: w
                        }) : {},
                        T = h({
                            offset: d,
                            placement: w,
                            isArrow: !0
                        }),
                        P = ((n = {})[v[R]] = d, n.borderRadius = E, n),
                        j = a().createElement(f.Ay, (0, r.__assign)({}, O, {
                            className: D,
                            style: (0, r.__assign)((0, r.__assign)({}, S), C)
                        }), !!o && a().createElement(f.Ay, {
                            className: "".concat(M, "-arrow"),
                            style: T
                        }), !!o && !!c && a().createElement(f.Ay, {
                            className: "".concat(M, "-arrow-shadow"),
                            style: T
                        }), a().createElement(f.Ay, {
                            style: P,
                            className: "".concat(M, "-content"),
                            children: e.children
                        }));
                    return !i.lq && _ ? p().createPortal(j, x instanceof HTMLElement ? x : document.body) : j
                };
            b.displayName = "Bubble";
            const g = b;
            var y = {
                    right: "left",
                    left: "right",
                    "top-start": "top-end",
                    "right-start": "left-start",
                    "left-start": "right-start",
                    "bottom-start": "bottom-end",
                    "top-end": "top-start",
                    "right-end": "left-end",
                    "left-end": "right-end",
                    "bottom-end": "bottom-start"
                },
                w = 50,
                _ = function(e) {
                    var t;
                    e.stopPropagation(), i.lq || null === (t = null === e || void 0 === e ? void 0 : e.nativeEvent) || void 0 === t || t.stopImmediatePropagation()
                },
                x = n("H2//"),
                C = "tooltip";

            function E(e, t, n) {
                return "menu" === t ? {
                    role: "button",
                    "aria-expanded": n,
                    "aria-controls": e,
                    "aria-haspopup": "listbox"
                } : "combobox" === t ? {} : {
                    "aria-describedby": e
                }
            }

            function k(e, t, n) {
                return "combobox" === t ? {} : {
                    id: e,
                    role: t,
                    tabindex: n ? 0 : -1
                }
            }

            function A(e, t, n) {
                void 0 === t && (t = C), void 0 === n && (n = !1);
                var r = (0, o.useMemo)((function() {
                    return "".concat(e, "-").concat((0, x.uR)(8))
                }), [e, t, n]);
                return {
                    triggerAriaProps: E(r, t, n),
                    contentAriaProps: k(r, t, n)
                }
            }
            var O = function(e) {
                var t, n = e.open,
                    l = e.once,
                    d = e.arrow,
                    p = e.offset,
                    v = void 0 === p ? 12 : p,
                    h = e.disabled,
                    b = e.tooltips,
                    x = e.variant,
                    E = void 0 === x ? "gray" : x,
                    k = e.placement,
                    O = void 0 === k ? "top" : k,
                    N = e.trigger,
                    M = void 0 === N ? "hover" : N,
                    D = e.onVisibleChange,
                    R = e.enablePortal,
                    S = e.portalNode,
                    T = e.bubbleClassName,
                    P = e.triggerClassName,
                    j = e.delay,
                    B = void 0 === j ? w : j,
                    z = e.enableClickBubble,
                    F = e.ariaRole,
                    L = void 0 === F ? C : F,
                    W = (0, r.__rest)(e, ["open", "once", "arrow", "offset", "disabled", "tooltips", "variant", "placement", "trigger", "onVisibleChange", "enablePortal", "portalNode", "bubbleClassName", "triggerClassName", "delay", "enableClickBubble", "ariaRole"]),
                    H = a().useState(n),
                    I = H[0],
                    V = H[1],
                    q = a().useRef(),
                    Y = (0, m.r)(),
                    Z = Y.prefixCls,
                    X = Y.isMobile,
                    U = Y.isTablet,
                    K = Y.isClient,
                    J = Y.isRTL,
                    Q = !i.lq && !X && !U;
                M = Q ? M : "click";
                var G = "".concat(Z, "-tooltips");
                a().useEffect((function() {
                    "undefined" !== typeof n && I !== !!n && V(!I)
                }), [n, I]);
                var $ = (0, c.d)({
                        fn: D
                    }).debounceFn,
                    ee = (0, o.useCallback)((function(e) {
                        h || V((function(t) {
                            var n = "boolean" === typeof e ? e : !t;
                            return t !== n && $(n), t !== n ? n : t
                        }))
                    }), [h, $]),
                    te = (0, o.useMemo)((function() {
                        var e, t, n;
                        return "number" === typeof B ? {
                            enter: B,
                            leave: B,
                            click: B
                        } : {
                            enter: null !== (e = B.enter) && void 0 !== e ? e : w,
                            leave: null !== (t = B.leave) && void 0 !== t ? t : w,
                            click: null !== (n = B.click) && void 0 !== n ? n : w
                        }
                    }), [B]),
                    ne = (0, c.d)({
                        fn: ee,
                        time: te.enter
                    }),
                    re = ne.debounceFn,
                    oe = ne.clearTimer,
                    ae = (0, c.d)({
                        fn: ee,
                        time: te.leave
                    }),
                    ie = ae.debounceFn,
                    ce = ae.clearTimer,
                    se = (0, c.d)({
                        fn: ee,
                        time: te.click
                    }).debounceFn,
                    le = (0, o.useCallback)(se, [se]),
                    ue = (0, o.useCallback)((function() {
                        return se(!1)
                    }), [se]);
                a().useEffect((function() {
                    var e = q.current,
                        t = function() {
                            ce(), re(!0)
                        },
                        n = function() {
                            oe(), ie(!1)
                        };
                    if (!i.lq && e instanceof Element) {
                        if ("hover" === M) return e.addEventListener("mouseover", t, !0), e.addEventListener("mouseout", n, !0),
                            function() {
                                e.removeEventListener("mouseover", t, !0), e.removeEventListener("mouseout", n, !0)
                            };
                        var r = function(e) {
                            if (!q.current.contains(e.target)) return se(!1)
                        };
                        return document.addEventListener("click", r),
                            function() {
                                document.removeEventListener("click", r)
                            }
                    }
                    return s.es
                }), [M, re, ce, oe, ie, se]);
                var fe = "click" === M,
                    de = !h && I,
                    pe = l ? ue : void 0,
                    me = !fe && !l || z ? void 0 : _,
                    ve = fe ? le : void 0,
                    he = u()("".concat(G, "-wrap"), {
                        active: de
                    }, e.className),
                    be = u()("".concat(G, "-ele"), ((t = {})["".concat(G, "-ele-rtl")] = !!J, t), P),
                    ge = u()(G, {
                        active: de
                    }, T),
                    ye = J && y[O] || O,
                    we = (0, r.__assign)({
                        arrow: d,
                        offset: v,
                        variant: E,
                        placement: ye,
                        shadow: !0,
                        isFloat: !0,
                        enablePortal: R,
                        portalNode: S
                    }, W);
                "gray" === E && (we = (0, r.__assign)((0, r.__assign)({}, we), {
                    shadow: !1
                }));
                var _e = K && !h,
                    xe = A(G, L, _e),
                    Ce = xe.triggerAriaProps,
                    Ee = xe.contentAriaProps;
                return a().createElement(f.Ay, {
                    ref: q,
                    onClick: me,
                    className: he
                }, a().createElement(f.Ay, (0, r.__assign)({}, Ce, {
                    className: be,
                    onClick: ve,
                    children: e.children
                })), _e ? a().createElement(g, (0, r.__assign)({}, Ee, we, {
                    className: ge,
                    onClick: pe,
                    children: b
                })) : null)
            };
            O.displayName = "Tooltips";
            const N = O;
            var M = n("W3Ja");

            function D(e) {
                if (null == e) return window;
                if ("[object Window]" !== e.toString()) {
                    var t = e.ownerDocument;
                    return t && t.defaultView || window
                }
                return e
            }

            function R(e) {
                return e instanceof D(e).Element || e instanceof Element
            }

            function S(e) {
                return e instanceof D(e).HTMLElement || e instanceof HTMLElement
            }

            function T(e) {
                return "undefined" !== typeof ShadowRoot && (e instanceof D(e).ShadowRoot || e instanceof ShadowRoot)
            }
            var P = Math.max,
                j = Math.min,
                B = Math.round;

            function z() {
                var e = navigator.userAgentData;
                return null != e && e.brands && Array.isArray(e.brands) ? e.brands.map((function(e) {
                    return e.brand + "/" + e.version
                })).join(" ") : navigator.userAgent
            }

            function F() {
                return !/^((?!chrome|android).)*safari/i.test(z())
            }

            function L(e, t, n) {
                void 0 === t && (t = !1), void 0 === n && (n = !1);
                var r = e.getBoundingClientRect(),
                    o = 1,
                    a = 1;
                t && S(e) && (o = e.offsetWidth > 0 && B(r.width) / e.offsetWidth || 1, a = e.offsetHeight > 0 && B(r.height) / e.offsetHeight || 1);
                var i = (R(e) ? D(e) : window).visualViewport,
                    c = !F() && n,
                    s = (r.left + (c && i ? i.offsetLeft : 0)) / o,
                    l = (r.top + (c && i ? i.offsetTop : 0)) / a,
                    u = r.width / o,
                    f = r.height / a;
                return {
                    width: u,
                    height: f,
                    top: l,
                    right: s + u,
                    bottom: l + f,
                    left: s,
                    x: s,
                    y: l
                }
            }

            function W(e) {
                var t = D(e);
                return {
                    scrollLeft: t.pageXOffset,
                    scrollTop: t.pageYOffset
                }
            }

            function H(e) {
                return e ? (e.nodeName || "").toLowerCase() : null
            }

            function I(e) {
                return ((R(e) ? e.ownerDocument : e.document) || window.document).documentElement
            }

            function V(e) {
                return L(I(e)).left + W(e).scrollLeft
            }

            function q(e) {
                return D(e).getComputedStyle(e)
            }

            function Y(e) {
                var t = q(e),
                    n = t.overflow,
                    r = t.overflowX,
                    o = t.overflowY;
                return /auto|scroll|overlay|hidden/.test(n + o + r)
            }

            function Z(e, t, n) {
                void 0 === n && (n = !1);
                var r = S(t),
                    o = S(t) && function(e) {
                        var t = e.getBoundingClientRect(),
                            n = B(t.width) / e.offsetWidth || 1,
                            r = B(t.height) / e.offsetHeight || 1;
                        return 1 !== n || 1 !== r
                    }(t),
                    a = I(t),
                    i = L(e, o, n),
                    c = {
                        scrollLeft: 0,
                        scrollTop: 0
                    },
                    s = {
                        x: 0,
                        y: 0
                    };
                return (r || !r && !n) && (("body" !== H(t) || Y(a)) && (c = function(e) {
                    return e !== D(e) && S(e) ? {
                        scrollLeft: (t = e).scrollLeft,
                        scrollTop: t.scrollTop
                    } : W(e);
                    var t
                }(t)), S(t) ? ((s = L(t, !0)).x += t.clientLeft, s.y += t.clientTop) : a && (s.x = V(a))), {
                    x: i.left + c.scrollLeft - s.x,
                    y: i.top + c.scrollTop - s.y,
                    width: i.width,
                    height: i.height
                }
            }

            function X(e) {
                var t = L(e),
                    n = e.offsetWidth,
                    r = e.offsetHeight;
                return Math.abs(t.width - n) <= 1 && (n = t.width), Math.abs(t.height - r) <= 1 && (r = t.height), {
                    x: e.offsetLeft,
                    y: e.offsetTop,
                    width: n,
                    height: r
                }
            }

            function U(e) {
                return "html" === H(e) ? e : e.assignedSlot || e.parentNode || (T(e) ? e.host : null) || I(e)
            }

            function K(e) {
                return ["html", "body", "#document"].indexOf(H(e)) >= 0 ? e.ownerDocument.body : S(e) && Y(e) ? e : K(U(e))
            }

            function J(e, t) {
                var n;
                void 0 === t && (t = []);
                var r = K(e),
                    o = r === (null == (n = e.ownerDocument) ? void 0 : n.body),
                    a = D(r),
                    i = o ? [a].concat(a.visualViewport || [], Y(r) ? r : []) : r,
                    c = t.concat(i);
                return o ? c : c.concat(J(U(i)))
            }

            function Q(e) {
                return ["table", "td", "th"].indexOf(H(e)) >= 0
            }

            function G(e) {
                return S(e) && "fixed" !== q(e).position ? e.offsetParent : null
            }

            function $(e) {
                for (var t = D(e), n = G(e); n && Q(n) && "static" === q(n).position;) n = G(n);
                return n && ("html" === H(n) || "body" === H(n) && "static" === q(n).position) ? t : n || function(e) {
                    var t = /firefox/i.test(z());
                    if (/Trident/i.test(z()) && S(e) && "fixed" === q(e).position) return null;
                    var n = U(e);
                    for (T(n) && (n = n.host); S(n) && ["html", "body"].indexOf(H(n)) < 0;) {
                        var r = q(n);
                        if ("none" !== r.transform || "none" !== r.perspective || "paint" === r.contain || -1 !== ["transform", "perspective"].indexOf(r.willChange) || t && "filter" === r.willChange || t && r.filter && "none" !== r.filter) return n;
                        n = n.parentNode
                    }
                    return null
                }(e) || t
            }
            var ee = "top",
                te = "bottom",
                ne = "right",
                re = "left",
                oe = "auto",
                ae = [ee, te, ne, re],
                ie = "start",
                ce = "end",
                se = "viewport",
                le = "popper",
                ue = ae.reduce((function(e, t) {
                    return e.concat([t + "-" + ie, t + "-" + ce])
                }), []),
                fe = [].concat(ae, [oe]).reduce((function(e, t) {
                    return e.concat([t, t + "-" + ie, t + "-" + ce])
                }), []),
                de = ["beforeRead", "read", "afterRead", "beforeMain", "main", "afterMain", "beforeWrite", "write", "afterWrite"];

            function pe(e) {
                var t = new Map,
                    n = new Set,
                    r = [];

                function o(e) {
                    n.add(e.name), [].concat(e.requires || [], e.requiresIfExists || []).forEach((function(e) {
                        if (!n.has(e)) {
                            var r = t.get(e);
                            r && o(r)
                        }
                    })), r.push(e)
                }
                return e.forEach((function(e) {
                    t.set(e.name, e)
                })), e.forEach((function(e) {
                    n.has(e.name) || o(e)
                })), r
            }

            function me(e) {
                var t;
                return function() {
                    return t || (t = new Promise((function(n) {
                        Promise.resolve().then((function() {
                            t = void 0, n(e())
                        }))
                    }))), t
                }
            }
            var ve = {
                placement: "bottom",
                modifiers: [],
                strategy: "absolute"
            };

            function he() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return !t.some((function(e) {
                    return !(e && "function" === typeof e.getBoundingClientRect)
                }))
            }

            function be(e) {
                void 0 === e && (e = {});
                var t = e,
                    n = t.defaultModifiers,
                    r = void 0 === n ? [] : n,
                    o = t.defaultOptions,
                    a = void 0 === o ? ve : o;
                return function(e, t, n) {
                    void 0 === n && (n = a);
                    var o = {
                            placement: "bottom",
                            orderedModifiers: [],
                            options: Object.assign({}, ve, a),
                            modifiersData: {},
                            elements: {
                                reference: e,
                                popper: t
                            },
                            attributes: {},
                            styles: {}
                        },
                        i = [],
                        c = !1,
                        s = {
                            state: o,
                            setOptions: function(n) {
                                var c = "function" === typeof n ? n(o.options) : n;
                                l(), o.options = Object.assign({}, a, o.options, c), o.scrollParents = {
                                    reference: R(e) ? J(e) : e.contextElement ? J(e.contextElement) : [],
                                    popper: J(t)
                                };
                                var u = function(e) {
                                    var t = pe(e);
                                    return de.reduce((function(e, n) {
                                        return e.concat(t.filter((function(e) {
                                            return e.phase === n
                                        })))
                                    }), [])
                                }(function(e) {
                                    var t = e.reduce((function(e, t) {
                                        var n = e[t.name];
                                        return e[t.name] = n ? Object.assign({}, n, t, {
                                            options: Object.assign({}, n.options, t.options),
                                            data: Object.assign({}, n.data, t.data)
                                        }) : t, e
                                    }), {});
                                    return Object.keys(t).map((function(e) {
                                        return t[e]
                                    }))
                                }([].concat(r, o.options.modifiers)));
                                return o.orderedModifiers = u.filter((function(e) {
                                    return e.enabled
                                })), o.orderedModifiers.forEach((function(e) {
                                    var t = e.name,
                                        n = e.options,
                                        r = void 0 === n ? {} : n,
                                        a = e.effect;
                                    if ("function" === typeof a) {
                                        var c = a({
                                                state: o,
                                                name: t,
                                                instance: s,
                                                options: r
                                            }),
                                            l = function() {};
                                        i.push(c || l)
                                    }
                                })), s.update()
                            },
                            forceUpdate: function() {
                                if (!c) {
                                    var e = o.elements,
                                        t = e.reference,
                                        n = e.popper;
                                    if (he(t, n)) {
                                        o.rects = {
                                            reference: Z(t, $(n), "fixed" === o.options.strategy),
                                            popper: X(n)
                                        }, o.reset = !1, o.placement = o.options.placement, o.orderedModifiers.forEach((function(e) {
                                            return o.modifiersData[e.name] = Object.assign({}, e.data)
                                        }));
                                        for (var r = 0; r < o.orderedModifiers.length; r++)
                                            if (!0 !== o.reset) {
                                                var a = o.orderedModifiers[r],
                                                    i = a.fn,
                                                    l = a.options,
                                                    u = void 0 === l ? {} : l,
                                                    f = a.name;
                                                "function" === typeof i && (o = i({
                                                    state: o,
                                                    options: u,
                                                    name: f,
                                                    instance: s
                                                }) || o)
                                            } else o.reset = !1, r = -1
                                    }
                                }
                            },
                            update: me((function() {
                                return new Promise((function(e) {
                                    s.forceUpdate(), e(o)
                                }))
                            })),
                            destroy: function() {
                                l(), c = !0
                            }
                        };
                    if (!he(e, t)) return s;

                    function l() {
                        i.forEach((function(e) {
                            return e()
                        })), i = []
                    }
                    return s.setOptions(n).then((function(e) {
                        !c && n.onFirstUpdate && n.onFirstUpdate(e)
                    })), s
                }
            }
            var ge = {
                passive: !0
            };

            function ye(e) {
                return e.split("-")[0]
            }

            function we(e) {
                return e.split("-")[1]
            }

            function _e(e) {
                return ["top", "bottom"].indexOf(e) >= 0 ? "x" : "y"
            }

            function xe(e) {
                var t, n = e.reference,
                    r = e.element,
                    o = e.placement,
                    a = o ? ye(o) : null,
                    i = o ? we(o) : null,
                    c = n.x + n.width / 2 - r.width / 2,
                    s = n.y + n.height / 2 - r.height / 2;
                switch (a) {
                    case ee:
                        t = {
                            x: c,
                            y: n.y - r.height
                        };
                        break;
                    case te:
                        t = {
                            x: c,
                            y: n.y + n.height
                        };
                        break;
                    case ne:
                        t = {
                            x: n.x + n.width,
                            y: s
                        };
                        break;
                    case re:
                        t = {
                            x: n.x - r.width,
                            y: s
                        };
                        break;
                    default:
                        t = {
                            x: n.x,
                            y: n.y
                        }
                }
                var l = a ? _e(a) : null;
                if (null != l) {
                    var u = "y" === l ? "height" : "width";
                    switch (i) {
                        case ie:
                            t[l] = t[l] - (n[u] / 2 - r[u] / 2);
                            break;
                        case ce:
                            t[l] = t[l] + (n[u] / 2 - r[u] / 2)
                    }
                }
                return t
            }
            var Ce = {
                top: "auto",
                right: "auto",
                bottom: "auto",
                left: "auto"
            };

            function Ee(e) {
                var t, n = e.popper,
                    r = e.popperRect,
                    o = e.placement,
                    a = e.variation,
                    i = e.offsets,
                    c = e.position,
                    s = e.gpuAcceleration,
                    l = e.adaptive,
                    u = e.roundOffsets,
                    f = e.isFixed,
                    d = i.x,
                    p = void 0 === d ? 0 : d,
                    m = i.y,
                    v = void 0 === m ? 0 : m,
                    h = "function" === typeof u ? u({
                        x: p,
                        y: v
                    }) : {
                        x: p,
                        y: v
                    };
                p = h.x, v = h.y;
                var b = i.hasOwnProperty("x"),
                    g = i.hasOwnProperty("y"),
                    y = re,
                    w = ee,
                    _ = window;
                if (l) {
                    var x = $(n),
                        C = "clientHeight",
                        E = "clientWidth";
                    if (x === D(n) && "static" !== q(x = I(n)).position && "absolute" === c && (C = "scrollHeight", E = "scrollWidth"), o === ee || (o === re || o === ne) && a === ce) w = te, v -= (f && x === _ && _.visualViewport ? _.visualViewport.height : x[C]) - r.height, v *= s ? 1 : -1;
                    if (o === re || (o === ee || o === te) && a === ce) y = ne, p -= (f && x === _ && _.visualViewport ? _.visualViewport.width : x[E]) - r.width, p *= s ? 1 : -1
                }
                var k, A = Object.assign({
                        position: c
                    }, l && Ce),
                    O = !0 === u ? function(e, t) {
                        var n = e.x,
                            r = e.y,
                            o = t.devicePixelRatio || 1;
                        return {
                            x: B(n * o) / o || 0,
                            y: B(r * o) / o || 0
                        }
                    }({
                        x: p,
                        y: v
                    }, D(n)) : {
                        x: p,
                        y: v
                    };
                return p = O.x, v = O.y, s ? Object.assign({}, A, ((k = {})[w] = g ? "0" : "", k[y] = b ? "0" : "", k.transform = (_.devicePixelRatio || 1) <= 1 ? "translate(" + p + "px, " + v + "px)" : "translate3d(" + p + "px, " + v + "px, 0)", k)) : Object.assign({}, A, ((t = {})[w] = g ? v + "px" : "", t[y] = b ? p + "px" : "", t.transform = "", t))
            }
            const ke = {
                name: "offset",
                enabled: !0,
                phase: "main",
                requires: ["popperOffsets"],
                fn: function(e) {
                    var t = e.state,
                        n = e.options,
                        r = e.name,
                        o = n.offset,
                        a = void 0 === o ? [0, 0] : o,
                        i = fe.reduce((function(e, n) {
                            return e[n] = function(e, t, n) {
                                var r = ye(e),
                                    o = [re, ee].indexOf(r) >= 0 ? -1 : 1,
                                    a = "function" === typeof n ? n(Object.assign({}, t, {
                                        placement: e
                                    })) : n,
                                    i = a[0],
                                    c = a[1];
                                return i = i || 0, c = (c || 0) * o, [re, ne].indexOf(r) >= 0 ? {
                                    x: c,
                                    y: i
                                } : {
                                    x: i,
                                    y: c
                                }
                            }(n, t.rects, a), e
                        }), {}),
                        c = i[t.placement],
                        s = c.x,
                        l = c.y;
                    null != t.modifiersData.popperOffsets && (t.modifiersData.popperOffsets.x += s, t.modifiersData.popperOffsets.y += l), t.modifiersData[r] = i
                }
            };
            var Ae = {
                left: "right",
                right: "left",
                bottom: "top",
                top: "bottom"
            };

            function Oe(e) {
                return e.replace(/left|right|bottom|top/g, (function(e) {
                    return Ae[e]
                }))
            }
            var Ne = {
                start: "end",
                end: "start"
            };

            function Me(e) {
                return e.replace(/start|end/g, (function(e) {
                    return Ne[e]
                }))
            }

            function De(e, t) {
                var n = t.getRootNode && t.getRootNode();
                if (e.contains(t)) return !0;
                if (n && T(n)) {
                    var r = t;
                    do {
                        if (r && e.isSameNode(r)) return !0;
                        r = r.parentNode || r.host
                    } while (r)
                }
                return !1
            }

            function Re(e) {
                return Object.assign({}, e, {
                    left: e.x,
                    top: e.y,
                    right: e.x + e.width,
                    bottom: e.y + e.height
                })
            }

            function Se(e, t, n) {
                return t === se ? Re(function(e, t) {
                    var n = D(e),
                        r = I(e),
                        o = n.visualViewport,
                        a = r.clientWidth,
                        i = r.clientHeight,
                        c = 0,
                        s = 0;
                    if (o) {
                        a = o.width, i = o.height;
                        var l = F();
                        (l || !l && "fixed" === t) && (c = o.offsetLeft, s = o.offsetTop)
                    }
                    return {
                        width: a,
                        height: i,
                        x: c + V(e),
                        y: s
                    }
                }(e, n)) : R(t) ? function(e, t) {
                    var n = L(e, !1, "fixed" === t);
                    return n.top = n.top + e.clientTop, n.left = n.left + e.clientLeft, n.bottom = n.top + e.clientHeight, n.right = n.left + e.clientWidth, n.width = e.clientWidth, n.height = e.clientHeight, n.x = n.left, n.y = n.top, n
                }(t, n) : Re(function(e) {
                    var t, n = I(e),
                        r = W(e),
                        o = null == (t = e.ownerDocument) ? void 0 : t.body,
                        a = P(n.scrollWidth, n.clientWidth, o ? o.scrollWidth : 0, o ? o.clientWidth : 0),
                        i = P(n.scrollHeight, n.clientHeight, o ? o.scrollHeight : 0, o ? o.clientHeight : 0),
                        c = -r.scrollLeft + V(e),
                        s = -r.scrollTop;
                    return "rtl" === q(o || n).direction && (c += P(n.clientWidth, o ? o.clientWidth : 0) - a), {
                        width: a,
                        height: i,
                        x: c,
                        y: s
                    }
                }(I(e)))
            }

            function Te(e, t, n, r) {
                var o = "clippingParents" === t ? function(e) {
                        var t = J(U(e)),
                            n = ["absolute", "fixed"].indexOf(q(e).position) >= 0 && S(e) ? $(e) : e;
                        return R(n) ? t.filter((function(e) {
                            return R(e) && De(e, n) && "body" !== H(e)
                        })) : []
                    }(e) : [].concat(t),
                    a = [].concat(o, [n]),
                    i = a[0],
                    c = a.reduce((function(t, n) {
                        var o = Se(e, n, r);
                        return t.top = P(o.top, t.top), t.right = j(o.right, t.right), t.bottom = j(o.bottom, t.bottom), t.left = P(o.left, t.left), t
                    }), Se(e, i, r));
                return c.width = c.right - c.left, c.height = c.bottom - c.top, c.x = c.left, c.y = c.top, c
            }

            function Pe(e) {
                return Object.assign({}, {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                }, e)
            }

            function je(e, t) {
                return t.reduce((function(t, n) {
                    return t[n] = e, t
                }), {})
            }

            function Be(e, t) {
                void 0 === t && (t = {});
                var n = t,
                    r = n.placement,
                    o = void 0 === r ? e.placement : r,
                    a = n.strategy,
                    i = void 0 === a ? e.strategy : a,
                    c = n.boundary,
                    s = void 0 === c ? "clippingParents" : c,
                    l = n.rootBoundary,
                    u = void 0 === l ? se : l,
                    f = n.elementContext,
                    d = void 0 === f ? le : f,
                    p = n.altBoundary,
                    m = void 0 !== p && p,
                    v = n.padding,
                    h = void 0 === v ? 0 : v,
                    b = Pe("number" !== typeof h ? h : je(h, ae)),
                    g = d === le ? "reference" : le,
                    y = e.rects.popper,
                    w = e.elements[m ? g : d],
                    _ = Te(R(w) ? w : w.contextElement || I(e.elements.popper), s, u, i),
                    x = L(e.elements.reference),
                    C = xe({
                        reference: x,
                        element: y,
                        strategy: "absolute",
                        placement: o
                    }),
                    E = Re(Object.assign({}, y, C)),
                    k = d === le ? E : x,
                    A = {
                        top: _.top - k.top + b.top,
                        bottom: k.bottom - _.bottom + b.bottom,
                        left: _.left - k.left + b.left,
                        right: k.right - _.right + b.right
                    },
                    O = e.modifiersData.offset;
                if (d === le && O) {
                    var N = O[o];
                    Object.keys(A).forEach((function(e) {
                        var t = [ne, te].indexOf(e) >= 0 ? 1 : -1,
                            n = [ee, te].indexOf(e) >= 0 ? "y" : "x";
                        A[e] += N[n] * t
                    }))
                }
                return A
            }
            const ze = {
                name: "flip",
                enabled: !0,
                phase: "main",
                fn: function(e) {
                    var t = e.state,
                        n = e.options,
                        r = e.name;
                    if (!t.modifiersData[r]._skip) {
                        for (var o = n.mainAxis, a = void 0 === o || o, i = n.altAxis, c = void 0 === i || i, s = n.fallbackPlacements, l = n.padding, u = n.boundary, f = n.rootBoundary, d = n.altBoundary, p = n.flipVariations, m = void 0 === p || p, v = n.allowedAutoPlacements, h = t.options.placement, b = ye(h), g = s || (b === h || !m ? [Oe(h)] : function(e) {
                                if (ye(e) === oe) return [];
                                var t = Oe(e);
                                return [Me(e), t, Me(t)]
                            }(h)), y = [h].concat(g).reduce((function(e, n) {
                                return e.concat(ye(n) === oe ? function(e, t) {
                                    void 0 === t && (t = {});
                                    var n = t,
                                        r = n.placement,
                                        o = n.boundary,
                                        a = n.rootBoundary,
                                        i = n.padding,
                                        c = n.flipVariations,
                                        s = n.allowedAutoPlacements,
                                        l = void 0 === s ? fe : s,
                                        u = we(r),
                                        f = u ? c ? ue : ue.filter((function(e) {
                                            return we(e) === u
                                        })) : ae,
                                        d = f.filter((function(e) {
                                            return l.indexOf(e) >= 0
                                        }));
                                    0 === d.length && (d = f);
                                    var p = d.reduce((function(t, n) {
                                        return t[n] = Be(e, {
                                            placement: n,
                                            boundary: o,
                                            rootBoundary: a,
                                            padding: i
                                        })[ye(n)], t
                                    }), {});
                                    return Object.keys(p).sort((function(e, t) {
                                        return p[e] - p[t]
                                    }))
                                }(t, {
                                    placement: n,
                                    boundary: u,
                                    rootBoundary: f,
                                    padding: l,
                                    flipVariations: m,
                                    allowedAutoPlacements: v
                                }) : n)
                            }), []), w = t.rects.reference, _ = t.rects.popper, x = new Map, C = !0, E = y[0], k = 0; k < y.length; k++) {
                            var A = y[k],
                                O = ye(A),
                                N = we(A) === ie,
                                M = [ee, te].indexOf(O) >= 0,
                                D = M ? "width" : "height",
                                R = Be(t, {
                                    placement: A,
                                    boundary: u,
                                    rootBoundary: f,
                                    altBoundary: d,
                                    padding: l
                                }),
                                S = M ? N ? ne : re : N ? te : ee;
                            w[D] > _[D] && (S = Oe(S));
                            var T = Oe(S),
                                P = [];
                            if (a && P.push(R[O] <= 0), c && P.push(R[S] <= 0, R[T] <= 0), P.every((function(e) {
                                    return e
                                }))) {
                                E = A, C = !1;
                                break
                            }
                            x.set(A, P)
                        }
                        if (C)
                            for (var j = function(e) {
                                    var t = y.find((function(t) {
                                        var n = x.get(t);
                                        if (n) return n.slice(0, e).every((function(e) {
                                            return e
                                        }))
                                    }));
                                    if (t) return E = t, "break"
                                }, B = m ? 3 : 1; B > 0; B--) {
                                if ("break" === j(B)) break
                            }
                        t.placement !== E && (t.modifiersData[r]._skip = !0, t.placement = E, t.reset = !0)
                    }
                },
                requiresIfExists: ["offset"],
                data: {
                    _skip: !1
                }
            };

            function Fe(e, t, n) {
                return P(e, j(t, n))
            }
            const Le = {
                name: "preventOverflow",
                enabled: !0,
                phase: "main",
                fn: function(e) {
                    var t = e.state,
                        n = e.options,
                        r = e.name,
                        o = n.mainAxis,
                        a = void 0 === o || o,
                        i = n.altAxis,
                        c = void 0 !== i && i,
                        s = n.boundary,
                        l = n.rootBoundary,
                        u = n.altBoundary,
                        f = n.padding,
                        d = n.tether,
                        p = void 0 === d || d,
                        m = n.tetherOffset,
                        v = void 0 === m ? 0 : m,
                        h = Be(t, {
                            boundary: s,
                            rootBoundary: l,
                            padding: f,
                            altBoundary: u
                        }),
                        b = ye(t.placement),
                        g = we(t.placement),
                        y = !g,
                        w = _e(b),
                        _ = "x" === w ? "y" : "x",
                        x = t.modifiersData.popperOffsets,
                        C = t.rects.reference,
                        E = t.rects.popper,
                        k = "function" === typeof v ? v(Object.assign({}, t.rects, {
                            placement: t.placement
                        })) : v,
                        A = "number" === typeof k ? {
                            mainAxis: k,
                            altAxis: k
                        } : Object.assign({
                            mainAxis: 0,
                            altAxis: 0
                        }, k),
                        O = t.modifiersData.offset ? t.modifiersData.offset[t.placement] : null,
                        N = {
                            x: 0,
                            y: 0
                        };
                    if (x) {
                        if (a) {
                            var M, D = "y" === w ? ee : re,
                                R = "y" === w ? te : ne,
                                S = "y" === w ? "height" : "width",
                                T = x[w],
                                B = T + h[D],
                                z = T - h[R],
                                F = p ? -E[S] / 2 : 0,
                                L = g === ie ? C[S] : E[S],
                                W = g === ie ? -E[S] : -C[S],
                                H = t.elements.arrow,
                                I = p && H ? X(H) : {
                                    width: 0,
                                    height: 0
                                },
                                V = t.modifiersData["arrow#persistent"] ? t.modifiersData["arrow#persistent"].padding : {
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0
                                },
                                q = V[D],
                                Y = V[R],
                                Z = Fe(0, C[S], I[S]),
                                U = y ? C[S] / 2 - F - Z - q - A.mainAxis : L - Z - q - A.mainAxis,
                                K = y ? -C[S] / 2 + F + Z + Y + A.mainAxis : W + Z + Y + A.mainAxis,
                                J = t.elements.arrow && $(t.elements.arrow),
                                Q = J ? "y" === w ? J.clientTop || 0 : J.clientLeft || 0 : 0,
                                G = null != (M = null == O ? void 0 : O[w]) ? M : 0,
                                oe = T + K - G,
                                ae = Fe(p ? j(B, T + U - G - Q) : B, T, p ? P(z, oe) : z);
                            x[w] = ae, N[w] = ae - T
                        }
                        if (c) {
                            var ce, se = "x" === w ? ee : re,
                                le = "x" === w ? te : ne,
                                ue = x[_],
                                fe = "y" === _ ? "height" : "width",
                                de = ue + h[se],
                                pe = ue - h[le],
                                me = -1 !== [ee, re].indexOf(b),
                                ve = null != (ce = null == O ? void 0 : O[_]) ? ce : 0,
                                he = me ? de : ue - C[fe] - E[fe] - ve + A.altAxis,
                                be = me ? ue + C[fe] + E[fe] - ve - A.altAxis : pe,
                                ge = p && me ? function(e, t, n) {
                                    var r = Fe(e, t, n);
                                    return r > n ? n : r
                                }(he, ue, be) : Fe(p ? he : de, ue, p ? be : pe);
                            x[_] = ge, N[_] = ge - ue
                        }
                        t.modifiersData[r] = N
                    }
                },
                requiresIfExists: ["offset"]
            };
            const We = {
                name: "arrow",
                enabled: !0,
                phase: "main",
                fn: function(e) {
                    var t, n = e.state,
                        r = e.name,
                        o = e.options,
                        a = n.elements.arrow,
                        i = n.modifiersData.popperOffsets,
                        c = ye(n.placement),
                        s = _e(c),
                        l = [re, ne].indexOf(c) >= 0 ? "height" : "width";
                    if (a && i) {
                        var u = function(e, t) {
                                return Pe("number" !== typeof(e = "function" === typeof e ? e(Object.assign({}, t.rects, {
                                    placement: t.placement
                                })) : e) ? e : je(e, ae))
                            }(o.padding, n),
                            f = X(a),
                            d = "y" === s ? ee : re,
                            p = "y" === s ? te : ne,
                            m = n.rects.reference[l] + n.rects.reference[s] - i[s] - n.rects.popper[l],
                            v = i[s] - n.rects.reference[s],
                            h = $(a),
                            b = h ? "y" === s ? h.clientHeight || 0 : h.clientWidth || 0 : 0,
                            g = m / 2 - v / 2,
                            y = u[d],
                            w = b - f[l] - u[p],
                            _ = b / 2 - f[l] / 2 + g,
                            x = Fe(y, _, w),
                            C = s;
                        n.modifiersData[r] = ((t = {})[C] = x, t.centerOffset = x - _, t)
                    }
                },
                effect: function(e) {
                    var t = e.state,
                        n = e.options.element,
                        r = void 0 === n ? "[data-popper-arrow]" : n;
                    null != r && ("string" !== typeof r || (r = t.elements.popper.querySelector(r))) && De(t.elements.popper, r) && (t.elements.arrow = r)
                },
                requires: ["popperOffsets"],
                requiresIfExists: ["preventOverflow"]
            };

            function He(e, t, n) {
                return void 0 === n && (n = {
                    x: 0,
                    y: 0
                }), {
                    top: e.top - t.height - n.y,
                    right: e.right - t.width + n.x,
                    bottom: e.bottom - t.height + n.y,
                    left: e.left - t.width - n.x
                }
            }

            function Ie(e) {
                return [ee, ne, te, re].some((function(t) {
                    return e[t] >= 0
                }))
            }
            var Ve = be({
                    defaultModifiers: [{
                        name: "eventListeners",
                        enabled: !0,
                        phase: "write",
                        fn: function() {},
                        effect: function(e) {
                            var t = e.state,
                                n = e.instance,
                                r = e.options,
                                o = r.scroll,
                                a = void 0 === o || o,
                                i = r.resize,
                                c = void 0 === i || i,
                                s = D(t.elements.popper),
                                l = [].concat(t.scrollParents.reference, t.scrollParents.popper);
                            return a && l.forEach((function(e) {
                                    e.addEventListener("scroll", n.update, ge)
                                })), c && s.addEventListener("resize", n.update, ge),
                                function() {
                                    a && l.forEach((function(e) {
                                        e.removeEventListener("scroll", n.update, ge)
                                    })), c && s.removeEventListener("resize", n.update, ge)
                                }
                        },
                        data: {}
                    }, {
                        name: "popperOffsets",
                        enabled: !0,
                        phase: "read",
                        fn: function(e) {
                            var t = e.state,
                                n = e.name;
                            t.modifiersData[n] = xe({
                                reference: t.rects.reference,
                                element: t.rects.popper,
                                strategy: "absolute",
                                placement: t.placement
                            })
                        },
                        data: {}
                    }, {
                        name: "computeStyles",
                        enabled: !0,
                        phase: "beforeWrite",
                        fn: function(e) {
                            var t = e.state,
                                n = e.options,
                                r = n.gpuAcceleration,
                                o = void 0 === r || r,
                                a = n.adaptive,
                                i = void 0 === a || a,
                                c = n.roundOffsets,
                                s = void 0 === c || c,
                                l = {
                                    placement: ye(t.placement),
                                    variation: we(t.placement),
                                    popper: t.elements.popper,
                                    popperRect: t.rects.popper,
                                    gpuAcceleration: o,
                                    isFixed: "fixed" === t.options.strategy
                                };
                            null != t.modifiersData.popperOffsets && (t.styles.popper = Object.assign({}, t.styles.popper, Ee(Object.assign({}, l, {
                                offsets: t.modifiersData.popperOffsets,
                                position: t.options.strategy,
                                adaptive: i,
                                roundOffsets: s
                            })))), null != t.modifiersData.arrow && (t.styles.arrow = Object.assign({}, t.styles.arrow, Ee(Object.assign({}, l, {
                                offsets: t.modifiersData.arrow,
                                position: "absolute",
                                adaptive: !1,
                                roundOffsets: s
                            })))), t.attributes.popper = Object.assign({}, t.attributes.popper, {
                                "data-popper-placement": t.placement
                            })
                        },
                        data: {}
                    }, {
                        name: "applyStyles",
                        enabled: !0,
                        phase: "write",
                        fn: function(e) {
                            var t = e.state;
                            Object.keys(t.elements).forEach((function(e) {
                                var n = t.styles[e] || {},
                                    r = t.attributes[e] || {},
                                    o = t.elements[e];
                                S(o) && H(o) && (Object.assign(o.style, n), Object.keys(r).forEach((function(e) {
                                    var t = r[e];
                                    !1 === t ? o.removeAttribute(e) : o.setAttribute(e, !0 === t ? "" : t)
                                })))
                            }))
                        },
                        effect: function(e) {
                            var t = e.state,
                                n = {
                                    popper: {
                                        position: t.options.strategy,
                                        left: "0",
                                        top: "0",
                                        margin: "0"
                                    },
                                    arrow: {
                                        position: "absolute"
                                    },
                                    reference: {}
                                };
                            return Object.assign(t.elements.popper.style, n.popper), t.styles = n, t.elements.arrow && Object.assign(t.elements.arrow.style, n.arrow),
                                function() {
                                    Object.keys(t.elements).forEach((function(e) {
                                        var r = t.elements[e],
                                            o = t.attributes[e] || {},
                                            a = Object.keys(t.styles.hasOwnProperty(e) ? t.styles[e] : n[e]).reduce((function(e, t) {
                                                return e[t] = "", e
                                            }), {});
                                        S(r) && H(r) && (Object.assign(r.style, a), Object.keys(o).forEach((function(e) {
                                            r.removeAttribute(e)
                                        })))
                                    }))
                                }
                        },
                        requires: ["computeStyles"]
                    }, ke, ze, Le, We, {
                        name: "hide",
                        enabled: !0,
                        phase: "main",
                        requiresIfExists: ["preventOverflow"],
                        fn: function(e) {
                            var t = e.state,
                                n = e.name,
                                r = t.rects.reference,
                                o = t.rects.popper,
                                a = t.modifiersData.preventOverflow,
                                i = Be(t, {
                                    elementContext: "reference"
                                }),
                                c = Be(t, {
                                    altBoundary: !0
                                }),
                                s = He(i, r),
                                l = He(c, o, a),
                                u = Ie(s),
                                f = Ie(l);
                            t.modifiersData[n] = {
                                referenceClippingOffsets: s,
                                popperEscapeOffsets: l,
                                isReferenceHidden: u,
                                hasPopperEscaped: f
                            }, t.attributes.popper = Object.assign({}, t.attributes.popper, {
                                "data-popper-reference-hidden": u,
                                "data-popper-escaped": f
                            })
                        }
                    }]
                }),
                qe = n("F0GY"),
                Ye = n.n(qe),
                Ze = function(e) {
                    return e.reduce((function(e, t) {
                        var n = t[0],
                            r = t[1];
                        return e[n] = r, e
                    }), {})
                },
                Xe = window.document && window.document.createElement ? o.useLayoutEffect : o.useEffect,
                Ue = [],
                Ke = (0, o.forwardRef)((function(e, t) {
                    var n, o = e.arrow,
                        c = e.shadow,
                        s = e.variant,
                        l = void 0 === s ? "primary" : s,
                        d = (e.placement, e.style),
                        p = e.radius,
                        v = e.arrowRef,
                        h = e.arrowStyle,
                        b = e.bubbleFontSize,
                        g = void 0 === b ? 14 : b,
                        y = (0, r.__rest)(e, ["arrow", "shadow", "variant", "placement", "style", "radius", "arrowRef", "arrowStyle", "bubbleFontSize"]),
                        w = (0, m.r)().prefixCls,
                        _ = "".concat(w, "-bubble"),
                        x = u()(_, "".concat(_, "-web"), ((n = {})["".concat(_, "__").concat(l)] = !!l, n["data-font-".concat(g)] = !!g, n["web-shadow"] = !!c, n), e.className),
                        C = {
                            borderRadius: p
                        };
                    if (i.lq) throw new Error("this component only use Web side");
                    return a().createElement(f.Ay, (0, r.__assign)({}, y, {
                        className: x,
                        style: d,
                        ref: t
                    }), a().createElement(f.Ay, {
                        style: C,
                        className: "".concat(_, "-content"),
                        children: e.children
                    }), !!o && a().createElement(f.Ay, {
                        className: "".concat(_, "-web-arrow"),
                        style: h,
                        ref: v,
                        "data-popper-arrow": !0
                    }))
                }));
            Ke.displayName = "Bubble";
            const Je = Ke;
            var Qe = n("Svbh"),
                Ge = function(e) {
                    var t, n = e.open,
                        s = e.once,
                        l = e.arrow,
                        v = e.offset,
                        h = void 0 === v ? 12 : v,
                        b = e.disabled,
                        g = e.tooltips,
                        x = e.variant,
                        E = void 0 === x ? "gray" : x,
                        k = e.placement,
                        O = void 0 === k ? "top" : k,
                        N = e.trigger,
                        D = void 0 === N ? "hover" : N,
                        R = e.onVisibleChange,
                        S = e.enablePortal,
                        T = e.portalNode,
                        P = e.reactPopperProps,
                        j = void 0 === P ? {} : P,
                        B = j.sameWidth,
                        z = j.popperWidth,
                        F = j.offsetX,
                        L = j.screenPadding,
                        W = e.bubbleClassName,
                        H = e.bubbleWrapperClz,
                        I = e.triggerClassName,
                        V = e.enableHoverSafeArea,
                        q = e.delay,
                        Y = void 0 === q ? w : q,
                        Z = e.enableClickBubble,
                        X = e.ariaRole,
                        U = void 0 === X ? C : X,
                        K = (0, r.__rest)(e, ["open", "once", "arrow", "offset", "disabled", "tooltips", "variant", "placement", "trigger", "onVisibleChange", "enablePortal", "portalNode", "reactPopperProps", "bubbleClassName", "bubbleWrapperClz", "triggerClassName", "enableHoverSafeArea", "delay", "enableClickBubble", "ariaRole"]),
                        J = (0, o.useState)(n),
                        Q = J[0],
                        G = J[1],
                        $ = (0, o.useState)(null),
                        ee = $[0],
                        te = $[1],
                        ne = (0, m.r)(),
                        re = ne.prefixCls,
                        oe = ne.isMobile,
                        ae = ne.isTablet,
                        ie = ne.isRTL,
                        ce = ne.isClient,
                        se = (0, o.useState)(null),
                        le = se[0],
                        ue = se[1],
                        fe = (0, o.useState)(null),
                        de = fe[0],
                        pe = fe[1],
                        me = (0, o.useState)(null),
                        ve = me[0],
                        he = me[1],
                        be = (0, o.useState)(""),
                        ge = be[0],
                        ye = be[1],
                        we = !i.lq && !oe && !ae,
                        _e = "".concat(re, "-tooltips"),
                        xe = u()("".concat(re, "-tooltips-trans"), H),
                        Ce = u()("".concat(_e, "-ele"), ((t = {})["".concat(_e, "-ele-rtl")] = !!ie, t["".concat(_e, "-ele-with-safe-area")] = !!V && "hover" === D, t), I),
                        Ee = u()(_e, {
                            active: Q
                        }, W),
                        ke = u()("".concat(_e, "-wrap"), "".concat(_e, "-web"), {
                            active: !b && Q
                        }, K.className);
                    D = we ? D : "click";
                    var Ae = ie && y[O] || O;
                    if (i.lq) throw new Error("this component only use Web side");
                    var Oe = (0, c.d)({
                            fn: R
                        }).debounceFn,
                        Ne = (0, o.useCallback)((function(e) {
                            b || G((function(t) {
                                var n = "boolean" === typeof e ? e : !t;
                                return t !== n && (null === Oe || void 0 === Oe || Oe(n)), t !== n ? n : t
                            }))
                        }), [b, Oe]),
                        Me = (0, o.useMemo)((function() {
                            var e, t, n;
                            return "number" === typeof Y ? {
                                enter: Y,
                                leave: Y,
                                click: Y
                            } : {
                                enter: null !== (e = Y.enter) && void 0 !== e ? e : w,
                                leave: null !== (t = Y.leave) && void 0 !== t ? t : w,
                                click: null !== (n = Y.click) && void 0 !== n ? n : w
                            }
                        }), [Y]),
                        De = (0, c.d)({
                            fn: Ne,
                            time: Me.enter
                        }),
                        Re = De.debounceFn,
                        Se = De.clearTimer,
                        Te = (0, c.d)({
                            fn: Ne,
                            time: Me.leave
                        }),
                        Pe = Te.debounceFn,
                        je = Te.clearTimer,
                        Be = (0, c.d)({
                            fn: Ne,
                            time: Me.click
                        }).debounceFn,
                        ze = (0, o.useCallback)((function(e) {
                            var t = null === de || void 0 === de ? void 0 : de.contains(e.target),
                                n = null === le || void 0 === le ? void 0 : le.contains(e.target);
                            !(!s && t || n) && Q && Be(!1)
                        }), [Be, le, de, s, Q]);
                    h = l ? Math.max(h, 4) : h;
                    var Fe = a().useMemo((function() {
                            return {
                                name: "applyArrowHide",
                                enabled: !0,
                                phase: "write",
                                fn: function(e) {
                                    var t = e.state,
                                        n = t.placement,
                                        r = t.elements,
                                        o = t.rects,
                                        a = r.arrow,
                                        i = r.reference;
                                    if (a && i) {
                                        var c = (["top", "bottom"].includes(n.split("-")[0]) ? o.reference.width : o.reference.height) / 2 - 3,
                                            s = Math.abs(t.modifiersData.arrow.centerOffset),
                                            l = Math.abs(s) > c;
                                        a && (l ? a.setAttribute("data-hide", "") : a.removeAttribute("data-hide"))
                                    }
                                }
                            }
                        }), []),
                        Le = [{
                            name: "arrow",
                            options: {
                                element: ve,
                                padding: 12
                            }
                        }, {
                            name: "offset",
                            options: {
                                offset: [F || 0, h]
                            }
                        }, Fe],
                        We = a().useMemo((function() {
                            return {
                                name: "sameWidth",
                                enabled: !0,
                                phase: "beforeWrite",
                                requires: ["computeStyles"],
                                fn: function(e) {
                                    var t = e.state;
                                    t.styles.popper.width = "".concat(z || t.rects.reference.width, "px")
                                },
                                effect: function(e) {
                                    var t = e.state;
                                    t.elements.popper.style.width = "".concat(z || t.elements.reference.offsetWidth, "px")
                                }
                            }
                        }), [z]),
                        He = a().useMemo((function() {
                            return {
                                name: "preventOverflow",
                                options: {
                                    padding: L
                                }
                            }
                        }), [L]);
                    (z || B) && Le.push(We), L && Le.push(He);
                    var Ie = function(e, t, n) {
                            void 0 === n && (n = {});
                            var r = o.useRef(null),
                                a = {
                                    onFirstUpdate: n.onFirstUpdate,
                                    placement: n.placement || "bottom",
                                    strategy: n.strategy || "absolute",
                                    modifiers: n.modifiers || Ue
                                },
                                i = o.useState({
                                    styles: {
                                        popper: {
                                            position: a.strategy,
                                            left: "0",
                                            top: "0"
                                        },
                                        arrow: {
                                            position: "absolute"
                                        }
                                    },
                                    attributes: {}
                                }),
                                c = i[0],
                                s = i[1],
                                l = o.useMemo((function() {
                                    return {
                                        name: "updateState",
                                        enabled: !0,
                                        phase: "write",
                                        fn: function(e) {
                                            var t = e.state,
                                                n = Object.keys(t.elements);
                                            d.flushSync((function() {
                                                s({
                                                    styles: Ze(n.map((function(e) {
                                                        return [e, t.styles[e] || {}]
                                                    }))),
                                                    attributes: Ze(n.map((function(e) {
                                                        return [e, t.attributes[e]]
                                                    })))
                                                })
                                            }))
                                        },
                                        requires: ["computeStyles"]
                                    }
                                }), []),
                                u = o.useMemo((function() {
                                    var e = {
                                        onFirstUpdate: a.onFirstUpdate,
                                        placement: a.placement,
                                        strategy: a.strategy,
                                        modifiers: [].concat(a.modifiers, [l, {
                                            name: "applyStyles",
                                            enabled: !1
                                        }])
                                    };
                                    return Ye()(r.current, e) ? r.current || e : (r.current = e, e)
                                }), [a.onFirstUpdate, a.placement, a.strategy, a.modifiers, l]),
                                f = o.useRef();
                            return Xe((function() {
                                f.current && f.current.setOptions(u)
                            }), [u]), Xe((function() {
                                if (null != e && null != t) {
                                    var r = (n.createPopper || Ve)(e, t, u);
                                    return f.current = r,
                                        function() {
                                            r.destroy(), f.current = null
                                        }
                                }
                            }), [e, t, n.createPopper]), {
                                state: f.current ? f.current.state : null,
                                styles: c.styles,
                                attributes: c.attributes,
                                update: f.current ? f.current.update : null,
                                forceUpdate: f.current ? f.current.forceUpdate : null
                            }
                        }(le, de, {
                            placement: Ae,
                            strategy: "fixed",
                            modifiers: Le
                        }),
                        qe = Ie.styles,
                        Ke = Ie.attributes,
                        Ge = Ie.update,
                        $e = (0, o.useCallback)((function(e) {
                            !Z && _(e);
                            var t = null === de || void 0 === de ? void 0 : de.contains(e.target),
                                n = !s && t;
                            t && Ge && Ge(), n || Be(e)
                        }), [s, de, Be, Ge, Z]),
                        et = (0, o.useCallback)((function(e) {
                            if (de && le) {
                                var t, n, r, o = de.getBoundingClientRect(),
                                    a = le.getBoundingClientRect(),
                                    i = e.clientX - a.left,
                                    c = e.clientY - a.top,
                                    s = {
                                        top: o.top - a.top,
                                        bottom: o.bottom - a.top,
                                        left: o.left - a.left,
                                        right: o.right - a.left
                                    };
                                switch (Ae.split("-")[0]) {
                                    case "left":
                                        i = Math.min(i + 4, a.width);
                                        var l = s.top + (i - s.right) * (0 - s.top) / (a.width - s.right),
                                            u = s.bottom + (i - s.right) * (a.height - s.bottom) / (a.width - s.right);
                                        c = Math.min(Math.max(c, l), u), t = "".concat(i, ",").concat(c), n = "".concat(s.right, ",").concat(s.top - 2), r = "".concat(s.right, ",").concat(s.bottom + 2);
                                        break;
                                    case "right":
                                        i = Math.max(i - 4, 0);
                                        var f = s.top + (i - s.left) * (0 - s.top) / (0 - s.left),
                                            d = s.bottom + (i - s.left) * (a.height - s.bottom) / (0 - s.left);
                                        c = Math.min(Math.max(c, f), d), t = "".concat(i, ",").concat(c), n = "".concat(s.left, ",").concat(s.top - 2), r = "".concat(s.left, ",").concat(s.bottom + 2);
                                        break;
                                    case "top":
                                        c = Math.min(c + 4, a.height);
                                        var p = s.left + (c - s.bottom) * (0 - s.left) / (a.height - s.bottom),
                                            m = s.right + (c - s.bottom) * (a.width - s.right) / (a.height - s.bottom);
                                        i = Math.min(Math.max(i, p), m), t = "".concat(i, ",").concat(c), n = "".concat(s.left, ",").concat(s.bottom), r = "".concat(s.right, ",").concat(s.bottom);
                                        break;
                                    default:
                                        c = Math.max(c - 4, 0);
                                        var v = s.left + (c - s.top) * (0 - s.left) / (0 - s.top),
                                            h = s.right + (c - s.top) * (a.width - s.right) / (0 - s.top);
                                        i = Math.min(Math.max(i, v), h), t = "".concat(i, ",").concat(c), n = "".concat(s.left, ",").concat(s.top), r = "".concat(s.right, ",").concat(s.top)
                                }
                                ye("".concat(t, " ").concat(n, " ").concat(r))
                            }
                        }), [de, le, Ae]);
                    (0, o.useEffect)((function() {
                        return document.addEventListener("click", ze),
                            function() {
                                document.removeEventListener("click", ze)
                            }
                    }), [ze]), (0, o.useEffect)((function() {
                        "undefined" !== typeof n && !!n !== Q && G(n)
                    }), [n, Q]), (0, o.useEffect)((function() {
                        T instanceof HTMLElement ? te(T) : te(document.body)
                    }), [T]), (0, M.op)((function() {
                        null === Ge || void 0 === Ge || Ge()
                    }), [g, Ge]);
                    var tt = "hover" === D ? {
                            onMouseEnter: function() {
                                je(), Re(!0)
                            },
                            onMouseLeave: function() {
                                Se(), Pe(!1)
                            },
                            onMouseMove: V ? et : void 0
                        } : {
                            onClick: $e
                        },
                        nt = (0, r.__assign)({
                            arrow: l,
                            variant: E,
                            shadow: !0
                        }, K);
                    "gray" === E && (nt = (0, r.__assign)((0, r.__assign)({}, nt), {
                        shadow: !1
                    }));
                    var rt = !b && Q,
                        ot = A(_e, U, rt),
                        at = ot.triggerAriaProps,
                        it = ot.contentAriaProps,
                        ct = a().createElement(Qe.A, {
                            visible: rt,
                            className: xe
                        }, a().createElement(Je, (0, r.__assign)({}, it, nt, {
                            className: Ee,
                            ref: pe,
                            arrowRef: he,
                            arrowStyle: qe.arrow,
                            style: (0, r.__assign)((0, r.__assign)({}, qe.popper), null === K || void 0 === K ? void 0 : K.style)
                        }, Ke.popper, {
                            children: g
                        })));
                    return a().createElement(f.Ay, (0, r.__assign)({
                        ref: ue
                    }, tt, {
                        className: ke
                    }), V && "hover" === D && Q && a().createElement("svg", {
                        className: "".concat(_e, "-safety-triangle"),
                        pointerEvents: "none"
                    }, a().createElement("polygon", {
                        pointerEvents: "auto",
                        points: ge
                    })), a().createElement(f.Ay, (0, r.__assign)({}, at, {
                        className: Ce,
                        children: K.children
                    })), ce && S && null !== ee ? p().createPortal(ct, ee) : ct)
                };
            Ge.displayName = "Tooltips";
            const $e = Ge;
            var et = function(e) {
                var t = e.useReactPopper,
                    n = e.reactPopperProps,
                    o = e.enableHoverSafeArea,
                    c = e.bubbleWrapperClz,
                    s = (0, r.__rest)(e, ["useReactPopper", "reactPopperProps", "enableHoverSafeArea", "bubbleWrapperClz"]);
                return !i.lq && t ? a().createElement($e, (0, r.__assign)({
                    reactPopperProps: n,
                    enableHoverSafeArea: o,
                    bubbleWrapperClz: c
                }, s)) : a().createElement(N, (0, r.__assign)({}, s))
            };
            et.displayName = "Tooltips";
            const tt = et
        },
        F0GY: e => {
            var t = "undefined" !== typeof Element,
                n = "function" === typeof Map,
                r = "function" === typeof Set,
                o = "function" === typeof ArrayBuffer && !!ArrayBuffer.isView;

            function a(e, i) {
                if (e === i) return !0;
                if (e && i && "object" == typeof e && "object" == typeof i) {
                    if (e.constructor !== i.constructor) return !1;
                    var c, s, l, u;
                    if (Array.isArray(e)) {
                        if ((c = e.length) != i.length) return !1;
                        for (s = c; 0 !== s--;)
                            if (!a(e[s], i[s])) return !1;
                        return !0
                    }
                    if (n && e instanceof Map && i instanceof Map) {
                        if (e.size !== i.size) return !1;
                        for (u = e.entries(); !(s = u.next()).done;)
                            if (!i.has(s.value[0])) return !1;
                        for (u = e.entries(); !(s = u.next()).done;)
                            if (!a(s.value[1], i.get(s.value[0]))) return !1;
                        return !0
                    }
                    if (r && e instanceof Set && i instanceof Set) {
                        if (e.size !== i.size) return !1;
                        for (u = e.entries(); !(s = u.next()).done;)
                            if (!i.has(s.value[0])) return !1;
                        return !0
                    }
                    if (o && ArrayBuffer.isView(e) && ArrayBuffer.isView(i)) {
                        if ((c = e.length) != i.length) return !1;
                        for (s = c; 0 !== s--;)
                            if (e[s] !== i[s]) return !1;
                        return !0
                    }
                    if (e.constructor === RegExp) return e.source === i.source && e.flags === i.flags;
                    if (e.valueOf !== Object.prototype.valueOf) return e.valueOf() === i.valueOf();
                    if (e.toString !== Object.prototype.toString) return e.toString() === i.toString();
                    if ((c = (l = Object.keys(e)).length) !== Object.keys(i).length) return !1;
                    for (s = c; 0 !== s--;)
                        if (!Object.prototype.hasOwnProperty.call(i, l[s])) return !1;
                    if (t && e instanceof Element) return !1;
                    for (s = c; 0 !== s--;)
                        if (("_owner" !== l[s] && "__v" !== l[s] && "__o" !== l[s] || !e.$$typeof) && !a(e[l[s]], i[l[s]])) return !1;
                    return !0
                }
                return e !== e && i !== i
            }
            e.exports = function(e, t) {
                try {
                    return a(e, t)
                } catch (n) {
                    if ((n.message || "").match(/stack|recursion/i)) return console.warn("react-fast-compare cannot handle circular refs"), !1;
                    throw n
                }
            }
        }
    }
]);
//# debugId=e0f4f941-e9b0-5c4e-9293-946f8e966d22