"use strict";
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "0a7b8e5a-e825-581b-8e33-b4f3a5077f75")
    } catch (e) {}
}();
(self.webpackChunkrewards_hub_ui = self.webpackChunkrewards_hub_ui || []).push([
    [537], {
        CffR: (e, t, r) => {
            r.d(t, {
                Z5: () => a
            });
            var n = "i18n-auto-prefix-",
                a = function(e, t) {
                    return function(e) {
                        return null === e || void 0 === e ? void 0 : e.startsWith(n)
                    }(t) ? e(function(e) {
                        return null === e || void 0 === e ? void 0 : e.slice(n.length)
                    }(t)) : t
                }
        },
        lR91: (e, t, r) => {
            r.d(t, {
                O: () => u
            });
            var n = r("BK7R"),
                a = r("QUKP"),
                o = r("TrCV"),
                i = r("Y4uf"),
                u = function(e) {
                    return (0, o.jsxs)(i.A, (0, a.A)((0, n.A)({
                        width: "125",
                        height: "94",
                        viewBox: "0 0 125 94"
                    }, e), {
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: [(0, o.jsxs)("g", {
                            clipPath: "url(#clip0_323_37442)",
                            children: [(0, o.jsx)("path", {
                                d: "M45.3184 41.2534H80.2489V85.6995H45.3184V41.2534Z",
                                fill: "url(#paint0_linear_323_37442)"
                            }), (0, o.jsx)("path", {
                                d: "M80.2495 41.2534H112.97V85.6995H80.2495V41.2534Z",
                                fill: "url(#paint1_linear_323_37442)"
                            }), (0, o.jsx)("path", {
                                d: "M58.791 41.2534H66.4362V85.6995H58.791V41.2534Z",
                                fill: "#AEB4BC"
                            }), (0, o.jsx)("path", {
                                d: "M12.2269 32.2956L16.2386 28.2951L22.4117 34.4855L22.4239 25.7429L28.0893 25.7508L28.0771 34.4921L34.2666 28.32L38.267 32.3316L16.203 54.3343L12.2026 50.3226L18.3924 44.15L9.65176 44.1378L9.65967 38.4723L18.3985 38.4845L12.2269 32.2956Z",
                                fill: "#AEB4BC"
                            }), (0, o.jsx)("path", {
                                d: "M1.37109 68.541L53.1217 16.9348L61.122 24.9575L9.37139 76.5637L1.37109 68.541Z",
                                fill: "#F8D33A"
                            }), (0, o.jsx)("path", {
                                d: "M23.2275 46.7432L31.2509 38.7422L39.2514 46.7651L31.228 54.766L23.2275 46.7432Z",
                                fill: "#AEB4BC"
                            }), (0, o.jsx)("rect", {
                                x: "31.7361",
                                y: "67.8",
                                width: "5.38917",
                                height: "5.38917",
                                transform: "rotate(-45 31.7361 67.8)",
                                fill: "#E6E8EA"
                            }), (0, o.jsx)("rect", {
                                x: "114.473",
                                y: "35.9951",
                                width: "2.82425",
                                height: "2.82425",
                                transform: "rotate(-45 114.473 35.9951)",
                                fill: "#AEB4BC"
                            }), (0, o.jsx)("rect", {
                                x: "35.2568",
                                y: "15.4951",
                                width: "2.82425",
                                height: "2.82425",
                                transform: "rotate(-45 35.2568 15.4951)",
                                fill: "#AEB4BC"
                            }), (0, o.jsx)("rect", {
                                x: "101.409",
                                y: "7.35229",
                                width: "2.82425",
                                height: "2.82425",
                                transform: "rotate(-45 101.409 7.35229)",
                                fill: "#E6E8EA"
                            }), (0, o.jsx)("rect", {
                                x: "66.436",
                                y: "3.25781",
                                width: "4.0943",
                                height: "4.0943",
                                fill: "white"
                            }), (0, o.jsx)("path", {
                                d: "M63.6494 35.487C63.6494 24.0564 76.9161 12.8168 90.6646 16.4034C105.546 20.2854 100.866 39.3244 87.5347 35.487C75.0804 31.902 76.476 8.68311 98.8933 2.61011",
                                stroke: "#AEB4BC",
                                strokeWidth: "2.79"
                            }), (0, o.jsx)("path", {
                                d: "M95.481 85.7V69.2608C95.481 58.8281 100.28 51.5251 113.425 51.5251L121.146 51.5251",
                                stroke: "#AEB4BC",
                                strokeWidth: "8.37"
                            })]
                        }), (0, o.jsxs)("defs", {
                            children: [(0, o.jsxs)("linearGradient", {
                                id: "paint0_linear_323_37442",
                                x1: "62.7837",
                                y1: "41.2534",
                                x2: "62.7837",
                                y2: "85.6995",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, o.jsx)("stop", {
                                    stopColor: "#F0B90B"
                                }), (0, o.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#F8D33A"
                                })]
                            }), (0, o.jsxs)("linearGradient", {
                                id: "paint1_linear_323_37442",
                                x1: "96.61",
                                y1: "41.2534",
                                x2: "96.61",
                                y2: "85.6995",
                                gradientUnits: "userSpaceOnUse",
                                children: [(0, o.jsx)("stop", {
                                    stopColor: "#F8D33A"
                                }), (0, o.jsx)("stop", {
                                    offset: "1",
                                    stopColor: "#FCEA9C"
                                })]
                            }), (0, o.jsx)("clipPath", {
                                id: "clip0_323_37442",
                                children: (0, o.jsx)("rect", {
                                    width: "136.8",
                                    height: "92.4",
                                    fill: "white",
                                    transform: "translate(-4.75049 0.799805)"
                                })
                            })]
                        })]
                    }))
                }
        },
        RApW: (e, t, r) => {
            r.d(t, {
                Tk: () => oe,
                r6: () => ie,
                s7: () => ue
            });
            var n = r("JuBR"),
                a = r("mrqE");

            function o(e) {
                (0, a.A)(1, arguments);
                var t = (0, n.A)(e);
                return !isNaN(t)
            }
            var i = {
                lessThanXSeconds: {
                    one: "less than a second",
                    other: "less than {{count}} seconds"
                },
                xSeconds: {
                    one: "1 second",
                    other: "{{count}} seconds"
                },
                halfAMinute: "half a minute",
                lessThanXMinutes: {
                    one: "less than a minute",
                    other: "less than {{count}} minutes"
                },
                xMinutes: {
                    one: "1 minute",
                    other: "{{count}} minutes"
                },
                aboutXHours: {
                    one: "about 1 hour",
                    other: "about {{count}} hours"
                },
                xHours: {
                    one: "1 hour",
                    other: "{{count}} hours"
                },
                xDays: {
                    one: "1 day",
                    other: "{{count}} days"
                },
                aboutXWeeks: {
                    one: "about 1 week",
                    other: "about {{count}} weeks"
                },
                xWeeks: {
                    one: "1 week",
                    other: "{{count}} weeks"
                },
                aboutXMonths: {
                    one: "about 1 month",
                    other: "about {{count}} months"
                },
                xMonths: {
                    one: "1 month",
                    other: "{{count}} months"
                },
                aboutXYears: {
                    one: "about 1 year",
                    other: "about {{count}} years"
                },
                xYears: {
                    one: "1 year",
                    other: "{{count}} years"
                },
                overXYears: {
                    one: "over 1 year",
                    other: "over {{count}} years"
                },
                almostXYears: {
                    one: "almost 1 year",
                    other: "almost {{count}} years"
                }
            };

            function u(e) {
                return function(t) {
                    var r = t || {},
                        n = r.width ? String(r.width) : e.defaultWidth;
                    return e.formats[n] || e.formats[e.defaultWidth]
                }
            }
            var s = {
                date: u({
                    formats: {
                        full: "EEEE, MMMM do, y",
                        long: "MMMM do, y",
                        medium: "MMM d, y",
                        short: "MM/dd/yyyy"
                    },
                    defaultWidth: "full"
                }),
                time: u({
                    formats: {
                        full: "h:mm:ss a zzzz",
                        long: "h:mm:ss a z",
                        medium: "h:mm:ss a",
                        short: "h:mm a"
                    },
                    defaultWidth: "full"
                }),
                dateTime: u({
                    formats: {
                        full: "{{date}} 'at' {{time}}",
                        long: "{{date}} 'at' {{time}}",
                        medium: "{{date}}, {{time}}",
                        short: "{{date}}, {{time}}"
                    },
                    defaultWidth: "full"
                })
            };
            var c = {
                lastWeek: "'last' eeee 'at' p",
                yesterday: "'yesterday at' p",
                today: "'today at' p",
                tomorrow: "'tomorrow at' p",
                nextWeek: "eeee 'at' p",
                other: "P"
            };

            function d(e) {
                return function(t, r) {
                    var n, a = r || {};
                    if ("formatting" === (a.context ? String(a.context) : "standalone") && e.formattingValues) {
                        var o = e.defaultFormattingWidth || e.defaultWidth,
                            i = a.width ? String(a.width) : o;
                        n = e.formattingValues[i] || e.formattingValues[o]
                    } else {
                        var u = e.defaultWidth,
                            s = a.width ? String(a.width) : e.defaultWidth;
                        n = e.values[s] || e.values[u]
                    }
                    return n[e.argumentCallback ? e.argumentCallback(t) : t]
                }
            }

            function l(e) {
                return function(t, r) {
                    var n = String(t),
                        a = r || {},
                        o = a.width,
                        i = o && e.matchPatterns[o] || e.matchPatterns[e.defaultMatchWidth],
                        u = n.match(i);
                    if (!u) return null;
                    var s, c = u[0],
                        d = o && e.parsePatterns[o] || e.parsePatterns[e.defaultParseWidth];
                    return s = "[object Array]" === Object.prototype.toString.call(d) ? function(e, t) {
                        for (var r = 0; r < e.length; r++)
                            if (t(e[r])) return r
                    }(d, (function(e) {
                        return e.test(c)
                    })) : function(e, t) {
                        for (var r in e)
                            if (e.hasOwnProperty(r) && t(e[r])) return r
                    }(d, (function(e) {
                        return e.test(c)
                    })), s = e.valueCallback ? e.valueCallback(s) : s, {
                        value: s = a.valueCallback ? a.valueCallback(s) : s,
                        rest: n.slice(c.length)
                    }
                }
            }
            var h;
            const f = {
                code: "en-US",
                formatDistance: function(e, t, r) {
                    var n;
                    return r = r || {}, n = "string" === typeof i[e] ? i[e] : 1 === t ? i[e].one : i[e].other.replace("{{count}}", t), r.addSuffix ? r.comparison > 0 ? "in " + n : n + " ago" : n
                },
                formatLong: s,
                formatRelative: function(e, t, r, n) {
                    return c[e]
                },
                localize: {
                    ordinalNumber: function(e, t) {
                        var r = Number(e),
                            n = r % 100;
                        if (n > 20 || n < 10) switch (n % 10) {
                            case 1:
                                return r + "st";
                            case 2:
                                return r + "nd";
                            case 3:
                                return r + "rd"
                        }
                        return r + "th"
                    },
                    era: d({
                        values: {
                            narrow: ["B", "A"],
                            abbreviated: ["BC", "AD"],
                            wide: ["Before Christ", "Anno Domini"]
                        },
                        defaultWidth: "wide"
                    }),
                    quarter: d({
                        values: {
                            narrow: ["1", "2", "3", "4"],
                            abbreviated: ["Q1", "Q2", "Q3", "Q4"],
                            wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
                        },
                        defaultWidth: "wide",
                        argumentCallback: function(e) {
                            return Number(e) - 1
                        }
                    }),
                    month: d({
                        values: {
                            narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
                            abbreviated: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                            wide: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
                        },
                        defaultWidth: "wide"
                    }),
                    day: d({
                        values: {
                            narrow: ["S", "M", "T", "W", "T", "F", "S"],
                            short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
                            abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                            wide: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
                        },
                        defaultWidth: "wide"
                    }),
                    dayPeriod: d({
                        values: {
                            narrow: {
                                am: "a",
                                pm: "p",
                                midnight: "mi",
                                noon: "n",
                                morning: "morning",
                                afternoon: "afternoon",
                                evening: "evening",
                                night: "night"
                            },
                            abbreviated: {
                                am: "AM",
                                pm: "PM",
                                midnight: "midnight",
                                noon: "noon",
                                morning: "morning",
                                afternoon: "afternoon",
                                evening: "evening",
                                night: "night"
                            },
                            wide: {
                                am: "a.m.",
                                pm: "p.m.",
                                midnight: "midnight",
                                noon: "noon",
                                morning: "morning",
                                afternoon: "afternoon",
                                evening: "evening",
                                night: "night"
                            }
                        },
                        defaultWidth: "wide",
                        formattingValues: {
                            narrow: {
                                am: "a",
                                pm: "p",
                                midnight: "mi",
                                noon: "n",
                                morning: "in the morning",
                                afternoon: "in the afternoon",
                                evening: "in the evening",
                                night: "at night"
                            },
                            abbreviated: {
                                am: "AM",
                                pm: "PM",
                                midnight: "midnight",
                                noon: "noon",
                                morning: "in the morning",
                                afternoon: "in the afternoon",
                                evening: "in the evening",
                                night: "at night"
                            },
                            wide: {
                                am: "a.m.",
                                pm: "p.m.",
                                midnight: "midnight",
                                noon: "noon",
                                morning: "in the morning",
                                afternoon: "in the afternoon",
                                evening: "in the evening",
                                night: "at night"
                            }
                        },
                        defaultFormattingWidth: "wide"
                    })
                },
                match: {
                    ordinalNumber: (h = {
                        matchPattern: /^(\d+)(th|st|nd|rd)?/i,
                        parsePattern: /\d+/i,
                        valueCallback: function(e) {
                            return parseInt(e, 10)
                        }
                    }, function(e, t) {
                        var r = String(e),
                            n = t || {},
                            a = r.match(h.matchPattern);
                        if (!a) return null;
                        var o = a[0],
                            i = r.match(h.parsePattern);
                        if (!i) return null;
                        var u = h.valueCallback ? h.valueCallback(i[0]) : i[0];
                        return {
                            value: u = n.valueCallback ? n.valueCallback(u) : u,
                            rest: r.slice(o.length)
                        }
                    }),
                    era: l({
                        matchPatterns: {
                            narrow: /^(b|a)/i,
                            abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
                            wide: /^(before christ|before common era|anno domini|common era)/i
                        },
                        defaultMatchWidth: "wide",
                        parsePatterns: {
                            any: [/^b/i, /^(a|c)/i]
                        },
                        defaultParseWidth: "any"
                    }),
                    quarter: l({
                        matchPatterns: {
                            narrow: /^[1234]/i,
                            abbreviated: /^q[1234]/i,
                            wide: /^[1234](th|st|nd|rd)? quarter/i
                        },
                        defaultMatchWidth: "wide",
                        parsePatterns: {
                            any: [/1/i, /2/i, /3/i, /4/i]
                        },
                        defaultParseWidth: "any",
                        valueCallback: function(e) {
                            return e + 1
                        }
                    }),
                    month: l({
                        matchPatterns: {
                            narrow: /^[jfmasond]/i,
                            abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
                            wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
                        },
                        defaultMatchWidth: "wide",
                        parsePatterns: {
                            narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
                            any: [/^ja/i, /^f/i, /^mar/i, /^ap/i, /^may/i, /^jun/i, /^jul/i, /^au/i, /^s/i, /^o/i, /^n/i, /^d/i]
                        },
                        defaultParseWidth: "any"
                    }),
                    day: l({
                        matchPatterns: {
                            narrow: /^[smtwf]/i,
                            short: /^(su|mo|tu|we|th|fr|sa)/i,
                            abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
                            wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
                        },
                        defaultMatchWidth: "wide",
                        parsePatterns: {
                            narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
                            any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
                        },
                        defaultParseWidth: "any"
                    }),
                    dayPeriod: l({
                        matchPatterns: {
                            narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
                            any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
                        },
                        defaultMatchWidth: "any",
                        parsePatterns: {
                            any: {
                                am: /^a/i,
                                pm: /^p/i,
                                midnight: /^mi/i,
                                noon: /^no/i,
                                morning: /morning/i,
                                afternoon: /afternoon/i,
                                evening: /evening/i,
                                night: /night/i
                            }
                        },
                        defaultParseWidth: "any"
                    })
                },
                options: {
                    weekStartsOn: 0,
                    firstWeekContainsDate: 1
                }
            };
            var p = r("N1LS");

            function m(e, t) {
                (0, a.A)(2, arguments);
                var r = (0, n.A)(e).getTime(),
                    o = (0, p.A)(t);
                return new Date(r + o)
            }

            function E(e, t) {
                (0, a.A)(2, arguments);
                var r = (0, p.A)(t);
                return m(e, -r)
            }

            function U(e, t) {
                for (var r = e < 0 ? "-" : "", n = Math.abs(e).toString(); n.length < t;) n = "0" + n;
                return r + n
            }
            const T = {
                y: function(e, t) {
                    var r = e.getUTCFullYear(),
                        n = r > 0 ? r : 1 - r;
                    return U("yy" === t ? n % 100 : n, t.length)
                },
                M: function(e, t) {
                    var r = e.getUTCMonth();
                    return "M" === t ? String(r + 1) : U(r + 1, 2)
                },
                d: function(e, t) {
                    return U(e.getUTCDate(), t.length)
                },
                a: function(e, t) {
                    var r = e.getUTCHours() / 12 >= 1 ? "pm" : "am";
                    switch (t) {
                        case "a":
                        case "aa":
                            return r.toUpperCase();
                        case "aaa":
                            return r;
                        case "aaaaa":
                            return r[0];
                        default:
                            return "am" === r ? "a.m." : "p.m."
                    }
                },
                h: function(e, t) {
                    return U(e.getUTCHours() % 12 || 12, t.length)
                },
                H: function(e, t) {
                    return U(e.getUTCHours(), t.length)
                },
                m: function(e, t) {
                    return U(e.getUTCMinutes(), t.length)
                },
                s: function(e, t) {
                    return U(e.getUTCSeconds(), t.length)
                },
                S: function(e, t) {
                    var r = t.length,
                        n = e.getUTCMilliseconds();
                    return U(Math.floor(n * Math.pow(10, r - 3)), t.length)
                }
            };
            var R = 864e5;

            function y(e) {
                (0, a.A)(1, arguments);
                var t = 1,
                    r = (0, n.A)(e),
                    o = r.getUTCDay(),
                    i = (o < t ? 7 : 0) + o - t;
                return r.setUTCDate(r.getUTCDate() - i), r.setUTCHours(0, 0, 0, 0), r
            }

            function C(e) {
                (0, a.A)(1, arguments);
                var t = (0, n.A)(e),
                    r = t.getUTCFullYear(),
                    o = new Date(0);
                o.setUTCFullYear(r + 1, 0, 4), o.setUTCHours(0, 0, 0, 0);
                var i = y(o),
                    u = new Date(0);
                u.setUTCFullYear(r, 0, 4), u.setUTCHours(0, 0, 0, 0);
                var s = y(u);
                return t.getTime() >= i.getTime() ? r + 1 : t.getTime() >= s.getTime() ? r : r - 1
            }

            function _(e) {
                (0, a.A)(1, arguments);
                var t = C(e),
                    r = new Date(0);
                r.setUTCFullYear(t, 0, 4), r.setUTCHours(0, 0, 0, 0);
                var n = y(r);
                return n
            }
            var b = 6048e5;

            function g(e, t) {
                (0, a.A)(1, arguments);
                var r = t || {},
                    o = r.locale,
                    i = o && o.options && o.options.weekStartsOn,
                    u = null == i ? 0 : (0, p.A)(i),
                    s = null == r.weekStartsOn ? u : (0, p.A)(r.weekStartsOn);
                if (!(s >= 0 && s <= 6)) throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");
                var c = (0, n.A)(e),
                    d = c.getUTCDay(),
                    l = (d < s ? 7 : 0) + d - s;
                return c.setUTCDate(c.getUTCDate() - l), c.setUTCHours(0, 0, 0, 0), c
            }

            function v(e, t) {
                (0, a.A)(1, arguments);
                var r = (0, n.A)(e, t),
                    o = r.getUTCFullYear(),
                    i = t || {},
                    u = i.locale,
                    s = u && u.options && u.options.firstWeekContainsDate,
                    c = null == s ? 1 : (0, p.A)(s),
                    d = null == i.firstWeekContainsDate ? c : (0, p.A)(i.firstWeekContainsDate);
                if (!(d >= 1 && d <= 7)) throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");
                var l = new Date(0);
                l.setUTCFullYear(o + 1, 0, d), l.setUTCHours(0, 0, 0, 0);
                var h = g(l, t),
                    f = new Date(0);
                f.setUTCFullYear(o, 0, d), f.setUTCHours(0, 0, 0, 0);
                var m = g(f, t);
                return r.getTime() >= h.getTime() ? o + 1 : r.getTime() >= m.getTime() ? o : o - 1
            }

            function A(e, t) {
                (0, a.A)(1, arguments);
                var r = t || {},
                    n = r.locale,
                    o = n && n.options && n.options.firstWeekContainsDate,
                    i = null == o ? 1 : (0, p.A)(o),
                    u = null == r.firstWeekContainsDate ? i : (0, p.A)(r.firstWeekContainsDate),
                    s = v(e, t),
                    c = new Date(0);
                c.setUTCFullYear(s, 0, u), c.setUTCHours(0, 0, 0, 0);
                var d = g(c, t);
                return d
            }
            var w = 6048e5;
            var I = "midnight",
                N = "noon",
                O = "morning",
                M = "afternoon",
                S = "evening",
                V = "night",
                L = {
                    G: function(e, t, r) {
                        var n = e.getUTCFullYear() > 0 ? 1 : 0;
                        switch (t) {
                            case "G":
                            case "GG":
                            case "GGG":
                                return r.era(n, {
                                    width: "abbreviated"
                                });
                            case "GGGGG":
                                return r.era(n, {
                                    width: "narrow"
                                });
                            default:
                                return r.era(n, {
                                    width: "wide"
                                })
                        }
                    },
                    y: function(e, t, r) {
                        if ("yo" === t) {
                            var n = e.getUTCFullYear(),
                                a = n > 0 ? n : 1 - n;
                            return r.ordinalNumber(a, {
                                unit: "year"
                            })
                        }
                        return T.y(e, t)
                    },
                    Y: function(e, t, r, n) {
                        var a = v(e, n),
                            o = a > 0 ? a : 1 - a;
                        return "YY" === t ? U(o % 100, 2) : "Yo" === t ? r.ordinalNumber(o, {
                            unit: "year"
                        }) : U(o, t.length)
                    },
                    R: function(e, t) {
                        return U(C(e), t.length)
                    },
                    u: function(e, t) {
                        return U(e.getUTCFullYear(), t.length)
                    },
                    Q: function(e, t, r) {
                        var n = Math.ceil((e.getUTCMonth() + 1) / 3);
                        switch (t) {
                            case "Q":
                                return String(n);
                            case "QQ":
                                return U(n, 2);
                            case "Qo":
                                return r.ordinalNumber(n, {
                                    unit: "quarter"
                                });
                            case "QQQ":
                                return r.quarter(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                });
                            case "QQQQQ":
                                return r.quarter(n, {
                                    width: "narrow",
                                    context: "formatting"
                                });
                            default:
                                return r.quarter(n, {
                                    width: "wide",
                                    context: "formatting"
                                })
                        }
                    },
                    q: function(e, t, r) {
                        var n = Math.ceil((e.getUTCMonth() + 1) / 3);
                        switch (t) {
                            case "q":
                                return String(n);
                            case "qq":
                                return U(n, 2);
                            case "qo":
                                return r.ordinalNumber(n, {
                                    unit: "quarter"
                                });
                            case "qqq":
                                return r.quarter(n, {
                                    width: "abbreviated",
                                    context: "standalone"
                                });
                            case "qqqqq":
                                return r.quarter(n, {
                                    width: "narrow",
                                    context: "standalone"
                                });
                            default:
                                return r.quarter(n, {
                                    width: "wide",
                                    context: "standalone"
                                })
                        }
                    },
                    M: function(e, t, r) {
                        var n = e.getUTCMonth();
                        switch (t) {
                            case "M":
                            case "MM":
                                return T.M(e, t);
                            case "Mo":
                                return r.ordinalNumber(n + 1, {
                                    unit: "month"
                                });
                            case "MMM":
                                return r.month(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                });
                            case "MMMMM":
                                return r.month(n, {
                                    width: "narrow",
                                    context: "formatting"
                                });
                            default:
                                return r.month(n, {
                                    width: "wide",
                                    context: "formatting"
                                })
                        }
                    },
                    L: function(e, t, r) {
                        var n = e.getUTCMonth();
                        switch (t) {
                            case "L":
                                return String(n + 1);
                            case "LL":
                                return U(n + 1, 2);
                            case "Lo":
                                return r.ordinalNumber(n + 1, {
                                    unit: "month"
                                });
                            case "LLL":
                                return r.month(n, {
                                    width: "abbreviated",
                                    context: "standalone"
                                });
                            case "LLLLL":
                                return r.month(n, {
                                    width: "narrow",
                                    context: "standalone"
                                });
                            default:
                                return r.month(n, {
                                    width: "wide",
                                    context: "standalone"
                                })
                        }
                    },
                    w: function(e, t, r, o) {
                        var i = function(e, t) {
                            (0, a.A)(1, arguments);
                            var r = (0, n.A)(e),
                                o = g(r, t).getTime() - A(r, t).getTime();
                            return Math.round(o / w) + 1
                        }(e, o);
                        return "wo" === t ? r.ordinalNumber(i, {
                            unit: "week"
                        }) : U(i, t.length)
                    },
                    I: function(e, t, r) {
                        var o = function(e) {
                            (0, a.A)(1, arguments);
                            var t = (0, n.A)(e),
                                r = y(t).getTime() - _(t).getTime();
                            return Math.round(r / b) + 1
                        }(e);
                        return "Io" === t ? r.ordinalNumber(o, {
                            unit: "week"
                        }) : U(o, t.length)
                    },
                    d: function(e, t, r) {
                        return "do" === t ? r.ordinalNumber(e.getUTCDate(), {
                            unit: "date"
                        }) : T.d(e, t)
                    },
                    D: function(e, t, r) {
                        var o = function(e) {
                            (0, a.A)(1, arguments);
                            var t = (0, n.A)(e),
                                r = t.getTime();
                            t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0);
                            var o = t.getTime(),
                                i = r - o;
                            return Math.floor(i / R) + 1
                        }(e);
                        return "Do" === t ? r.ordinalNumber(o, {
                            unit: "dayOfYear"
                        }) : U(o, t.length)
                    },
                    E: function(e, t, r) {
                        var n = e.getUTCDay();
                        switch (t) {
                            case "E":
                            case "EE":
                            case "EEE":
                                return r.day(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                });
                            case "EEEEE":
                                return r.day(n, {
                                    width: "narrow",
                                    context: "formatting"
                                });
                            case "EEEEEE":
                                return r.day(n, {
                                    width: "short",
                                    context: "formatting"
                                });
                            default:
                                return r.day(n, {
                                    width: "wide",
                                    context: "formatting"
                                })
                        }
                    },
                    e: function(e, t, r, n) {
                        var a = e.getUTCDay(),
                            o = (a - n.weekStartsOn + 8) % 7 || 7;
                        switch (t) {
                            case "e":
                                return String(o);
                            case "ee":
                                return U(o, 2);
                            case "eo":
                                return r.ordinalNumber(o, {
                                    unit: "day"
                                });
                            case "eee":
                                return r.day(a, {
                                    width: "abbreviated",
                                    context: "formatting"
                                });
                            case "eeeee":
                                return r.day(a, {
                                    width: "narrow",
                                    context: "formatting"
                                });
                            case "eeeeee":
                                return r.day(a, {
                                    width: "short",
                                    context: "formatting"
                                });
                            default:
                                return r.day(a, {
                                    width: "wide",
                                    context: "formatting"
                                })
                        }
                    },
                    c: function(e, t, r, n) {
                        var a = e.getUTCDay(),
                            o = (a - n.weekStartsOn + 8) % 7 || 7;
                        switch (t) {
                            case "c":
                                return String(o);
                            case "cc":
                                return U(o, t.length);
                            case "co":
                                return r.ordinalNumber(o, {
                                    unit: "day"
                                });
                            case "ccc":
                                return r.day(a, {
                                    width: "abbreviated",
                                    context: "standalone"
                                });
                            case "ccccc":
                                return r.day(a, {
                                    width: "narrow",
                                    context: "standalone"
                                });
                            case "cccccc":
                                return r.day(a, {
                                    width: "short",
                                    context: "standalone"
                                });
                            default:
                                return r.day(a, {
                                    width: "wide",
                                    context: "standalone"
                                })
                        }
                    },
                    i: function(e, t, r) {
                        var n = e.getUTCDay(),
                            a = 0 === n ? 7 : n;
                        switch (t) {
                            case "i":
                                return String(a);
                            case "ii":
                                return U(a, t.length);
                            case "io":
                                return r.ordinalNumber(a, {
                                    unit: "day"
                                });
                            case "iii":
                                return r.day(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                });
                            case "iiiii":
                                return r.day(n, {
                                    width: "narrow",
                                    context: "formatting"
                                });
                            case "iiiiii":
                                return r.day(n, {
                                    width: "short",
                                    context: "formatting"
                                });
                            default:
                                return r.day(n, {
                                    width: "wide",
                                    context: "formatting"
                                })
                        }
                    },
                    a: function(e, t, r) {
                        var n = e.getUTCHours() / 12 >= 1 ? "pm" : "am";
                        switch (t) {
                            case "a":
                            case "aa":
                                return r.dayPeriod(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                });
                            case "aaa":
                                return r.dayPeriod(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                }).toLowerCase();
                            case "aaaaa":
                                return r.dayPeriod(n, {
                                    width: "narrow",
                                    context: "formatting"
                                });
                            default:
                                return r.dayPeriod(n, {
                                    width: "wide",
                                    context: "formatting"
                                })
                        }
                    },
                    b: function(e, t, r) {
                        var n, a = e.getUTCHours();
                        switch (n = 12 === a ? N : 0 === a ? I : a / 12 >= 1 ? "pm" : "am", t) {
                            case "b":
                            case "bb":
                                return r.dayPeriod(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                });
                            case "bbb":
                                return r.dayPeriod(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                }).toLowerCase();
                            case "bbbbb":
                                return r.dayPeriod(n, {
                                    width: "narrow",
                                    context: "formatting"
                                });
                            default:
                                return r.dayPeriod(n, {
                                    width: "wide",
                                    context: "formatting"
                                })
                        }
                    },
                    B: function(e, t, r) {
                        var n, a = e.getUTCHours();
                        switch (n = a >= 17 ? S : a >= 12 ? M : a >= 4 ? O : V, t) {
                            case "B":
                            case "BB":
                            case "BBB":
                                return r.dayPeriod(n, {
                                    width: "abbreviated",
                                    context: "formatting"
                                });
                            case "BBBBB":
                                return r.dayPeriod(n, {
                                    width: "narrow",
                                    context: "formatting"
                                });
                            default:
                                return r.dayPeriod(n, {
                                    width: "wide",
                                    context: "formatting"
                                })
                        }
                    },
                    h: function(e, t, r) {
                        if ("ho" === t) {
                            var n = e.getUTCHours() % 12;
                            return 0 === n && (n = 12), r.ordinalNumber(n, {
                                unit: "hour"
                            })
                        }
                        return T.h(e, t)
                    },
                    H: function(e, t, r) {
                        return "Ho" === t ? r.ordinalNumber(e.getUTCHours(), {
                            unit: "hour"
                        }) : T.H(e, t)
                    },
                    K: function(e, t, r) {
                        var n = e.getUTCHours() % 12;
                        return "Ko" === t ? r.ordinalNumber(n, {
                            unit: "hour"
                        }) : U(n, t.length)
                    },
                    k: function(e, t, r) {
                        var n = e.getUTCHours();
                        return 0 === n && (n = 24), "ko" === t ? r.ordinalNumber(n, {
                            unit: "hour"
                        }) : U(n, t.length)
                    },
                    m: function(e, t, r) {
                        return "mo" === t ? r.ordinalNumber(e.getUTCMinutes(), {
                            unit: "minute"
                        }) : T.m(e, t)
                    },
                    s: function(e, t, r) {
                        return "so" === t ? r.ordinalNumber(e.getUTCSeconds(), {
                            unit: "second"
                        }) : T.s(e, t)
                    },
                    S: function(e, t) {
                        return T.S(e, t)
                    },
                    X: function(e, t, r, n) {
                        var a = (n._originalDate || e).getTimezoneOffset();
                        if (0 === a) return "Z";
                        switch (t) {
                            case "X":
                                return F(a);
                            case "XXXX":
                            case "XX":
                                return P(a);
                            default:
                                return P(a, ":")
                        }
                    },
                    x: function(e, t, r, n) {
                        var a = (n._originalDate || e).getTimezoneOffset();
                        switch (t) {
                            case "x":
                                return F(a);
                            case "xxxx":
                            case "xx":
                                return P(a);
                            default:
                                return P(a, ":")
                        }
                    },
                    O: function(e, t, r, n) {
                        var a = (n._originalDate || e).getTimezoneOffset();
                        switch (t) {
                            case "O":
                            case "OO":
                            case "OOO":
                                return "GMT" + D(a, ":");
                            default:
                                return "GMT" + P(a, ":")
                        }
                    },
                    z: function(e, t, r, n) {
                        var a = (n._originalDate || e).getTimezoneOffset();
                        switch (t) {
                            case "z":
                            case "zz":
                            case "zzz":
                                return "GMT" + D(a, ":");
                            default:
                                return "GMT" + P(a, ":")
                        }
                    },
                    t: function(e, t, r, n) {
                        var a = n._originalDate || e;
                        return U(Math.floor(a.getTime() / 1e3), t.length)
                    },
                    T: function(e, t, r, n) {
                        return U((n._originalDate || e).getTime(), t.length)
                    }
                };

            function D(e, t) {
                var r = e > 0 ? "-" : "+",
                    n = Math.abs(e),
                    a = Math.floor(n / 60),
                    o = n % 60;
                if (0 === o) return r + String(a);
                var i = t || "";
                return r + String(a) + i + U(o, 2)
            }

            function F(e, t) {
                return e % 60 === 0 ? (e > 0 ? "-" : "+") + U(Math.abs(e) / 60, 2) : P(e, t)
            }

            function P(e, t) {
                var r = t || "",
                    n = e > 0 ? "-" : "+",
                    a = Math.abs(e);
                return n + U(Math.floor(a / 60), 2) + r + U(a % 60, 2)
            }
            const x = L;

            function G(e, t) {
                switch (e) {
                    case "P":
                        return t.date({
                            width: "short"
                        });
                    case "PP":
                        return t.date({
                            width: "medium"
                        });
                    case "PPP":
                        return t.date({
                            width: "long"
                        });
                    default:
                        return t.date({
                            width: "full"
                        })
                }
            }

            function k(e, t) {
                switch (e) {
                    case "p":
                        return t.time({
                            width: "short"
                        });
                    case "pp":
                        return t.time({
                            width: "medium"
                        });
                    case "ppp":
                        return t.time({
                            width: "long"
                        });
                    default:
                        return t.time({
                            width: "full"
                        })
                }
            }
            var H = {
                p: k,
                P: function(e, t) {
                    var r, n = e.match(/(P+)(p+)?/),
                        a = n[1],
                        o = n[2];
                    if (!o) return G(e, t);
                    switch (a) {
                        case "P":
                            r = t.dateTime({
                                width: "short"
                            });
                            break;
                        case "PP":
                            r = t.dateTime({
                                width: "medium"
                            });
                            break;
                        case "PPP":
                            r = t.dateTime({
                                width: "long"
                            });
                            break;
                        default:
                            r = t.dateTime({
                                width: "full"
                            })
                    }
                    return r.replace("{{date}}", G(a, t)).replace("{{time}}", k(o, t))
                }
            };
            const Y = H;

            function B(e) {
                var t = new Date(Date.UTC(e.getFullYear(), e.getMonth(), e.getDate(), e.getHours(), e.getMinutes(), e.getSeconds(), e.getMilliseconds()));
                return t.setUTCFullYear(e.getFullYear()), e.getTime() - t.getTime()
            }
            var j = ["D", "DD"],
                W = ["YY", "YYYY"];

            function K(e) {
                return -1 !== j.indexOf(e)
            }

            function q(e) {
                return -1 !== W.indexOf(e)
            }

            function Q(e, t, r) {
                if ("YYYY" === e) throw new RangeError("Use `yyyy` instead of `YYYY` (in `".concat(t, "`) for formatting years to the input `").concat(r, "`; see: https://git.io/fxCyr"));
                if ("YY" === e) throw new RangeError("Use `yy` instead of `YY` (in `".concat(t, "`) for formatting years to the input `").concat(r, "`; see: https://git.io/fxCyr"));
                if ("D" === e) throw new RangeError("Use `d` instead of `D` (in `".concat(t, "`) for formatting days of the month to the input `").concat(r, "`; see: https://git.io/fxCyr"));
                if ("DD" === e) throw new RangeError("Use `dd` instead of `DD` (in `".concat(t, "`) for formatting days of the month to the input `").concat(r, "`; see: https://git.io/fxCyr"))
            }
            var z = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,
                Z = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,
                X = /^'([^]*?)'?$/,
                J = /''/g,
                $ = /[a-zA-Z]/;

            function ee(e, t, r) {
                (0, a.A)(2, arguments);
                var i = String(t),
                    u = r || {},
                    s = u.locale || f,
                    c = s.options && s.options.firstWeekContainsDate,
                    d = null == c ? 1 : (0, p.A)(c),
                    l = null == u.firstWeekContainsDate ? d : (0, p.A)(u.firstWeekContainsDate);
                if (!(l >= 1 && l <= 7)) throw new RangeError("firstWeekContainsDate must be between 1 and 7 inclusively");
                var h = s.options && s.options.weekStartsOn,
                    m = null == h ? 0 : (0, p.A)(h),
                    U = null == u.weekStartsOn ? m : (0, p.A)(u.weekStartsOn);
                if (!(U >= 0 && U <= 6)) throw new RangeError("weekStartsOn must be between 0 and 6 inclusively");
                if (!s.localize) throw new RangeError("locale must contain localize property");
                if (!s.formatLong) throw new RangeError("locale must contain formatLong property");
                var T = (0, n.A)(e);
                if (!o(T)) throw new RangeError("Invalid time value");
                var R = B(T),
                    y = E(T, R),
                    C = {
                        firstWeekContainsDate: l,
                        weekStartsOn: U,
                        locale: s,
                        _originalDate: T
                    },
                    _ = i.match(Z).map((function(e) {
                        var t = e[0];
                        return "p" === t || "P" === t ? (0, Y[t])(e, s.formatLong, C) : e
                    })).join("").match(z).map((function(r) {
                        if ("''" === r) return "'";
                        var n = r[0];
                        if ("'" === n) return te(r);
                        var a = x[n];
                        if (a) return !u.useAdditionalWeekYearTokens && q(r) && Q(r, t, e), !u.useAdditionalDayOfYearTokens && K(r) && Q(r, t, e), a(y, r, s.localize, C);
                        if (n.match($)) throw new RangeError("Format string contains an unescaped latin alphabet character `" + n + "`");
                        return r
                    })).join("");
                return _
            }

            function te(e) {
                return e.match(X)[1].replace(J, "'")
            }
            var re = r("nsO7"),
                ne = r("yiIT"),
                ae = function(e) {
                    var t = e / 60 * -1;
                    return "(UTC".concat(t >= 0 ? "+" : "-").concat(t, ")")
                }((new Date).getTimezoneOffset()),
                oe = function(e) {
                    var t, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ", ";
                    return null === (t = null === e || void 0 === e ? void 0 : e.filter((function(e) {
                        return !(0, re.isEmpty)(e) && !(0, re.isNull)(e) && !(0, re.isUndefined)(e)
                    }))) || void 0 === t ? void 0 : t.join(r)
                },
                ie = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Date.now(),
                        t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    return t ? "".concat(ee(new Date(e), "yyyy-MM-dd HH:mm"), " ").concat(ae) : "".concat(ee(new Date(e), "yyyy-MM-dd HH:mm"))
                },
                ue = function(e) {
                    return ne.ro.includes(e) ? ne.Z9 : e
                }
        },
        HjzO: (e, t, r) => {
            r.d(t, {
                u: () => u
            });
            var n = r("BK7R"),
                a = r("QUKP"),
                o = {
                    code: "11023",
                    message: "access denied",
                    messageDetail: "access denied",
                    data: null,
                    success: !1,
                    status: "ERROR",
                    type: "GENERAL"
                },
                i = {
                    code: "000000",
                    message: null,
                    messageDetail: null,
                    data: null,
                    success: !0,
                    status: "OK",
                    type: "GENERAL"
                },
                u = function(e) {
                    var t = e.success,
                        r = void 0 === t || t,
                        u = e.data,
                        s = void 0 === u ? null : u,
                        c = e.code,
                        d = void 0 === c ? "110002" : c;
                    return new Promise((function(e) {
                        setTimeout((function() {
                            e(r ? (0, a.A)((0, n.A)({}, i), {
                                data: s
                            }) : (0, a.A)((0, n.A)({}, o), {
                                data: s,
                                code: d
                            }))
                        }), 300)
                    }))
                }
        },
        "dh/N": (e, t, r) => {
            r.d(t, {
                jI: () => l,
                d3: () => h,
                Mz: () => m,
                tj: () => E,
                j0: () => p,
                Rp: () => d,
                zl: () => c,
                T: () => f
            });
            var n = r("sViW"),
                a = r("BK7R"),
                o = r("Pz56"),
                i = r.n(o),
                u = r("xj71"),
                s = r("3qxK"),
                c = (r("HjzO"), function() {
                    var e = (0, n.A)(i().mark((function e() {
                        var t, r;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    e.next = 5;
                                    break;
                                case 3:
                                    return t = e.sent, e.abrupt("return", t.data);
                                case 5:
                                    return e.next = 7, (0, s.b)("/bapi/composite/v1/private/promo/voucherV2/rewardhub", {}, {});
                                case 7:
                                    return r = e.sent, e.abrupt("return", r.data);
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }()),
                d = function() {
                    var e = (0, n.A)(i().mark((function e(t) {
                        var r, n, o;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    e.next = 5;
                                    break;
                                case 3:
                                    return r = e.sent, e.abrupt("return", r.data);
                                case 5:
                                    return n = t.tab, e.next = 8, (0, s.b)("/bapi/composite/v1/private/promo/voucherV2/list", t, {});
                                case 8:
                                    return o = e.sent, e.abrupt("return", (0, a.A)({
                                        tab: n
                                    }, o.data));
                                case 10:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                l = function() {
                    var e = (0, n.A)(i().mark((function e(t) {
                        var r, n;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    e.next = 5;
                                    break;
                                case 3:
                                    return r = e.sent, e.abrupt("return", r);
                                case 5:
                                    return e.next = 7, (0, s.b)("/bapi/composite/v1/private/promo/voucherV2/claim", t, {});
                                case 7:
                                    return n = e.sent, e.abrupt("return", n);
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                h = function() {
                    var e = (0, n.A)(i().mark((function e(t) {
                        var r, n;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    e.next = 5;
                                    break;
                                case 3:
                                    return r = e.sent, e.abrupt("return", r);
                                case 5:
                                    return e.next = 7, (0, s.b)("/bapi/composite/v1/private/promo/voucherV2/code/claim", t, {});
                                case 7:
                                    return n = e.sent, e.abrupt("return", n);
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                f = function() {
                    var e = (0, n.A)(i().mark((function e(t) {
                        var r, n;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    e.next = 5;
                                    break;
                                case 3:
                                    return r = e.sent, e.abrupt("return", r);
                                case 5:
                                    return e.next = 7, (0, s.b)("/bapi/composite/v1/private/promo/voucherV2/use", t, {});
                                case 7:
                                    return n = e.sent, e.abrupt("return", n);
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                p = function() {
                    var e = (0, n.A)(i().mark((function e(t) {
                        var r;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, (0, s.b)("/bapi/composite/v1/private/promo/voucherV2/query", t, {});
                                case 2:
                                    return r = e.sent, e.abrupt("return", r.data);
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                m = function() {
                    var e = (0, n.A)(i().mark((function e(t) {
                        var r;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, (0, u.Jt)("/bapi/earn/v1/public/lending/daily/product/getProductIdByAsset?asset=".concat(t));
                                case 2:
                                    return r = e.sent, e.abrupt("return", r);
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                E = function() {
                    var e = (0, n.A)(i().mark((function e() {
                        var t;
                        return i().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, (0, s.b)("/bapi/composite/v1/private/promo/voucherV2/codeHistory");
                                case 2:
                                    return t = e.sent, e.abrupt("return", t);
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }()
        },
        "6jV+": (e, t, r) => {
            r.d(t, {
                F0: () => w,
                IH: () => a,
                fi: () => v,
                nH: () => A,
                z0: () => n
            });
            var n = "/simple-earn?asset=%asset%&coupon=%couponId%",
                a = {
                    pro: {
                        "2.55.0": "bnc://app.binance.com/earns/couponBuy?asset=%asset%&coupon=%couponId%",
                        lowerVersion: "bnc://app.binance.com/earns/couponBuy?asset=%asset%&product=%productId%&coupon=%couponId%&selectTrialTab=true"
                    },
                    lite: "bnc://app.binance.com/earns/liteCouponBuy?asset=%asset%&coupon=%couponId%"
                },
                o = "/my/wallet/account/margin",
                i = "/my/wallet/c2c/balance",
                u = "/my/wallet/account/futures",
                s = "/simple-earn",
                c = "bnc://app.binance.com/funds/funds?at=margin",
                d = "bnc://app.binance.com/funds/funds?at=fiat",
                l = "bnc://app.binance.com/funds/funds?at=spot",
                h = "bnc://app.binance.com/funds/funds?at=futures",
                f = "bnc://app.binance.com/funds/funds?at=delivery",
                p = "bnc://app.binance.com/earns/couponBuy?product=%product%&coupon=%voucherId%",
                m = "bnc://app.binance.com/trade/trade?at=futures&symbol=btcusdt",
                E = "bnc://app.binance.com/trade/trade?at=delivery",
                U = "bnc://app.binance.com/trade/trade?at=spot&symbol=btcusdt",
                T = "bnc://app.binance.com/trade/trade?at=margin&symbol=btcusdt",
                R = "bnc://app.binance.com/trade/trade?at=margin&symbol=btcusdt",
                y = "bnc://app.binance.com/trade/trade?at=margin&symbol=btcusdt",
                C = "bnc://app.binance.com/margin/borrowAndRepay?type=cross&mode=borrow&asset=%facePriceUnit%",
                _ = "bnc://app.binance.com/margin/borrowAndRepay?type=isolated&mode=borrow&symbol=%selectedCoin%&asset=%facePriceUnit%",
                b = "bnc://app.binance.com/mp/app?appId=1kq94jFiS3LLBZTWU9C1LV&startPagePath=cGFnZXMvaG9tZS9pbmRleA==",
                g = "bnc://app.binance.com/webview/webview/?type=default&url=aHR0cHM6Ly93d3cuYmluYW5jZS5jb20vZW4vZmVlL3ZpcA",
                v = {
                    C2C: i,
                    MARGIN: o,
                    MARGIN_CROSS: o,
                    MARGIN_ISOLATED: o,
                    FUTURE: u,
                    FUTURE_DELIVERY: u
                },
                A = {
                    CASH_COUPON: {
                        C2C: {
                            web: i,
                            iOS: d,
                            Android: d
                        },
                        SPOT: {
                            web: "/my/wallet/exchange/balance",
                            iOS: l,
                            Android: l
                        },
                        FUTURE: {
                            web: u,
                            iOS: h,
                            Android: h
                        },
                        FUTURE_DELIVERY: {
                            web: "/my/wallet/account/futures",
                            iOS: {
                                "2.17.0": f,
                                lowVersion: h
                            },
                            Android: {
                                "1.26.0": f,
                                lowVersion: h
                            }
                        },
                        MARGIN: {
                            web: o,
                            iOS: c,
                            Android: c
                        }
                    },
                    FUTURE_GIF_MONEY: {
                        FUTURE: {
                            web: "/my/orders/futures/transactionhistory",
                            iOS: h,
                            Android: h
                        },
                        FUTURE_DELIVERY: {
                            web: "/my/orders/futures/transactionhistory",
                            iOS: {
                                "2.17.0": "bnc://app.binance.com/funds/funds?at=delivery",
                                lowVersion: h
                            },
                            Android: {
                                "1.26.0": f,
                                lowVersion: h
                            }
                        }
                    },
                    SAVING_GIF_MONEY: {
                        SAVINGS: {
                            web: s,
                            iOS: p,
                            Android: p
                        },
                        SIMPLE_EARN: {
                            web: s,
                            iOS: p,
                            Android: p
                        }
                    },
                    LOCKED_GIF_MONEY: {
                        SAVINGS: {
                            web: s,
                            iOS: p,
                            Android: p
                        },
                        SIMPLE_EARN: {
                            web: s,
                            iOS: p,
                            Android: p
                        }
                    },
                    VIP_UPGRADE: {
                        PLATFORM: {
                            web: "/fee/vip",
                            iOS: g,
                            Android: g
                        }
                    },
                    FEE_REBATE: {
                        FUTURE: {
                            web: "/futuresng/BTC_USDT",
                            iOS: m,
                            Android: m,
                            lite: "/support/faq/360039304272"
                        },
                        FUTURE_DELIVERY: {
                            web: "/delivery/BTCUSD_QUARTER",
                            iOS: {
                                "2.17.0": E,
                                lowVersion: m
                            },
                            Android: {
                                "1.26.0": E,
                                lowVersion: m
                            },
                            lite: "/support/faq/360039304272"
                        },
                        SPOT: {
                            web: "/trade/pro/BTC_USDT?type=spot",
                            iOS: U,
                            Android: U,
                            lite: "/support/faq/c0669862a9e743d781c067c14106c29a"
                        },
                        MARGIN: {
                            web: "/trade/pro/BTC_USDT?type=cross",
                            iOS: T,
                            Android: T,
                            lite: "/support/faq/360041505471"
                        },
                        MARGIN_CROSS: {
                            web: "/trade/pro/BTC_USDT?type=cross",
                            iOS: R,
                            Android: R,
                            lite: "/support/faq/360041505471"
                        },
                        MARGIN_ISOLATED: {
                            web: "/trade/pro/BTC_USDT?type=cross",
                            iOS: y,
                            Android: y,
                            lite: "/support/faq/360041505471"
                        },
                        C2C: {
                            web: i,
                            iOS: d,
                            Android: d
                        },
                        NFT: {
                            web: "/nft/home",
                            iOS: b,
                            Android: b,
                            lite: "/support/faq/777d6487fb7b491696571e3cbf3518f7"
                        }
                    },
                    MARGIN_LOAN: {
                        MARGIN_CROSS: {
                            web: "/my/wallet/account/margin/cross?coin=%facePriceUnit%",
                            iOS: {
                                "2.20.0": C,
                                lowVersion: c
                            },
                            Android: {
                                "1.31.0": C,
                                lowVersion: c
                            }
                        },
                        MARGIN_ISOLATED: {
                            web: "/my/wallet/account/margin/isolated?symbol=%selectedCoin%&coin=%facePriceUnit%",
                            iOS: {
                                "2.20.0": _,
                                lowVersion: c
                            },
                            Android: {
                                "1.31.0": _,
                                lowVersion: c
                            }
                        }
                    },
                    CUSTOM_VOUCHER: {}
                },
                w = {
                    SPOT: {
                        web: "/my/orders/exchange/usertrade",
                        ios: "bnc://app.binance.com/orders/orders?at=spot",
                        android: "bnc://app.binance.com/orders/orders?at=spot"
                    },
                    MARGIN: {
                        web: "/my/orders/margin/usertrade",
                        ios: "bnc://app.binance.com/orders/marginHistory?type=liquidation",
                        android: "bnc://app.binance.com/orders/marginHistory?type=liquidation"
                    },
                    FUTURE: {
                        web: "/my/orders/futures/tradehistory",
                        ios: "bnc://app.binance.com/orders/futuresHistory?type=liquidation",
                        android: "bnc://app.binance.com/orders/futuresHistory?type=liquidation"
                    },
                    NFT: {
                        web: "/nft",
                        ios: "bnc://app.binance.com/mp/app?appId=1kq94jFiS3LLBZTWU9C1LV&startPagePath=cGFnZXMvb3RoZXIvd2ViL2luZGV4&startPageQuery=d2ViU3JjPSU3QiUyMnNyYyUyMiUzQSUyMiUyRmVuJTJGbmZ0JTJGY29sbGVjdGlvbiUyRndpbi1uZnQtaGVyby02MTgwMTczMjI4OTI4NTMyNDglMjIlMkMlMjJpc0NvbmNhdGVuYXRlZCUyMiUzQXRydWUlN0Q=",
                        android: "bnc://app.binance.com/mp/app?appId=1kq94jFiS3LLBZTWU9C1LV&startPagePath=cGFnZXMvb3RoZXIvd2ViL2luZGV4&startPageQuery=d2ViU3JjPSU3QiUyMnNyYyUyMiUzQSUyMiUyRmVuJTJGbmZ0JTJGY29sbGVjdGlvbiUyRndpbi1uZnQtaGVyby02MTgwMTczMjI4OTI4NTMyNDglMjIlMkMlMjJpc0NvbmNhdGVuYXRlZCUyMiUzQXRydWUlN0Q="
                    }
                }
        },
        eNvi: (e, t, r) => {
            r.d(t, {
                V: () => a
            });
            var n = {
                    SPOT: {
                        key: "product-spot",
                        defaultValue: "Spot"
                    },
                    MARGIN: {
                        key: "product-margin",
                        defaultValue: "Margin"
                    },
                    MARGIN_CROSS: {
                        key: "product-cross-margin",
                        defaultValue: "Cross Margin"
                    },
                    CROSS_MARGIN: {
                        key: "product-cross-margin",
                        defaultValue: "Cross Margin"
                    },
                    MARGIN_ISOLATED: {
                        key: "product-isolated-margin",
                        defaultValue: "Isolated Margin"
                    },
                    ISOLATED_MARGIN: {
                        key: "product-isolated-margin",
                        defaultValue: "Isolated Margin"
                    },
                    FUTURE: {
                        key: "product-future",
                        defaultValue: "USD-\u24c2 Futures"
                    },
                    PERPETUAL_FEATURE: {
                        key: "product-future",
                        defaultValue: "USD-\u24c2 Futures"
                    },
                    FUTURE_DELIVERY: {
                        key: "product-future-delivery",
                        defaultValue: "COIN-\u24c2 Futures"
                    },
                    QUARTERLY_FEATURE: {
                        key: "product-future-delivery",
                        defaultValue: "COIN-\u24c2 Futures"
                    },
                    SAVINGS: {
                        key: "product-savings",
                        defaultValue: "Simple Earn"
                    },
                    SIMPLE_EARN: {
                        key: "product-simple-earn",
                        defaultValue: "Simple Earn"
                    },
                    NFT: {
                        key: "product-nft",
                        defaultValue: "NFT"
                    },
                    CONVERT: {
                        key: "product-convert",
                        defaultValue: "Convert"
                    },
                    OPTIONS: {
                        key: "product-options",
                        defaultValue: "Options"
                    },
                    PLATFORM: {
                        key: "product-platform",
                        defaultValue: "Platform"
                    },
                    FUTURE_FREE_POSITION: {
                        key: "product-future-position",
                        defaultValue: "Futures Position"
                    }
                },
                a = function(e, t) {
                    var r = n[e || ""];
                    return r ? t(r.key, r.defaultValue) : ""
                }
        },
        u7Qj: (e, t, r) => {
            r.d(t, {
                fv: () => l,
                rN: () => h,
                sj: () => f,
                VG: () => d.V,
                PK: () => p,
                t8: () => a,
                IG: () => n
            });
            var n = {
                    VIP_UPGRADE: {
                        key: "voucherType-vipUpgrade",
                        defaultValue: "Vip Upgrade",
                        voucherNameKey: "voucherName-vipUpgrade",
                        defaultVoucherName: "VIP Upgrade Voucher",
                        imageFileName: "vip-upgrade-voucher-{{theme}}.svg"
                    },
                    SAVING_GIF_MONEY: {
                        key: "voucherType-flexibleTrialFund",
                        defaultValue: "Flexible Trial Fund",
                        voucherNameKey: "voucherName-flexibleTrialFund",
                        defaultVoucherName: "Flexible Trial Fund Voucher",
                        imageFileName: "flexible-trial-fund-voucher-{{theme}}.svg"
                    },
                    LOCKED_GIF_MONEY: {
                        key: "voucherType-lockedTrialFund",
                        defaultValue: "Locked Trial Fund",
                        voucherNameKey: "voucherName-lockedTrialFund",
                        defaultVoucherName: "Locked Trial Fund Voucher",
                        imageFileName: "locked-trial-fund-voucher-{{theme}}.svg"
                    },
                    FUTURE_GIF_MONEY: {
                        key: "voucherType-futureBonus",
                        defaultValue: "Futures Bonus",
                        voucherNameKey: "voucherName-futureBonus",
                        defaultVoucherName: "Futures Bonus Voucher",
                        imageFileName: "future-bonus-voucher-{{theme}}.svg"
                    },
                    CASH_COUPON: {
                        key: "voucherType-token",
                        defaultValue: "Cash",
                        voucherNameKey: "voucherName-token",
                        defaultVoucherName: "Token Voucher",
                        imageFileName: "token-voucher-{{theme}}.svg"
                    },
                    FEE_REBATE: {
                        key: "voucherType-tradingFeeRebate",
                        defaultValue: "Trading Fee Rebate",
                        voucherNameKey: "voucherName-tradingFeeRebate",
                        defaultVoucherName: "Trading Fee Rebate Voucher",
                        imageFileName: "trading-fee-rebate-voucher-{{theme}}.svg"
                    },
                    MARGIN_LOAN: {
                        key: "voucherType-zeroInterest",
                        defaultValue: "0% Interest",
                        voucherNameKey: "voucherName-zeroInterest",
                        defaultVoucherName: "0% Interest Voucher",
                        imageFileName: "margin-interest-voucher-{{theme}}.svg"
                    },
                    CUSTOM_VOUCHER: {
                        key: "voucherType-custom",
                        defaultValue: "Custom Voucher",
                        voucherNameKey: "voucherName-custom",
                        defaultVoucherName: "Custom Voucher",
                        imageFileName: "token-voucher-{{theme}}.svg"
                    },
                    FUTURE_FREE_POSITION: {
                        key: "voucherType-futureFreePosition",
                        defaultValue: "Futures Position",
                        voucherNameKey: "voucherName-futureFreePosition",
                        defaultVoucherName: "Futures Position Voucher",
                        imageFileName: "margin-interest-voucher-{{theme}}.svg"
                    }
                },
                a = {
                    ONGOING: {
                        key: "voucherTabs-onGoing",
                        defaultValue: "Ongoing",
                        sectionList: [{
                            key: "voucherTabs-onGoing-inUse",
                            defaultValue: "In Use",
                            dataField: "inUseVouchers"
                        }, {
                            key: "voucherTabs-onGoing-canUse",
                            defaultValue: "Can Use",
                            dataField: "usableVouchers",
                            mysteryBoxDataField: "enableMysteryBoxes"
                        }, {
                            key: "voucherTabs-onGoing-canClaim",
                            defaultValue: "Can Claim",
                            dataField: "claimableVouchers"
                        }]
                    },
                    PAST: {
                        key: "voucherTabs-past",
                        defaultValue: "Past",
                        sectionList: [{
                            key: "voucherTabs-past-used",
                            defaultValue: "Used",
                            dataField: "usedVouchers",
                            mysteryBoxDataField: "usedMysteryBoxes"
                        }, {
                            key: "voucherTabs-past-expired",
                            defaultValue: "Expired",
                            dataField: "expiredVouchers"
                        }]
                    }
                },
                o = r("TrCV"),
                i = r("qMwq"),
                u = r("xE8/"),
                s = r("lR91"),
                c = r("6jV+"),
                d = r("eNvi"),
                l = {
                    PARAMS_INVALID: "110002",
                    USER_RISKY: "11023",
                    ALREADY_CLAIMED: "11024",
                    SYS_UNDER_MAINTENANCE: "12000",
                    VOUCHER_DISABLED: "11056",
                    REGION_UNAVAILABLE: "11080",
                    REQUEST_DUPLICATE: "11063",
                    USER_INELIGIBLE: "11081",
                    VOUCHER_CLAIMED: "11062",
                    VOUCHER_FULLY_CLAIMED: "11055",
                    INVALID_CODE: "11060",
                    EXPIRED_CODE: "11082",
                    USER_KYC_FAILED: "11061",
                    DOWNSTREAM_SERVICE_ERROR: "11016",
                    REQUEST_TIMEOUT: "100001011",
                    VIP_LIMIT_REACHED: "11027",
                    VOUCHER_USED: "11010",
                    USER_FUTURE_ACCOUNT_INELIGIBLE: "11072",
                    FUTURES_ACCOUNT_REQUIRED: "11017",
                    SUB_ACCOUNT_CANNOT_USE_MARGIN_LOAN_VOUCHER: "11048",
                    MARGIN_ACCOUNT_OPEN_RESTRICTED_IN_REGION: "11049",
                    MARGIN_TRADING_RESTRICTED_IN_REGION: "11050",
                    USER_ACCOUNT_IN_MARGIN_BLOCK_LIST: "11100",
                    VOUCHER_FUTURES_DELIVERY_COIN_NOT_ALLOWED: "11083",
                    USER_ALREADY_UPGRADED_VIP: "11025",
                    MARGIN_ACCOUNT_REQUIRED: "11021",
                    WEB_VOUCHER_USE_NOT_ALLOWED: "11084",
                    OLD_VOUCHER_FULLY_CLAIMED: "11008",
                    OLD_VOUCHER_MARGIN_CHECK_FAILED: "11071",
                    OLD_VOUCHER_SPOT_ACCOUNT_REGISTER_TIME_CHECK_FAILED: "11073",
                    OLD_VOUCHER_SPOT_ACCOUNT_REGISTER_DAY_CHECK_FAILED: "11076",
                    OLD_VOUCHER_MARGIN_ACCOUNT_REGISTER_TIME_CHECK_FAILED: "11074",
                    OLD_VOUCHER_MARGIN_ACCOUNT_REGISTER_DAY_CHECK_FAILED: "11077",
                    OLD_VOUCHER_FUTURE_ACCOUNT_REGISTER_TIME_CHECK_FAILED: "11075",
                    OLD_VOUCHER_FUTURE_ACCOUNT_REGISTER_DAY_CHECK_FAILED: "11078",
                    OLD_VOUCHER_REFERRAL_CHECK_FAILED: "11079",
                    MYSTERY_BOX_STATUS_NOT_ALLOWED_FOR_THE_OPERATION: "210408"
                },
                h = function(e) {
                    var t = e.code,
                        r = e.t,
                        n = e.product;
                    if ([l.VOUCHER_FULLY_CLAIMED, l.OLD_VOUCHER_FULLY_CLAIMED].includes(t)) return r("error-VOUCHER_FULLY_CLAIMED", "Fully claimed.");
                    if ([l.OLD_VOUCHER_MARGIN_CHECK_FAILED, l.OLD_VOUCHER_MARGIN_ACCOUNT_REGISTER_TIME_CHECK_FAILED, l.OLD_VOUCHER_MARGIN_ACCOUNT_REGISTER_DAY_CHECK_FAILED].includes(t)) return r("error-VOUCHER_FAILED_PRODUCT_CONDITION", "Not eligible to claim as you did not meet the {{product}} account criteria.", {
                        product: (0, d.V)("MARGIN", r)
                    });
                    if ([l.OLD_VOUCHER_SPOT_ACCOUNT_REGISTER_TIME_CHECK_FAILED, l.OLD_VOUCHER_SPOT_ACCOUNT_REGISTER_DAY_CHECK_FAILED].includes(t)) return r("error-VOUCHER_FAILED_PRODUCT_CONDITION", "Not eligible to claim as you did not meet the {{product}} account criteria.", {
                        product: (0, d.V)("SPOT", r)
                    });
                    if ([l.OLD_VOUCHER_FUTURE_ACCOUNT_REGISTER_TIME_CHECK_FAILED, l.OLD_VOUCHER_FUTURE_ACCOUNT_REGISTER_DAY_CHECK_FAILED].includes(t)) return r("error-VOUCHER_FAILED_PRODUCT_CONDITION", "Not eligible to claim as you did not meet the {{product}} account criteria.", {
                        product: (0, d.V)("FUTURE", r)
                    });
                    switch (t) {
                        case l.INVALID_CODE:
                            return r("error-INVALID_CODE", "Invalid code");
                        case l.USER_INELIGIBLE:
                        case l.USER_RISKY:
                            return r("RiskUser-desc", "Your account did not pass the risk assessment for this activity. In case of any objections, you may <AppealLink>submit an appeal</AppealLink>.", {}, {
                                AppealLink: (0, o.jsx)(u.qO, {
                                    className: "ul-text-link",
                                    target: "_blank",
                                    to: "/my/risk/appeal?templateId=T4adc24fe0"
                                })
                            });
                        case l.USER_KYC_FAILED:
                            return r("error-VOUCHER_FAILED_KYC", "Not eligible to claim as you do not meet the KYC criteria.");
                        case l.USER_FUTURE_ACCOUNT_INELIGIBLE:
                            return r("error-VOUCHER_FAILED_FUTURE", "Not eligible to claim as you do not meet the Futures account criteria.");
                        case l.REGION_UNAVAILABLE:
                            return r("errorClaimCode-REGION_UNAVAILABLE", "{{product}} service is unavailable in your region", {
                                product: (0, d.V)(n, r)
                            });
                        case l.EXPIRED_CODE:
                            return r("error-EXPIRED_CODE", "Expired code");
                        case l.VOUCHER_DISABLED:
                            return r("error-VOUCHER_DISABLED", "Reward is temporarily suspended. Try again later.");
                        case l.SYS_UNDER_MAINTENANCE:
                            return r("error-SYS_UNDER_MAINTENANCE", "Function is temporarily suspended. Try again later.");
                        case l.VOUCHER_CLAIMED:
                            return r("errorClaimCode-VOUCHER_CLAIMED", "Already claimed");
                        case l.FUTURES_ACCOUNT_REQUIRED:
                            return r("error-FUTURES_ACCOUNT_REQUIRED", "You do not have a Futures Account yet.");
                        case l.OLD_VOUCHER_REFERRAL_CHECK_FAILED:
                            return r("error-VOUCHER_FAILED_REFERRAL_CONDITION", "Not eligible to claim as you did not meet the referral criteria.");
                        case l.ALREADY_CLAIMED:
                            return r("error-ALREADY_CLAIMED", "Already Claimed");
                        case l.MYSTERY_BOX_STATUS_NOT_ALLOWED_FOR_THE_OPERATION:
                        default:
                            return r("errorClaimCode-default", "An unexpected error has occured.")
                    }
                },
                f = function(e) {
                    var t = e.voucher,
                        r = e.code,
                        n = e.t,
                        a = t.product;
                    switch (r) {
                        case l.USER_KYC_FAILED:
                            return {
                                title: n("CannotClaim", "Cannot Claim Reward"),
                                desc: n("errorClaim-USER_KYC_FAILED", "You are not eligible to claim this reward as you do not meet the KYC criteria"),
                                type: "error"
                            };
                        case l.USER_FUTURE_ACCOUNT_INELIGIBLE:
                            return {
                                title: n("CannotClaim", "Cannot Claim Reward"),
                                desc: n("errorClaim-USER_FUTURE_ACCOUNT_INELIGIBLE", "You are not eligible to claim this reward as you do not meet the Futures Account criteria."),
                                type: "error"
                            };
                        case l.VOUCHER_FULLY_CLAIMED:
                            return {
                                title: n("NoReward", "No More Reward"),
                                desc: n("errorClaim-VOUCHER_FULLY_CLAIMED", "This reward is fully claimed. Please check out other activities and rewards."),
                                buttonText: "Go to Rewards Hub",
                                icon: (0, o.jsx)(s.O, {})
                            };
                        case l.REGION_UNAVAILABLE:
                            return {
                                title: n("CannotClaim", "Cannot Claim Reward"),
                                desc: n("error-REGION_UNAVAILABLE", "{{product}} service is unavailable in your region", {
                                    product: (0, d.V)(a, n)
                                }),
                                type: "error"
                            };
                        case l.USER_RISKY:
                            return {
                                title: n("CannotClaim", "Cannot  Reward"),
                                desc: n("error-USER_RISKY", "Your account did not pass the risk assessment for this activity. Refer to FAQ for more details."),
                                type: "error"
                            };
                        case l.FUTURES_ACCOUNT_REQUIRED:
                            var u = (0, i.hL)(c.fi[a || "FUTURE"]);
                            return {
                                title: n("CannotClaim", "Cannot Claim Reward"),
                                desc: n("errorClaim-FUTURES_ACCOUNT_REQUIRED", "You do not have a Futures Account yet. Claim this reward after you open a Futures Account."),
                                buttonText: n("error-btn-openFuturesAccount", "Open Futures Account"),
                                linkProps: {
                                    target: "_blank",
                                    to: u,
                                    ios: u,
                                    android: u
                                },
                                type: "error"
                            };
                        case l.MARGIN_ACCOUNT_REQUIRED:
                            var h = (0, i.hL)(c.fi[a || "MARGIN"]);
                            return {
                                title: n("CannotClaim", "Cannot Claim Reward"),
                                desc: n("errorClaim-MARGIN_ACCOUNT_REQUIRED", "You do not have a Margin Account yet. Use this reward after you open a Margin Account."),
                                buttonText: n("error-btn-openMarginAccount", "Open Margin Account"),
                                linkProps: {
                                    target: "_blank",
                                    to: h,
                                    ios: h,
                                    android: h
                                },
                                type: "error"
                            };
                        case l.VOUCHER_DISABLED:
                            return {
                                title: n("RewardSuspension", "Reward Suspension"),
                                desc: n("error-VOUCHER_DISABLED", "Reward is temporarily suspended. Try again later."),
                                type: "warning"
                            };
                        case l.VOUCHER_CLAIMED:
                            return {
                                title: n("RewardClaimed", "Reward Claimed"),
                                desc: n("errorClaim-VOUCHER_CLAIMED", "You have already claimed this reward successfully."),
                                type: "warning"
                            };
                        default:
                            return {
                                title: n("UnexpectedError", "Unexpected Error"),
                                desc: n("error-default", "An unexpected error has occured. Please try again later."),
                                type: "warning"
                            }
                    }
                },
                p = function(e) {
                    var t = e.voucher,
                        r = e.code,
                        n = e.t,
                        a = t.product,
                        s = t.facePriceUnit;
                    switch (r) {
                        case l.USER_KYC_FAILED:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-USER_KYC_FAILED", "You are not eligible to use this reward as you do not meet the KYC criteria."),
                                type: "error"
                            };
                        case l.USER_FUTURE_ACCOUNT_INELIGIBLE:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-USER_FUTURE_ACCOUNT_INELIGIBLE", "You are not eligible to use this reward as you do not meet the Futures Account criteria."),
                                type: "error"
                            };
                        case l.REGION_UNAVAILABLE:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("error-REGION_UNAVAILABLE", "{{product}} service is unavailable in your region", {
                                    product: (0, d.V)(a, n)
                                }),
                                type: "error"
                            };
                        case l.USER_RISKY:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("RiskUser-desc", "Your account did not pass the risk assessment for this activity. In case of any objections, you may <AppealLink>submit an appeal</AppealLink>.", {}, {
                                    AppealLink: (0, o.jsx)(u.qO, {
                                        className: "ul-text-link",
                                        target: "_blank",
                                        to: "/my/risk/appeal?templateId=T4adc24fe0"
                                    })
                                }),
                                type: "error"
                            };
                        case l.VIP_LIMIT_REACHED:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-VIP_LIMIT_REACHED", "You have already reached the maximum VIP level."),
                                type: "error"
                            };
                        case l.SUB_ACCOUNT_CANNOT_USE_MARGIN_LOAN_VOUCHER:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-SUB_ACCOUNT_CANNOT_USE_MARGIN_LOAN_VOUCHER", "This Sub-Account cannot use this voucher."),
                                type: "error"
                            };
                        case l.MARGIN_ACCOUNT_OPEN_RESTRICTED_IN_REGION:
                        case l.MARGIN_TRADING_RESTRICTED_IN_REGION:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-MARGIN_TRADING_RESTRICTED_IN_REGION", "Margin service is unavailable in your region."),
                                type: "error"
                            };
                        case l.USER_ACCOUNT_IN_MARGIN_BLOCK_LIST:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-USER_ACCOUNT_IN_MARGIN_BLOCK_LIST", "Your account did not pass the risk assessment for this Margin activity."),
                                type: "error"
                            };
                        case l.VOUCHER_FUTURES_DELIVERY_COIN_NOT_ALLOWED:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-VOUCHER_FUTURES_DELIVERY_COIN_NOT_ALLOWED", "Futures Bonus Voucher for Coin-Margined Contracts only supports specific coins and does not support {{facePriceUnit}}.", {
                                    facePriceUnit: s
                                }),
                                type: "error"
                            };
                        case l.USER_ALREADY_UPGRADED_VIP:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-USER_ALREADY_UPGRADED_VIP", 'You have an "In Use" VIP Upgrade voucher and are in upgraded state currently.'),
                                type: "error"
                            };
                        case l.FUTURES_ACCOUNT_REQUIRED:
                            var h = (0, i.hL)(c.fi[a || "FUTURE"]);
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-FUTURES_ACCOUNT_REQUIRED", "You do not have a Futures Account yet. Use this reward after you open a Futures Account."),
                                buttonText: n("error-btn-openFuturesAccount", "Open Futures Account"),
                                linkProps: {
                                    target: "_blank",
                                    to: h,
                                    ios: h,
                                    android: h
                                },
                                type: "error"
                            };
                        case l.MARGIN_ACCOUNT_REQUIRED:
                            var f = (0, i.hL)(c.fi[a || "MARGIN"]);
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-MARGIN_ACCOUNT_REQUIRED", "You do not have a Margin Account yet. Use this reward after you open a Margin Account."),
                                buttonText: n("error-btn-openMarginAccount", "Open Margin Account"),
                                linkProps: {
                                    target: "_blank",
                                    to: f,
                                    ios: f,
                                    android: f
                                },
                                type: "error"
                            };
                        case l.WEB_VOUCHER_USE_NOT_ALLOWED:
                            return {
                                title: n("CannotUseReward", "Cannot Use Reward"),
                                desc: n("errorUse-WEB_VOUCHER_USE_NOT_ALLOWED", "Voucher can only be used on the app."),
                                type: "warning"
                            };
                        case l.SYS_UNDER_MAINTENANCE:
                            return {
                                title: n("SysMaintenance", "System Maintenance"),
                                desc: n("error-SYS_UNDER_MAINTENANCE", "This function is temporarily suspended. Please try again later."),
                                type: "warning"
                            };
                        case l.VOUCHER_DISABLED:
                            return {
                                title: n("RewardSuspension", "Reward Suspension"),
                                desc: n("error-VOUCHER_DISABLED", "Reward is temporarily suspended. Try again later."),
                                type: "warning"
                            };
                        case l.VOUCHER_USED:
                            return {
                                title: n("RewardUsed", "Reward Used"),
                                desc: n("errorUse-VOUCHER_USED", "You have already used this reward successfully."),
                                type: "warning"
                            };
                        default:
                            return {
                                title: n("UnexpectedError", "Unexpected Error"),
                                desc: n("error-default", "An unexpected error has occured. Please try again later."),
                                type: "warning"
                            }
                    }
                }
        },
        "3Pj3": (e, t, r) => {
            r.d(t, {
                kb: () => A,
                _$: () => S,
                po: () => N,
                gb: () => M,
                HU: () => L,
                YF: () => D,
                R5: () => F,
                Fe: () => V,
                dy: () => w,
                SZ: () => O
            });
            var n = r("iDJA"),
                a = r("CffR"),
                o = r("RApW"),
                i = r("eheR"),
                u = r("u7Qj"),
                s = r("sViW"),
                c = r("BK7R"),
                d = r("QUKP"),
                l = r("Pz56"),
                h = r.n(l),
                f = r("SFPm"),
                p = r("qMwq"),
                m = r("XaLc"),
                E = r("dh/N"),
                U = r("6jV+"),
                T = (0, f.S)(),
                R = T.isHybrid,
                y = T.clientType,
                C = T.clientVersion,
                _ = function(e) {
                    var t = e.iosMiniVersion,
                        r = void 0 === t ? "" : t,
                        n = e.androidMiniVersion;
                    if (!R) return !1;
                    for (var a = {
                            iOS: r,
                            Android: void 0 === n ? "" : n
                        }[y].split("."), o = C.split("."), i = 0; i < 3;) {
                        if (+o[i] > +a[i]) return !0;
                        if (+o[i] < +a[i]) return !1;
                        i++
                    }
                    return !0
                },
                b = (0, f.S)().clientType,
                g = void 0 === b ? "web" : b,
                v = function(e) {
                    var t, r, n, a, o = e.voucherType,
                        i = e.product,
                        u = e.clientType,
                        s = void 0 === u ? g : u,
                        c = e.isLiteMode,
                        d = void 0 !== c && c,
                        l = null === U.nH || void 0 === U.nH || null === (t = U.nH[o]) || void 0 === t || null === (r = t[i || "PLATFORM"]) || void 0 === r ? void 0 : r.lite,
                        h = null === U.nH || void 0 === U.nH || null === (n = U.nH[o]) || void 0 === n || null === (a = n[i || "PLATFORM"]) || void 0 === a ? void 0 : a[s],
                        f = d && l || h;
                    if ("object" !== typeof f) return f;
                    var p = Object.keys(f);
                    return _({
                        iosMiniVersion: p[0],
                        androidMiniVersion: p[0]
                    }) ? f[p[0]] : f.lowVersion
                },
                A = function(e) {
                    var t = e.voucherType,
                        r = e.product,
                        n = e.payload,
                        a = void 0 === n ? {} : n,
                        o = e.isLiteMode,
                        i = v({
                            voucherType: t,
                            product: r,
                            clientType: "web"
                        }) || "",
                        u = v({
                            voucherType: t,
                            product: r,
                            isLiteMode: o,
                            clientType: "iOS"
                        }) || "",
                        s = v({
                            voucherType: t,
                            product: r,
                            isLiteMode: o,
                            clientType: "Android"
                        }) || "",
                        c = a.facePriceUnit,
                        d = a.coinPair,
                        l = a.voucherId,
                        h = function(e) {
                            return e.replace("%facePriceUnit%", c).replace("%selectedCoin%", (t = d, t && t.replace("/", ""))).replace("%product%", r || "").replace("%voucherId%", l);
                            var t
                        };
                    return {
                        web: (0, p.hL)(h(i)),
                        ios: (0, p.hL)(h(u)),
                        android: (0, p.hL)(h(s))
                    }
                };

            function w(e) {
                return I.apply(this, arguments)
            }

            function I() {
                return I = (0, s.A)(h().mark((function e(t) {
                    var r, n, a, o, i, u, s, c, d, l, f, T, R, y, C, b, g, v, A;
                    return h().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return r = t.voucher, n = _({
                                    iosMiniVersion: "2.55.0",
                                    androidMiniVersion: "2.55.0"
                                }), a = r.facePriceUnit, o = r.voucherId, i = a || "", e.next = 6, (0, E.Mz)(i);
                            case 6:
                                u = e.sent, s = u.data, d = (c = void 0 === s ? [] : s) && c[0] || "", l = d.id, f = void 0 === l ? "" : l, T = U.IH.lite, R = U.IH.pro, y = T.replace("%asset%", i).replace("%couponId%", o), C = R["2.55.0"].replace("%asset%", i).replace("%couponId%", o), b = R.lowerVersion.replace("%productId%", f).replace("%asset%", i).replace("%couponId%", o), g = n ? C : b, v = U.z0.replace("%asset%", i).replace("%couponId%", o).replace("%demandId%", f), A = (0, p.hL)(v), n ? (0, m.Z)({
                                    web: A,
                                    hybrid: "".concat(g, "&litelink=").concat(encodeURI(y))
                                }, !0) : (0, m.Z)({
                                    web: A,
                                    hybrid: A
                                }, !0);
                            case 18:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                }))), I.apply(this, arguments)
            }
            var N = function(e) {
                    var t = {
                        web: "",
                        ios: "",
                        android: ""
                    };
                    switch (e.product) {
                        case "MARGIN":
                        case "MARGIN_CROSS":
                        case "MARGIN_ISOLATED":
                            t = U.F0.MARGIN;
                            break;
                        case "FUTURE":
                        case "FUTURE_DELIVERY":
                            t = U.F0.FUTURE;
                            break;
                        case "NFT":
                            t = U.F0.NFT;
                            break;
                        default:
                            t = U.F0.SPOT
                    }
                    return (0, d.A)((0, c.A)({}, t), {
                        web: (0, p.hL)(t.web)
                    })
                },
                O = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 6,
                        r = (0, n.A)(parseFloat(e), t);
                    return parseFloat(e) === r ? "".concat(parseFloat(e)) : "~".concat(r)
                },
                M = function(e) {
                    var t = e.voucher,
                        r = e.t,
                        n = e.coinPair,
                        a = e.isLiteMode,
                        o = t.voucherType,
                        i = t.facePrice,
                        s = t.facePriceUnit,
                        c = t.product,
                        d = t.fromVipUpgradeLevel,
                        l = t.toVipUpgradeLevel,
                        h = t.voucherId,
                        f = A({
                            voucherType: o,
                            product: c,
                            isLiteMode: a,
                            payload: {
                                facePriceUnit: s,
                                coinPair: n,
                                voucherId: h
                            }
                        }),
                        p = {
                            target: "_blank",
                            to: f.web,
                            ios: f.ios,
                            android: f.android
                        };
                    switch (o) {
                        case "VIP_UPGRADE":
                            return {
                                desc: r("UseVoucherModal-successDesc-".concat(o), "You have successfully upgraded from VIP {{fromVipUpgradeLevel}} to VIP {{toVipUpgradeLevel}}. This will be effective until the expiry time of the reward.", {
                                    fromVipUpgradeLevel: d,
                                    toVipUpgradeLevel: l
                                }),
                                buttonText: r("UseVoucherModal-btnText-viewVIPPage", "Go to VIP page"),
                                linkProps: p
                            };
                        case "CASH_COUPON":
                            if (c && ["SPOT", "MARGIN", "FUTURE"].includes(c)) return {
                                desc: r("UseVoucherModal-successDesc-".concat(o), "The {{product}} reward value of {{facePrice}} {{facePriceUnit}} has been credited into your {{product}} wallet.", {
                                    product: (0, u.VG)(c, r),
                                    facePrice: i,
                                    facePriceUnit: s
                                }),
                                buttonText: r("UseVoucherModal-btnText-viewWallet", "View Wallet"),
                                linkProps: p
                            };
                            break;
                        case "FEE_REBATE":
                            if ("SPOT" === c) return {
                                desc: r("UseVoucherModal-successDesc-".concat(o, "-SPOT").concat(a ? "-LITE" : ""), "Trade Spot and enjoy the trading fee rebates before the expiry time of the reward."),
                                buttonText: a ? r("UseVoucherModal-btnText-howTo-SPOT", "How to Trade Spot") : r("UseVoucherModal-btnText-goTo-SPOT", "Go to Spot Trading"),
                                linkProps: p
                            };
                            if ("MARGIN_CROSS" === c) return {
                                desc: r("UseVoucherModal-successDesc-".concat(o, "-MARGIN_CROSS").concat(a ? "-LITE" : ""), "Trade Cross Margin and enjoy the trading fee rebates before the expiry time of the reward."),
                                buttonText: a ? r("UseVoucherModal-btnText-howTo-MARGIN_CROSS", "How to Trade Margin") : r("UseVoucherModal-btnText-goTo-MARGIN_CROSS", "Go to Cross Margin Trading"),
                                linkProps: p
                            };
                            if ("MARGIN_ISOLATED" === c) return {
                                desc: r("UseVoucherModal-successDesc-".concat(o, "-MARGIN_ISOLATED").concat(a ? "-LITE" : ""), "Trade Isolated Margin and enjoy the trading fee rebates before the expiry time of the reward."),
                                buttonText: a ? r("UseVoucherModal-btnText-howTo-MARGIN_CROSS", "How to Trade Margin") : r("UseVoucherModal-btnText-goTo-MARGIN_ISOLATED", "Go to Isolated Margin Trading"),
                                linkProps: p
                            };
                            if (c && ["FUTURE", "FUTURE_DELIVERY"].includes(c)) return {
                                desc: r("UseVoucherModal-successDesc-".concat(o, "-FUTURE").concat(a ? "-LITE" : ""), "Trade Futures and enjoy the trading fee rebates before the expiry time of the reward."),
                                buttonText: a ? r("UseVoucherModal-btnText-howTo-FUTURE", "How to Trade Futures") : r("UseVoucherModal-btnText-goTo-FUTURE", "Go to Futures Trading"),
                                linkProps: p
                            };
                            if ("NFT" === c) return {
                                desc: r("UseVoucherModal-successDesc-".concat(o, "-NFT").concat(a ? "-LITE" : ""), "Trade NFT and enjoy the platform fee rebates before the expiry time of the reward."),
                                buttonText: a ? r("UseVoucherModal-btnText-howTo-NFT", "How to Trade NFTs") : r("UseVoucherModal-btnText-goTo-NFT", "Go to NFT Trading"),
                                linkProps: p
                            };
                            break;
                        case "MARGIN_LOAN":
                            if ("MARGIN_ISOLATED" === c || "ISOLATED_MARGIN" === c) return {
                                desc: r("UseVoucherModal-successDesc-".concat(o, "-").concat(c), "Transfer the collateral before the \u201cUse Before\u201d time of the reward to enjoy interest-free borrowing."),
                                buttonText: r("UseVoucherModal-btnText-goTo-MARGIN", "Go to Margin Trading"),
                                linkProps: p
                            };
                            if ("MARGIN_CROSS" === c || "CROSS_MARGIN" === c) return {
                                desc: r("UseVoucherModal-successDesc-".concat(o, "-").concat(c), "Transfer the collateral before the expiry time of the reward to enjoy interest-free borrowing."),
                                buttonText: r("UseVoucherModal-btnText-goTo-MARGIN", "Go to Margin Trading"),
                                linkProps: p
                            };
                            break;
                        case "SAVING_GIF_MONEY":
                            return {
                                desc: r("UseVoucherModal-successDesc-".concat(o), "Go to Simple Earn and apply this voucher when you subscribe to Flexible term for {{facePriceUnit}} to complete the subscription process.", {
                                    facePriceUnit: s
                                }),
                                buttonText: r("UseVoucherModal-btnText-simpleEarn", "Go to Simple Earn"),
                                linkProps: p
                            };
                        case "LOCKED_GIF_MONEY":
                            return {
                                desc: r("UseVoucherModal-successDesc-".concat(o), "Go to Simple Earn and apply this voucher when you subscribe to Locked term for {{facePriceUnit}} to complete the subscription process.", {
                                    facePriceUnit: s
                                }),
                                buttonText: r("UseVoucherModal-btnText-simpleEarn", "Go to Simple Earn"),
                                linkProps: p
                            };
                        case "FUTURE_GIF_MONEY":
                            return {
                                desc: r("UseVoucherModal-successDesc-".concat(o), "The {{facePrice}} {{facePriceUnit}} Futures Bonus has been credited into your Futures wallet.", {
                                    facePrice: i,
                                    facePriceUnit: s
                                }),
                                buttonText: r("UseVoucherModal-btnText-viewWallet", "View Wallet"),
                                linkProps: p
                            };
                        default:
                            return {
                                desc: r("UseVoucherModal-successDesc-default", "Your reward has been activated successfully.")
                            }
                    }
                    return {
                        desc: r("UseVoucherModal-successDesc-default", "Your reward has been activated successfully.")
                    }
                },
                S = function(e, t, r) {
                    var n = e.voucherType,
                        a = e.product,
                        o = e.facePrice,
                        i = e.facePriceUnit;
                    if ("VIP_UPGRADE" === n) return t("UseVoucherModal-desc-".concat(n), "Once you use this reward, you will be upgraded by {{level}} VIP levels until the expiry time of the reward.", {
                        level: (o || "").replace("+", "")
                    });
                    if ("CASH_COUPON" === n && a && ["SPOT", "MARGIN", "FUTURE"].includes(a)) return t("UseVoucherModal-desc-".concat(n), "Once you use this reward, the {{product}} reward value will be credited into your {{product}} wallet.", {
                        product: (0, u.VG)(a, t)
                    });
                    if ("FEE_REBATE" === n && a && ["SPOT", "MARGIN_CROSS", "MARGIN_ISOLATED", "FUTURE", "FUTURE_DELIVERY", "NFT"].includes(a)) return r ? t("UseVoucherModal-desc-".concat(n, "-LITE"), "Once you use this reward, the trading fee rebate will be credited to your wallet one day after the {{product}} trade has been made in Binance Pro.", {
                        product: (0, u.VG)(a, t)
                    }) : t("UseVoucherModal-desc-".concat(n), "Once you use this reward, the trading fee rebate will be credited to your wallet one day after the {{product}} trade has been made.", {
                        product: (0, u.VG)(a, t)
                    });
                    if ("MARGIN_LOAN" === n && a) {
                        if ("MARGIN_ISOLATED" === a) return t("UseVoucherModal-desc-".concat(n, "-").concat(a), "Once you use this reward, you will enjoy a USDT 0% interest privilege on your Isolated Margin loans.");
                        if ("MARGIN_CROSS" === a || "CROSS_MARGIN" === a) return t("UseVoucherModal-desc-".concat(n, "-").concat(a), "Once you use this reward, you will enjoy a USDT 0% interest privilege on your Cross Margin loans.")
                    }
                    return "SAVING_GIF_MONEY" === n ? t("UseVoucherModal-desc-".concat(n), "To use this voucher, go to Simple Earn and apply this voucher when you subscribe to Flexible Term for {{facePriceUnit}}.", {
                        facePriceUnit: i
                    }) : "LOCKED_GIF_MONEY" === n ? t("UseVoucherModal-desc-".concat(n), "To use this voucher, go to Simple Earn and apply this voucher when you subscribe to Locked Term for {{facePriceUnit}}.", {
                        facePriceUnit: i
                    }) : "FUTURE_GIF_MONEY" === n ? t("UseVoucherModal-desc-".concat(n), "Once you use this reward, the Futures Bonus will be credited into your Futures wallet.") : t("UseVoucherModal-desc-default", "Once you use this reward, the reward will be activated.")
                },
                V = function(e, t) {
                    var r = e.voucherType,
                        n = e.status,
                        a = e.claimBefore,
                        i = e.inUseBefore,
                        u = e.usedTime,
                        s = e.expiredTime,
                        c = e.canUseBefore;
                    switch (n) {
                        case "CLAIMABLE":
                            return t("VoucherCard-claimBefore", "Claim before {{time}}", {
                                time: (0, o.r6)(a)
                            });
                        case "USABLE":
                            return t("VoucherCard-useBefore", "Use before {{time}}", {
                                time: (0, o.r6)(c || void 0)
                            });
                        case "IN_USE":
                            return t("VoucherCard-expiresOn", "Expires on {{time}}", {
                                time: (0, o.r6)(i)
                            });
                        case "USED":
                            return "CASH_COUPON" === r || "FUTURE_GIF_MONEY" === r ? t("VoucherCard-usedOn", "Used on {{time}}", {
                                time: (0, o.r6)(u)
                            }) : t("VoucherCard-usedBefore", "Used before {{time}}", {
                                time: (0, o.r6)(u)
                            });
                        case "EXPIRED_UNUSED":
                        case "EXPIRED_UNCLAIMED":
                            return t("VoucherCard-expiredOn", "Expired on {{time}}", {
                                time: (0, o.r6)(s)
                            });
                        default:
                            return ""
                    }
                },
                L = function(e, t) {
                    return e ? (null === e || void 0 === e ? void 0 : e.days) < 1 ? t("expiredInCountdown", "Expires in {{countdown}}", {
                        countdown: t("hours-minutes-seconds", "{{hours}}H:{{minutes}}M:{{seconds}}S", e)
                    }) : t("useBeforeXDays", "Use before {{number}} days", {
                        number: null === e || void 0 === e ? void 0 : e.days
                    }) : ""
                },
                D = function(e, t) {
                    var r, n = u.IG[e.voucherType || ""] || {},
                        o = n.defaultVoucherName,
                        i = t(n.voucherNameKey, o);
                    return "FEE_REBATE" === e.voucherType && (i = "NFT" === e.product ? t("VoucherName-platformRebate", "Platform Fee Rebate Voucher") : t("VoucherName-tradingRebate", "Trading Fee Rebate Voucher")), "CUSTOM_VOUCHER" === e.voucherType ? (0, a.Z5)(t, null === e || void 0 === e || null === (r = e.voucherDisplayContent) || void 0 === r ? void 0 : r.title) || i : e.displayName || i
                },
                F = function(e, t, r) {
                    if (!e || e.rewardType === i.E.Points) return "";
                    var n = u.IG[e.voucherType] || {},
                        a = n.defaultVoucherName,
                        o = t(n.voucherNameKey, a);
                    return "FEE_REBATE" === e.voucherType && (o = "NFT" === e.products || e.products.includes("NFT") ? t("VoucherName-platformRebate", "Platform Fee Rebate Voucher") : t("VoucherName-tradingRebate", "Trading Fee Rebate Voucher")), (null === r || void 0 === r ? void 0 : r.isNUZ) && "FEE_REBATE" === e.voucherType && (o = t("NewUserZone-vouchercard-subtitle", "Worth in trading fee rebates")), o
                }
        },
        mrqE: (e, t, r) => {
            function n(e, t) {
                if (t.length < e) throw new TypeError(e + " argument" + (e > 1 ? "s" : "") + " required, but only " + t.length + " present")
            }
            r.d(t, {
                A: () => n
            })
        },
        N1LS: (e, t, r) => {
            function n(e) {
                if (null === e || !0 === e || !1 === e) return NaN;
                var t = Number(e);
                return isNaN(t) ? t : t < 0 ? Math.ceil(t) : Math.floor(t)
            }
            r.d(t, {
                A: () => n
            })
        },
        JuBR: (e, t, r) => {
            r.d(t, {
                A: () => a
            });
            var n = r("mrqE");

            function a(e) {
                (0, n.A)(1, arguments);
                var t = Object.prototype.toString.call(e);
                return e instanceof Date || "object" === typeof e && "[object Date]" === t ? new Date(e.getTime()) : "number" === typeof e || "[object Number]" === t ? new Date(e) : ("string" !== typeof e && "[object String]" !== t || "undefined" === typeof console || (console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://git.io/fjule"), console.warn((new Error).stack)), new Date(NaN))
            }
        },
        iDJA: (e, t, r) => {
            r.d(t, {
                A: () => C
            });
            var n = r("YmLP"),
                a = /\s/;
            const o = function(e) {
                for (var t = e.length; t-- && a.test(e.charAt(t)););
                return t
            };
            var i = /^\s+/;
            const u = function(e) {
                return e ? e.slice(0, o(e) + 1).replace(i, "") : e
            };
            var s = r("Z8yJ"),
                c = r("4HpO"),
                d = /^[-+]0x[0-9a-f]+$/i,
                l = /^0b[01]+$/i,
                h = /^0o[0-7]+$/i,
                f = parseInt;
            const p = function(e) {
                if ("number" == typeof e) return e;
                if ((0, c.A)(e)) return NaN;
                if ((0, s.A)(e)) {
                    var t = "function" == typeof e.valueOf ? e.valueOf() : e;
                    e = (0, s.A)(t) ? t + "" : t
                }
                if ("string" != typeof e) return 0 === e ? e : +e;
                e = u(e);
                var r = l.test(e);
                return r || h.test(e) ? f(e.slice(2), r ? 2 : 8) : d.test(e) ? NaN : +e
            };
            var m = 1 / 0;
            const E = function(e) {
                return e ? (e = p(e)) === m || e === -1 / 0 ? 17976931348623157e292 * (e < 0 ? -1 : 1) : e === e ? e : 0 : 0 === e ? e : 0
            };
            const U = function(e) {
                var t = E(e),
                    r = t % 1;
                return t === t ? r ? t - r : t : 0
            };
            var T = r("zHQE"),
                R = n.A.isFinite,
                y = Math.min;
            const C = function(e) {
                var t = Math[e];
                return function(e, r) {
                    if (e = p(e), (r = null == r ? 0 : y(U(r), 292)) && R(e)) {
                        var n = ((0, T.A)(e) + "e").split("e"),
                            a = t(n[0] + "e" + (+n[1] + r));
                        return +((n = ((0, T.A)(a) + "e").split("e"))[0] + "e" + (+n[1] - r))
                    }
                    return t(e)
                }
            }("round")
        }
    }
]);
//# debugId=0a7b8e5a-e825-581b-8e33-b4f3a5077f75