! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "1921f424-6f85-5603-a26d-c69405e3398b")
    } catch (e) {}
}();
(self.webpackChunkc2c_user_ui = self.webpackChunkc2c_user_ui || []).push([
    [6593], {
        fix3: (t, e, n) => {
            "use strict";
            n.d(e, {
                Y: () => o
            });
            var r = n("k/Mm");

            function o() {
                const t = document.getElementById(r.CH);
                return t && t.textContent ? JSON.parse(t.textContent) : {
                    ssr: !1,
                    pageData: {},
                    filesByRoutId: {},
                    publicPath: "/",
                    runtimeConfig: {}
                }
            }
        },
        NVnN: (t, e, n) => {
            "use strict";
            n.d(e, {
                K: () => s
            });
            var r = n("fix3");
            const o = Object.prototype.hasOwnProperty;

            function s(t, e) {
                const {
                    pageData: n = {}
                } = (0, r.Y)();
                return o.call(n, t) ? n[t] : e
            }
        },
        JtFa: (t, e, n) => {
            "use strict";
            n.d(e, {
                K: () => o,
                l: () => s
            });
            var r = n("VyXn");
            const o = "loader",
                s = (0, r.NP)({
                    state: {
                        dataByRouteId: {}
                    },
                    actions: {
                        setDatas(t) {
                            this.dataByRouteId = (0, r.IG)(Object.assign(Object.assign({}, this.dataByRouteId), t))
                        }
                    },
                    views: {
                        getAllData() {
                            return this.dataByRouteId
                        }
                    }
                })
        },
        UCWY: (t, e, n) => {
            "use strict";
            n.d(e, {
                yO: () => E,
                Uu: () => O,
                l1: () => S,
                EI: () => x,
                H7: () => j
            });
            var r = function(t, e, n, r) {
                return new(n || (n = Promise))((function(o, s) {
                    function i(t) {
                        try {
                            c(r.next(t))
                        } catch (e) {
                            s(e)
                        }
                    }

                    function a(t) {
                        try {
                            c(r.throw(t))
                        } catch (e) {
                            s(e)
                        }
                    }

                    function c(t) {
                        var e;
                        t.done ? o(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                            t(e)
                        }))).then(i, a)
                    }
                    c((r = r.apply(t, e || [])).next())
                }))
            };
            const o = () => {
                    let t = [];
                    return {
                        use: (...e) => {
                            t.push(...e)
                        },
                        run: (...e) => t.map((t => t(...e))),
                        clear: () => {
                            t = []
                        },
                        type: "SyncHook"
                    }
                },
                s = () => {
                    let t = [];
                    return {
                        use: (...e) => {
                            t.push(...e)
                        },
                        run: (...e) => {
                            for (let n = 0; n < t.length; n++) {
                                const r = (0, t[n])(...e);
                                if (r) return r
                            }
                        },
                        clear: () => {
                            t = []
                        },
                        type: "SyncBailHook"
                    }
                },
                i = () => {
                    let t = [];
                    return {
                        use: (...e) => {
                            t.push(...e)
                        },
                        run: (...e) => {
                            let [n, ...r] = e;
                            for (let o = 0; o < t.length; o++) {
                                const e = (0, t[o])(n, ...r);
                                void 0 !== e && (n = e)
                            }
                            return n
                        },
                        clear: () => {
                            t = []
                        },
                        type: "SyncWaterfallHook"
                    }
                },
                a = () => {
                    let t = [];
                    return {
                        use: (...e) => {
                            t.push(...e)
                        },
                        run: (...e) => r(void 0, void 0, void 0, (function*() {
                            return yield Promise.all(t.map((t => t(...e))))
                        })),
                        clear: () => {
                            t = []
                        },
                        type: "AsyncParallelHook"
                    }
                },
                c = () => {
                    let t = [];
                    return {
                        use: (...e) => {
                            t.push(...e)
                        },
                        run: (...e) => r(void 0, void 0, void 0, (function*() {
                            const n = [];
                            for (let r = 0; r < t.length; r++) {
                                const o = t[r],
                                    s = yield o(...e);
                                n.push(s)
                            }
                            return n
                        })),
                        clear: () => {
                            t = []
                        },
                        type: "AsyncSeriesHook"
                    }
                },
                u = () => {
                    let t = [];
                    return {
                        use: (...e) => {
                            t.push(...e)
                        },
                        run: (...e) => r(void 0, void 0, void 0, (function*() {
                            for (let n = 0; n < t.length; n++) {
                                const r = t[n],
                                    o = yield r(...e);
                                if (void 0 !== o) return o
                            }
                        })),
                        clear: () => {
                            t = []
                        },
                        type: "AsyncSeriesHook"
                    }
                },
                l = () => {
                    let t = [];
                    return {
                        use: (...e) => {
                            t.push(...e)
                        },
                        run: (...e) => r(void 0, void 0, void 0, (function*() {
                            let [n, ...r] = e;
                            for (let e = 0; e < t.length; e++) {
                                const o = t[e],
                                    s = yield o(n, ...r);
                                void 0 !== s && (n = s)
                            }
                            return n
                        })),
                        clear: () => {
                            t = []
                        },
                        type: "AsyncSeriesWaterfallHook"
                    }
                },
                h = t => {
                    const e = new Map;
                    t.forEach((t => {
                        e.has(t.group) || e.set(t.group, []), e.get(t.group).push(t)
                    }));
                    const n = Array.from(e.keys()).sort(((t, e) => t - e)),
                        r = [];
                    return n.forEach((t => {
                        r.push(...(t => {
                            const e = new Map,
                                n = new Map,
                                r = (t, e) => {
                                    n.has(e) || n.set(e, new Set), n.get(e).add(t)
                                };
                            t.forEach((t => {
                                e.set(t.name, t)
                            })), t.forEach((t => {
                                n.has(t.name) || n.set(t.name, new Set), t.before && t.before.forEach((n => {
                                    e.has(n) && r(t.name, n)
                                })), t.after && t.after.forEach((n => {
                                    e.has(n) && r(n, t.name)
                                }))
                            }));
                            const o = [];
                            for (; n.size > 0;) {
                                let t = !1;
                                if (n.forEach(((r, s) => {
                                        0 === r.size && (t = !0, o.push(e.get(s)), n.delete(s), n.forEach((t => {
                                            t.delete(s)
                                        })))
                                    })), !t) throw new Error(`Plugin circular dependency detected: ${Array.from(n.keys()).join(", ")}. Please ensure the plugins have correct 'before' and 'after' property.`)
                            }
                            return o
                        })(e.get(t)))
                    })), r
                },
                f = {
                    name: "untitled",
                    before: [],
                    after: [],
                    conflict: [],
                    required: [],
                    group: 0
                },
                p = "PLUGIN_SYMBOL",
                d = t => t && t.hasOwnProperty(p) && t.PLUGIN_SYMBOL === p;
            const y = t => {
                const e = {};
                for (const n in t) {
                    const r = t[n];
                    switch (null === r || void 0 === r ? void 0 : r.type) {
                        case "SyncHook":
                            e[n] = o();
                            break;
                        case "SyncBailHook":
                            e[n] = s();
                            break;
                        case "SyncWaterfallHook":
                            e[n] = i();
                            break;
                        case "AsyncParallelHook":
                            e[n] = a();
                            break;
                        case "AsyncSeriesHook":
                            e[n] = c();
                            break;
                        case "AsyncSeriesBailHook":
                            e[n] = u();
                            break;
                        case "AsyncSeriesWaterfallHook":
                            e[n] = l()
                    }
                }
                return e
            };

            function g(t, e = {}) {
                return Object.assign(Object.assign(Object.assign(Object.assign({}, f), {
                    name: `plugin-id-${"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,(function(t){var e=16*Math.random()|0;return("x"==t?e:3&e|8).toString(16)}))}`
                }), e), {
                    handlers: t,
                    PLUGIN_SYMBOL: p
                })
            }
            const m = (t, e = !0) => {
                const n = o(),
                    r = Object.assign(Object.assign({}, y(t)), {
                        setup: n
                    });
                let s, i = [],
                    a = {},
                    c = {},
                    u = !1;
                const l = () => {
                        (t => {
                            const e = new Set;
                            for (const n of t) {
                                if ("string" !== typeof n.name) throw new Error("Plugin name must be string type.");
                                if (!n.name) throw new Error("Plugin name must be non-empty string.");
                                if (e.has(n.name)) throw new Error(`Plugin name duplication detected: ${n.name}.`);
                                if (e.add(n.name), n.conflict)
                                    for (const e of n.conflict)
                                        for (const r of t)
                                            if (e === r.name) throw new Error(`Plugin conflict detected: ${n.name} has conflict with ${r.name}.`);
                                if (n.required)
                                    for (const e of n.required)
                                        if (!t.some((t => t.name === e))) throw new Error(`Plugin missing detected: ${e} is required by ${n.name}.`)
                            }
                        })(i), i = h(i), i.forEach((t => {
                            const e = t.handlers;
                            let n;
                            for (n in e) a[n] || (a[n] = []), a[n].push(e[n])
                        }))
                    },
                    f = r,
                    p = t => {
                        const e = y(t);
                        for (const n in e) r[n] ? console.log("has been added", n) : (r[n] = e[n], c[n] && delete c[n])
                    },
                    d = t => {
                        if (c[t]) return c[t];
                        const e = m(t);
                        return c[t] = e, e
                    },
                    m = t => {
                        let n = !1;
                        const o = r[t],
                            i = a[t] || [];
                        if (!o) return () => {};
                        return "setup" === t ? t => {
                            let e = !1;
                            n || (o.use(...i), o.use((() => {
                                e = !0
                            })), n = !0);
                            const r = Object.assign({}, t);
                            for (let n in r) "function" === typeof r[n] && (r[n] = (s = r[n], new Proxy(s, {
                                apply(t, n, r) {
                                    if (!e) return t.apply(n, r)
                                }
                            })));
                            var s;
                            return o.run(r)
                        } : (...r) => {
                            if (n || (o.use(...i), n = !0), e && !s) throw new Error(`Context not set. Hook ${String(t)} running failed.`);
                            return o.run(...r, s)
                        }
                    };
                return {
                    createPlugin: g,
                    usePlugin: (...t) => {
                        u || i.push(...t)
                    },
                    runner: new Proxy({}, {
                        get: (t, e) => (u || (l(), d("setup")({
                            addHooks: p
                        }), u = !0), d(e))
                    }),
                    clear: () => {
                        Object.values(r).forEach((t => {
                            t.clear()
                        })), i = [], a = {}, c = {}, u = !1
                    },
                    addHooks: p,
                    hooks: f,
                    setContext: t => {
                        s = t
                    },
                    getPlugins: () => i
                }
            };
            var v = function(t, e, n, r) {
                return new(n || (n = Promise))((function(o, s) {
                    function i(t) {
                        try {
                            c(r.next(t))
                        } catch (e) {
                            s(e)
                        }
                    }

                    function a(t) {
                        try {
                            c(r.throw(t))
                        } catch (e) {
                            s(e)
                        }
                    }

                    function c(t) {
                        var e;
                        t.done ? o(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                            t(e)
                        }))).then(i, a)
                    }
                    c((r = r.apply(t, e || [])).next())
                }))
            };
            const _ = a(),
                b = c(),
                w = {
                    init: _,
                    appComponent: l(),
                    appContext: b,
                    dispose: a()
                },
                x = () => m(w, !1),
                {
                    createPluginBefore: S,
                    createPlugin: E,
                    createPluginAfter: O
                } = function() {
                    const t = (t, e = {}) => {
                        const {
                            name: n,
                            before: r,
                            after: o,
                            conflict: s,
                            required: i
                        } = e, a = {
                            group: t
                        };
                        return void 0 !== n && (a.name = n), void 0 !== r && (a.before = r), void 0 !== o && (a.after = o), void 0 !== s && (a.conflict = s), void 0 !== i && (a.required = i), a
                    };
                    return {
                        createPluginBefore: (e, n) => g(e, t(-1, n)),
                        createPlugin: (e, n) => g(e, t(0, n)),
                        createPluginAfter: (e, n) => g(e, t(1, n))
                    }
                }(),
                j = (t, e) => v(void 0, void 0, void 0, (function*() {
                    for (const [n, r] of e) {
                        let e;
                        r && (e = JSON.parse(r)), d(n) ? t.usePlugin(n) : t.usePlugin(n(e))
                    }
                }))
        },
        Dz1D: (t, e) => {
            "use strict";
            e.PC = function() {
                return Object.assign(Object.assign({}, s() || {}), o() || {})
            }, e.UB = function(t) {
                n = t
            };
            Symbol.for("shuvi_server_runtime_config"), Symbol.for("shuvi_client_runtime_config");
            let n, r;

            function o() {
                return n
            }

            function s() {
                return r
            }
        },
        BK9r: (t, e, n) => {
            "use strict";
            n.d(e, {
                N_: () => k,
                Ix: () => w,
                zA: () => l,
                Tp: () => E,
                K7: () => p,
                $P: () => d,
                z7: () => b,
                Zp: () => g,
                g: () => m,
                x$: () => v,
                rd: () => _
            });
            var r = n("wcIl"),
                o = n("DTvD");
            const s = t => t;

            function i(t, e) {
                if (!t) {
                    "undefined" !== typeof console && console.warn(e);
                    try {
                        throw new Error(e)
                    } catch (n) {}
                }
            }
            var a = n("IJ96"),
                c = n.n(a),
                u = n("t2HS");
            const l = o.createContext(null);
            const h = o.createContext(null);
            const f = o.createContext({
                depth: 0,
                params: s({}),
                pathname: "",
                route: null
            });

            function p() {
                return (0, o.useContext)(h)
            }

            function d(t) {
                c()(y(), "useHref() may be used only in the context of a <Router> component.");
                const {
                    router: e
                } = (0, o.useContext)(l), n = v(t);
                return e.resolve(n).href
            }

            function y() {
                return null != (0, o.useContext)(l)
            }

            function g() {
                c()(y(), "useNavigate() may be used only in the context of a <Router> component.");
                const {
                    router: t
                } = (0, o.useContext)(l), {
                    pathname: e
                } = (0, o.useContext)(f), n = o.useRef(!1);
                return o.useEffect((() => {
                    n.current = !0
                })), o.useCallback(((r, o = {}) => {
                    if (n.current)
                        if ("number" === typeof r) t.go(r);
                        else {
                            let {
                                path: n
                            } = t.resolve(r, e);
                            (o.replace ? t.replace : t.push).call(t, n, o.state)
                        }
                    else i(!1, "You should call navigate() in a useEffect, not when your component is first rendered.")
                }), [t, e])
            }

            function m() {
                return (0, o.useContext)(h).params
            }

            function v(t) {
                const {
                    router: e
                } = (0, o.useContext)(l), {
                    pathname: n
                } = (0, o.useContext)(f);
                return o.useMemo((() => e.resolve(t, n).path), [t, n])
            }

            function _() {
                return c()(y(), "useRouter() may be used only in the context of a <Router> component."), (0, o.useContext)(l).router
            }

            function b() {
                return (0, o.useContext)(f)
            }

            function w({
                children: t = null,
                static: e = !1,
                router: n
            }) {
                c()(!y(), "You cannot render a <Router> inside another <Router>. You never need more than one.");
                const r = o.useMemo((() => ({
                        static: e,
                        router: n
                    })), [e, n]),
                    {
                        subscribe: s,
                        getSnapshot: i
                    } = o.useMemo((() => ({
                        subscribe: t => n.listen(t),
                        getSnapshot: () => n.current
                    })), [n]),
                    a = (0, u.useSyncExternalStore)(s, i, i);
                return o.createElement(l.Provider, {
                    value: r
                }, o.createElement(h.Provider, {
                    children: t,
                    value: a
                }))
            }
            const x = o.createElement(E, null);

            function S({
                match: t,
                depth: e,
                parentPathname: n,
                parentParams: i
            }) {
                const {
                    route: a,
                    params: c,
                    pathname: u
                } = t, l = o.useMemo((() => a.component ? o.createElement(a.component, a.props) : x), [a.component, a.props, x]);
                return o.createElement(f.Provider, {
                    children: l,
                    value: {
                        depth: e + 1,
                        params: s(Object.assign(Object.assign({}, i), c)),
                        pathname: (0, r.HS)([n, u]),
                        route: a
                    }
                })
            }

            function E() {
                let {
                    depth: t,
                    pathname: e,
                    params: n
                } = o.useContext(f);
                const {
                    matches: r
                } = p();
                if (!r.length) return null;
                const s = r[t];
                return s ? o.createElement(S, {
                    match: s,
                    depth: t,
                    parentPathname: e,
                    parentParams: n
                }) : null
            }
            var O = function(t, e) {
                var n = {};
                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && e.indexOf(r) < 0 && (n[r] = t[r]);
                if (null != t && "function" === typeof Object.getOwnPropertySymbols) {
                    var o = 0;
                    for (r = Object.getOwnPropertySymbols(t); o < r.length; o++) e.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(t, r[o]) && (n[r[o]] = t[r[o]])
                }
                return n
            };
            const j = o.forwardRef((function(t, e) {
                    var {
                        onClick: n,
                        replace: s = !1,
                        state: i,
                        target: a,
                        to: c
                    } = t, u = O(t, ["onClick", "replace", "state", "target", "to"]);
                    let l = d(c),
                        h = g();
                    const f = p();
                    let y = v(c);
                    return o.createElement("a", Object.assign({}, u, {
                        href: l,
                        onClick: function(t) {
                            if (n && n(t), !t.defaultPrevented && 0 === t.button && (!a || "_self" === a) && ! function(t) {
                                    return !!(t.metaKey || t.altKey || t.ctrlKey || t.shiftKey)
                                }(t)) {
                                t.preventDefault();
                                let e = !!s || (f && (0, r.uj)(f)) === (0, r.uj)(y);
                                h(c, {
                                    replace: e,
                                    state: i
                                })
                            }
                        },
                        ref: e,
                        target: a
                    }))
                })),
                k = o.forwardRef((function(t, e) {
                    const n = "undefined" === typeof t.to;
                    n && console.error("The prop 'to' is required in '<Link>', but its value is 'undefined'", JSON.stringify({
                        props: t
                    }));
                    const [r, s] = o.useState(!0);
                    return r && n ? o.createElement("a", Object.assign({}, t, {
                        onClick: t => {
                            t.preventDefault(), s(!1)
                        },
                        ref: e
                    })) : o.createElement(j, Object.assign({}, t, {
                        ref: e
                    }))
                }))
        },
        "8dyb": (t, e, n) => {
            "use strict";
            var r = n("DTvD");
            var o = "function" === typeof Object.is ? Object.is : function(t, e) {
                    return t === e && (0 !== t || 1 / t === 1 / e) || t !== t && e !== e
                },
                s = r.useState,
                i = r.useEffect,
                a = r.useLayoutEffect,
                c = r.useDebugValue;

            function u(t) {
                var e = t.getSnapshot;
                t = t.value;
                try {
                    var n = e();
                    return !o(t, n)
                } catch (r) {
                    return !0
                }
            }
            var l = "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? function(t, e) {
                return e()
            } : function(t, e) {
                var n = e(),
                    r = s({
                        inst: {
                            value: n,
                            getSnapshot: e
                        }
                    }),
                    o = r[0].inst,
                    l = r[1];
                return a((function() {
                    o.value = n, o.getSnapshot = e, u(o) && l({
                        inst: o
                    })
                }), [t, n, e]), i((function() {
                    return u(o) && l({
                        inst: o
                    }), t((function() {
                        u(o) && l({
                            inst: o
                        })
                    }))
                }), [t]), c(n), n
            };
            e.useSyncExternalStore = void 0 !== r.useSyncExternalStore ? r.useSyncExternalStore : l
        },
        t2HS: (t, e, n) => {
            "use strict";
            t.exports = n("8dyb")
        },
        oUj1: (t, e, n) => {
            "use strict";
            var r = n("hTvQ");
            e.createRoot = r.createRoot, e.hydrateRoot = r.hydrateRoot
        },
        V0mm: (t, e, n) => {
            "use strict";
            n.d(e, {
                ab: () => h,
                g$: () => l
            });
            var r = n("DTvD"),
                o = n.n(r),
                s = n("VyXn"),
                i = n("dod3"),
                a = n("hTvQ");
            const c = (t, e) => (n, o, s, a) => {
                    const c = (0, r.useRef)(s),
                        {
                            modelInstance: u,
                            subscribe: l
                        } = function(t, e, n, o) {
                            const {
                                modelInstance: s,
                                subscribe: i
                            } = (0, r.useMemo)((() => {
                                const r = n.getModel(t, e);
                                return {
                                    modelInstance: r,
                                    subscribe: t => o.addSubscribe(r, t)
                                }
                            }), [t, n]);
                            return {
                                modelInstance: s,
                                subscribe: i
                            }
                        }(n, o, t, e);
                    return c.current ? function(t, e, n, o) {
                        const s = (0, r.useRef)(void 0),
                            a = (0, r.useMemo)((() => {
                                const e = s.current;
                                return e && e.destory(), s.current = t.$createView(n)
                            }), [t, ...o || [n]]),
                            c = (0, i.useSyncExternalStore)(e, a, a);
                        return (0, r.useDebugValue)(c), c
                    }(u, l, s, a) : function(t, e) {
                        const n = (0, r.useMemo)((() => () => t.$getApi()), [t]),
                            o = (0, i.useSyncExternalStore)(e, n, n);
                        return (0, r.useDebugValue)(o), o
                    }(u, l)
                },
                u = () => {
                    const t = new WeakMap,
                        e = new WeakMap,
                        n = function(n, r) {
                            const o = t.get(n);
                            if (o && (o.delete(r), 0 === o.size && e.has(n))) {
                                t.delete(n);
                                const r = e.get(n);
                                r && (r(), e.delete(n))
                            }
                        },
                        r = function(e) {
                            const n = Array.from(t.get(e) || []);
                            (0, a.unstable_batchedUpdates)((() => {
                                let t = n.pop();
                                for (; t;) t(), t = n.pop()
                            }))
                        };
                    return {
                        addSubscribe: function(o, s) {
                            let i = t.get(o);
                            if (i) i.add(s);
                            else {
                                i = new Set, i.add(s);
                                const n = o.$subscribe((function() {
                                    r(o)
                                }));
                                t.set(o, i), e.set(o, n)
                            }
                            return function() {
                                return n(o, s)
                            }
                        },
                        triggerSubscribe: r
                    }
                };
            const l = function(t) {
                    const e = (0, r.createContext)(null);
                    const n = () => (0, r.useContext)(e);
                    return {
                        Provider: function(n) {
                            const {
                                children: i,
                                store: a
                            } = n, c = (0, r.useMemo)((function() {
                                let e;
                                e = a || (0, s.Sz)(t);
                                return {
                                    store: e,
                                    batchManager: u()
                                }
                            }), [a]), [l, h] = (0, r.useState)(c);
                            return (0, r.useEffect)((function() {
                                h(c)
                            }), [a]), o().createElement(e.Provider, {
                                value: l
                            }, i)
                        },
                        useSharedModel: (t, e, o, s) => {
                            const {
                                store: i,
                                batchManager: a
                            } = n();
                            return (0, r.useMemo)((() => c(i, a)), [i, a])(t, e, o, s)
                        },
                        useStaticModel: (t, e) => {
                            const {
                                store: o
                            } = n();
                            return (0, r.useMemo)((() => (t => (e, n) => {
                                const o = (0, r.useMemo)((() => t.getModel(e, n)), [e, t]);
                                return (0, r.useMemo)((() => o), [o])
                            })(o)), [o])(t, e)
                        }
                    }
                },
                {
                    Provider: h,
                    useSharedModel: f,
                    useStaticModel: p
                } = l({
                    plugins: []
                })
        },
        "1kr1": (t, e, n) => {
            "use strict";
            var r = n("DTvD");
            var o = "function" === typeof Object.is ? Object.is : function(t, e) {
                    return t === e && (0 !== t || 1 / t === 1 / e) || t !== t && e !== e
                },
                s = r.useState,
                i = r.useEffect,
                a = r.useLayoutEffect,
                c = r.useDebugValue;

            function u(t) {
                var e = t.getSnapshot;
                t = t.value;
                try {
                    var n = e();
                    return !o(t, n)
                } catch (r) {
                    return !0
                }
            }
            var l = "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? function(t, e) {
                return e()
            } : function(t, e) {
                var n = e(),
                    r = s({
                        inst: {
                            value: n,
                            getSnapshot: e
                        }
                    }),
                    o = r[0].inst,
                    l = r[1];
                return a((function() {
                    o.value = n, o.getSnapshot = e, u(o) && l({
                        inst: o
                    })
                }), [t, n, e]), i((function() {
                    return u(o) && l({
                        inst: o
                    }), t((function() {
                        u(o) && l({
                            inst: o
                        })
                    }))
                }), [t]), c(n), n
            };
            e.useSyncExternalStore = void 0 !== r.useSyncExternalStore ? r.useSyncExternalStore : l
        },
        dod3: (t, e, n) => {
            "use strict";
            t.exports = n("1kr1")
        },
        UyHI: (t, e, n) => {
            "use strict";
            var r = n("DTvD"),
                o = Symbol.for("react.element"),
                s = Symbol.for("react.fragment"),
                i = Object.prototype.hasOwnProperty,
                a = r.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
                c = {
                    key: !0,
                    ref: !0,
                    __self: !0,
                    __source: !0
                };

            function u(t, e, n) {
                var r, s = {},
                    u = null,
                    l = null;
                for (r in void 0 !== n && (u = "" + n), void 0 !== e.key && (u = "" + e.key), void 0 !== e.ref && (l = e.ref), e) i.call(e, r) && !c.hasOwnProperty(r) && (s[r] = e[r]);
                if (t && t.defaultProps)
                    for (r in e = t.defaultProps) void 0 === s[r] && (s[r] = e[r]);
                return {
                    $$typeof: o,
                    type: t,
                    key: u,
                    ref: l,
                    props: s,
                    _owner: a.current
                }
            }
            e.Fragment = s, e.jsx = u, e.jsxs = u
        },
        TrCV: (t, e, n) => {
            "use strict";
            t.exports = n("UyHI")
        },
        F2HG: (t, e, n) => {
            "use strict";
            var r = n("DTvD");
            var o = "function" === typeof Object.is ? Object.is : function(t, e) {
                    return t === e && (0 !== t || 1 / t === 1 / e) || t !== t && e !== e
                },
                s = r.useState,
                i = r.useEffect,
                a = r.useLayoutEffect,
                c = r.useDebugValue;

            function u(t) {
                var e = t.getSnapshot;
                t = t.value;
                try {
                    var n = e();
                    return !o(t, n)
                } catch (r) {
                    return !0
                }
            }
            var l = "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? function(t, e) {
                return e()
            } : function(t, e) {
                var n = e(),
                    r = s({
                        inst: {
                            value: n,
                            getSnapshot: e
                        }
                    }),
                    o = r[0].inst,
                    l = r[1];
                return a((function() {
                    o.value = n, o.getSnapshot = e, u(o) && l({
                        inst: o
                    })
                }), [t, n, e]), i((function() {
                    return u(o) && l({
                        inst: o
                    }), t((function() {
                        u(o) && l({
                            inst: o
                        })
                    }))
                }), [t]), c(n), n
            };
            e.useSyncExternalStore = void 0 !== r.useSyncExternalStore ? r.useSyncExternalStore : l
        },
        "8ptQ": (t, e, n) => {
            "use strict";
            t.exports = n("F2HG")
        },
        wcIl: (t, e, n) => {
            "use strict";
            n.d(e, {
                zR: () => F,
                TM: () => G,
                aE: () => z,
                HS: () => _,
                WN: () => p,
                uj: () => S
            });
            const r = "[^/]+?",
                o = {
                    sensitive: !1,
                    strict: !1,
                    start: !0,
                    end: !0
                },
                s = {
                    type: 3,
                    value: "*",
                    regexp: "(?:/((?:.*?)(?:/(?:.*?))*))?$"
                },
                i = Object.assign(Object.assign({}, s), {
                    regexp: "(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))?$"
                }),
                a = /[.+*?^${}()[\]/\\]/g;

            function c(t, e, n) {
                var c;
                const u = Object.assign({}, o, e);
                let l = s;
                u.strict && (l = i);
                let h = !1;
                const f = t[t.length - 1];
                if (f) {
                    const e = f[f.length - 1];
                    e && 0 === e.type && (e.value === l.value ? (h = !0, f.pop(), 0 === f.length && t.pop(), t.push([l])) : e.value.endsWith(l.value) && (h = !0, console.warn(`Route path "${e.value}" will be treated as if it were "${e.value.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.value.replace(/\*$/,"/*")}".`), e.value = e.value.slice(0, -1), t.push([l])))
                }
                let p = [],
                    d = u.start ? "^" : "";
                const y = [];
                for (const o of t) {
                    const t = o.length ? [] : [90];
                    u.strict && !o.length && (d += "/");
                    for (let e = 0; e < o.length; e++) {
                        const n = o[e];
                        let s = 40 + (u.sensitive ? .25 : 0);
                        if (0 === n.type) e || (d += "/"), d += n.value.replace(a, "\\$&"), s += 40;
                        else if (1 === n.type) {
                            const {
                                value: t,
                                repeatable: i,
                                optional: a,
                                regexp: c
                            } = n;
                            y.push({
                                name: t,
                                repeatable: i,
                                optional: a
                            });
                            const l = c || r;
                            if (l !== r) {
                                s += 10;
                                try {
                                    new RegExp(`(${l})`)
                                } catch (m) {
                                    throw new Error(`Invalid custom RegExp for param "${t}" (${l}): ` + m.message)
                                }
                            }
                            let h = i ? `((?:${l})(?:/(?:${l}))*)` : `(${l})`;
                            e || (h = a && o.length < 2 ? `(?:/${h})` : "/" + h), a && (h += "?"), d += h, u.end || (d += "(?=/|$)"), s += 20, a && (s += -8), i && (s += -20), ".*" === l && (s += -50)
                        } else if (3 === n.type) {
                            const {
                                value: t,
                                regexp: e
                            } = n;
                            y.push({
                                name: t,
                                repeatable: !1,
                                optional: !1
                            }), d += e, s += 20, s += -41
                        }
                        t.push(s)
                    }
                    p.push(t)
                }
                if (u.strict && u.end) {
                    const t = p.length - 1;
                    p[t][p[t].length - 1] += .7000000000000001
                }
                h || (u.strict || (d += "/*?"), u.end ? d += "$" : u.strict && (d += "(?:/*|$)"));
                const g = new RegExp(d, u.sensitive ? "" : "i");
                if (null === n || void 0 === n ? void 0 : n.routes) {
                    "" === (null === (c = n.routes[n.routes.length - 1]) || void 0 === c ? void 0 : c.path) && p.push([.1])
                }
                return {
                    re: g,
                    score: p,
                    keys: y,
                    parse: function(t) {
                        const e = t.match(g),
                            n = {};
                        if (!e) return null;
                        for (let r = 1; r < e.length; r++) {
                            const t = e[r] || "",
                                o = y[r - 1];
                            if (o.name === l.value) {
                                n[o.name] = t;
                                break
                            }
                            o.repeatable ? n[o.name] = t ? t.split("/") : [] : n[o.name] = t
                        }
                        return {
                            match: e[0],
                            params: n
                        }
                    },
                    stringify: function(e) {
                        let n = "",
                            r = !1;
                        for (const o of t) {
                            r && n.endsWith("/") || (n += "/"), r = !1;
                            for (const t of o)
                                if (0 === t.type) n += t.value;
                                else if (1 === t.type) {
                                const {
                                    value: s,
                                    repeatable: i,
                                    optional: a
                                } = t, c = e[s];
                                if (Array.isArray(c) && !i) throw new Error(`Provided param "${s}" is an array but it is not repeatable (* or + modifiers)`);
                                if (void 0 === c && !a) throw new Error(`Missing required param "${s}"`);
                                const u = Array.isArray(c) ? c.join("/") : c || "";
                                !u && a && o.length < 2 && (n.endsWith("/") ? n = n.slice(0, -1) : r = !0), n += u
                            }
                        }
                        return n
                    }
                }
            }

            function u(t, e) {
                let n = 0;
                for (; n < t.length && n < e.length;) {
                    const r = e[n] - t[n];
                    if (r) return r;
                    n++
                }
                return t.length < e.length ? 1 === t.length && 80 === t[0] ? -1 : 1 : t.length > e.length ? 1 === e.length && 80 === e[0] ? 1 : -1 : 0
            }
            const l = {
                    type: 0,
                    value: ""
                },
                h = /[a-zA-Z0-9_]/;

            function f(t) {
                if (!t) return [
                    []
                ];
                if ("/" === t) return [
                    [l]
                ];

                function e(t) {
                    throw new Error(`ERR (${n})/"${u}": ${t}`)
                }
                t.startsWith("/") || (t = t.replace(/^\/*/, "/"));
                let n = 0,
                    r = n;
                const o = [];
                let s;

                function i() {
                    s && o.push(s), s = []
                }
                let a, c = 0,
                    u = "",
                    f = "";

                function p() {
                    u && (0 === n ? s.push({
                        type: 0,
                        value: u
                    }) : 1 === n || 2 === n || 3 === n ? (s.length > 1 && ("*" === a || "+" === a) && e(`A repeatable param (${u}) must be alone in its segment. `), s.push({
                        type: 1,
                        value: u,
                        regexp: f,
                        repeatable: "*" === a || "+" === a,
                        optional: "*" === a || "?" === a
                    })) : e("Invalid state to consume buffer"), u = "")
                }

                function d() {
                    u += a
                }
                for (; c < t.length;)
                    if (a = t[c++], "\\" !== a || 2 === n) switch (n) {
                        case 0:
                            "/" === a ? (u && p(), i()) : ":" === a ? (p(), n = 1) : d();
                            break;
                        case 4:
                            d(), n = r;
                            break;
                        case 1:
                            "(" === a ? n = 2 : h.test(a) ? d() : (p(), n = 0, "*" !== a && "?" !== a && "+" !== a && c--);
                            break;
                        case 2:
                            ")" === a ? "\\" == f[f.length - 1] ? f = f.slice(0, -1) + a : n = 3 : f += a;
                            break;
                        case 3:
                            p(), n = 0, "*" !== a && "?" !== a && "+" !== a && c--, f = "";
                            break;
                        default:
                            e("Unknown state")
                    } else r = n, n = 4;
                return 2 === n && e(`Unfinished custom RegExp for param "${u}"`), p(), i(), o
            }

            function p(t, e) {
                "string" === typeof t && (t = {
                    path: t
                });
                const {
                    path: n,
                    caseSensitive: r = !1,
                    end: o = !0
                } = t, s = c(f(n), {
                    strict: !1,
                    end: o,
                    sensitive: r
                }), i = s.parse(e);
                if (!i) return null;
                const {
                    keys: a = []
                } = s, {
                    match: u,
                    params: l
                } = i;
                return {
                    path: n,
                    pathname: u,
                    params: a.reduce(((t, e, n) => {
                        const r = e.name;
                        return t[r] = function(t, e, n) {
                            try {
                                return Array.isArray(t) ? t.map((t => decodeURIComponent(t.replace(/\+/g, " ")))) : decodeURIComponent(t.replace(/\+/g, " "))
                            } catch (r) {
                                return n || console.warn(`The value for the URL param "${e}" will not be decoded because the string "${t}" is a malformed URL segment. This is probably due to a bad percent encoding (${r}).`), t
                            }
                        }(l[r], String(r), e.optional), t
                    }), {})
                }
            }

            function d() {
                let t = [];
                return {
                    get length() {
                        return t.length
                    },
                    toArray: () => t,
                    push: e => (t.push(e), function() {
                        t = t.filter((t => t !== e))
                    }),
                    call(...e) {
                        t.forEach((t => t && t(...e)))
                    }
                }
            }
            const y = t => t;

            function g(t, e) {
                if (!t) {
                    "undefined" !== typeof console && console.warn(e);
                    try {
                        throw new Error(e)
                    } catch (n) {}
                }
            }
            var m = n("oHTK");
            const v = t => t.replace(/\/\/+/g, "/"),
                _ = t => v(t.join("/")),
                b = t => v(t).split("/");

            function w(t) {
                return t || (t = "/"), "/" !== t.charAt(0) && (t = "/" + t), t.replace(/\/$/, "")
            }

            function x(t) {
                return m.parse(t)
            }

            function S({
                pathname: t = "/",
                search: e = "",
                hash: n = "",
                query: r = {}
            }, o) {
                if (!e) {
                    const t = m.stringify(r);
                    e = t ? `?${t}` : ""
                }
                const s = t + e + n;
                return o ? _([o, s]) : s
            }

            function E(t, e = "/") {
                let n = {
                    pathname: "",
                    search: "",
                    hash: "",
                    query: {}
                };
                if ("string" === typeof t) {
                    if (t) {
                        let e = t.indexOf("#");
                        e >= 0 && (n.hash = t.substr(e), t = t.substr(0, e));
                        let r = t.indexOf("?");
                        r >= 0 && (n.search = t.substr(r), n.query = x(n.search), t = t.substr(0, r)), t && (n.pathname = t)
                    }
                } else {
                    const e = t;
                    ["pathname", "search", "hash", "query"].forEach((t => {
                        const r = e[t];
                        null != r && (n[t] = r)
                    })), n.search ? n.query = x(n.search) : n.search = m.stringify(n.query)
                }
                const r = n.pathname;
                return n.pathname = r ? function(t, e) {
                    let n = b(e.replace(/\/+$/, ""));
                    return b(t).forEach((t => {
                        ".." === t ? n.length > 1 && n.pop() : "." !== t && n.push(t)
                    })), n.length > 1 ? _(n) : "/"
                }(r, r.startsWith("/") ? "/" : e) : e, n
            }

            function O(t, e) {
                return e && "/" !== e ? t.toLowerCase().startsWith(e.toLowerCase()) ? t.slice(e.length) || "/" : null : t
            }
            const j = "beforeunload";

            function k(t) {
                t.preventDefault(), t.returnValue = ""
            }

            function A(t, {
                basename: e,
                state: n = null,
                key: r,
                redirectedFrom: o
            } = {}) {
                const s = E(t),
                    i = O(s.pathname, e || "/");
                i && (s.pathname = i);
                const a = Boolean(e) && !i;
                return y(Object.assign(Object.assign({}, s), {
                    redirectedFrom: o,
                    notMatchBasename: a,
                    state: n,
                    key: r || Math.random().toString(36).substr(2, 8)
                }))
            }

            function C(t, e, {
                replace: n = !1
            } = {}) {
                const r = window.history;
                try {
                    n ? r.replaceState(t, "", e) : r.pushState(t, "", e)
                } catch (o) {
                    window.location[n ? "replace" : "assign"](e)
                }
            }

            function P(t, e) {
                C(t, e, {
                    replace: !0
                })
            }

            function I(t, e) {
                let n = t.push(e);
                return 1 === t.length && window.addEventListener(j, k),
                    function() {
                        n(), t.length || window.removeEventListener(j, k)
                    }
            }

            function T(t, e) {
                let n = t[1],
                    r = "/",
                    o = {},
                    s = [];
                for (let i = 0; i < n.length; ++i) {
                    let t = n[i],
                        a = "/" === r ? e : e.slice(r.length) || "/",
                        c = p({
                            path: t.path,
                            caseSensitive: t.caseSensitive,
                            end: i === n.length - 1
                        }, a);
                    if (!c) return null;
                    r = _([r, c.pathname]), o = Object.assign(Object.assign({}, o), c.params), s.push({
                        route: t,
                        pathname: r,
                        params: Object.freeze(o)
                    })
                }
                return s
            }

            function R(t) {
                if (t.length <= 1) return t;
                const e = t.map(((t, e) => {
                    const [n, r] = t;
                    return Object.assign(Object.assign({}, c(f(n), void 0, {
                        routes: r
                    })), {
                        path: n,
                        index: e
                    })
                }));
                e.sort(((t, e) => function(t, e) {
                    let n = 0;
                    const r = t.score,
                        o = e.score;
                    for (; n < r.length && n < o.length;) {
                        const t = u(r[n], o[n]);
                        if (t) return t;
                        n++
                    }
                    return o.length - r.length || t.index - e.index
                }(t, e)));
                const n = [];
                return e.forEach(((e, r) => {
                    const {
                        index: o
                    } = e;
                    n[r] = t[o]
                })), n
            }

            function L(t, e = [], n = "", r = [], o = []) {
                return t.forEach(((t, s) => {
                    let i;
                    i = "" === t.path ? n : _([n, t.path]);
                    let a = r.concat(t),
                        c = o.concat(s);
                    t.children && L(t.children, e, i, a, c), e.push([i, a, c])
                })), e
            }

            function N(t, e, n = "") {
                "string" === typeof e && (e = E(e));
                let r = e.pathname || "/";
                if (n) {
                    const t = O(r, w(n));
                    if (!t) return null;
                    r = t
                }
                let o = L(t);
                o = R(o);
                let s = null;
                for (let i = 0; null == s && i < o.length; ++i) s = T(o[i], r);
                return s
            }
            const D = "POP",
                M = "REPLACE";
            class H {
                constructor({
                    basename: t = ""
                } = {}) {
                    this.action = D, this.location = A("/"), this.doTransition = () => {}, this._index = 0, this._blockers = d(), this.basename = w(t)
                }
                back() {
                    this.go(-1)
                }
                forward() {
                    this.go(1)
                }
                resolve(t, e) {
                    const n = E(t, e);
                    return {
                        path: n,
                        href: S(n, this.basename)
                    }
                }
                transitionTo(t, {
                    onTransition: e,
                    onAbort: n,
                    action: r = "PUSH",
                    state: o = null,
                    redirectedFrom: s,
                    skipGuards: i
                }) {
                    const {
                        path: a
                    } = this.resolve(t, this.location.pathname), c = A(a, {
                        state: o,
                        redirectedFrom: s
                    });
                    this._blockers.length ? this._blockers.call({
                        action: r,
                        location: c,
                        retry: () => {
                            this.transitionTo(t, {
                                onTransition: e,
                                onAbort: n,
                                action: r,
                                state: o,
                                redirectedFrom: s,
                                skipGuards: i
                            })
                        }
                    }) : this.doTransition(t, (() => {
                        e({
                            location: c,
                            state: {
                                usr: c.state,
                                key: c.key,
                                idx: this._index + 1
                            },
                            url: this.resolve(c).href
                        }), this._updateState(r)
                    }), n, i, r === M, s)
                }
                _updateState(t) {
                    this.action = t, [this._index, this.location] = this.getIndexAndLocation()
                }
            }
            class U extends H {
                constructor({
                    basename: t
                } = {}) {
                    super({
                        basename: t
                    }), this._history = window.history, [this._index, this.location] = this.getIndexAndLocation();
                    const {
                        notMatchBasename: e
                    } = this.location;
                    if ((null == this._index || e) && (this._index = this._index || 0, this._history.replaceState(Object.assign(Object.assign({}, this._history.state), {
                            idx: this._index
                        }), "", e ? this.resolve(this.location).href : void 0)), e) {
                        const t = this._history.state || {};
                        this.location = A(this.location, {
                            state: t.usr || null,
                            key: t.key || "default"
                        })
                    }
                }
                push(t, {
                    state: e,
                    redirectedFrom: n
                } = {}) {
                    return this.transitionTo(t, {
                        state: e,
                        redirectedFrom: n,
                        onTransition({
                            state: t,
                            url: e
                        }) {
                            C(t, e)
                        }
                    })
                }
                replace(t, {
                    state: e,
                    redirectedFrom: n
                } = {}) {
                    return this.transitionTo(t, {
                        state: e,
                        action: M,
                        redirectedFrom: n,
                        onTransition({
                            state: t,
                            url: e
                        }) {
                            P(t, e)
                        }
                    })
                }
                go(t) {
                    this._history.go(t)
                }
                block(t) {
                    return I(this._blockers, t)
                }
                setup() {
                    let t = null;
                    window.addEventListener("popstate", (() => {
                        const e = this._index,
                            n = this._blockers;
                        if (t) n.call(t), t = null;
                        else {
                            let r = D,
                                [o, s] = this.getIndexAndLocation();
                            if (n.length)
                                if (null != o) {
                                    let n = e - o;
                                    n && (t = {
                                        action: r,
                                        location: s,
                                        retry: () => {
                                            this.go(-1 * n)
                                        }
                                    }, this.go(n))
                                } else g(!1, "You are trying to block a POP navigation to a location that was not created by the history library. The block will fail silently in production, but in general you should do all navigation with the history library (instead of using window.history.pushState directly) to avoid this situation.");
                            else this.transitionTo(s, {
                                onTransition: () => {},
                                action: r
                            })
                        }
                    }))
                }
                getIndexAndLocation() {
                    const {
                        pathname: t,
                        search: e,
                        hash: n
                    } = window.location, r = this._history.state || {};
                    return [r.idx, A({
                        pathname: t,
                        search: e,
                        hash: n
                    }, {
                        basename: this.basename,
                        state: r.usr || null,
                        key: r.key || "default"
                    })]
                }
            }

            function $(t, e) {
                return "#" + S(E(t), e)
            }
            class V extends H {
                constructor({
                    basename: t
                } = {}) {
                    super({
                        basename: t
                    }), this._history = window.history, [this._index, this.location] = this.getIndexAndLocation();
                    const {
                        notMatchBasename: e
                    } = this.location;
                    if ((null == this._index || e) && (this._index = this._index || 0, this._history.replaceState(Object.assign(Object.assign({}, this._history.state), {
                            idx: this._index
                        }), "", e ? this.resolve(this.location).href : void 0)), e) {
                        const t = this._history.state || {};
                        this.location = A(this.location, {
                            state: t.usr || null,
                            key: t.key || "default"
                        })
                    }
                }
                push(t, {
                    state: e,
                    redirectedFrom: n
                } = {}) {
                    return this.transitionTo(t, {
                        state: e,
                        redirectedFrom: n,
                        onTransition({
                            state: t,
                            url: e
                        }) {
                            C(t, e)
                        }
                    })
                }
                replace(t, {
                    state: e,
                    redirectedFrom: n
                } = {}) {
                    return this.transitionTo(t, {
                        state: e,
                        action: M,
                        redirectedFrom: n,
                        onTransition({
                            state: t,
                            url: e
                        }) {
                            P(t, e)
                        }
                    })
                }
                go(t) {
                    this._history.go(t)
                }
                block(t) {
                    return I(this._blockers, t)
                }
                resolve(t, e) {
                    const n = E(t, e);
                    return {
                        path: n,
                        href: $(n, this.basename)
                    }
                }
                setup() {
                    let t = null;
                    const e = () => {
                        const e = this._index,
                            n = this._blockers;
                        if (t) n.call(t), t = null;
                        else {
                            let r = D,
                                [o, s] = this.getIndexAndLocation();
                            if (n.length)
                                if (null != o) {
                                    let n = e - o;
                                    n && (t = {
                                        action: r,
                                        location: s,
                                        retry: () => {
                                            this.go(-1 * n)
                                        }
                                    }, this.go(n))
                                } else g(!1, "You are trying to block a POP navigation to a location that was not created by the history library. The block will fail silently in production, but in general you should do all navigation with the history library (instead of using window.history.pushState directly) to avoid this situation.");
                            else this.transitionTo(s, {
                                onTransition: () => {},
                                action: r
                            })
                        }
                    };
                    window.addEventListener("popstate", e), window.addEventListener("hashchange", (() => {
                        const [, t] = this.getIndexAndLocation();
                        S(t) !== S(this.location) && e()
                    }))
                }
                getIndexAndLocation() {
                    const {
                        pathname: t,
                        search: e,
                        hash: n
                    } = E(window.location.hash.substr(1)), r = this._history.state || {};
                    return [r.idx, A({
                        pathname: t,
                        search: e,
                        hash: n
                    }, {
                        basename: this.basename,
                        state: r.usr || null,
                        key: r.key || "default"
                    })]
                }
            }

            function F(t = {}) {
                return new U(t)
            }

            function G(t = {}) {
                return new V(t)
            }
            var q = n("Z2pg");

            function B(t, e = !1) {
                return t.map((t => {
                    const n = e ? "" : "/";
                    let r = Object.assign(Object.assign({}, t), {
                        caseSensitive: !!t.caseSensitive,
                        path: t.path || n
                    });
                    return t.children && (r.children = B(t.children, !0)), r
                }))
            }
            const K = {
                matches: [],
                params: {},
                pathname: "/",
                search: "",
                hash: "",
                key: "default",
                query: {},
                state: null,
                redirected: !1
            };
            class Y {
                constructor({
                    history: t,
                    routes: e
                }) {
                    this._pending = null, this._cancleHandler = null, this._ready = !1, this._readyDefer = (0, q.r)(), this._listeners = d(), this._beforeEachs = d(), this._beforeResolves = d(), this._afterEachs = d(), this.init = () => {
                        const t = () => this._history.setup(),
                            e = this._getCurrent();
                        return this._history.transitionTo(e, {
                            onTransition: t,
                            onAbort: t,
                            skipGuards: Boolean(e.redirected)
                        }), this
                    }, this.push = (t, e) => this._history.push(t, {
                        state: e
                    }), this.replace = (t, e) => this._history.replace(t, {
                        state: e
                    }), this.go = t => {
                        this._history.go(t)
                    }, this.back = () => {
                        this._history.back()
                    }, this.forward = () => {
                        this._history.forward()
                    }, this.block = t => this._history.block(t), this.listen = t => this._listeners.push(t), this.beforeEach = t => this._beforeEachs.push(t), this.beforeResolve = t => this._beforeResolves.push(t), this.afterEach = t => this._afterEachs.push(t), this.resolve = (t, e) => this._history.resolve(t, e), this.match = t => {
                        const {
                            _routes: e
                        } = this;
                        return N(e, t) || []
                    }, this.replaceRoutes = t => {
                        this._ready && (this._ready = !1, this._readyDefer = (0, q.r)()), this._cancleHandler && (this._cancleHandler(), this._cancleHandler = null), this._routes = B(t), this._current = K;
                        const e = () => this._history.setup();
                        this._history.transitionTo(this._getCurrent(), {
                            onTransition: e,
                            onAbort: e
                        })
                    }, this._history = t, this._routes = B(e), this._current = K, this._history.doTransition = this._doTransition.bind(this)
                }
                get ready() {
                    return this._readyDefer.promise
                }
                get current() {
                    return this._current
                }
                get routes() {
                    return this._routes
                }
                get action() {
                    return this._history.action
                }
                get basename() {
                    return this._history.basename
                }
                _doTransition(t, e, n, r, o, s) {
                    const i = this._getNextRoute(t),
                        a = this._current,
                        c = i.matches,
                        u = c.reduceRight(((t, {
                            route: {
                                redirect: e
                            }
                        }) => !t && e ? e : t), null);
                    const l = a === K;
                    if (u) {
                        const t = o || l ? "replace" : "push";
                        return this._history[t](u, {
                            redirectedFrom: s || i
                        })
                    }
                    const h = new Map,
                        f = r ? [] : [].concat(this._beforeEachs.toArray(), this._beforeResolves.toArray());
                    let p = !1;
                    this._cancleHandler = () => {
                        p = !0, this._pending = null
                    };
                    const d = () => {
                        this._cancleHandler = null, n && n(), this._ready || this._current === K || (this._ready = !0, this._readyDefer.resolve())
                    };
                    this._pending = t;
                    let y = [];
                    ! function(t, e, n) {
                        const r = o => {
                            o >= t.length ? n() : t[o] ? e(t[o], (() => {
                                r(o + 1)
                            })) : r(o + 1)
                        };
                        r(0)
                    }(f, ((e, n) => {
                        if (!p) {
                            if (this._pending !== t) return d();
                            try {
                                e(i, a, (t => {
                                    if (!1 === t) d();
                                    else if (r = t, Object.prototype.toString.call(r).indexOf("Error") > -1) d();
                                    else if ("string" === typeof t || "object" === typeof t && "string" === typeof t.path) {
                                        d();
                                        const e = o || "object" === typeof t && t.replace || l ? "replace" : "push";
                                        "object" === typeof t ? this._history[e](t.path, {
                                            redirectedFrom: s || i,
                                            skipGuards: t.skipGuards,
                                            state: t.state
                                        }) : this._history[e](t, {
                                            redirectedFrom: s || i
                                        })
                                    } else e = t, Object.prototype.toString.call(e).indexOf("Function") > -1 && y.push(t), n();
                                    var e, r
                                }))
                            } catch (r) {
                                d(), console.error("Uncaught error during navigation:", r)
                            }
                        }
                    }), (() => {
                        if (p) return;
                        if (this._pending !== t) return d();
                        this._pending = null, this._cancleHandler = null, e();
                        const n = this._current;
                        this._current = this._getCurrent(h), this._ready || (this._ready = !0, this._readyDefer.resolve()), this._listeners.call({
                            action: this._history.action,
                            location: this._history.location
                        }), this._afterEachs.call(this._current, n), y.forEach((t => {
                            t()
                        }))
                    }))
                }
                _getCurrent(t) {
                    var e;
                    const {
                        _history: {
                            location: n
                        }
                    } = this, r = this.match(n);
                    let o;
                    if (r.length) {
                        if (o = r[r.length - 1].params, t)
                            for (const {
                                    route: s
                                } of r) {
                                const n = null === (e = t.get(s)) || void 0 === e ? void 0 : e.props;
                                n && (s.props = Object.assign(Object.assign({}, s.props), n))
                            }
                    } else o = {};
                    return {
                        matches: r,
                        params: o,
                        pathname: n.pathname,
                        search: n.search,
                        hash: n.hash,
                        query: n.query,
                        state: n.state,
                        redirected: Boolean(n.redirectedFrom) || n.notMatchBasename,
                        key: n.key
                    }
                }
                _getNextRoute(t) {
                    const e = this.match(t),
                        n = e.length ? e[e.length - 1].params : {},
                        r = E(t);
                    return Object.assign(Object.assign({
                        matches: e,
                        params: n
                    }, r), {
                        key: "",
                        state: null
                    })
                }
            }
            const z = t => new Y(t)
        },
        oHTK: (t, e, n) => {
            "use strict";
            const r = n("UM5q"),
                o = n("1Fob"),
                s = n("p/97");

            function i(t) {
                if ("string" !== typeof t || 1 !== t.length) throw new TypeError("arrayFormatSeparator must be single character string")
            }

            function a(t, e) {
                return e.encode ? e.strict ? r(t) : encodeURIComponent(t) : t
            }

            function c(t, e) {
                return e.decode ? o(t) : t
            }

            function u(t) {
                return Array.isArray(t) ? t.sort() : "object" === typeof t ? u(Object.keys(t)).sort(((t, e) => Number(t) - Number(e))).map((e => t[e])) : t
            }

            function l(t) {
                const e = t.indexOf("#");
                return -1 !== e && (t = t.slice(0, e)), t
            }

            function h(t) {
                const e = (t = l(t)).indexOf("?");
                return -1 === e ? "" : t.slice(e + 1)
            }

            function f(t, e) {
                return e.parseNumbers && !Number.isNaN(Number(t)) && "string" === typeof t && "" !== t.trim() ? t = Number(t) : !e.parseBooleans || null === t || "true" !== t.toLowerCase() && "false" !== t.toLowerCase() || (t = "true" === t.toLowerCase()), t
            }

            function p(t, e) {
                i((e = Object.assign({
                    decode: !0,
                    sort: !0,
                    arrayFormat: "none",
                    arrayFormatSeparator: ",",
                    parseNumbers: !1,
                    parseBooleans: !1
                }, e)).arrayFormatSeparator);
                const n = function(t) {
                        let e;
                        switch (t.arrayFormat) {
                            case "index":
                                return (t, n, r) => {
                                    e = /\[(\d*)\]$/.exec(t), t = t.replace(/\[\d*\]$/, ""), e ? (void 0 === r[t] && (r[t] = {}), r[t][e[1]] = n) : r[t] = n
                                };
                            case "bracket":
                                return (t, n, r) => {
                                    e = /(\[\])$/.exec(t), t = t.replace(/\[\]$/, ""), e ? void 0 !== r[t] ? r[t] = [].concat(r[t], n) : r[t] = [n] : r[t] = n
                                };
                            case "comma":
                            case "separator":
                                return (e, n, r) => {
                                    const o = "string" === typeof n && n.includes(t.arrayFormatSeparator),
                                        s = "string" === typeof n && !o && c(n, t).includes(t.arrayFormatSeparator);
                                    n = s ? c(n, t) : n;
                                    const i = o || s ? n.split(t.arrayFormatSeparator).map((e => c(e, t))) : null === n ? n : c(n, t);
                                    r[e] = i
                                };
                            default:
                                return (t, e, n) => {
                                    void 0 !== n[t] ? n[t] = [].concat(n[t], e) : n[t] = e
                                }
                        }
                    }(e),
                    r = Object.create(null);
                if ("string" !== typeof t) return r;
                if (!(t = t.trim().replace(/^[?#&]/, ""))) return r;
                for (const o of t.split("&")) {
                    let [t, i] = s(e.decode ? o.replace(/\+/g, " ") : o, "=");
                    i = void 0 === i ? null : ["comma", "separator"].includes(e.arrayFormat) ? i : c(i, e), n(c(t, e), i, r)
                }
                for (const o of Object.keys(r)) {
                    const t = r[o];
                    if ("object" === typeof t && null !== t)
                        for (const n of Object.keys(t)) t[n] = f(t[n], e);
                    else r[o] = f(t, e)
                }
                return !1 === e.sort ? r : (!0 === e.sort ? Object.keys(r).sort() : Object.keys(r).sort(e.sort)).reduce(((t, e) => {
                    const n = r[e];
                    return Boolean(n) && "object" === typeof n && !Array.isArray(n) ? t[e] = u(n) : t[e] = n, t
                }), Object.create(null))
            }
            e.extract = h, e.parse = p, e.stringify = (t, e) => {
                if (!t) return "";
                i((e = Object.assign({
                    encode: !0,
                    strict: !0,
                    arrayFormat: "none",
                    arrayFormatSeparator: ","
                }, e)).arrayFormatSeparator);
                const n = n => {
                        return e.skipNull && (null === (r = t[n]) || void 0 === r) || e.skipEmptyString && "" === t[n];
                        var r
                    },
                    r = function(t) {
                        switch (t.arrayFormat) {
                            case "index":
                                return e => (n, r) => {
                                    const o = n.length;
                                    return void 0 === r || t.skipNull && null === r || t.skipEmptyString && "" === r ? n : null === r ? [...n, [a(e, t), "[", o, "]"].join("")] : [...n, [a(e, t), "[", a(o, t), "]=", a(r, t)].join("")]
                                };
                            case "bracket":
                                return e => (n, r) => void 0 === r || t.skipNull && null === r || t.skipEmptyString && "" === r ? n : null === r ? [...n, [a(e, t), "[]"].join("")] : [...n, [a(e, t), "[]=", a(r, t)].join("")];
                            case "comma":
                            case "separator":
                                return e => (n, r) => null === r || void 0 === r || 0 === r.length ? n : 0 === n.length ? [
                                    [a(e, t), "=", a(r, t)].join("")
                                ] : [
                                    [n, a(r, t)].join(t.arrayFormatSeparator)
                                ];
                            default:
                                return e => (n, r) => void 0 === r || t.skipNull && null === r || t.skipEmptyString && "" === r ? n : null === r ? [...n, a(e, t)] : [...n, [a(e, t), "=", a(r, t)].join("")]
                        }
                    }(e),
                    o = {};
                for (const i of Object.keys(t)) n(i) || (o[i] = t[i]);
                const s = Object.keys(o);
                return !1 !== e.sort && s.sort(e.sort), s.map((n => {
                    const o = t[n];
                    return void 0 === o ? "" : null === o ? a(n, e) : Array.isArray(o) ? o.reduce(r(n), []).join("&") : a(n, e) + "=" + a(o, e)
                })).filter((t => t.length > 0)).join("&")
            }, e.parseUrl = (t, e) => {
                e = Object.assign({
                    decode: !0
                }, e);
                const [n, r] = s(t, "#");
                return Object.assign({
                    url: n.split("?")[0] || "",
                    query: p(h(t), e)
                }, e && e.parseFragmentIdentifier && r ? {
                    fragmentIdentifier: c(r, e)
                } : {})
            }, e.stringifyUrl = (t, n) => {
                n = Object.assign({
                    encode: !0,
                    strict: !0
                }, n);
                const r = l(t.url).split("?")[0] || "",
                    o = e.extract(t.url),
                    s = e.parse(o, {
                        sort: !1
                    }),
                    i = Object.assign(s, t.query);
                let c = e.stringify(i, n);
                c && (c = `?${c}`);
                let u = function(t) {
                    let e = "";
                    const n = t.indexOf("#");
                    return -1 !== n && (e = t.slice(n)), e
                }(t.url);
                return t.fragmentIdentifier && (u = `#${a(t.fragmentIdentifier,n)}`), `${r}${c}${u}`
            }
        },
        qK3R: function(t, e) {
            "use strict";
            var n, r = this && this.__awaiter || function(t, e, n, r) {
                return new(n || (n = Promise))((function(o, s) {
                    function i(t) {
                        try {
                            c(r.next(t))
                        } catch (e) {
                            s(e)
                        }
                    }

                    function a(t) {
                        try {
                            c(r.throw(t))
                        } catch (e) {
                            s(e)
                        }
                    }

                    function c(t) {
                        var e;
                        t.done ? o(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                            t(e)
                        }))).then(i, a)
                    }
                    c((r = r.apply(t, e || [])).next())
                }))
            };
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.trace = e.Span = e.SpanStatus = void 0, e.setReporter = function(t) {
                    false;
                    if (s) throw new Error("Reporter already set !");
                    s = t
                },
                function(t) {
                    t[t.Started = 0] = "Started", t[t.Stopped = 1] = "Stopped"
                }(n || (e.SpanStatus = n = {}));
            Symbol.for("shuvi_server_reporter");
            let o = 0;
            let s;
            class i {
                constructor({
                    name: t,
                    parentId: e,
                    attrs: r,
                    startTime: s
                }) {
                    this._name = t, this._parentId = e, this._attrs = r ? Object.assign({}, r) : {}, this._status = n.Started, this._id = (o++, o);
                    const i = Date.now();
                    this._start = s || i, this._now = i
                }
                get status() {
                    return this._status
                }
                stop(t) {
                    const e = s;
                    if (!e) return;
                    const r = t || Date.now(),
                        o = r - this._start;
                    this._status = n.Stopped, o > Number.MAX_SAFE_INTEGER && console.warn(`Duration is too long to express as float64: ${o}`), e({
                        timestamp: this._now,
                        name: this._name,
                        duration: o,
                        startTime: this._start,
                        endTime: r,
                        id: this._id,
                        parentId: this._parentId,
                        attrs: this._attrs
                    })
                }
                traceChild(t, e) {
                    return new i({
                        name: t,
                        parentId: this._id,
                        attrs: e
                    })
                }
                manualTraceChild(t, e, n, r) {
                    new i({
                        name: t,
                        parentId: this._id,
                        attrs: r,
                        startTime: e
                    }).stop(n)
                }
                setAttribute(t, e) {
                    this._attrs[t] = e
                }
                setAttributes(t) {
                    Object.keys(t).forEach((e => {
                        this.setAttribute(e, t[e])
                    }))
                }
                traceFn(t) {
                    try {
                        return t(this)
                    } finally {
                        this.stop()
                    }
                }
                traceAsyncFn(t) {
                    return r(this, void 0, void 0, (function*() {
                        try {
                            return yield t(this)
                        } finally {
                            this.stop()
                        }
                    }))
                }
            }
            e.Span = i;
            e.trace = (t, e, n) => new i({
                name: t,
                parentId: e,
                attrs: n
            })
        },
        "k/Mm": (t, e, n) => {
            "use strict";
            n.d(e, {
                CH: () => o,
                Kj: () => r,
                nt: () => s
            });
            const r = "__APP",
                o = "__APP_DATA",
                s = {
                    APP_ERROR: {
                        code: 500,
                        message: "Internal Application Error."
                    },
                    SERVER_ERROR: {
                        code: 500,
                        message: "Internal Server Error."
                    },
                    CLIENT_ERROR: {
                        message: "Internal Application Error"
                    },
                    PAGE_NOT_FOUND: {
                        code: 404,
                        message: "This page could not be found."
                    }
                }
        },
        kvBi: (t, e, n) => {
            "use strict";
            n.d(e, {
                ft: () => s,
                vO: () => a
            });
            const r = "requestId",
                o = {
                    requestId: {
                        name: r,
                        type: "string"
                    },
                    error: {
                        name: "error",
                        type: "boolean"
                    },
                    errorType: {
                        name: "errorType",
                        type: "string",
                        enum: ["redirect", "userError", "unexpectedError"]
                    }
                },
                s = {
                    name: "CLIENT_ENTRY",
                    events: {
                        SHUVI_CLIENT_ENTRY_START: {
                            name: "SHUVI_CLIENT_ENTRY_START",
                            duration: !1
                        },
                        SHUVI_CLIENT_SETUP_ENV: {
                            name: "SHUVI_CLIENT_SETUP_ENV",
                            duration: !0
                        },
                        SHUVI_CLIENT_CREATE_APP: {
                            name: "SHUVI_CLIENT_CREATE_APP",
                            duration: !0
                        },
                        SHUVI_CLIENT_APP_INIT: {
                            name: "SHUVI_CLIENT_APP_INIT",
                            duration: !0
                        },
                        SHUVI_CLIENT_RUN_APP: {
                            name: "SHUVI_CLIENT_RUN_APP",
                            duration: !0
                        },
                        SHUVI_CLIENT_DO_RENDER: {
                            name: "SHUVI_CLIENT_DO_RENDER",
                            duration: !0
                        }
                    }
                },
                i = {
                    from: {
                        name: "from",
                        type: "string"
                    },
                    to: {
                        name: "to",
                        type: "string"
                    },
                    navigationId: {
                        name: "navigationId",
                        type: "string"
                    }
                },
                a = {
                    name: "CLIENT_RENDER",
                    events: {
                        SHUVI_PAGE_READY: {
                            name: "SHUVI_PAGE_READY",
                            duration: !1
                        },
                        SHUVI_NAVIGATION_TRIGGERED: {
                            name: "SHUVI_NAVIGATION_TRIGGERED",
                            duration: !0,
                            attrs: i
                        },
                        SHUVI_NAVIGATION_DONE: {
                            name: "SHUVI_NAVIGATION_DONE",
                            duration: !0,
                            attrs: i
                        },
                        SHUVI_CLIENT_RUN_LOADERS: {
                            name: "SHUVI_CLIENT_RUN_LOADERS",
                            duration: !0,
                            attrs: o
                        }
                    }
                }
        },
        nlrA: (t, e, n) => {
            "use strict";
            var r = n("Dz1D"),
                o = n("etBY"),
                s = n("fix3"),
                i = n("kvBi"),
                a = n("aUDg");
            a.x.traceChild(i.ft.events.SHUVI_CLIENT_ENTRY_START.name).stop();
            var c = a.x.traceChild(i.ft.events.SHUVI_CLIENT_SETUP_ENV.name),
                u = (0, s.Y)();
            o.A && (0, r.UB)(o.A), u.runtimeConfig && (0, r.UB)(u.runtimeConfig), c.stop();
            n("cpeW");
            n("2rPy")
        },
        "2rPy": (t, e, n) => {
            "use strict";
            n.r(e);
            var r = n("2URn"),
                o = n("0GOp"),
                s = n.n(o),
                i = n("k/Mm"),
                a = n("TrCV"),
                c = n("DTvD"),
                u = n("BK9r");

            function l() {
                return (0, a.jsx)(u.Tp, {})
            }
            const h = c.memo(l);
            var f = n("888e"),
                p = n("kvBi"),
                d = n("VyXn");
            const y = "error",
                g = (0, d.NP)({
                    state: {
                        error: null
                    },
                    actions: {
                        set(t) {
                            this.error = t
                        },
                        clear() {
                            this.hasError && (this.error = null)
                        }
                    },
                    views: {
                        errorObject() {
                            return this.error
                        },
                        hasError() {
                            return null !== this.error
                        }
                    }
                });
            var m = c.createContext(null);

            function v(t) {
                var e = t.app,
                    n = t.children;
                return (0, a.jsx)(m.Provider, {
                    value: e,
                    children: n
                })
            }
            var _ = n("uHCZ"),
                b = {
                    container: {
                        color: "#000",
                        background: "#fff",
                        fontFamily: '-apple-system, BlinkMacSystemFont, Roboto, "Segoe UI", "Fira Sans", Avenir, "Helvetica Neue", "Lucida Grande", sans-serif',
                        height: "100vh",
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center"
                    },
                    error: {
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center"
                    },
                    errorCode: {
                        fontSize: "24px",
                        fontWeight: 500,
                        borderRight: "1px solid rgba(0, 0, 0, 0.3)",
                        paddingRight: "20px",
                        marginRight: "20px"
                    },
                    errorDesc: {
                        fontSize: "16px",
                        lineHeight: "1"
                    }
                };
            var w = n("v7Og").A || function(t) {
                var e = t.errorCode,
                    n = t.errorDesc;
                return (0, a.jsxs)("div", {
                    style: b.container,
                    children: [(0, a.jsx)(_.A, {
                        children: (0, a.jsx)("title", {
                            children: "Page Error"
                        })
                    }), (0, a.jsxs)("div", {
                        style: b.error,
                        children: [void 0 !== e && (0, a.jsx)("div", {
                            style: b.errorCode,
                            children: e
                        }), (0, a.jsx)("div", {
                            style: b.errorDesc,
                            children: n || "Error"
                        })]
                    })]
                })
            };

            function x(t) {
                var e = t.code,
                    n = t.message,
                    r = t.error;
                return (0, a.jsx)(w, {
                    errorCode: e,
                    errorDesc: n,
                    error: r
                })
            }
            var S = n("nG1z"),
                E = n("2PCm"),
                O = n("VKAp"),
                j = function(t) {
                    (0, E.A)(n, t);
                    var e = (0, O.A)(n);

                    function n() {
                        var t;
                        return (0, f.A)(this, n), (t = e.call.apply(e, [this].concat(Array.prototype.slice.call(arguments)))).state = {
                            error: null
                        }, t
                    }
                    return (0, S.A)(n, [{
                        key: "componentDidCatch",
                        value: function(t, e) {
                            this.setState({
                                error: t
                            }), console.error("the error is below: \n", t), e && e.componentStack && console.error("the componentStack is below: \n", e.componentStack)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this.state.error ? (0, a.jsx)(x, {
                                message: i.nt.CLIENT_ERROR.message,
                                error: this.state.error
                            }) : this.props.children
                        }
                    }]), n
                }(c.PureComponent),
                k = n("77a2"),
                A = n("ezuS"),
                C = n("aUDg"),
                P = p.vO.events,
                I = P.SHUVI_NAVIGATION_TRIGGERED,
                T = P.SHUVI_NAVIGATION_DONE,
                R = P.SHUVI_PAGE_READY;

            function L() {
                var t = (0, u.rd)(),
                    e = (0, u.K7)(),
                    n = c.useRef();
                c.useEffect((function() {
                    C.t.traceChild(R.name).stop(), t.beforeEach((function(t, e, r) {
                        var o, s = "".concat(e.pathname).concat(e.search),
                            i = "".concat(t.pathname).concat(t.search),
                            a = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(t) {
                                var e = 16 * Math.random() | 0;
                                return ("x" == t ? e : 3 & e | 8).toString(16)
                            })),
                            c = (o = {}, (0, A.A)(o, T.attrs.from.name, s), (0, A.A)(o, T.attrs.to.name, i), (0, A.A)(o, T.attrs.navigationId.name, a), o);
                        C.t.traceChild(I.name, c).stop(), n.current = C.t.traceChild(T.name), n.current.setAttributes(c), r()
                    }))
                }), []), c.useEffect((function() {
                    var t;
                    null === (t = n.current) || void 0 === t || t.stop()
                }), [e])
            }

            function N(t) {
                var e = t.children,
                    n = void 0 === e ? null : e;
                return L(), (0, a.jsx)(a.Fragment, {
                    children: n
                })
            }

            function D(t) {
                var e = t.children,
                    n = void 0 === e ? null : e,
                    r = (0, k.MA)(y, g),
                    o = r.error;
                return r.hasError ? (0, a.jsx)(x, {
                    code: null === o || void 0 === o ? void 0 : o.code,
                    message: null === o || void 0 === o ? void 0 : o.message,
                    error: null === o || void 0 === o ? void 0 : o.error
                }) : (0, a.jsx)(a.Fragment, {
                    children: n
                })
            }

            function M(t) {
                var e = t.app,
                    n = t.children;
                return (0, a.jsx)(v, {
                    app: e,
                    children: (0, a.jsx)(j, {
                        children: (0, a.jsx)(k.Kq, {
                            store: e.store,
                            children: (0, a.jsx)(D, {
                                children: (0, a.jsx)(N, {
                                    children: n
                                })
                            })
                        })
                    })
                })
            }
            var H = function() {
                function t() {
                    (0, f.A)(this, t), this._pedningPromise = null, this.updateHead = this.updateHead.bind(this)
                }
                return (0, S.A)(t, [{
                    key: "updateHead",
                    value: function(t) {
                        var e = this;
                        this._head = t, this._pedningPromise || (this._pedningPromise = Promise.resolve().then((function() {
                            e._pedningPromise = null, e._doUpdateHead()
                        })))
                    }
                }, {
                    key: "_doUpdateHead",
                    value: function() {
                        var t = this,
                            e = {};
                        this._head.forEach((function(t) {
                            (e[t.tagName] || (e[t.tagName] = [])).push(t)
                        })), e.title && this._updateTitle(e.title[0]);
                        ["meta", "base", "link", "style", "script"].forEach((function(n) {
                            t._updateElements(n, e[n] || [])
                        }))
                    }
                }, {
                    key: "_updateTitle",
                    value: function(t) {
                        var e = t.attrs,
                            n = e.textContent || "";
                        n !== document.title && (document.title = n);
                        var r = document.getElementsByTagName("title")[0];
                        r && U(r, e)
                    }
                }, {
                    key: "_updateElements",
                    value: function(t, e) {
                        var n = document.getElementsByTagName("head")[0],
                            r = n.querySelectorAll("".concat(t, "[").concat(_.a, "='true']")),
                            o = Array.prototype.slice.call(r),
                            s = null;
                        o.length && (s = o[o.length - 1].nextElementSibling);
                        var i = e.map($).filter((function(t) {
                            for (var e = 0, n = o.length; e < n; e++) {
                                if (o[e].isEqualNode(t)) return o.splice(e, 1), !1
                            }
                            return !0
                        }));
                        o.forEach((function(t) {
                            return t.parentNode.removeChild(t)
                        })), i.forEach((function(t) {
                            s ? n.insertBefore(t, s) : n.appendChild(t)
                        }))
                    }
                }]), t
            }();

            function U(t, e) {
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && "textContent" !== n && void 0 !== e[n] && t.setAttribute(n.toLowerCase(), e[n])
            }

            function $(t) {
                var e = t.tagName,
                    n = t.attrs,
                    r = t.innerHTML,
                    o = document.createElement(e);
                U(o, n);
                var s = n.textContent;
                return r ? o.innerHTML = r : s && (o.textContent = s), o
            }
            var V, F, G = n("gmsc"),
                q = n("nFfn"),
                B = n("oUj1"),
                K = B.createRoot,
                Y = B.hydrateRoot;
            V = function(t, e) {
                var n = t.root,
                    r = t.appContainer;
                t.shouldHydrate ? (F = Y(r, n), null === e || void 0 === e || e()) : (F || (F = K(r)), F.render(n))
            };
            var z = function(t, e, n, o) {
                    return new(n || (n = Promise))((function(s, i) {
                        var a = function(t) {
                                try {
                                    u(o.next(t))
                                } catch (e) {
                                    i(e)
                                }
                            },
                            c = function(t) {
                                try {
                                    u(o.throw(t))
                                } catch (e) {
                                    i(e)
                                }
                            },
                            u = function(t) {
                                var e;
                                t.done ? s(t.value) : (e = t.value, (0, r.A)(e, n) ? e : new n((function(t) {
                                    t(e)
                                }))).then(a, c)
                            };
                        u((o = o.apply(t, e || [])).next())
                    }))
                },
                W = new H;
            const J = new function t() {
                var e = this;
                (0, f.A)(this, t), this._isInitialRender = !0, this.renderApp = function(t) {
                    return z(e, [t], void 0, s().mark((function t(e) {
                        var n, r, o, c, l, h, f, d, y, g, m, v, _;
                        return s().wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (n = e.appContainer, r = e.app, o = e.appData, c = this, l = this._isInitialRender, h = r.router, f = r.appComponent, d = r.setError, r.error, y = o.ssr, g = o.dynamicIds, m = y && l, v = f, !y || !l) {
                                        t.next = 13;
                                        break
                                    }
                                    return t.next = 11, Promise.all([q.A.preloadReady(g), h.ready]);
                                case 11:
                                    t.next = 17;
                                    break;
                                case 13:
                                    return t.next = 15, h.ready;
                                case 15:
                                    h.current.matches.length || d(i.nt.PAGE_NOT_FOUND);
                                case 17:
                                    _ = (0, a.jsx)(u.Ix, {
                                        router: h,
                                        children: (0, a.jsx)(M, {
                                            app: r,
                                            children: (0, a.jsx)(G.T.Provider, {
                                                value: W.updateHead,
                                                children: (0, a.jsx)(v, {})
                                            })
                                        })
                                    }), C.x.traceChild(p.ft.events.SHUVI_CLIENT_DO_RENDER.name).traceFn((function() {
                                        V({
                                            root: _,
                                            appContainer: n,
                                            shouldHydrate: m
                                        }, (function() {
                                            c._isInitialRender = !1
                                        }))
                                    }));
                                case 19:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })))
                }
            };
            var X = n("3cKB"),
                Z = n("fix3"),
                Q = n("OFK0");
            var tt = function(t, e) {
                var n = {};
                for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && e.indexOf(r) < 0 && (n[r] = t[r]);
                if (null != t && "function" === typeof Object.getOwnPropertySymbols) {
                    var o = 0;
                    for (r = Object.getOwnPropertySymbols(t); o < r.length; o++) e.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(t, r[o]) && (n[r[o]] = t[r[o]])
                }
                return n
            };

            function et(t) {
                var e = function(t) {
                    return t.map((function(t) {
                        var n = Object.assign({}, t),
                            r = n.__componentRawRequest__,
                            o = n.__import__,
                            s = n.__resolveWeak__,
                            i = n.children,
                            a = tt(n, ["__componentRawRequest__", "__import__", "__resolveWeak__", "children"]);
                        return i && (a.children = e(i)), o && (a.component = function(t, e) {
                            return (0, Q.A)((function() {
                                return t().then((function(t) {
                                    return t.default || t
                                }))
                            }), e)
                        }(o, Object.assign({
                            webpack: s
                        }, r && {
                            modules: [r]
                        }))), r && (a.__componentRawRequest__ = r), a
                    }))
                };
                return e(t || [])
            }
            var nt = n("hSG1"),
                rt = function(t, e, n, r) {
                    return new(n || (n = Promise))((function(o, s) {
                        function i(t) {
                            try {
                                c(r.next(t))
                            } catch (e) {
                                s(e)
                            }
                        }

                        function a(t) {
                            try {
                                c(r.throw(t))
                            } catch (e) {
                                s(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                                t(e)
                            }))).then(i, a)
                        }
                        c((r = r.apply(t, e || [])).next())
                    }))
                };

            function ot(t) {
                return rt(this, void 0, void 0, (function*() {
                    const e = t.matches,
                        n = [];
                    e.forEach((t => {
                        var e;
                        const r = null === (e = t.route.component) || void 0 === e ? void 0 : e.preload;
                        r && "function" === typeof r && n.push(r())
                    })), yield Promise.all(n)
                }))
            }

            function st(t, e, n) {
                const r = t.matches,
                    o = e.matches;
                let s = [];
                for (let a = 0; a < r.length; a++) {
                    const t = r[a],
                        e = o[a];
                    if (t.route.id !== (null === e || void 0 === e ? void 0 : e.route.id)) {
                        s.push(...r.slice(a));
                        break
                    }
                    if (!(0, nt.A)(t.params, null === e || void 0 === e ? void 0 : e.params)) {
                        s.push(...r.slice(a));
                        break
                    }
                    a === r.length - 1 && s.push(t)
                }
                const i = [];
                return s.forEach((t => {
                    const e = t.route.id;
                    n[e] && "function" === typeof n[e] && i.push(t)
                })), i
            }
            var it = n("IJ96"),
                at = n.n(it);
            const ct = "Symbol" in n.g && "iterator" in Symbol;

            function ut(t) {
                if ("string" !== typeof t && (t = String(t)), /[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(t) || "" === t) throw new TypeError('Invalid character in header field name: "' + t + '"');
                return t.toLowerCase()
            }

            function lt(t) {
                return "string" !== typeof t && (t = String(t)), t
            }

            function ht(t) {
                var e = {
                    next: function() {
                        var e = t.shift();
                        return {
                            done: void 0 === e,
                            value: e
                        }
                    }
                };
                return ct && (e[Symbol.iterator] = function() {
                    return e
                }), e
            }
            class ft {
                constructor(t) {
                    this._map = {}, t instanceof ft ? t.forEach(((t, e) => {
                        this.append(e, t)
                    })) : Array.isArray(t) ? t.forEach((t => this.append(t[0], t[1]))) : t && Object.keys(t).forEach((e => {
                        this.append(e, t[e])
                    }))
                }
                append(t, e) {
                    t = ut(t), e = lt(e);
                    var n = this._map[t];
                    this._map[t] = n ? n + ", " + e : e
                }
                delete(t) {
                    delete this._map[ut(t)]
                }
                get(t) {
                    return t = ut(t), this.has(t) ? this._map[t] : null
                }
                has(t) {
                    return this._map.hasOwnProperty(ut(t))
                }
                set(t, e) {
                    this._map[ut(t)] = lt(e)
                }
                forEach(t, e) {
                    for (var n in Object.keys(this._map)) t.call(e, this._map[n], n, this)
                }
                keys() {
                    const t = [];
                    return this.forEach(((e, n) => t.push(n))), ht(t)
                }
                value() {
                    const t = [];
                    return this.forEach((e => t.push(e))), ht(t)
                }
                entries() {
                    const t = [];
                    return this.forEach(((e, n) => t.push([n, e]))), ht(t)
                }
            }
            ct && (ft.prototype[Symbol.iterator] = ft.prototype.entries);
            class pt {
                constructor(t, e, n = {}) {
                    this.__shuvi_resp_type__ = e, this.data = t, this.status = n.status || 200, this.statusText = n.statusText || "", this.headers = new ft(n.headers)
                }
            }

            function dt(t) {
                return e => e && e.__shuvi_resp_type__ === t
            }
            dt("json"), dt("text");
            const yt = dt("redirect");
            var gt = function(t, e, n, r) {
                return new(n || (n = Promise))((function(o, s) {
                    function i(t) {
                        try {
                            c(r.next(t))
                        } catch (e) {
                            s(e)
                        }
                    }

                    function a(t) {
                        try {
                            c(r.throw(t))
                        } catch (e) {
                            s(e)
                        }
                    }

                    function c(t) {
                        var e;
                        t.done ? o(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                            t(e)
                        }))).then(i, a)
                    }
                    c((r = r.apply(t, e || [])).next())
                }))
            };

            function mt(t) {
                return gt(this, void 0, void 0, (function*() {
                    return new Promise((e => {
                        const n = [];
                        let r = t.length,
                            o = 0,
                            s = new Map,
                            i = !1;
                        const a = () => {
                            i = !0, e(n.slice())
                        };
                        t.map(((t, e) => gt(this, void 0, void 0, (function*() {
                            let c, u;
                            try {
                                c = yield t()
                            } catch (l) {
                                u = l
                            }
                            i || (n[e] = {
                                error: u,
                                result: c
                            }, o += 1, s.set(e, !0), (o === r || o === e + 1 && (t => {
                                for (let e = 0; e < t; e++)
                                    if (!s.has(e)) return !1;
                                return !0
                            })(e) && u) && a())
                        }))))
                    }))
                }))
            }

            function vt(t, e = 302) {
                throw function(t, e = 302) {
                    return new pt("", "redirect", {
                        status: e,
                        headers: {
                            Location: t
                        }
                    })
                }(t, e)
            }

            function _t(t, e = 500, {
                fatal: n = !1
            } = {}) {
                throw at()(e >= 400 && e < 600, "status code should be 4xx and 5xx"), new pt({
                    error: !0,
                    fatal: n
                }, "raw", {
                    status: e,
                    statusText: t
                })
            }

            function bt({
                pathname: t,
                query: e,
                params: n,
                req: r,
                getAppContext: o
            }) {
                return Object.assign({
                    pathname: t,
                    params: n,
                    query: e,
                    redirect: vt,
                    error: _t,
                    appContext: o()
                }, r ? {
                    req: r
                } : {})
            }

            function wt(t, e, n) {
                return gt(this, void 0, void 0, (function*() {
                    const r = {};
                    if (!t.length) return r;
                    const o = yield mt(t.map((t => () => gt(this, void 0, void 0, (function*() {
                        const r = e[t.route.id];
                        if ("function" !== typeof r) return;
                        let o, s;
                        try {
                            const e = yield r(n);
                            void 0 === e ? s = new Error(`You defined a loader for route "${t.route.path}" but didn't return anything from your \`loader\` function. Please return a value or \`null\`.`) : o = new pt(e, "json")
                        } catch (i) {
                            0,
                            s = i
                        }
                        if (s) throw s;
                        return o
                    })))));
                    for (let e = 0; e < o.length; e++) {
                        const n = o[e];
                        if (n.error) throw n.error;
                        const s = t[e].route.id;
                        at()(n.result, `loader function of route "${t[e].route.path}" should return a value`), r[s] = n.result.data
                    }
                    return r
                }))
            }
            var xt = n("Avjw"),
                St = n("X4qN"),
                Et = n("UCWY"),
                Ot = n("JtFa"),
                jt = function(t, e, n, r) {
                    return new(n || (n = Promise))((function(o, s) {
                        function i(t) {
                            try {
                                c(r.next(t))
                            } catch (e) {
                                s(e)
                            }
                        }

                        function a(t) {
                            try {
                                c(r.throw(t))
                            } catch (e) {
                                s(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                                t(e)
                            }))).then(i, a)
                        }
                        c((r = r.apply(t, e || [])).next())
                    }))
                };
            class kt {
                constructor(t) {
                    this._config = t.config, this._router = t.router, this._request = t.request, this._context = {}, this._store = (0, d.Sz)({
                        initialState: t.initialState
                    }), this._error = this._store.getModel(y, g), this._loader = this._store.getModel(Ot.K, Ot.l), this._getLoaders = t.getLoaders, this._appComponent = t.AppComponent, this._pluginManager = (0, Et.EI)(), (0, Et.H7)(this._pluginManager, t.plugins || [])
                }
                get router() {
                    return this._router
                }
                get config() {
                    return this._config
                }
                get context() {
                    return this._context
                }
                get pluginManager() {
                    return this._pluginManager
                }
                get appComponent() {
                    return this._appComponent
                }
                get error() {
                    return this._error.errorObject
                }
                setError(t) {
                    this._error.set(t)
                }
                clearError() {
                    this._error.clear()
                }
                getLoaders() {
                    return this._getLoaders()
                }
                getLoadersData() {
                    return this._loader.getAllData
                }
                setLoadersData(t) {
                    this._loader.setDatas(t)
                }
                init() {
                    return jt(this, void 0, void 0, (function*() {
                        yield this._initPlugin(), yield this._initAppContext(), this._router.init(), yield this._initAppComponent()
                    }))
                }
                get store() {
                    return this._store
                }
                updateComponents() {
                    return jt(this, arguments, void 0, (function*({
                        AppComponent: t
                    } = {}) {
                        t && t !== this._appComponent && (this._appComponent = t), yield this._initAppComponent()
                    }))
                }
                dispose() {
                    return jt(this, void 0, void 0, (function*() {
                        yield this._pluginManager.runner.dispose()
                    }))
                }
                _initPlugin() {
                    return jt(this, void 0, void 0, (function*() {
                        yield this._pluginManager.runner.init()
                    }))
                }
                _initAppContext() {
                    return jt(this, void 0, void 0, (function*() {
                        yield this._pluginManager.runner.appContext(this._context, {
                            router: this._router,
                            req: this._request
                        })
                    }))
                }
                _initAppComponent() {
                    return jt(this, void 0, void 0, (function*() {
                        this._appComponent = yield this._pluginManager.runner.appComponent(this._appComponent, this._context)
                    }))
                }
                getPublicAPI() {
                    const t = this;
                    return {
                        get config() {
                            return t._config
                        },
                        get context() {
                            return t._context
                        },
                        get router() {
                            return t._router
                        },
                        get appComponent() {
                            return t._appComponent
                        },
                        get store() {
                            return t._store
                        },
                        get error() {
                            return t.error
                        },
                        setError(e) {
                            t.setError(e)
                        },
                        clearError() {
                            t.clearError()
                        },
                        getLoadersData: () => t.getLoadersData(),
                        setLoadersData(e) {
                            t.setLoadersData(e)
                        }
                    }
                }
            }
            var At = function(t, e, n, o) {
                return new(n || (n = Promise))((function(s, i) {
                    var a = function(t) {
                            try {
                                u(o.next(t))
                            } catch (e) {
                                i(e)
                            }
                        },
                        c = function(t) {
                            try {
                                u(o.throw(t))
                            } catch (e) {
                                i(e)
                            }
                        },
                        u = function(t) {
                            var e;
                            t.done ? s(t.value) : (e = t.value, (0, r.A)(e, n) ? e : new n((function(t) {
                                t(e)
                            }))).then(a, c)
                        };
                    u((o = o.apply(t, e || [])).next())
                }))
            };

            function Ct(t, e) {
                for (var n = [], r = Object.keys(e), o = 0; o < r.length; o++) {
                    var s = e[r[o]];
                    n.push([s.plugin, s.options])
                }
                for (var i = {}, a = ["appComponent", "appContext", "init", "dispose"], c = 0; c < a.length; c++) {
                    var u = a[c];
                    "function" === typeof t[u] && (i[u] = t[u])
                }
                return n.push([(0, Et.yO)(i, {
                    name: "shuvi-user-app"
                })]), n
            }
            var Pt = n("wcIl"),
                It = n("accZ"),
                Tt = /^http(s?)\:\/\//;
            const Rt = function(t) {
                return Tt.test(t)
            };
            var Lt, Nt = function(t, e, n, o) {
                    return new(n || (n = Promise))((function(s, i) {
                        var a = function(t) {
                                try {
                                    u(o.next(t))
                                } catch (e) {
                                    i(e)
                                }
                            },
                            c = function(t) {
                                try {
                                    u(o.throw(t))
                                } catch (e) {
                                    i(e)
                                }
                            },
                            u = function(t) {
                                var e;
                                t.done ? s(t.value) : (e = t.value, (0, r.A)(e, n) ? e : new n((function(t) {
                                    t(e)
                                }))).then(a, c)
                            };
                        u((o = o.apply(t, e || [])).next())
                    }))
                },
                Dt = p.vO.events.SHUVI_CLIENT_RUN_LOADERS,
                Mt = function(t) {
                    var e = t.routes,
                        r = t.appData,
                        o = t.appComponent;
                    if (Lt) return Lt;
                    var a, c = r.appState,
                        u = r.ssr,
                        l = r.basename;
                    a = "hash" === It.a ? (0, Pt.TM)({
                        basename: l
                    }) : (0, Pt.zR)({
                        basename: l
                    });
                    var h = (0, Pt.aE)({
                            history: a,
                            routes: et(e)
                        }),
                        f = (Lt = function(t) {
                            var e = this;
                            return new kt(Object.assign(Object.assign({}, t), {
                                getLoaders: function() {
                                    return At(e, void 0, void 0, s().mark((function t() {
                                        var e;
                                        return s().wrap((function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    return t.next = 2, Promise.all([n.e(8230), n.e(9625)]).then(n.bind(n, "HXfC"));
                                                case 2:
                                                    return e = t.sent, t.abrupt("return", e.default || e);
                                                case 4:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }), t)
                                    })))
                                },
                                plugins: Ct(xt, St.P)
                            }))
                        }({
                            initialState: c,
                            AppComponent: o,
                            router: h,
                            config: {
                                ssr: u
                            }
                        })).getLoadersData(),
                        p = Object.keys(f).length > 0,
                        d = !!u;
                    return h.beforeResolve((function(t, e, n) {
                        return Nt(void 0, void 0, void 0, s().mark((function r() {
                            var o, a, c, u, l, h;
                            return s().wrap((function(r) {
                                for (;;) switch (r.prev = r.next) {
                                    case 0:
                                        if (!d) {
                                            r.next = 4;
                                            break
                                        }
                                        return d = !1, p && Lt.setLoadersData(f), r.abrupt("return", n());
                                    case 4:
                                        if (t.matches.length) {
                                            r.next = 8;
                                            break
                                        }
                                        return Lt.setError(i.nt.PAGE_NOT_FOUND), n(), r.abrupt("return");
                                    case 8:
                                        return o = C.t.traceChild(Dt.name), r.next = 11, Lt.getLoaders();
                                    case 11:
                                        return a = r.sent, c = st(t, e, a), u = bt({
                                            pathname: t.pathname,
                                            query: t.query,
                                            params: t.params,
                                            getAppContext: function() {
                                                return Lt.context
                                            }
                                        }), r.prev = 14, r.next = 17, new Promise((function(e, n) {
                                            var r, o, s = 0,
                                                i = function() {
                                                    2 === ++s && (o ? n(o) : e(r))
                                                };
                                            ot(t).then(i).catch((function(t) {
                                                n(t)
                                            })), wt(c, a, u).then((function(t) {
                                                r = t, i()
                                            })).catch((function(t) {
                                                o = t, i()
                                            }))
                                        }));
                                    case 17:
                                        l = r.sent, Lt.setLoadersData(l), o.setAttribute(Dt.attrs.error.name, !1), o.stop(), r.next = 43;
                                        break;
                                    case 23:
                                        if (r.prev = 23, r.t0 = r.catch(14), o.setAttribute(Dt.attrs.error.name, !0), !yt(r.t0)) {
                                            r.next = 32;
                                            break
                                        }
                                        return h = r.t0.headers.get("Location"), Rt(h) ? window.location.replace(h) : n(h), o.setAttribute(Dt.attrs.errorType.name, "redirect"), o.stop(), r.abrupt("return");
                                    case 32:
                                        if (!((s = r.t0) && "string" === typeof s.__shuvi_resp_type__ && r.t0.status >= 400 && r.t0.status < 600)) {
                                            r.next = 38;
                                            break
                                        }
                                        return Lt.setError({
                                            message: r.t0.statusText,
                                            fatal: r.t0.data.fatal
                                        }), n(), o.setAttribute(Dt.attrs.errorType.name, "userError"), o.stop(), r.abrupt("return");
                                    case 38:
                                        return o.setAttribute(Dt.attrs.errorType.name, "unexpectedError"), o.stop(), Lt.setError({
                                            message: i.nt.CLIENT_ERROR.message,
                                            error: r.t0
                                        }), n((function() {
                                            throw r.t0
                                        })), r.abrupt("return");
                                    case 43:
                                        n((function() {
                                            Lt.clearError()
                                        }));
                                    case 44:
                                    case "end":
                                        return r.stop()
                                }
                                var s
                            }), r, null, [
                                [14, 23]
                            ])
                        })))
                    })), Lt
                },
                Ht = function(t, e, n, o) {
                    return new(n || (n = Promise))((function(s, i) {
                        var a = function(t) {
                                try {
                                    u(o.next(t))
                                } catch (e) {
                                    i(e)
                                }
                            },
                            c = function(t) {
                                try {
                                    u(o.throw(t))
                                } catch (e) {
                                    i(e)
                                }
                            },
                            u = function(t) {
                                var e;
                                t.done ? s(t.value) : (e = t.value, (0, r.A)(e, n) ? e : new n((function(t) {
                                    t(e)
                                }))).then(a, c)
                            };
                        u((o = o.apply(t, e || [])).next())
                    }))
                },
                Ut = (0, Z.Y)(),
                $t = C.x.traceChild(p.ft.events.SHUVI_CLIENT_CREATE_APP.name).traceFn((function() {
                    return Mt({
                        appComponent: h,
                        routes: X.A,
                        appData: Ut
                    })
                }));
            window.__SHUVI ? window.__SHUVI.router = $t.router : window.__SHUVI = {
                router: $t.router
            }, Ht(void 0, void 0, void 0, s().mark((function t() {
                var e;
                return s().wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e = C.x.traceChild(p.ft.events.SHUVI_CLIENT_RUN_APP.name), t.next = 3, C.x.traceChild(p.ft.events.SHUVI_CLIENT_APP_INIT.name).traceAsyncFn((function() {
                                return $t.init()
                            }));
                        case 3:
                            return t.next = 5, Ht(void 0, void 0, void 0, s().mark((function t() {
                                var e;
                                return s().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return e = document.getElementById(i.Kj), t.next = 3, J.renderApp({
                                                app: $t.getPublicAPI(),
                                                appData: Ut,
                                                appContainer: e
                                            });
                                        case 3:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })));
                        case 5:
                            e.stop();
                        case 6:
                        case "end":
                            return t.stop()
                    }
                }), t)
            })))
        },
        aUDg: (t, e, n) => {
            "use strict";
            n.d(e, {
                t: () => i,
                x: () => s
            });
            var r = n("qK3R"),
                o = n("kvBi"),
                s = (0, r.trace)(o.ft.name),
                i = (0, r.trace)(o.vO.name)
        },
        EGIz: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => a
            });
            var r, o = n("VyXn"),
                s = n("UCWY"),
                i = n("NVnN");
            const a = (0, s.yO)({
                appContext: function(t) {
                    var e = {};
                    e = (0, i.K)("shuviInitialState", {}), t.store = function(t) {
                        var e = t.initialState,
                            n = (t.ctx, function() {
                                return (0, o.Sz)({
                                    initialState: e,
                                    plugins: []
                                })
                            });
                        return r || (r = n()), r
                    }({
                        ctx: t,
                        initialState: e
                    })
                }
            }, {
                name: "model"
            })
        },
        OFK0: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => o
            });
            n("TrCV"), n("DTvD");
            var r = n("nFfn");

            function o(t, e) {
                var n = r.A,
                    o = {
                        loading: function(t) {
                            t.error, t.isLoading;
                            return t.pastDelay, null
                        }
                    };
                if ("function" === typeof t ? o.loader = t : "object" === typeof t && (o = Object.assign(Object.assign({}, o), t)), "boolean" === typeof(o = Object.assign(Object.assign({}, o), e)).ssr) {
                    if (!o.ssr) return delete o.ssr,
                        function(t, e) {
                            return delete e.webpack, delete e.modules, t(e)
                        }(n, o);
                    delete o.ssr
                }
                return n(o)
            }
        },
        gmsc: (t, e, n) => {
            "use strict";
            n.d(e, {
                T: () => o
            });
            var r = n("DTvD"),
                o = r.createContext(null)
        },
        uHCZ: (t, e, n) => {
            "use strict";
            n.d(e, {
                a: () => f,
                A: () => b
            });
            var r = n("ezuS"),
                o = n("TrCV"),
                s = n("DTvD"),
                i = (n("uqCI"), n("888e")),
                a = n("nG1z"),
                c = n("2PCm"),
                u = n("tEf9"),
                l = n("VKAp");
            var h = n("gmsc"),
                f = "data-shuvi-head",
                p = {
                    acceptCharset: "accept-charset",
                    className: "class",
                    htmlFor: "for",
                    httpEquiv: "http-equiv"
                };

            function d(t, e) {
                return "string" === typeof e || "number" === typeof e ? t : e.type === s.Fragment ? t.concat(s.Children.toArray(e.props.children).reduce((function(t, e) {
                    return "string" === typeof e || "number" === typeof e ? t : t.concat(e)
                }), [])) : t.concat(e)
            }
            var y = ["name", "httpEquiv", "charSet", "itemProp"];

            function g(t) {
                return "string" === typeof t.type
            }

            function m(t) {
                return t.reduce((function(t, e) {
                    var n = s.Children.toArray(e.props.children);
                    return t.concat(n)
                }), []).reduce(d, []).filter(g).reverse().filter(function() {
                    var t = new Set,
                        e = new Set,
                        n = new Set,
                        r = {};
                    return function(o) {
                        var s = !0;
                        if (o.key && "number" !== typeof o.key && o.key.indexOf("$") > 0) {
                            var i = o.key.slice(o.key.indexOf("$") + 1);
                            t.has(i) ? s = !1 : t.add(i)
                        }
                        switch (o.type) {
                            case "title":
                            case "base":
                                e.has(o.type) ? s = !1 : e.add(o.type);
                                break;
                            case "meta":
                                for (var a = 0, c = y.length; a < c; a++) {
                                    var u = y[a];
                                    if (o.props.hasOwnProperty(u))
                                        if ("charSet" === u) n.has(u) ? s = !1 : n.add(u);
                                        else {
                                            var l = o.props[u],
                                                h = r[u] || new Set;
                                            h.has(l) ? s = !1 : (h.add(l), r[u] = h)
                                        }
                                }
                        }
                        return s
                    }
                }()).reverse().map((function(t) {
                    var e = t.type,
                        n = t.props;
                    return function(t) {
                        var e = t.type,
                            n = t.props,
                            r = {
                                tagName: e,
                                attrs: {}
                            };
                        for (var o in n)
                            if (n.hasOwnProperty(o) && "children" !== o && "dangerouslySetInnerHTML" !== o && void 0 !== n[o]) {
                                var s = p[o] || o.toLowerCase();
                                r.attrs[s] = n[o]
                            }
                        var i = n.children,
                            a = n.dangerouslySetInnerHTML;
                        return a ? r.innerHTML = a.__html || "" : i && (r.attrs.textContent = "string" === typeof i ? i : i.join("")), r
                    }({
                        type: e,
                        props: Object.assign(Object.assign({}, n), (0, r.A)({}, f, "true"))
                    })
                }))
            }
            var v = function() {
                var t, e = function(e) {
                        t = e.props.reduceComponentsToState((0, u.A)(n), e.props), e.props.handleStateChange && e.props.handleStateChange(t)
                    },
                    n = new Set;
                return function(r) {
                    (0, c.A)(s, r);
                    var o = (0, l.A)(s);

                    function s(t) {
                        return (0, i.A)(this, s), o.call(this, t)
                    }
                    return (0, a.A)(s, [{
                        key: "componentDidMount",
                        value: function() {
                            n.add(this), e(this)
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            e(this)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            n.delete(this), e(this)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return null
                        }
                    }], [{
                        key: "rewind",
                        value: function() {
                            var e = t;
                            return t = void 0, n.clear(), e
                        }
                    }]), s
                }(s.Component)
            }();

            function _(t) {
                var e = t.children;
                return (0, o.jsx)(h.T.Consumer, {
                    children: function(t) {
                        return (0, o.jsx)(v, {
                            reduceComponentsToState: m,
                            handleStateChange: t,
                            children: e
                        })
                    }
                })
            }
            _.rewind = v.rewind;
            const b = _
        },
        nFfn: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => y
            });
            var r = n("888e"),
                o = n("nG1z"),
                s = n("DTvD"),
                i = n("8ptQ"),
                a = s.createContext(null),
                c = [],
                u = [],
                l = !1;

            function h(t) {
                var e = t(),
                    n = {
                        loading: !0,
                        loaded: null,
                        error: null
                    };
                return n.promise = e.then((function(t) {
                    return n.loading = !1, n.loaded = t, t
                })).catch((function(t) {
                    throw n.loading = !1, n.error = t, t
                })), n
            }
            var f = function() {
                function t(e, n) {
                    (0, r.A)(this, t), this._loadFn = e, this._opts = n, this._callbacks = new Set, this._delay = null, this._timeout = null, this.retry()
                }
                return (0, o.A)(t, [{
                    key: "promise",
                    value: function() {
                        return this._res.promise
                    }
                }, {
                    key: "retry",
                    value: function() {
                        var t = this;
                        this._clearTimeouts(), this._res = this._loadFn(this._opts.loader), this._state = {
                            pastDelay: !1,
                            timedOut: !1
                        };
                        var e = this._res,
                            n = this._opts;
                        e.loading && ("number" === typeof n.delay && (0 === n.delay ? this._state.pastDelay = !0 : this._delay = setTimeout((function() {
                            t._update({
                                pastDelay: !0
                            })
                        }), n.delay)), "number" === typeof n.timeout && (this._timeout = setTimeout((function() {
                            t._update({
                                timedOut: !0
                            })
                        }), n.timeout))), this._res.promise.then((function() {
                            t._update({}), t._clearTimeouts()
                        })).catch((function(e) {
                            t._update({}), t._clearTimeouts()
                        })), this._update({})
                    }
                }, {
                    key: "_update",
                    value: function(t) {
                        this._state = Object.assign(Object.assign(Object.assign({}, this._state), {
                            error: this._res.error,
                            loaded: this._res.loaded,
                            loading: this._res.loading
                        }), t), this._callbacks.forEach((function(t) {
                            return t()
                        }))
                    }
                }, {
                    key: "_clearTimeouts",
                    value: function() {
                        clearTimeout(this._delay), clearTimeout(this._timeout)
                    }
                }, {
                    key: "getCurrentValue",
                    value: function() {
                        return this._state
                    }
                }, {
                    key: "subscribe",
                    value: function(t) {
                        var e = this;
                        return this._callbacks.add(t),
                            function() {
                                e._callbacks.delete(t)
                            }
                    }
                }]), t
            }();

            function p(t) {
                return function(t, e) {
                    var n = function() {
                            if (!o) {
                                var e = new f(t, r);
                                o = {
                                    getCurrentValue: e.getCurrentValue.bind(e),
                                    subscribe: e.subscribe.bind(e),
                                    retry: e.retry.bind(e),
                                    promise: e.promise.bind(e)
                                }
                            }
                            return o.promise()
                        },
                        r = Object.assign({
                            loader: null,
                            loading: null,
                            delay: 200,
                            timeout: null,
                            webpack: null,
                            modules: null
                        }, e),
                        o = null;
                    if (!l && "function" === typeof r.webpack) {
                        var c = r.webpack();
                        u.push((function(t) {
                            var e = !0,
                                r = !1,
                                o = void 0;
                            try {
                                for (var s, i = c[Symbol.iterator](); !(e = (s = i.next()).done); e = !0) {
                                    var a = s.value;
                                    if (-1 !== t.indexOf(a)) return n()
                                }
                            } catch (u) {
                                r = !0, o = u
                            } finally {
                                try {
                                    e || null == i.return || i.return()
                                } finally {
                                    if (r) throw o
                                }
                            }
                        }))
                    }
                    var h = s.forwardRef((function(t, e) {
                        n();
                        var c = s.useContext(a),
                            u = (0, i.useSyncExternalStore)(o.subscribe, o.getCurrentValue, o.getCurrentValue);
                        return s.useImperativeHandle(e, (function() {
                            return {
                                retry: o.retry
                            }
                        }), []), c && Array.isArray(r.modules) && r.modules.forEach((function(t) {
                            c(t)
                        })), s.useMemo((function() {
                            return u.loading || u.error ? s.createElement(r.loading, {
                                isLoading: u.loading,
                                pastDelay: u.pastDelay,
                                timedOut: u.timedOut,
                                error: u.error,
                                retry: o.retry
                            }) : u.loaded ? s.createElement((e = u.loaded) && e.__esModule ? e.default : e, t) : null;
                            var e
                        }), [t, u])
                    }));
                    return h.preload = function() {
                        return n()
                    }, h.displayName = "LoadableComponent", h
                }(h, t)
            }

            function d(t, e) {
                for (var n = []; t.length;) {
                    var r = t.pop();
                    n.push(r(e))
                }
                return Promise.all(n).then((function() {
                    if (t.length) return d(t, e)
                }))
            }
            p.preloadAll = function() {
                return new Promise((function(t, e) {
                    d(c).then(t, e)
                }))
            }, p.preloadReady = function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                return new Promise((function(e) {
                    var n = function() {
                        return l = !0, e()
                    };
                    d(u, t).then(n, n)
                }))
            };
            const y = p
        },
        "2ae6": (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => h
            });
            var r = n("2URn"),
                o = n("0GOp"),
                s = n.n(o),
                i = n("UCWY"),
                a = n("TrCV"),
                c = (n("DTvD"), n("V0mm")),
                u = function(t, e) {
                    var n = function() {
                        return (0, a.jsx)(c.ab, {
                            store: e.store,
                            children: (0, a.jsx)(t, {})
                        })
                    };
                    return n.displayName = "DouraAppWrapper", n
                },
                l = function(t, e, n, o) {
                    return new(n || (n = Promise))((function(s, i) {
                        var a = function(t) {
                                try {
                                    u(o.next(t))
                                } catch (e) {
                                    i(e)
                                }
                            },
                            c = function(t) {
                                try {
                                    u(o.throw(t))
                                } catch (e) {
                                    i(e)
                                }
                            },
                            u = function(t) {
                                var e;
                                t.done ? s(t.value) : (e = t.value, (0, r.A)(e, n) ? e : new n((function(t) {
                                    t(e)
                                }))).then(a, c)
                            };
                        u((o = o.apply(t, e || [])).next())
                    }))
                };
            const h = (0, i.Uu)({
                appComponent: function(t, e) {
                    return l(void 0, void 0, void 0, s().mark((function n() {
                        return s().wrap((function(n) {
                            for (;;) switch (n.prev = n.next) {
                                case 0:
                                    return n.abrupt("return", u(t, {
                                        store: e.store
                                    }));
                                case 1:
                                case "end":
                                    return n.stop()
                            }
                        }), n)
                    })))
                }
            }, {
                name: "model-react"
            })
        },
        "77a2": (t, e, n) => {
            "use strict";
            n.d(e, {
                JB: () => i,
                Kq: () => o,
                MA: () => s
            });
            var r = (0, n("V0mm").g$)(),
                o = r.Provider,
                s = r.useSharedModel,
                i = r.useStaticModel
        },
        Srb9: (t, e, n) => {
            "use strict";
            n.d(e, {
                L: () => a
            });
            var r = n("BK9r"),
                o = n("JtFa"),
                s = n("77a2"),
                i = Object.prototype.hasOwnProperty,
                a = function() {
                    var t = (0, r.z7)(),
                        e = t.route.id,
                        n = (0, s.JB)(o.K, o.l);
                    if (!i.call(n.dataByRouteId, e)) throw Error('Loader data not found for route "'.concat(t.route.path, '". Please make sure the page component where `useLoaderData` is called has a `loader` export.'));
                    return n.dataByRouteId[e]
                }
        },
        "0GOp": t => {
            var e = function(t) {
                "use strict";
                var e, n = Object.prototype,
                    r = n.hasOwnProperty,
                    o = "function" === typeof Symbol ? Symbol : {},
                    s = o.iterator || "@@iterator",
                    i = o.asyncIterator || "@@asyncIterator",
                    a = o.toStringTag || "@@toStringTag";

                function c(t, e, n) {
                    return Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), t[e]
                }
                try {
                    c({}, "")
                } catch (I) {
                    c = function(t, e, n) {
                        return t[e] = n
                    }
                }

                function u(t, e, n, r) {
                    var o = e && e.prototype instanceof g ? e : g,
                        s = Object.create(o.prototype),
                        i = new A(r || []);
                    return s._invoke = function(t, e, n) {
                        var r = h;
                        return function(o, s) {
                            if (r === p) throw new Error("Generator is already running");
                            if (r === d) {
                                if ("throw" === o) throw s;
                                return P()
                            }
                            for (n.method = o, n.arg = s;;) {
                                var i = n.delegate;
                                if (i) {
                                    var a = O(i, n);
                                    if (a) {
                                        if (a === y) continue;
                                        return a
                                    }
                                }
                                if ("next" === n.method) n.sent = n._sent = n.arg;
                                else if ("throw" === n.method) {
                                    if (r === h) throw r = d, n.arg;
                                    n.dispatchException(n.arg)
                                } else "return" === n.method && n.abrupt("return", n.arg);
                                r = p;
                                var c = l(t, e, n);
                                if ("normal" === c.type) {
                                    if (r = n.done ? d : f, c.arg === y) continue;
                                    return {
                                        value: c.arg,
                                        done: n.done
                                    }
                                }
                                "throw" === c.type && (r = d, n.method = "throw", n.arg = c.arg)
                            }
                        }
                    }(t, n, i), s
                }

                function l(t, e, n) {
                    try {
                        return {
                            type: "normal",
                            arg: t.call(e, n)
                        }
                    } catch (I) {
                        return {
                            type: "throw",
                            arg: I
                        }
                    }
                }
                t.wrap = u;
                var h = "suspendedStart",
                    f = "suspendedYield",
                    p = "executing",
                    d = "completed",
                    y = {};

                function g() {}

                function m() {}

                function v() {}
                var _ = {};
                c(_, s, (function() {
                    return this
                }));
                var b = Object.getPrototypeOf,
                    w = b && b(b(C([])));
                w && w !== n && r.call(w, s) && (_ = w);
                var x = v.prototype = g.prototype = Object.create(_);

                function S(t) {
                    ["next", "throw", "return"].forEach((function(e) {
                        c(t, e, (function(t) {
                            return this._invoke(e, t)
                        }))
                    }))
                }

                function E(t, e) {
                    function n(o, s, i, a) {
                        var c = l(t[o], t, s);
                        if ("throw" !== c.type) {
                            var u = c.arg,
                                h = u.value;
                            return h && "object" === typeof h && r.call(h, "__await") ? e.resolve(h.__await).then((function(t) {
                                n("next", t, i, a)
                            }), (function(t) {
                                n("throw", t, i, a)
                            })) : e.resolve(h).then((function(t) {
                                u.value = t, i(u)
                            }), (function(t) {
                                return n("throw", t, i, a)
                            }))
                        }
                        a(c.arg)
                    }
                    var o;
                    this._invoke = function(t, r) {
                        function s() {
                            return new e((function(e, o) {
                                n(t, r, e, o)
                            }))
                        }
                        return o = o ? o.then(s, s) : s()
                    }
                }

                function O(t, n) {
                    var r = t.iterator[n.method];
                    if (r === e) {
                        if (n.delegate = null, "throw" === n.method) {
                            if (t.iterator.return && (n.method = "return", n.arg = e, O(t, n), "throw" === n.method)) return y;
                            n.method = "throw", n.arg = new TypeError("The iterator does not provide a 'throw' method")
                        }
                        return y
                    }
                    var o = l(r, t.iterator, n.arg);
                    if ("throw" === o.type) return n.method = "throw", n.arg = o.arg, n.delegate = null, y;
                    var s = o.arg;
                    return s ? s.done ? (n[t.resultName] = s.value, n.next = t.nextLoc, "return" !== n.method && (n.method = "next", n.arg = e), n.delegate = null, y) : s : (n.method = "throw", n.arg = new TypeError("iterator result is not an object"), n.delegate = null, y)
                }

                function j(t) {
                    var e = {
                        tryLoc: t[0]
                    };
                    1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
                }

                function k(t) {
                    var e = t.completion || {};
                    e.type = "normal", delete e.arg, t.completion = e
                }

                function A(t) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], t.forEach(j, this), this.reset(!0)
                }

                function C(t) {
                    if (t) {
                        var n = t[s];
                        if (n) return n.call(t);
                        if ("function" === typeof t.next) return t;
                        if (!isNaN(t.length)) {
                            var o = -1,
                                i = function n() {
                                    for (; ++o < t.length;)
                                        if (r.call(t, o)) return n.value = t[o], n.done = !1, n;
                                    return n.value = e, n.done = !0, n
                                };
                            return i.next = i
                        }
                    }
                    return {
                        next: P
                    }
                }

                function P() {
                    return {
                        value: e,
                        done: !0
                    }
                }
                return m.prototype = v, c(x, "constructor", v), c(v, "constructor", m), m.displayName = c(v, a, "GeneratorFunction"), t.isGeneratorFunction = function(t) {
                    var e = "function" === typeof t && t.constructor;
                    return !!e && (e === m || "GeneratorFunction" === (e.displayName || e.name))
                }, t.mark = function(t) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(t, v) : (t.__proto__ = v, c(t, a, "GeneratorFunction")), t.prototype = Object.create(x), t
                }, t.awrap = function(t) {
                    return {
                        __await: t
                    }
                }, S(E.prototype), c(E.prototype, i, (function() {
                    return this
                })), t.AsyncIterator = E, t.async = function(e, n, r, o, s) {
                    void 0 === s && (s = Promise);
                    var i = new E(u(e, n, r, o), s);
                    return t.isGeneratorFunction(n) ? i : i.next().then((function(t) {
                        return t.done ? t.value : i.next()
                    }))
                }, S(x), c(x, a, "Generator"), c(x, s, (function() {
                    return this
                })), c(x, "toString", (function() {
                    return "[object Generator]"
                })), t.keys = function(t) {
                    var e = [];
                    for (var n in t) e.push(n);
                    return e.reverse(),
                        function n() {
                            for (; e.length;) {
                                var r = e.pop();
                                if (r in t) return n.value = r, n.done = !1, n
                            }
                            return n.done = !0, n
                        }
                }, t.values = C, A.prototype = {
                    constructor: A,
                    reset: function(t) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(k), !t)
                            for (var n in this) "t" === n.charAt(0) && r.call(this, n) && !isNaN(+n.slice(1)) && (this[n] = e)
                    },
                    stop: function() {
                        this.done = !0;
                        var t = this.tryEntries[0].completion;
                        if ("throw" === t.type) throw t.arg;
                        return this.rval
                    },
                    dispatchException: function(t) {
                        if (this.done) throw t;
                        var n = this;

                        function o(r, o) {
                            return a.type = "throw", a.arg = t, n.next = r, o && (n.method = "next", n.arg = e), !!o
                        }
                        for (var s = this.tryEntries.length - 1; s >= 0; --s) {
                            var i = this.tryEntries[s],
                                a = i.completion;
                            if ("root" === i.tryLoc) return o("end");
                            if (i.tryLoc <= this.prev) {
                                var c = r.call(i, "catchLoc"),
                                    u = r.call(i, "finallyLoc");
                                if (c && u) {
                                    if (this.prev < i.catchLoc) return o(i.catchLoc, !0);
                                    if (this.prev < i.finallyLoc) return o(i.finallyLoc)
                                } else if (c) {
                                    if (this.prev < i.catchLoc) return o(i.catchLoc, !0)
                                } else {
                                    if (!u) throw new Error("try statement without catch or finally");
                                    if (this.prev < i.finallyLoc) return o(i.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(t, e) {
                        for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                            var o = this.tryEntries[n];
                            if (o.tryLoc <= this.prev && r.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                                var s = o;
                                break
                            }
                        }
                        s && ("break" === t || "continue" === t) && s.tryLoc <= e && e <= s.finallyLoc && (s = null);
                        var i = s ? s.completion : {};
                        return i.type = t, i.arg = e, s ? (this.method = "next", this.next = s.finallyLoc, y) : this.complete(i)
                    },
                    complete: function(t, e) {
                        if ("throw" === t.type) throw t.arg;
                        return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y
                    },
                    finish: function(t) {
                        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                            var n = this.tryEntries[e];
                            if (n.finallyLoc === t) return this.complete(n.completion, n.afterLoc), k(n), y
                        }
                    },
                    catch: function(t) {
                        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                            var n = this.tryEntries[e];
                            if (n.tryLoc === t) {
                                var r = n.completion;
                                if ("throw" === r.type) {
                                    var o = r.arg;
                                    k(n)
                                }
                                return o
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(t, n, r) {
                        return this.delegate = {
                            iterator: C(t),
                            resultName: n,
                            nextLoc: r
                        }, "next" === this.method && (this.arg = e), y
                    }
                }, t
            }(t.exports);
            try {
                regeneratorRuntime = e
            } catch (n) {
                "object" === typeof globalThis ? globalThis.regeneratorRuntime = e : Function("r", "regeneratorRuntime = r")(e)
            }
        },
        Z2pg: (t, e) => {
            "use strict";
            e.r = function() {
                let t = {
                    resolve: null,
                    reject: null,
                    status: "pending"
                };
                return t.promise = new Promise(((e, n) => {
                    t.resolve = n => {
                        e(n), t.status = "fulfilled"
                    }, t.reject = e => {
                        n(e), t.status = "rejected"
                    }
                })), t
            }
        },
        IJ96: function(t, e, n) {
            "use strict";
            var r = this && this.__importDefault || function(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            };
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            const o = r(n("h7FZ"));
            e.default = o.default
        },
        hSG1: (t, e) => {
            "use strict";
            e.A = function t(e, n) {
                function r(t) {
                    return Object.prototype.toString.call(t).slice(8, -1).toLowerCase()
                }
                let o = r(e);
                return o === r(n) && ("array" === o ? function() {
                    if (e.length !== n.length) return !1;
                    for (let r = 0; r < e.length; r++)
                        if (!t(e[r], n[r])) return !1;
                    return !0
                }() : "object" === o ? function() {
                    if (Object.keys(e).length !== Object.keys(n).length) return !1;
                    for (let r in e)
                        if (Object.prototype.hasOwnProperty.call(e, r) && !t(e[r], n[r])) return !1;
                    return !0
                }() : "function" === o ? e.toString() === n.toString() : e === n)
            }
        },
        v7Og: (t, e) => {
            "use strict";
            e.A = null
        },
        VyXn: (t, e, n) => {
            "use strict";
            n.d(e, {
                IG: () => k,
                NP: () => E,
                Sz: () => pe
            });
            const r = () => {},
                o = Object.create(null),
                s = [],
                i = Object.assign,
                a = Object.prototype.hasOwnProperty,
                c = (t, e) => a.call(t, e),
                u = Object.prototype.toString,
                l = t => u.call(t),
                h = Array.isArray,
                f = t => "[object Map]" === l(t),
                p = t => "[object Set]" === l(t),
                d = t => "symbol" === typeof t,
                y = t => null !== t && "object" === typeof t,
                g = t => "[object Object]" === l(t),
                m = t => "string" === typeof t && "NaN" !== t && "-" !== t[0] && "" + parseInt(t, 10) === t,
                v = (t, e) => Object.is(t, e),
                _ = (t, e, n) => {
                    Object.defineProperty(t, e, {
                        configurable: !0,
                        enumerable: !1,
                        value: n
                    })
                };
            const b = Array.prototype.slice;
            const w = Object.prototype.propertyIsEnumerable;

            function x(t) {
                return Array.isArray(t) ? b.call(t) : f(t) ? new Map(t) : p(t) ? new Set(t) : Object.getPrototypeOf(t) === Object.prototype ? function(t) {
                    const e = {},
                        n = S(t);
                    for (let r = 0; r < n.length; r++) {
                        const o = n[r],
                            s = t[o];
                        w.call(t, o) ? e[o] = s : Object.defineProperty(e, o, {
                            configurable: !0,
                            writable: !0,
                            enumerable: !1,
                            value: s
                        })
                    }
                    return e
                }(t) : function(t) {
                    const e = Object.getOwnPropertyDescriptors(t),
                        n = S(e);
                    for (let r = 0; r < n.length; r++) {
                        const o = n[r],
                            s = e[o];
                        !1 === s.writable && (s.writable = !0, s.configurable = !0), (s.get || s.set) && (e[o] = {
                            configurable: !0,
                            writable: !0,
                            enumerable: s.enumerable,
                            value: t[o]
                        })
                    }
                    return Object.create(Object.getPrototypeOf(t), e)
                }(t)
            }
            const S = "undefined" !== typeof Reflect && Reflect.ownKeys ? Reflect.ownKeys : "undefined" !== typeof Object.getOwnPropertySymbols ? t => Object.getOwnPropertyNames(t).concat(Object.getOwnPropertySymbols(t)) : Object.getOwnPropertyNames;
            const E = t => t;

            function O(t, ...e) {
                console.warn(`[Doura warn] ${t}`, ...e)
            }

            function j(t) {
                switch ((t => l(t).slice(8, -1))(t)) {
                    case "Object":
                        return 1;
                    case "Array":
                        return 2;
                    case "Set":
                        return 3;
                    case "Map":
                        return 4;
                    default:
                        return 0
                }
            }

            function k(t) {
                return _(t, "__r_skip", !0), t
            }

            function A(t) {
                return !!t && !!t.__r_state
            }

            function C(t) {
                const e = P(t);
                return e ? C(e.base) : t
            }

            function P(t) {
                return t && t.__r_state
            }

            function I(t) {
                return t.copy || t.base
            }

            function T(t) {
                t.modified || (t.modified = !0, t.parent && T(t.parent))
            }
            let R;
            class L {
                constructor(t = !1) {
                    this.active = !0, this.effects = [], this.cleanups = [], !t && R && (this.parent = R, this.index = (R.scopes || (R.scopes = [])).push(this) - 1)
                }
                run(t) {
                    if (this.active) {
                        const e = R;
                        try {
                            return R = this, t()
                        } finally {
                            R = e
                        }
                    } else 0
                }
                on() {
                    R = this
                }
                off() {
                    R = this.parent
                }
                stop(t) {
                    if (this.active) {
                        let e, n;
                        for (e = 0, n = this.effects.length; e < n; e++) this.effects[e].stop();
                        for (e = 0, n = this.cleanups.length; e < n; e++) this.cleanups[e]();
                        if (this.scopes)
                            for (e = 0, n = this.scopes.length; e < n; e++) this.scopes[e].stop(!0);
                        if (this.parent && !t) {
                            const t = this.parent.scopes.pop();
                            t && t !== this && (this.parent.scopes[this.index] = t, t.index = this.index)
                        }
                        this.active = !1
                    }
                }
            }
            const N = t => {
                    const e = new Set(t);
                    return e.w = 0, e.n = 0, e
                },
                D = t => (t.w & V) > 0,
                M = t => (t.n & V) > 0,
                H = new WeakMap,
                U = new WeakMap;
            let $ = 0,
                V = 1;
            let F;
            const G = Symbol(""),
                q = Symbol("");
            let B = 0;
            class K {
                constructor(t, e = null, n) {
                    this.fn = t, this.scheduler = e, this.id = B++, this.deps = [], this.active = !0, this.parent = void 0,
                        function(t, e = R) {
                            e && e.active && e.effects.push(t)
                        }(this, n)
                }
                run() {
                    if (!this.active) return this.fn();
                    let t = F;
                    const e = z;
                    for (; t;) {
                        if (t === this) return;
                        t = t.parent
                    }
                    try {
                        return this.parent = F, F = this, z = !0, V = 1 << ++$, $ <= 30 ? (({
                            deps: t
                        }) => {
                            if (t.length)
                                for (let e = 0; e < t.length; e++) t[e].w |= V
                        })(this) : Y(this), this.fn()
                    } finally {
                        $ <= 30 && (t => {
                            const {
                                deps: e
                            } = t;
                            if (e.length) {
                                let n = 0;
                                for (let r = 0; r < e.length; r++) {
                                    const o = e[r];
                                    D(o) && !M(o) ? o.delete(t) : e[n++] = o, o.w &= ~V, o.n &= ~V
                                }
                                e.length = n
                            }
                        })(this), V = 1 << --$, F = this.parent, z = e, this.parent = void 0, this.deferStop && this.stop()
                    }
                }
                stop() {
                    F === this ? this.deferStop = !0 : this.active && (Y(this), this.onStop && this.onStop(), this.active = !1)
                }
            }

            function Y(t) {
                const {
                    deps: e
                } = t;
                if (e.length) {
                    for (let n = 0; n < e.length; n++) e[n].delete(t);
                    e.length = 0
                }
            }
            let z = !0;
            const W = [];

            function J() {
                W.push(z), z = !1
            }

            function X() {
                const t = W.pop();
                z = void 0 === t || t
            }

            function Z(t, e, n) {
                if (z && F) {
                    let e = H.get(t);
                    e || H.set(t, e = new Map);
                    let r = e.get(n);
                    r || e.set(n, r = N()), tt(r)
                }
            }

            function Q(t) {
                if (z && F) {
                    const e = t.__r_state;
                    if (!e) return;
                    let n = U.get(e);
                    n || U.set(e, n = N()), tt(n)
                }
            }

            function tt(t) {
                let e = !1;
                $ <= 30 ? M(t) || (t.n |= V, e = !D(t)) : e = !t.has(F), e && (t.add(F), F.deps.push(t))
            }

            function et(t) {
                const e = U.get(t);
                if (e) {
                    const t = [...e];
                    for (const e of t) e.view && (e.view.mightChange = !0)
                }
            }

            function nt(t, e, n, r, o) {
                var s;
                const i = H.get(t),
                    a = t.base;
                let c = [];
                if (i)
                    if ("clear" === e) c = [...i.values()];
                    else if ("length" === n && h(a)) i.forEach(((t, e) => {
                    ("length" === e || e >= r) && c.push(t)
                }));
                else switch (void 0 !== n && c.push(i.get(n)), e) {
                    case "add":
                        h(a) ? m(n) && c.push(i.get("length")) : (c.push(i.get(G)), f(a) && c.push(i.get(q)));
                        break;
                    case "delete":
                        h(a) || (c.push(i.get(G)), f(a) && c.push(i.get(q)));
                        break;
                    case "set":
                        f(a) && c.push(i.get(G))
                }
                if (1 === c.length) c[0] && rt(c[0]);
                else {
                    const t = [];
                    for (const e of c) e && t.push(...e);
                    rt(N(t))
                }
                const u = null === (s = t.root) || void 0 === s ? void 0 : s.listeners;
                u && u.length && u.forEach((t => t()))
            }

            function rt(t) {
                const e = h(t) ? t : [...t];
                for (const n of e) n.view && ot(n);
                for (const n of e) n.view || ot(n)
            }

            function ot(t) {
                (t !== F || t.allowRecurse) && (t.scheduler ? t.scheduler() : t.run())
            }
            class st {
                constructor(t, {
                    disableCache: e = !1
                }) {
                    this.dep = void 0, this.mightChange = !1, this.dirty = !0, this.effect = new K(t, (() => {
                        this.dirty || (this.dirty = !0, function(t) {
                            (t = C(t)).dep && rt(t.dep)
                        }(this))
                    })), this.effect.view = this, this.effect.active = this._cacheable = !e
                }
                get value() {
                    const t = C(this);
                    return function(t) {
                        z && F && tt((t = C(t)).dep || (t.dep = N()))
                    }(t), !t.dirty && t._cacheable || (t.dirty = !1, t._value = t.effect.run()), t._value
                }
                set value(t) {
                    0
                }
            }
            const it = new Set(["__proto__"]),
                at = new Set(Object.getOwnPropertyNames(Symbol).filter((t => "arguments" !== t && "caller" !== t)).map((t => Symbol[t])).filter(d));

            function ct(t) {
                t.copy || (t.copy = x(t.base))
            }

            function ut(t, e) {
                const n = t.__r_state;
                return (n ? I(n) : t)[e]
            }
            const lt = pt(),
                ht = ft();

            function ft() {
                const t = {};
                return ["includes", "indexOf", "lastIndexOf"].forEach((e => {
                    t[e] = function(...t) {
                        const n = P(this),
                            r = I(n);
                        for (let e = 0, s = this.length; e < s; e++) Z(n, 0, e + "");
                        const o = r[e](...t);
                        return -1 === o || !1 === o ? r[e](...t.map(C)) : o
                    }
                })), ["push", "pop", "shift", "unshift", "splice"].forEach((e => {
                    t[e] = function(...t) {
                        J();
                        const n = I(P(this))[e].apply(this, t);
                        return X(), n
                    }
                })), t
            }

            function pt() {
                return function(t, e, n) {
                    const r = I(t);
                    if ("__r_isReactive" === e) return !0;
                    if ("__r_state" === e && n === At.get(t)) return t;
                    if (h(r) && c(ht, e)) return Reflect.get(ht, e, n);
                    let o = Reflect.get(r, e, n);
                    return (d(e) ? at.has(e) : it.has(e)) ? o : (Z(t, 0, e), c(r, e) ? (t.disposed || !y(o) || (A(o) || (ct(t), o = t.copy[e] = Pt(o, t)), Q(o)), o) : o)
                }
            }

            function dt() {
                return function(t, e, n, r) {
                    const o = I(t),
                        s = ut(o, e),
                        i = h(o) && m(e) ? Number(e) < o.length : c(o, e);
                    if (!t.modified) {
                        const r = null === s || void 0 === s ? void 0 : s.__r_state;
                        if (r && r.base === n) return t.copy[e] = n, !0;
                        if (v(n, s) && (void 0 !== n || c(t.base, e))) return !0;
                        ct(t), T(t)
                    }
                    return v(t.copy[e], n) && (void 0 !== n || e in t.copy) || (t.copy[e] = n, t === P(r) && (i ? v(n, s) || nt(t, "set", e, n) : nt(t, "add", e, n), function(t) {
                        let e = t;
                        for (; e;) et(e), e = e.parent
                    }(t))), !0
                }
            }
            const yt = {
                get: lt,
                set: dt(),
                deleteProperty: function(t, e) {
                    const n = c(I(t), e);
                    if ((void 0 !== ut(t.base, e) || e in t.base) && (ct(t), T(t)), t.copy) {
                        const r = delete t.copy[e];
                        return r && n && nt(t, "delete", e, void 0), r
                    }
                    return !0
                },
                has: function(t, e) {
                    const n = I(t),
                        r = Reflect.has(n, e);
                    return d(e) && at.has(e) || Z(t, 0, e), r
                },
                ownKeys: function(t) {
                    const e = I(t);
                    return Z(t, 0, h(e) ? "length" : G), Reflect.ownKeys(e)
                },
                setPrototypeOf: function(t, e) {
                    const n = Reflect.setPrototypeOf(t.base, e);
                    return n && t.copy && Reflect.setPrototypeOf(t.copy, e), n
                },
                getOwnPropertyDescriptor: function(t, e) {
                    const n = I(t),
                        r = Reflect.getOwnPropertyDescriptor(n, e);
                    return r ? {
                        writable: !0,
                        configurable: !h(n) || "length" !== e,
                        enumerable: r.enumerable,
                        value: n[e]
                    } : r
                }
            };

            function gt(t) {
                t.copy || (t.copy = new Set, t.base.forEach((e => {
                    if (y(e)) {
                        const n = Pt(e, t);
                        Q(n), e !== n && t.drafts.set(e, n), t.copy.add(n)
                    } else t.copy.add(e)
                })))
            }

            function mt(t) {
                1 === t.type ? function(t) {
                    t.copy || (t.copy = new Map(t.base))
                }(t) : gt(t)
            }

            function vt(t) {
                const e = this.__r_state,
                    n = I(e);
                if (Z(e, 0, t), !n.has(t)) return;
                let r = n.get(t);
                return y(r) ? (A(r) || (mt(e), r = Pt(r, e), e.copy.set(t, r)), Q(r), r) : r
            }

            function _t(t, e) {
                const n = this.__r_state,
                    r = I(n),
                    o = r.has(t),
                    s = r.get(t),
                    i = () => {
                        mt(n), T(n), n.copy.set(t, e)
                    };
                return o ? v(e, s) || (i(), nt(n, "set", t, e)) : (i(), nt(n, "add", t, e)), this
            }

            function bt(t) {
                const e = this.__r_state;
                return I(e).has(t) || (gt(e), T(e), e.copy.add(t), nt(e, "add", t, t)), this
            }

            function wt(t) {
                const e = this.__r_state;
                return Z(e, 0, t), e.copy ? !!e.copy.has(t) || 2 === e.type && (e.drafts.has(t) && e.drafts.has(e.drafts.get(t))) : e.base.has(t)
            }

            function xt(t) {
                const e = this.__r_state,
                    n = I(e),
                    r = n.has(t);
                "get" in n && n.get(t), mt(e), T(e);
                let o = e.copy.delete(t);
                return 2 !== e.type || o || (o = !!e.drafts.has(t) && e.drafts.delete(e.drafts.get(t))), r && nt(e, "delete", t, void 0), o
            }

            function St() {
                const t = this.__r_state,
                    e = I(t),
                    n = 0 !== e.size,
                    r = e.clear();
                return n && (mt(t), T(t), t.copy.clear(), nt(t, "clear", void 0, void 0)), r
            }

            function Et() {
                const t = {
                    get: vt,
                    get size() {
                        return Z(t = this.__r_state, 0, G), I(t).size;
                        var t
                    },
                    has: wt,
                    add: bt,
                    set: _t,
                    delete: xt,
                    clear: St,
                    keys() {
                        const t = this.__r_state;
                        return 1 === t.type ? function(t) {
                            return Z(t, 0, q), I(t).keys()
                        }(t) : function(t) {
                            return Z(t, 0, G), gt(t), t.copy.values()
                        }(t)
                    },
                    forEach(t, e) {
                        const n = this.__r_state;
                        1 === n.type ? function(t, e, n, r) {
                            Z(e, 0, G), I(e).forEach(((o, s) => n.call(r, e.proxy.get(s), s, t)))
                        }(this, n, t, e) : function(t, e, n, r) {
                            const o = e.proxy.values();
                            let s = o.next();
                            for (; !s.done;) n.call(r, s.value, s.value, t), s = o.next()
                        }(this, n, t, e)
                    }
                };
                return ["values", "entries", Symbol.iterator].forEach((e => {
                    t[e] = function(t) {
                        return function(...e) {
                            const n = this.__r_state,
                                r = 1 === n.type,
                                o = "entries" === t || t === Symbol.iterator && r;
                            if (r) {
                                const t = n.proxy.keys();
                                return {
                                    next() {
                                        const {
                                            value: e,
                                            done: r
                                        } = t.next(), s = n.proxy.get(e);
                                        return r ? {
                                            value: s,
                                            done: r
                                        } : {
                                            value: o ? [e, s] : s,
                                            done: r
                                        }
                                    },
                                    [Symbol.iterator]() {
                                        return this
                                    }
                                }
                            }
                            return Z(n, 0, G), gt(n), n.copy[t](...e)
                        }
                    }(e)
                })), [t]
            }
            const [Ot] = Et();

            function jt() {
                const t = Ot;
                return (e, n, r) => {
                    if ("__r_isReactive" === n) return !0;
                    if ("__r_state" === n) return e;
                    const o = I(e);
                    return Reflect.get(c(t, n) && n in o ? t : o, n, r)
                }
            }
            const kt = {
                get: jt()
            };
            const At = new WeakMap;
            let Ct = 0;

            function Pt(t, e) {
                const n = j(t);
                if (0 === n) return t;
                if (t.__r_skip || !Object.isExtensible(t)) return t;
                if (t.__r_state) return t;
                let r = {
                        type: 0,
                        id: Ct++,
                        root: null,
                        parent: e,
                        base: t,
                        proxy: null,
                        copy: null,
                        modified: !1,
                        disposed: !1,
                        listeners: [],
                        children: []
                    },
                    o = r,
                    s = yt;
                3 === n ? (r.type = 2, r.drafts = new Map, o = new Set, s = kt) : 4 === n ? (r.type = 1, o = new Map, s = kt) : 2 === n && (o = []), o !== r && Object.keys(r).forEach((t => {
                    Object.defineProperty(o, t, {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: r[t]
                    })
                }));
                const i = new Proxy(o, s);
                return o.proxy = i, e ? (o.root = e.root, e.children.push(o)) : o.root = o, At.set(o, i), o.proxy
            }

            function It(t, e) {
                const n = function(t, {
                    copies: e,
                    snapshots: n
                }) {
                    const r = t => {
                            switch (j(t)) {
                                case 1:
                                case 2:
                                    return l;
                                case 4:
                                case 3:
                                    return u;
                                default:
                                    throw new Error("Unpected Error. Please file an issue on https://github.com/dourajs/doura")
                            }
                        },
                        o = t => {
                            if (!y(t)) return t;
                            if (A(t)) {
                                let o = n.get(t);
                                if (!o) {
                                    const s = e.get(t.__r_state);
                                    n.set(t, o = new Proxy(s, r(s)))
                                }
                                return o
                            }
                            return t
                        },
                        s = t => function(...e) {
                            const n = this.__r_raw,
                                r = "entries" === t || t === Symbol.iterator && f(this),
                                s = n[t](...e);
                            return {
                                next() {
                                    const {
                                        value: t,
                                        done: e
                                    } = s.next();
                                    return e ? {
                                        value: o(t),
                                        done: e
                                    } : {
                                        value: r ? [t[0], o(t[1])] : o(t),
                                        done: e
                                    }
                                },
                                [Symbol.iterator]() {
                                    return this
                                }
                            }
                        },
                        i = t => function(...e) {
                            return this.__r_raw[t](...e)
                        },
                        a = {
                            get size() {
                                return this.__r_raw.size
                            },
                            get(t) {
                                const e = this.__r_raw;
                                if (e.has(t)) return o(e.get(t))
                            },
                            forEach(t, e) {
                                const n = this.__r_raw;
                                return n.forEach(((r, s) => (r = o(r), t.call(e, r, f(n) ? s : r, n))))
                            }
                        };
                    ["has", "add", "set", "delete", "clear"].forEach((t => {
                        a[t] = i(t)
                    })), ["keys", "values", "entries", Symbol.iterator].forEach((t => {
                        a[t] = s(t)
                    }));
                    const u = {
                            get: (t, e, n) => "__r_raw" === e ? t : Reflect.get(c(a, e) && e in t ? a : t, e, n)
                        },
                        l = {
                            get: (t, e, n) => o(Reflect.get(t, e, n))
                        };
                    return r(t)
                }(t, e);
                if (A(t)) {
                    const r = t.__r_state;
                    return new Proxy(e.copies.get(r), n)
                }
                return new Proxy(t, n)
            }

            function Tt(t, e, n) {
                if (!y(t)) return t;
                const r = function(t, e) {
                    const n = new Map,
                        r = {
                            copies: n,
                            snapshots: e || new Map
                        },
                        o = r.snapshots,
                        s = [t.__r_state];
                    for (; s.length;) {
                        const t = s.pop();
                        let e;
                        t.modified ? (e = x(t.copy), Rt(t, e), o.delete(t.proxy)) : e = It(t.base, r), n.set(t, e);
                        for (const n of t.children) s.push(n)
                    }
                    return r
                }(e, n);
                return It(t, r)
            }

            function Rt(t, e) {
                t.modified = !1, t.base = e
            }

            function Lt(t, e) {
                const n = t.createView((function() {
                        return e(this, this.$actions)
                    })),
                    r = n.getSnapshot;
                return r.destory = function() {
                    n.effect.stop();
                    const e = t.effectScope.effects.indexOf(n.effect);
                    e >= 0 && t.effectScope.effects.splice(e, 1)
                }, r
            }
            const Nt = i({
                    $name: t => t.name,
                    $rawState: t => t.getState(),
                    $state: t => t.stateValue,
                    $actions: t => t.actions,
                    $views: t => t.views,
                    $patch: t => t.patch,
                    $onAction: t => t.onAction,
                    $subscribe: t => t.subscribe,
                    $isolate: t => t.isolate,
                    $getApi: t => t.getApi,
                    $createView: t => Lt.bind(null, t)
                }),
                Dt = t => ({
                    _: e
                }, n) => {
                    const {
                        actions: r,
                        views: o,
                        accessCache: s,
                        ctx: i
                    } = e;
                    let a;
                    if (a = t ? e.getState() : e.stateValue, "$" !== n[0]) {
                        const t = s[n];
                        if (void 0 !== t) switch (t) {
                            case 0:
                                return a[n];
                            case 2:
                                return o[n];
                            case 1:
                                return r[n];
                            case 3:
                                return i[n]
                        } else {
                            if (c(a, n)) return s[n] = 0, a[n];
                            if (c(i, n)) return s[n] = 3, i[n]
                        }
                    }
                    const u = Nt[n];
                    return u ? u(e) : c(i, n) ? (s[n] = 3, i[n]) : void((t => "_" === t || "$" === t)(n[0]) && c(a, n) && O(`Property ${JSON.stringify(n)} must be accessed via $state because it starts with a reserved character ("$" or "_") and is not proxied on the render context.`))
                },
                Mt = ({
                    _: t
                }, e, n) => {
                    const {
                        ctx: r,
                        actions: o,
                        views: s,
                        accessContext: i,
                        stateRef: {
                            value: a
                        }
                    } = t;
                    return c(a, e) ? 1 !== i && (a[e] = n, !0) : !c(o, e) && (!c(s, e) && ("$state" === e ? "bigint" !== typeof n && "symbol" !== typeof n && (t.replace(n), !0) : ("$" !== e[0] || !c(Nt, e)) && (r[e] = n, !0)))
                },
                Ht = {
                    get: Dt(!1),
                    set: Mt
                },
                Ut = {
                    get: Dt(!0),
                    set: Mt
                };

            function $t(t, e, ...n) {
                console.error(t)
            }
            let Vt = !1,
                Ft = !1;
            const Gt = [];
            let qt = 0;
            const Bt = [];
            let Kt = null,
                Yt = 0;
            const zt = [];
            let Wt = null,
                Jt = 0;
            const Xt = Promise.resolve();
            let Zt = null,
                Qt = null;

            function te(t) {
                Gt.length && Gt.includes(t, Vt && t.allowRecurse ? qt + 1 : qt) || t === Qt || (null == t.id ? Gt.push(t) : Gt.splice(function(t) {
                    let e = qt + 1,
                        n = Gt.length;
                    for (; e < n;) {
                        const r = e + n >>> 1;
                        re(Gt[r]) < t ? e = r + 1 : n = r
                    }
                    return e
                }(t.id), 0, t), Vt || Ft || (Ft = !0, Zt = Xt.then(oe)))
            }

            function ee(t) {
                const e = Gt.indexOf(t);
                e >= qt && Gt.splice(e, 1)
            }

            function ne(t, e = null) {
                if (Bt.length) {
                    for (Qt = e, Kt = [...new Set(Bt)], Bt.length = 0, Yt = 0; Yt < Kt.length; Yt++) Kt[Yt]();
                    Kt = null, Yt = 0, Qt = null, ne(t, e)
                }
            }
            const re = t => null == t.id ? 1 / 0 : t.id;

            function oe(t) {
                Ft = !1, Vt = !0, ne(t), Gt.sort(((t, e) => re(t) - re(e)));
                try {
                    for (qt = 0; qt < Gt.length; qt++) {
                        const t = Gt[qt];
                        if (t && !1 !== t.active) {
                            0;
                            try {
                                t()
                            } catch (e) {
                                $t(e)
                            }
                        }
                    }
                } finally {
                    qt = 0, Gt.length = 0,
                        function(t) {
                            if (ne(), zt.length) {
                                const t = [...new Set(zt)];
                                if (zt.length = 0, Wt) return void Wt.push(...t);
                                for (Wt = t, Wt.sort(((t, e) => re(t) - re(e))), Jt = 0; Jt < Wt.length; Jt++) Wt[Jt]();
                                Wt = null, Jt = 0
                            }
                        }(), Vt = !1, Zt = null, (Gt.length || Bt.length || zt.length) && oe(t)
                }
            }
            var se;

            function ie(t, e) {
                const n = Object.keys(e);
                n.length && n.forEach((n => {
                    c(t, n) && g(e[n]) ? ie(t[n], e[n]) : t[n] = e[n]
                }))
            }

            function ae(t) {
                t.dirty = !0
            }! function(t) {
                t.REPLACE = "replace", t.MODIFY = "modify", t.PATCH = "patch"
            }(se || (se = {}));
            class ce {
                constructor(t, {
                    name: e,
                    initState: n
                }) {
                    var o;
                    this.viewInstances = [], this._actionDepth = 0, this._api = null, this._actionListeners = new Set, this._subscribers = new Set, this._depListenersHandlers = [], this._watchStateChange = !0, this._destroyed = !1, this._lastDraftToSnapshot = new Map, this.patch = this.patch.bind(this), this.onAction = this.onAction.bind(this), this.subscribe = this.subscribe.bind(this), this.isolate = this.isolate.bind(this), this.getApi = this.getApi.bind(this), this._update = this._update.bind(this), this.options = t, this.name = e || "", this._isDispatching = !1, this._initState = n || t.state, this.stateRef = Pt({
                        value: this._initState
                    }), this._update.__name = e, this._draftListenerHandler = function(t, e) {
                        const n = t.__r_state;
                        return n.disposed ? r : (n.listeners.push(e), () => {
                            const t = n.listeners.indexOf(e);
                            t >= 0 && n.listeners.splice(t, 1)
                        })
                    }(this.stateRef, (() => {
                        this._watchStateChange && te(this._update)
                    })), this._setState(this._initState), this.actions = Object.create(null), this.views = Object.create(null), this.accessContext = 0, this.ctx = {}, _(this.ctx, "_", this), this.accessCache = Object.create(null), this.proxy = new Proxy(this.ctx, Ht), this.publicInst = new Proxy(this.ctx, Ut), this.effectScope = new L(o), this._initActions(), this._initViews()
                }
                patch(t) {
                    g(t) && this._currentState && (this._watchStateChange = !1, ie(this.proxy.$state, t), this._watchStateChange = !0, this.dispatch({
                        type: se.PATCH,
                        args: {
                            patch: t
                        }
                    }))
                }
                replace(t) {
                    if (y(t)) {
                        this._watchStateChange = !1, this.stateRef.value = t, this._watchStateChange = !0;
                        for (const t of this.viewInstances) t.effect.scheduler();
                        this.dispatch({
                            type: se.REPLACE,
                            payload: t
                        })
                    } else O(`replace argument should be an object, but receive a ${Object.prototype.toString.call(t)}`)
                }
                getState() {
                    return this._currentState
                }
                getApi() {
                    if (null === this._api) {
                        const t = this._api = Object.assign(Object.assign({}, this._currentState), this.views);
                        for (const e of Object.keys(this.actions)) _(t, e, this.actions[e])
                    }
                    return this._api
                }
                onAction(t) {
                    return this._actionListeners.add(t), () => {
                        this._actionListeners.delete(t)
                    }
                }
                subscribe(t) {
                    return this._subscribers.add(t), () => {
                        this._subscribers.delete(t)
                    }
                }
                isolate(t) {
                    J();
                    const e = t(this.stateValue);
                    return X(), e
                }
                depend(t) {
                    this._depListenersHandlers.push(t.subscribe((t => {
                        this._triggerListener(Object.assign(Object.assign({}, t), {
                            model: this.proxy
                        }))
                    })))
                }
                createView(t) {
                    let e;
                    return this.effectScope.run((() => {
                        e = function(t, e = {}) {
                            return new st(t, e)
                        }((() => {
                            const n = this.accessContext;
                            this.accessContext = 1;
                            const r = e.__externalArgs;
                            try {
                                return t.call(this.proxy, this.proxy, ...r || s)
                            } finally {
                                this.accessContext = n
                            }
                        }))
                    })), e.getSnapshot = () => {
                        const t = e.value;
                        return e.mightChange ? (e.mightChange = !1, e.__snapshot = Tt(t, this.stateRef.value)) : e.__pre !== t && (e.__snapshot = Tt(t, this.stateRef.value)), e.__pre = t, e.__snapshot
                    }, this.viewInstances.push(e), e
                }
                reducer(t, e) {
                    switch (e.type) {
                        case se.MODIFY:
                        case se.PATCH:
                            {
                                const t = new Map(this._lastDraftToSnapshot);
                                return this._lastDraftToSnapshot = t,
                                Tt(this.stateRef.value, this.stateRef.value, this._lastDraftToSnapshot)
                            }
                        case se.REPLACE:
                            return e.payload;
                        default:
                            return t
                    }
                }
                dispatch(t) {
                    if ("undefined" === typeof t.type) return t;
                    if (this._isDispatching) return t;
                    let e;
                    try {
                        this._isDispatching = !0, e = this.reducer(this._currentState, t)
                    } finally {
                        this._isDispatching = !1
                    }
                    return e !== this._currentState && (this._setState(e), this._triggerListener(Object.assign({
                        type: t.type,
                        model: this.proxy,
                        target: this.proxy
                    }, t.args))), t
                }
                destroy() {
                    this._destroyed = !0, this._api = null, this._lastDraftToSnapshot.clear(), this._currentState = null, this.stateRef = {
                        value: null
                    }, this._subscribers.clear(), this.effectScope.stop();
                    for (const t of this._depListenersHandlers) t();
                    this._draftListenerHandler()
                }
                _setState(t) {
                    this._api = null, this._currentState = t, this.stateValue = this.stateRef.value
                }
                _update() {
                    !this._destroyed && function(t) {
                        return t.__r_state.modified
                    }(this.stateRef) && (this.dispatch({
                        type: se.MODIFY
                    }), function(t) {
                        const e = t.__r_state;
                        e && (e.modified = !1)
                    }(this.stateRef))
                }
                _triggerListener(t) {
                    for (const e of this._subscribers) e(t)
                }
                _initActions() {
                    const t = this.options.actions;
                    if (t)
                        for (const e of Object.keys(t)) {
                            this.accessCache[e] = 1;
                            const n = t[e];
                            Object.defineProperty(this.actions, e, {
                                configurable: !0,
                                enumerable: !0,
                                writable: !1,
                                value: (...t) => {
                                    if (1 === this.accessContext) return void 0;
                                    let r;
                                    this._actionDepth++;
                                    try {
                                        for (const n of this._actionListeners) n({
                                            name: e,
                                            args: t
                                        });
                                        r = n.call(this.proxy, ...t)
                                    } finally {
                                        0 === --this._actionDepth && (ee(this._update), this._update())
                                    }
                                    return r
                                }
                            })
                        }
                }
                _initViews() {
                    const t = this.options.views;
                    if (t)
                        for (const e of Object.keys(t)) {
                            this.accessCache[e] = 2;
                            const n = t[e],
                                r = n.length > 1,
                                o = this.createView(n),
                                s = o;
                            0;
                            const i = r ? () => (...t) => {
                                const e = s.__externalArgs;
                                if (e) {
                                    if (e.length !== t.length) ae(o);
                                    else
                                        for (let n = 0; n < e.length; n++)
                                            if (e[n] !== t[n]) {
                                                ae(o);
                                                break
                                            }
                                } else ae(o);
                                return s.__externalArgs = t, o.getSnapshot()
                            } : o.getSnapshot;
                            Object.defineProperty(this.views, e, {
                                configurable: !0,
                                enumerable: !0,
                                get: i,
                                set: () => !1
                            })
                        }
                }
            }

            function ue(t, e = {}) {
                return new ce(t, e)
            }
            let le = null;

            function he(t) {
                le = t
            }
            class fe {
                constructor(t = o, e = []) {
                    this._subscribers = new Set, this._initialState = t, this._models = (() => {
                        const t = new Map,
                            e = {
                                get: e => t.get(e),
                                set(e, n) {
                                    t.set(e, n)
                                },
                                each(e) {
                                    for (const [n, r] of t.entries()) e(r, n)
                                },
                                clear() {
                                    e.each((t => t.destroy())), t.clear()
                                }
                            };
                        return e
                    })();
                    const n = () => {
                        for (const t of this._subscribers) t()
                    };
                    this._onModelChange = () => {
                        te(n)
                    }, this._hooks = e.map((([t, e]) => t(e))), this._hooks.map((e => {
                        var n;
                        return null === (n = e.onInit) || void 0 === n ? void 0 : n.call(e, {
                            initialState: t
                        }, {
                            doura: this
                        })
                    }))
                }
                getModel(t, e) {
                    return this.getModelInstance({
                        name: t,
                        model: e
                    }).publicInst
                }
                getDetachedModel(t) {
                    return this.getModelInstance({
                        model: t
                    }).publicInst
                }
                getModelInstance({
                    name: t,
                    model: e
                }) {
                    const n = t && this._models.get(t);
                    if (n) return n;
                    let r;
                    if ("function" === typeof e) {
                        const n = le,
                            o = this._createModelProxy();
                        try {
                            he({
                                manager: this,
                                model: o
                            }), r = this._initModel({
                                name: t,
                                model: e()
                            })
                        } finally {
                            he(n)
                        }
                        o.setModel(r)
                    } else {
                        if ("object" !== typeof e) throw new Error("invalid model");
                        r = this._initModel({
                            name: t,
                            model: e
                        })
                    }
                    return r
                }
                getState() {
                    const t = {};
                    return this._models.each(((e, n) => {
                        t[n] = e.getState()
                    })), t
                }
                subscribe(t) {
                    return this._subscribers.add(t), () => {
                        this._subscribers.delete(t)
                    }
                }
                destroy() {
                    this._hooks.map((t => {
                        var e;
                        return null === (e = t.onDestroy) || void 0 === e ? void 0 : e.call(t)
                    })), this._models.clear(), this._subscribers.clear(), this._initialState = o
                }
                _createModelProxy() {
                    const t = [];
                    return {
                        addChild(e) {
                            t.push(e)
                        },
                        setModel(e) {
                            for (const n of t) e.depend(n);
                            t.length = 0
                        }
                    }
                }
                _initModel({
                    name: t,
                    model: e
                }) {
                    if (!t) return ue(e);
                    this._hooks.map((n => {
                        var r;
                        return null === (r = n.onModel) || void 0 === r ? void 0 : r.call(n, t, e, {
                            doura: this
                        })
                    }));
                    const n = ue(e, {
                        name: t,
                        initState: this._getInitialState(t)
                    });
                    return n.subscribe(this._onModelChange), this._models.set(t, n), this._hooks.map((t => {
                        var e;
                        null === (e = t.onModelInstance) || void 0 === e || e.call(t, n.publicInst, {
                            doura: this
                        })
                    })), n
                }
                _getInitialState(t) {
                    const e = this._initialState[t];
                    return e && delete this._initialState[t], e
                }
            }

            function pe({
                initialState: t,
                plugins: e = []
            } = {}) {
                return function({
                    initialState: t,
                    plugins: e
                } = {}) {
                    return new fe(t, e)
                }({
                    initialState: t,
                    plugins: e
                })
            }
        }
    }
]);
//# debugId=1921f424-6f85-5603-a26d-c69405e3398b